<template>
  <router-view v-slot="{ Component }">
    <!-- 由于使用了include, 所以要keepalive的页面一定要配置name属性 -->
    <keep-alive :include="cache">
      <component :is="Component" v-if="$route.meta.keepAlive" :key="$route.name" />
    </keep-alive>

    <component :is="Component" v-if="!$route.meta.keepAlive" :key="$route.name" />
  </router-view>
</template>

<script setup lang="ts">
import { useSettingStore, useKeepAliveStore } from "@/store";
import { initMenu } from "@/router";
import { useRoute } from "vue-router";
import { storeToRefs } from 'pinia';
import { hex2Rgb, hex2Rgba } from "./utils/hex2rgba";
import { isAllowVisitorToUseSchool } from "./utils/customizedType";
import { getToken } from "./utils";

const $route = useRoute();
const settingStore = useSettingStore();
const keepAliveStore = useKeepAliveStore()

const { cache } = storeToRefs(keepAliveStore);

onMounted(async () => {
  if (!isAllowVisitorToUseSchool() || getToken()){
    await initMenu();
  }
});

// 设置主题色
watch(
  () => settingStore.themeColor,
  (color: string) => {
    document.body.style.setProperty("fill", color);
    document.body.style.setProperty("--theme-color", color);
    document.body.style.setProperty("--theme-color-0-2", hex2Rgba(color, 0.2));
    document.body.style.setProperty("--theme-color-0-4", hex2Rgba(color, 0.4));
    document.body.style.setProperty("--theme-color-0-6", hex2Rgba(color, 0.6));
    document.body.style.setProperty("--theme-color-rgb", hex2Rgb(color));
    document.body.style.setProperty("--van-tabbar-item-active-color", color);
    document.body.style.setProperty(
      "--van-button-primary-background-color",
      color
    );
    document.body.style.setProperty("--van-button-primary-border-color", color);
    document.body.style.setProperty("--van-switch-on-background-color", color);
    document.body.style.setProperty("--van-tab-active-text-color", color);
    document.body.style.setProperty("--van-tabs-bottom-bar-color", color);
    document.body.style.setProperty("--van-checkbox-checked-icon-color", color);
  },
  {
    immediate: true
  }
);
</script>

<style>
#app {
  font-family: Inter, Avenir, Helvetica, Arial, sans-serif;
  font-synthesis: none;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-text-size-adjust: 100%;
}

body {
  overflow: scroll !important;
  /* max-height: 750px; */
  /* overflow-y: auto; */
  scrollbar-width: none;
  -ms-over-style:none;

  /* color: #000000; */
}
body::-webkit-scrollbar{
  display: none;
}

.gray-bg {
  background: #f5f5f5;
  min-height: 100%;
  position: relative;
  overflow-y: scroll;
}

.vant-toast {
  background: rgba(0, 0, 0, 0.7);
}

.stPart {
  position: relative;
  top: -25px;
  /* height: 25px; */
}</style>
