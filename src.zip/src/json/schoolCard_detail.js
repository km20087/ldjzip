export let schoolCard_detail = {
  "code": 200,
  "msg": "success",
  "data": {
    "pageNum": 1,
    "pageSize": 0,
    "pageFlag": null,
    "id": "e3639d8bb3ab4ba78d7e449c89793ff2",
    "username": "郭**",
    "collegeName": "地理科学学院 ",
    "schoolStartYear": null,
    "majorName": "地理",
    "userProfilePicture": "img/perLogo.png",
    "backgroundPicture": "img/gMS9Y2kMR0yAHZLHAAO8YaZPyIw424.png",
    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
    "createBy": "f452668ec19b42789d3bbee1141ee16e",
    "createDate": "2025-11-25 10:04:22",
    "updateBy": "f452668ec19b42789d3bbee1141ee16e",
    "updateDate": "2025-11-25 10:04:22",
    "auditStatus": '1',
    "rejectReason": null,
    "returnSchoolRegisterFlag": false,
    "schoolEndYear": null,
    "userNO": "2021201918173",
    "jobTitle": null,
    "schoolmateType": null,
    "jobDuration": null,
    "jobDepartment": null,
    "education": null,
    "collegeId": null
  }
}

export let schoolCard_save = {
  '{}': {
    "code": 200,
    "msg": "操作成功"
  }
}