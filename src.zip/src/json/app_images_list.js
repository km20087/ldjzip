export let app_images_list = {
    '{"imageType":"SCHOOL_MOTTO"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "imageType": "SCHOOL_MOTTO",
            "isJump": null,
            "imageTypeName": null,
            "width": "820",
            "height": "104",
            "interval": "0",
            "images": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "42BD7A56E5EDE7FDE06354EDC480939F",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "校训",
                    "imageType": "SCHOOL_MOTTO",
                    "fileAddress": "img/gMS9Y2kJc76ADvSnAABjECXLXE4211.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2025-11-04 11:32:23",
                    "editor": "a3f6f6b21db341518b389f036ef23c96",
                    "jumpUrl": null,
                    "typeName": null
                }
            ]
        }
    },
    '{"imageType":"BANNER"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "imageType": "BANNER",
            "isJump": null,
            "imageTypeName": null,
            "width": "325",
            "height": "150",
            "interval": "15",
            "images": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "3241B709DC7E0399E06357EDC480BAB6",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "首页顶部图片",
                    "imageType": "BANNER",
                    "fileAddress": "img/202610221111288726.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2025-04-08 17:11:58",
                    "editor": "e2e0ead85b634ea187574f87f46d0ee1",
                    "jumpUrl": null,
                    "typeName": null
                }
            ]
        }
    },
    '{"imageType":"HOME_HEADER_ICON"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "imageType": "HOME_HEADER_ICON",
            "isJump": null,
            "imageTypeName": null,
            "width": "314",
            "height": "70",
            "interval": "0",
            "images": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "3241B709DC7C0399E06357EDC480BAB6",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "首页顶部的学校名称",
                    "imageType": "HOME_HEADER_ICON",
                    "fileAddress": "img/gMS9Y2f06C2AMdZsAAL_pojiS-o063.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2025-04-08 17:11:13",
                    "editor": "e2e0ead85b634ea187574f87f46d0ee1",
                    "jumpUrl": null,
                    "typeName": null
                }
            ]
        }
    },
    '{"imageType":"HOME_BOTTOM_ICON"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "imageType": "HOME_BOTTOM_ICON",
            "isJump": null,
            "imageTypeName": null,
            "width": "250",
            "height": "250",
            "interval": "0",
            "images": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "3241B709DC7A0399E06357EDC480BAB6",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "首页底部图标",
                    "imageType": "HOME_BOTTOM_ICON",
                    "fileAddress": "img/gMS9Y2f0596ALc9NAABWBdYLy3A993.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2025-04-08 17:10:15",
                    "editor": "e2e0ead85b634ea187574f87f46d0ee1",
                    "jumpUrl": null,
                    "typeName": null
                }
            ]
        }
    },
    '{"imageType":"SCHOOLMATE_CARD"}': { "code": 200, "msg": "success", "data": { "imageType": "SCHOOLMATE_CARD", "isJump": null, "imageTypeName": null, "width": "330", "height": "330", "interval": "0", "images": [] } },
    '{"imageType":"ORGANIZATION_BANNER"}': { "code": 200, "msg": "success", "data": { "imageType": "ORGANIZATION_BANNER", "isJump": null, "imageTypeName": null, "width": "750", "height": "350", "interval": "0", "images": [{ "pageNum": 1, "pageSize": 0, "pageFlag": null, "id": "182B155BC94F8D12E06357EDC4803219", "schoolId": "FB628F1163EDC718E05354EDC480EF56", "imageName": "组织顶部", "imageType": "ORGANIZATION_BANNER", "fileAddress": "/img/gMS9Y2Y_O92ACrnNAAIIzLQ1SKs325.jpg", "sorting": "1", "status": "1", "updateTime": "2024-05-11 17:35:28", "editor": "d426912099ca4984a5db61f700bf4cce", "jumpUrl": null, "typeName": null }] } },
    '{"imageType":"ECARD_WRAP_BACKGROUND"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "imageType": "ECARD_WRAP_BACKGROUND",
            "isJump": null,
            "imageTypeName": null,
            "width": "750",
            "height": "480",
            "interval": "00",
            "images": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "42E89AF3FD4BAEB7E06354EDC4808361",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "学校电子卡外层背景图",
                    "imageType": "ECARD_WRAP_BACKGROUND",
                    "fileAddress": "img/gMS9Y2kMR2GAZ4cMAACmCYIW0pQ956.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2025-11-06 14:59:50",
                    "editor": "5755dd52e1ce40299c175f48020c23d2",
                    "jumpUrl": null,
                    "typeName": null
                }
            ]
        }
    },
    '{"imageType":"ECARD_BACKGROUND"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "imageType": "ECARD_BACKGROUND",
            "isJump": null,
            "imageTypeName": null,
            "width": "640",
            "height": "400",
            "interval": "1",
            "images": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "42E89AF3FD49AEB7E06354EDC4808361",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "学校电子卡",
                    "imageType": "ECARD_BACKGROUND",
                    "fileAddress": "img/gMS9Y2kMR0yAHZLHAAO8YaZPyIw424.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2025-11-06 14:59:27",
                    "editor": "5755dd52e1ce40299c175f48020c23d2",
                    "jumpUrl": null,
                    "typeName": null
                }
            ]
        }
    },
    '{"imageType":"SCHOOLMATE_CARD_BACKGROUND"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "imageType": "SCHOOLMATE_CARD_BACKGROUND",
            "isJump": null,
            "imageTypeName": null,
            "width": "750",
            "height": "600",
            "interval": "0",
            "images": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "32E0CF2171D492C9E06357EDC4809519",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "校友卡背景",
                    "imageType": "SCHOOLMATE_CARD_BACKGROUND",
                    "fileAddress": "img/202610221111288726.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2025-04-16 14:58:20",
                    "editor": "5755dd52e1ce40299c175f48020c23d2",
                    "jumpUrl": null,
                    "typeName": null
                }
            ]
        }
    },
    '{"imageType":"CARD_STYLE_PIC"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "imageType": "CARD_STYLE_PIC",
            "isJump": null,
            "imageTypeName": null,
            "width": "640",
            "height": "400",
            "interval": "0",
            "images": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "32E1171EBEFDD33AE06357EDC4802B64",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "卡片样式图",
                    "imageType": "CARD_STYLE_PIC",
                    "fileAddress": "img/gMS9Y2f_Wb6AZR_TABEAtCc02GQ745.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2025-04-16 15:18:25",
                    "editor": "e2e0ead85b634ea187574f87f46d0ee1",
                    "jumpUrl": null,
                    "typeName": null
                }
            ]
        }
    },
    '{"imageType":"graduationBanner"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "imageType": "graduationBanner",
            "isJump": null,
            "imageTypeName": null,
            "width": "640",
            "height": "214",
            "interval": "1",
            "images": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "5B1E8B47C8EF91FDE06357EDC480DCFC",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "毕业季福利图片",
                    "imageType": "graduationBanner",
                    // "fileAddress": "group1/M00/01/76/gMS9Y2qieSyARpTgABY55bEia6A664.png",
                    "fileAddress": "img/gMS9Y2qieEKAViGCABY55bEia6A417.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2026-09-10 17:32:38",
                    "editor": "1961da769e874aaea2519724bebc936e",
                    "jumpUrl": null,
                    "typeName": null
                },
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "55ECA592B28C9977E06354EDC480331D",
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "imageName": "毕业季海报",
                    "imageType": "graduationBanner",
                    // "fileAddress": "group1/M00/01/76/gMS9Y2qieEKAViGCABY55bEia6A417.png",
                    "fileAddress": "img/gMS9Y2qieEKAViGCABY55bEia6A417.png",
                    "sorting": "1",
                    "status": "1",
                    "updateTime": "2026-09-10 17:28:36",
                    "editor": "5755dd52e1ce40299c175f48020c23d2",
                    "jumpUrl": null,
                    "typeName": null
                }
            ]
        }
    },
    
  
}

export let app_news_page_typeLoginProtocol = {
    "code": 200,
    "msg": "success",
    "data": {
        "total": 0,
        "list": [],
        "pageNum": 1,
        "pageSize": 2,
        "size": 0,
        "startRow": 0,
        "endRow": 0,
        "pages": 0,
        "prePage": 0,
        "nextPage": 0,
        "isFirstPage": true,
        "isLastPage": true,
        "hasPreviousPage": false,
        "hasNextPage": false,
        "navigatePages": 8,
        "navigatepageNums": [],
        "navigateFirstPage": 0,
        "navigateLastPage": 0
    }
}

// /appSchoolmateEnterprise/pageEnterprise

//.   {"enterpriseName":"","pageNum":1,"pageSize":10}

export let app_schoolmate_pageEnterprise = {
    '{"enterpriseName":"","pageNum":1,"pageSize":4}': {
        "code": 200,
        "msg": "success",
        "data": {
            "total": 2,
            "list": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "9dc51b5d8597432dbb5e75c9acf3fa34",
                    "enterpriseName": "深圳市翠茵教育科技有限公司",
                    "logo": "img/Cs2CfGkVOtOAZh22AALp-XwGaaM511.jpg",
                    "status": "0",
                    "manager": "李翠花",
                    "contact": "13509898893",
                    "contentType": "1",
                    "content": "VTJ4U1QxSkhUa1JXV0hCVFZURldObFZVU25Oa1JuQTFWbGhzVGxORk5UVlhXR3hXWld4S1JGWlliRTVpVjJkM1drVm9RbUpGTUhkU1YzaE9ZVEZzYzFSWGRGcGxSVEZ4VlZoV1RtRnJiRFpVUjNCS1pWVXhWRTVJYkU1bGJXUnpWRlJDUm1WRk1VVlVXR1JMVmtWd1NGZHRNVWRsYlZKSVZXMHhhbVZXVmpWVmJURnJaVmRKZWxadVpFNVZNVlkxVlcxemQyUXdNVVJXV0d4VFlXdEdORk5zVWt0U01EVTJVbGQ0VG1FeGNIVldSbHBPVGxaa1ZWTnVhRmROUkd3MlZXcENSMkZXWkVWWGExSlNWbFZ3UlZwRlZqQldSa3BHWlVVNVZXVnRaRE5VVmxKR1pGZE9TRTVYTlV0V1JXdzFVMnhTU21ReVVYbGlSM1JyVWpKa2MxUlVRbEppUlRGeFUxaHNVRkpHYkhOVVYzQktZa1V4Y1ZGdE9XRldNbmgxV1ZWb1VtSkZNSGRWVjNoT1lXdHNORlJYY0VaTlZYQlZVMWhzUzFaRk5VZFRiRkpQVWtWd1ZWTnJaR3BSTVZZMlZXeEZPVkJSUFQwPQ==",
                    "contentUrl": null,
                    "createUser": "1961da769e874aaea2519724bebc936e",
                    "updateUser": "ba684dd40bb7496fbc26f739c17b65bb",
                    "createTime": 1788228131000,
                    "updateTime": 1788230352000,
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "views": "24",
                    "positionCount": "1",
                    "auditStatus": null,
                    "address": null,
                    "registrationTime": null,
                    "companyProfile": null,
                    "industry": null,
                    "businessLicense": null,
                    "addition": null,
                    "auditOpinion": null
                },
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "791ffe9e8f0d4985be8abb02969cac99",
                    "enterpriseName": "东莞市虹虹动漫有限公司",
                    "logo": "img/Cs2DbWjKcBSAS0IxAAB_di54yPw903.png",
                    "status": "0",
                    "manager": "测试牛马",
                    "contact": "13822998833",
                    "contentType": "1",
                    "content": "VTJ4U1QxSkhUa1JXV0hCVFZURldObFZVU25Oa1JuQTFWbGhzVGxORk5UVlhXR3hXWld4S1JGWlliRTVpVjJkM1drVm9RbUpGTUhkU1YzaE9ZVEZzYzFSWGRGcGxSVEZ4VlZoV1RtRnJiRFpVUjNCS1pWVXhWRTVJYkU1bGJXUnpWRlJDUm1WRk1VVlVXR1JMVmtWd1NGZHRNVWRsYlZKSVZXMHhhbVZXVmpWVmJURnJaVmRKZWxadVpFNVZNVlkxVlcxemQyUXdNVVJXV0d4VFlXdEdORk5zVWt0U01EVTJVbGQ0VG1FeGNIVldSbHBPVGxaa1ZWTnVhRmROUkd3MVdXeFdSMVJzVG5WWGExSlNWbFZ3VkZsWWEzaFNiVVoxWTBWYWEwMUhkRFpVYlhCYVpGZE9TRTVYTlV0V1JXdzFVMnhTU21ReGJGaGxSRUpMVmtVMVJsTnNVa3BsVlhCVlUxaHNTMVpGTlVkVGJGSlBVa1Z3VlZOclpHcFJNVlkyVld4Rk9WQlJQVDA9",
                    "contentUrl": null,
                    "createUser": "ba684dd40bb7496fbc26f739c17b65bb",
                    "updateUser": "1961da769e874aaea2519724bebc936e",
                    "createTime": 1754644925000,
                    "updateTime": 1788230339000,
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "views": "11",
                    "positionCount": null,
                    "auditStatus": null,
                    "address": null,
                    "registrationTime": null,
                    "companyProfile": null,
                    "industry": null,
                    "businessLicense": null,
                    "addition": null,
                    "auditOpinion": null
                },
            ],
            "pageNum": 1,
            "pageSize": 4,
            "size": 4,
            "startRow": 1,
            "endRow": 4,
            "pages": 2,
            "prePage": 0,
            "nextPage": 2,
            "isFirstPage": true,
            "isLastPage": false,
            "hasPreviousPage": false,
            "hasNextPage": true,
            "navigatePages": 8,
            "navigatepageNums": [
                1,
                2
            ],
            "navigateFirstPage": 1,
            "navigateLastPage": 2
        }
    },
    '{"enterpriseName":"","pageNum":1,"pageSize":10}': {
        "code": 200,
        "msg": "success",
        "data": {
            "total": 5,
            "list": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "9dc51b5d8597432dbb5e75c9acf3fa34",
                    "enterpriseName": "深圳市翠茵教育科技有限公司",
                    "logo": "img/Cs2CfGkVOtOAZh22AALp-XwGaaM511.jpg",
                    "status": "0",
                    "manager": "李翠花",
                    "contact": "13509898893",
                    "contentType": "1",
                    "content": "VTJ4U1QxSkhUa1JXV0hCVFZURldObFZVU25Oa1JuQTFWbGhzVGxORk5UVlhXR3hXWld4S1JGWlliRTVpVjJkM1drVm9RbUpGTUhkU1YzaE9ZVEZzYzFSWGRGcGxSVEZ4VlZoV1RtRnJiRFpVUjNCS1pWVXhWRTVJYkU1bGJXUnpWRlJDUm1WRk1VVlVXR1JMVmtWd1NGZHRNVWRsYlZKSVZXMHhhbVZXVmpWVmJURnJaVmRKZWxadVpFNVZNVlkxVlcxemQyUXdNVVJXV0d4VFlXdEdORk5zVWt0U01EVTJVbGQ0VG1FeGNIVldSbHBPVGxaa1ZWTnVhRmROUkd3MlZXcENSMkZXWkVWWGExSlNWbFZ3UlZwRlZqQldSa3BHWlVVNVZXVnRaRE5VVmxKR1pGZE9TRTVYTlV0V1JXdzFVMnhTU21ReVVYbGlSM1JyVWpKa2MxUlVRbEppUlRGeFUxaHNVRkpHYkhOVVYzQktZa1V4Y1ZGdE9XRldNbmgxV1ZWb1VtSkZNSGRWVjNoT1lXdHNORlJYY0VaTlZYQlZVMWhzUzFaRk5VZFRiRkpQVWtWd1ZWTnJaR3BSTVZZMlZXeEZPVkJSUFQwPQ==",
                    "contentUrl": null,
                    "createUser": "1961da769e874aaea2519724bebc936e",
                    "updateUser": "ba684dd40bb7496fbc26f739c17b65bb",
                    "createTime": 1788228131000,
                    "updateTime": 1788230352000,
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "views": "24",
                    "positionCount": "1",
                    "auditStatus": null,
                    "address": null,
                    "registrationTime": null,
                    "companyProfile": null,
                    "industry": null,
                    "businessLicense": null,
                    "addition": null,
                    "auditOpinion": null
                },
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "791ffe9e8f0d4985be8abb02969cac99",
                    "enterpriseName": "东莞市虹虹动漫有限公司",
                    "logo": "img/Cs2DbWjKcBSAS0IxAAB_di54yPw903.png",
                    "status": "0",
                    "manager": "测试牛马",
                    "contact": "13822998833",
                    "contentType": "1",
                    "content": "VTJ4U1QxSkhUa1JXV0hCVFZURldObFZVU25Oa1JuQTFWbGhzVGxORk5UVlhXR3hXWld4S1JGWlliRTVpVjJkM1drVm9RbUpGTUhkU1YzaE9ZVEZzYzFSWGRGcGxSVEZ4VlZoV1RtRnJiRFpVUjNCS1pWVXhWRTVJYkU1bGJXUnpWRlJDUm1WRk1VVlVXR1JMVmtWd1NGZHRNVWRsYlZKSVZXMHhhbVZXVmpWVmJURnJaVmRKZWxadVpFNVZNVlkxVlcxemQyUXdNVVJXV0d4VFlXdEdORk5zVWt0U01EVTJVbGQ0VG1FeGNIVldSbHBPVGxaa1ZWTnVhRmROUkd3MVdXeFdSMVJzVG5WWGExSlNWbFZ3VkZsWWEzaFNiVVoxWTBWYWEwMUhkRFpVYlhCYVpGZE9TRTVYTlV0V1JXdzFVMnhTU21ReGJGaGxSRUpMVmtVMVJsTnNVa3BsVlhCVlUxaHNTMVpGTlVkVGJGSlBVa1Z3VlZOclpHcFJNVlkyVld4Rk9WQlJQVDA9",
                    "contentUrl": null,
                    "createUser": "ba684dd40bb7496fbc26f739c17b65bb",
                    "updateUser": "1961da769e874aaea2519724bebc936e",
                    "createTime": 1754644925000,
                    "updateTime": 1788230339000,
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "views": "11",
                    "positionCount": null,
                    "auditStatus": null,
                    "address": null,
                    "registrationTime": null,
                    "companyProfile": null,
                    "industry": null,
                    "businessLicense": null,
                    "addition": null,
                    "auditOpinion": null
                },
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "1b78544b9a9147c28f87411532f06626",
                    "enterpriseName": "daxiaomi汽车有限公司广州市天河区分公司",
                    "logo": "img/Cs2DbWjKcBSAS0IxAAB_di54yPw903.png",
                    "status": "0",
                    "manager": "史蒂夫1",
                    "contact": "13766136666",
                    "contentType": "1",
                    "content": "VTJ4U1QxSkhUa1JXV0hCVFZrWnJlVlJ0Y0ZwaVJUQjNWRzVDYVZZeVRuTlVWM0JEWlcxT2RGUlhlRTVOUmtaelZGZHdTMkl5VWtsVmJtUkxWa1UxUTFOc1VrdFNNSEJWVTJ0a1RsWkZhekJVUjNCR1RsVTFjRTVJYUZCU1IzUXhWREZTY21KRk1IZFNWRkpPVWtkak1GTnNVa3RTTVc5NlUyNWFhMWRGUmpSVGJGSkxVakZTVlZGWVpFdFdSWEJJVkZWU1JtSkZNWEpYV0dST1VURldOVlZ0TVd0VWJGWTJZa1p3VG1KWGVHaFdha0pMVWtaR1ZtSjZUbXBOYXpWRFZWWldTMUpXU2paVWJXeG9ZbGhTVlZSVlVsWk5SVEZFVGxoa2FXSlhUbk5VVjNCS1lrVXhjVkZ0YUdsVFJrWnpWRlJDVW1KRk1YRlRWM2hPWVd0c2MxUlVRbFppUmtwVlYxZDRVRkpIWkhOVU1WSkdZa1V3ZDFSWGVFNWhNWEF6VTJ4U1QxSm5QVDA9",
                    "contentUrl": null,
                    "createUser": "e2e0ead85b634ea187574f87f46d0ee1",
                    "updateUser": "e2e0ead85b634ea187574f87f46d0ee1",
                    "createTime": 1754880020000,
                    "updateTime": 1755159873000,
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "views": "37",
                    "positionCount": "12",
                    "auditStatus": null,
                    "address": null,
                    "registrationTime": null,
                    "companyProfile": null,
                    "industry": null,
                    "businessLicense": null,
                    "addition": null,
                    "auditOpinion": null
                },
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "edcfbbd9d65a4eb1add3306f65b2a6b1",
                    "enterpriseName": "大力工程有限公司",
                    "logo": "img/Cs2DbWjKcBSAS0IxAAB_di54yPw903.png",
                    "status": "0",
                    "manager": "王二",
                    "contact": "13411111111",
                    "contentType": "0",
                    "content": null,
                    "contentUrl": "http://128.192.182.208/zjjg/pl4bjpc/index.html?ccbinsId=440683650#/role1",
                    "createUser": "a3f6f6b21db341518b389f036ef23c96",
                    "updateUser": "e2e0ead85b634ea187574f87f46d0ee1",
                    "createTime": 1754548177000,
                    "updateTime": 1755152024000,
                    "schoolId": "FB628F116A0BC718E05354EDC480EF56",
                    "views": "3",
                    "positionCount": "11",
                    "auditStatus": null,
                    "address": null,
                    "registrationTime": null,
                    "companyProfile": null,
                    "industry": null,
                    "businessLicense": null,
                    "addition": null,
                    "auditOpinion": null
                }
            ],
            "pageNum": 1,
            "pageSize": 10,
            "size": 5,
            "startRow": 1,
            "endRow": 5,
            "pages": 1,
            "prePage": 0,
            "nextPage": 0,
            "isFirstPage": true,
            "isLastPage": true,
            "hasPreviousPage": false,
            "hasNextPage": false,
            "navigatePages": 8,
            "navigatepageNums": [
                1
            ],
            "navigateFirstPage": 1,
            "navigateLastPage": 1
        }
    }
}

// export let appService_contactUs = {
//     '{"userName":"","concatUs":"2","pageSize":15,"pageNum":1}': {
//         "code": 200,
//         "msg": "success",
//         "data": {
//             "total": 7,
//             "list": [
//                 {
//                     "pageNum": 1,
//                     "pageSize": 0,
//                     "pageFlag": null,
//                     "userId": null,
//                     "schoolId": null,
//                     "userName": null,
//                     "position": null,
//                     "deptName": "广东XX学校",
//                     "email": null,
//                     "contactInformation": null,
//                     "officeAddress": "邮箱：123123@qq.com",
//                     "campusUserId": null,
//                     "deptLevel": null,
//                     "mobile": null,
//                     "concatUs": null,
//                     "sorting": null,
//                     "officeList": [
//                         {
//                             "pageNum": 1,
//                             "pageSize": 0,
//                             "pageFlag": null,
//                             "id": "c0bcfcce8a8c4b5d9d88bf720efcc12a",
//                             "deptName": "广东XX学校",
//                             "userName": "广东XX学校11",
//                             "contactInformation": "无",
//                             "deptLevel": "69",
//                             "officeAddress": "邮箱：123123@qq.com",
//                             "createDate": "2025-07-09 14:53:10",
//                             "schoolId": null,
//                             "email": null,
//                             "sorting": null,
//                             "officeSorting": null
//                         }
//                     ]
//                 },
//                 {
//                     "pageNum": 1,
//                     "pageSize": 0,
//                     "pageFlag": null,
//                     "userId": null,
//                     "schoolId": null,
//                     "userName": null,
//                     "position": null,
//                     "deptName": "广东XX学校",
//                     "email": null,
//                     "contactInformation": null,
//                     "officeAddress": "123123",
//                     "campusUserId": null,
//                     "deptLevel": null,
//                     "mobile": null,
//                     "concatUs": null,
//                     "sorting": null,
//                     "officeList": [
//                         {
//                             "pageNum": 1,
//                             "pageSize": 0,
//                             "pageFlag": null,
//                             "id": "f3b0a1d5d9254f88a6e4d78613956252",
//                             "deptName": "广东XX学校",
//                             "userName": "12312331",
//                             "contactInformation": "13422222221",
//                             "deptLevel": "72",
//                             "officeAddress": "123123",
//                             "createDate": "2025-07-09 15:47:25",
//                             "schoolId": null,
//                             "email": "111@qq.com",
//                             "sorting": null,
//                             "officeSorting": null
//                         },
//                         {
//                             "pageNum": 1,
//                             "pageSize": 0,
//                             "pageFlag": null,
//                             "id": "861b68f1e27847b99eb203a08685e789",
//                             "deptName": "广东XX学校",
//                             "userName": "123123",
//                             "contactInformation": "13411111111",
//                             "deptLevel": "72",
//                             "officeAddress": "123123",
//                             "createDate": "2025-07-09 15:45:12",
//                             "schoolId": null,
//                             "email": null,
//                             "sorting": null,
//                             "officeSorting": null
//                         }
//                     ]
//                 },
//                 {
//                     "pageNum": 1,
//                     "pageSize": 0,
//                     "pageFlag": null,
//                     "userId": null,
//                     "schoolId": null,
//                     "userName": null,
//                     "position": null,
//                     "deptName": "sdfdsf",
//                     "email": null,
//                     "contactInformation": null,
//                     "officeAddress": "11",
//                     "campusUserId": null,
//                     "deptLevel": null,
//                     "mobile": null,
//                     "concatUs": null,
//                     "sorting": null,
//                     "officeList": [
//                         {
//                             "pageNum": 1,
//                             "pageSize": 0,
//                             "pageFlag": null,
//                             "id": "b046eb31de0b4b6cae0152e931c771cc",
//                             "deptName": "sdfdsf",
//                             "userName": "1212",
//                             "contactInformation": "11",
//                             "deptLevel": "83",
//                             "officeAddress": "11",
//                             "createDate": "2026-05-15 16:51:27",
//                             "schoolId": null,
//                             "email": "11",
//                             "sorting": null,
//                             "officeSorting": null
//                         }
//                     ]
//                 },
//                 {
//                     "pageNum": 1,
//                     "pageSize": 0,
//                     "pageFlag": null,
//                     "userId": null,
//                     "schoolId": null,
//                     "userName": null,
//                     "position": null,
//                     "deptName": "学生宿舍",
//                     "email": null,
//                     "contactInformation": null,
//                     "officeAddress": "地址地址地址地址地址",
//                     "campusUserId": null,
//                     "deptLevel": null,
//                     "mobile": null,
//                     "concatUs": null,
//                     "sorting": null,
//                     "officeList": [
//                         {
//                             "pageNum": 1,
//                             "pageSize": 0,
//                             "pageFlag": null,
//                             "id": "bc50e87dfaac4547a2ecd25bceb82c54",
//                             "deptName": "学生宿舍",
//                             "userName": "十一栋宿舍",
//                             "contactInformation": "13899138888：109399123",
//                             "deptLevel": "73",
//                             "officeAddress": "地址地址地址地址地址",
//                             "createDate": "2025-07-09 16:17:46",
//                             "schoolId": null,
//                             "email": "8899.com",
//                             "sorting": null,
//                             "officeSorting": null
//                         }
//                     ]
//                 },
//                 {
//                     "pageNum": 1,
//                     "pageSize": 0,
//                     "pageFlag": null,
//                     "userId": null,
//                     "schoolId": null,
//                     "userName": null,
//                     "position": null,
//                     "deptName": "学工部",
//                     "email": null,
//                     "contactInformation": null,
//                     "officeAddress": "主校区",
//                     "campusUserId": null,
//                     "deptLevel": null,
//                     "mobile": null,
//                     "concatUs": null,
//                     "sorting": null,
//                     "officeList": [
//                         {
//                             "pageNum": 1,
//                             "pageSize": 0,
//                             "pageFlag": null,
//                             "id": "8c1f058fd9fa47f7aacaadf9dcd74dfd",
//                             "deptName": "学工部",
//                             "userName": "学工部",
//                             "contactInformation": "13800138000",
//                             "deptLevel": "68",
//                             "officeAddress": "主校区",
//                             "createDate": "2025-07-09 14:24:43",
//                             "schoolId": null,
//                             "email": null,
//                             "sorting": null,
//                             "officeSorting": null
//                         }
//                     ]
//                 },
//                 {
//                     "pageNum": 1,
//                     "pageSize": 0,
//                     "pageFlag": null,
//                     "userId": null,
//                     "schoolId": null,
//                     "userName": null,
//                     "position": null,
//                     "deptName": "广东XX学校",
//                     "email": null,
//                     "contactInformation": null,
//                     "officeAddress": "所在地址",
//                     "campusUserId": null,
//                     "deptLevel": null,
//                     "mobile": null,
//                     "concatUs": null,
//                     "sorting": null,
//                     "officeList": [
//                         {
//                             "pageNum": 1,
//                             "pageSize": 0,
//                             "pageFlag": null,
//                             "id": "12b00d0cac574d16940546a72435a6a0",
//                             "deptName": "广东XX学校",
//                             "userName": "办公室",
//                             "contactInformation": "13877138888",
//                             "deptLevel": "70",
//                             "officeAddress": "所在地址",
//                             "createDate": "2025-07-09 15:06:54",
//                             "schoolId": null,
//                             "email": "222@qq.com",
//                             "sorting": null,
//                             "officeSorting": null
//                         },
//                         {
//                             "pageNum": 1,
//                             "pageSize": 0,
//                             "pageFlag": null,
//                             "id": "aad86b6ffaff46a889c6ba77d81e65d3",
//                             "deptName": "广东XX学校",
//                             "userName": "123",
//                             "contactInformation": "13761631331",
//                             "deptLevel": "70",
//                             "officeAddress": "所在地址",
//                             "createDate": "2025-07-09 15:06:31",
//                             "schoolId": null,
//                             "email": null,
//                             "sorting": null,
//                             "officeSorting": null
//                         }
//                     ]
//                 },
//                 {
//                     "pageNum": 1,
//                     "pageSize": 0,
//                     "pageFlag": null,
//                     "userId": null,
//                     "schoolId": null,
//                     "userName": null,
//                     "position": null,
//                     "deptName": "345",
//                     "email": null,
//                     "contactInformation": null,
//                     "officeAddress": "123",
//                     "campusUserId": null,
//                     "deptLevel": null,
//                     "mobile": null,
//                     "concatUs": null,
//                     "sorting": null,
//                     "officeList": [
//                         {
//                             "pageNum": 1,
//                             "pageSize": 0,
//                             "pageFlag": null,
//                             "id": "ff8bd329463b45ec92790b7572b4c3b8",
//                             "deptName": "345",
//                             "userName": "123",
//                             "contactInformation": "1231",
//                             "deptLevel": "94",
//                             "officeAddress": "123",
//                             "createDate": "2026-06-18 16:40:03",
//                             "schoolId": null,
//                             "email": "1231",
//                             "sorting": null,
//                             "officeSorting": null
//                         }
//                     ]
//                 }
//             ],
//             "pageNum": 1,
//             "pageSize": 7,
//             "size": 7,
//             "startRow": 0,
//             "endRow": 6,
//             "pages": 1,
//             "prePage": 0,
//             "nextPage": 0,
//             "isFirstPage": true,
//             "isLastPage": true,
//             "hasPreviousPage": false,
//             "hasNextPage": false,
//             "navigatePages": 8,
//             "navigatepageNums": [
//                 1
//             ],
//             "navigateFirstPage": 1,
//             "navigateLastPage": 1
//         }
//     }
// }
export let app_schoolmate_enterprise_pagePosition = {
    '{"schoolmateEnterpriseId":"9dc51b5d8597432dbb5e75c9acf3fa34","pageNum":1,"pageSize":10}': {
        "code": 200,
        "msg": "success",
        "data": {
            "total": 1,
            "list": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "1c9752dc51ec4defbf772335857e1d46",
                    "schoolmateEnterpriseId": "9dc51b5d8597432dbb5e75c9acf3fa34",
                    "positionName": "新媒体运营拍摄剪辑1~2人",
                    "salaryType": "0",
                    "salaryMin": null,
                    "salaryMax": null,
                    "status": "0",
                    "address": "深圳市罗湖区水贝万山珠宝商业中心A座5楼5009-17",
                    "description": "VTJ4U1QxSkhUa1JXV0hCVFZURldObFZVU25Oa1JuQTFWbGhzVGxORk5UVlhXR3hXWld4S1JGWlliRTVpVjJkM1drVm9RbUpGTUhkU1YzaE9ZVEZzYzFSWGRGcGxSVEZ4VlZoV1RtRnJiRFpVUjNCS1pWVXhWRTVJYkU1bGJXUnpWRlJDUm1WRk1VVlVXR1JMVmtWd1NGZHRNVWRsYlZKSVZXMHhhbVZXVmpWVmJURnJaVmRKZWxadVpFNVZNVlkxVlcxemQyUXdNVVJXV0d4VFlXdEdORk5zVWt0U01EVTJVbGQ0VG1FeGNIVldSbHBPVGxaa1ZWTnVhRmROUkdkNVdXeFdSMVJ0VW5OU2JYaFNWbFZhZGxWV1pFdFZWa1kyVm01a1QyRnNSWGhVVjNCQ1pGZE9TRTVYTlV0V1JXdzFVMnhTU21ReGJGaGxSRUpMVmtVMVJsTnNVa3BsVlhCVlUxaHNTMVpGTlVkVGJGSlBVa1Z3VlZOclpHcFJNVlkyVld4Rk9WQlJQVDA9",
                    "createUser": "1961da769e874aaea2519724bebc936e",
                    "updateUser": "1961da769e874aaea2519724bebc936e",
                    "createTime": 1788228200000,
                    "updateTime": 1788230574000,
                    "views": "9",
                    "schoolId": null
                }
            ],
            "pageNum": 1,
            "pageSize": 10,
            "size": 1,
            "startRow": 1,
            "endRow": 1,
            "pages": 1,
            "prePage": 0,
            "nextPage": 0,
            "isFirstPage": true,
            "isLastPage": true,
            "hasPreviousPage": false,
            "hasNextPage": false,
            "navigatePages": 8,
            "navigatepageNums": [
                1
            ],
            "navigateFirstPage": 1,
            "navigateLastPage": 1
        }
    },//791ffe9e8f0d4985be8abb02969cac99
    '{"schoolmateEnterpriseId":"791ffe9e8f0d4985be8abb02969cac99","pageNum":1,"pageSize":10}': {
        "code": 200,
        "msg": "success",
        "data": {
            "total": 1,
            "list": [
                {
                    "pageNum": 1,
                    "pageSize": 0,
                    "pageFlag": null,
                    "id": "3569318bdb7f4f2bb8b22ef1480b1815",
                    "schoolmateEnterpriseId": "791ffe9e8f0d4985be8abb02969cac99",
                    "positionName": "3D动画制作技术",
                    "salaryType": "0",
                    "salaryMin": null,
                    "salaryMax": null,
                    "status": "0",
                    "address": "面议",
                    "description": "VTJ4U1QxSkhUa1JXV0hCVFZURmFSMVF4VGxaT1ZrWTFWbFJTVGxFeFdrZFVNRTVYVVdzMWNGWlVVazVWTVZwSFZHNXNWazVGTlhCV1ZGWlRZVlphUjFSdWJGZFJNVVp3VmxSU1RtVldXa2RVYTA1WFVURktSRlpyVGxOaFZscEhWRzVzVms1Vk5VUldhMHBRVWtVMVJsTnNWbFpOVlhCVllVVktTMVpWVlRCVGJGWldUVEJ3VldGNlFrdFdWWEJFVTJ4V1ZrMVZjRlZhZWxKTFZsVnJlVk5zVmxaTlJYQldVMnRXUzFaSGVFVlRiRlpXVFd0d1ZXRkZTa3RXUjJRelUyeFdWazFyY0ZWaVJWSkxWbFZhU0ZOc1ZsZFNNSEJXVTJ0U1MxWkhhRVZUYkZaV1RrVndWVnA2Vmt0V1ZWcElVMnhXVmsxVmNGWlNWRVpMVmxWd1JsTnNWbFpOTUhCVllrVktTMVpIWTNkVGJGWldUV3R3VmxOWWJFdFdSM2hJVTJ4V1ZrNVZjRlZhTTJSTFZrZDRRMU5zVmxaT1JYQlZXak53UzFaVmNFWlRiRlpXVFZWd1ZXRkZTa3RXUjNoRVUyeFdWazFGY0ZaVGEwNUxWbFZWZUZOc1ZsWk5WWEJWWVVWa1MxWkhhRU5UYkZaV1RWVndWV0V6YkV0V1IyaEZVMnhXVmsxVmNGWlNhMXBMVmxWV05WTnNWbFpOYTNCVlducFNTMVpWYTNwVGJGWldUa1Z3VlZvelpFdFdSM1F6VTJ4V1ZrMVZjRlpUYTJSTFZrZGtObE5zVmxaTmEzQldVMWhzUzFaSGVFaFRiRlpXVGxWd1ZWb3paRXRXUjNoRFUyeFdWbVZyY0ZWYU0yUkxWa2RrTlZOc1VrOVNSWEJWVTJ0a2FsRXhWalpWYkVVNVVGRTlQUT09",
                    "createUser": "ba684dd40bb7496fbc26f739c17b65bb",
                    "updateUser": "ba684dd40bb7496fbc26f739c17b65bb",
                    "createTime": 1792554732000,
                    "updateTime": 1792554732000,
                    "views": null,
                    "schoolId": null
                }
            ],
            "pageNum": 1,
            "pageSize": 10,
            "size": 1,
            "startRow": 1,
            "endRow": 1,
            "pages": 1,
            "prePage": 0,
            "nextPage": 0,
            "isFirstPage": true,
            "isLastPage": true,
            "hasPreviousPage": false,
            "hasNextPage": false,
            "navigatePages": 8,
            "navigatepageNums": [
                1
            ],
            "navigateFirstPage": 1,
            "navigateLastPage": 1
        }
    }
}

// /appSchoolmateEnterprise/detailEnterprise

export let app_schoolmate_detail_enterprise = {
    '{"id":"791ffe9e8f0d4985be8abb02969cac99"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "pageNum": 1,
            "pageSize": 0,
            "pageFlag": null,
            "id": "791ffe9e8f0d4985be8abb02969cac99",
            "enterpriseName": "东莞市虹虹动漫有限公司",
            "logo": "img/Cs2DbWjKcBSAS0IxAAB_di54yPw903.png",
            "status": "0",
            "manager": "李小红",
            "contact": "13822998833",
            "contentType": "1",
            "content": "img/2026102010015362423.jpg",
            "contentUrl": null,
            "createUser": "ba684dd40bb7496fbc26f739c17b65bb",
            "updateUser": "ba684dd40bb7496fbc26f739c17b65bb",
            "createTime": 1754644925000,
            "updateTime": 1792562520000,
            "schoolId": "FB628F116A0BC718E05354EDC480EF56",
            "views": "16",
            "positionCount": "1",
            "auditStatus": null,
            "address": null,
            "registrationTime": null,
            "companyProfile": null,
            "industry": null,
            "businessLicense": null,
            "addition": null,
            "auditOpinion": null
        }
    },
    '{"id":"9dc51b5d8597432dbb5e75c9acf3fa34"}': {
        "code": 200,
        "msg": "success",
        "data": {
            "pageNum": 1,
            "pageSize": 0,
            "pageFlag": null,
            "id": "9dc51b5d8597432dbb5e75c9acf3fa34",
            "enterpriseName": "深圳市翠茵教育科技有限公司",
            "logo": "img/Cs2CfGkVOtOAZh22AALp-XwGaaM511.jpg",
            "status": "0",
            "manager": "李翠花",
            "contact": "13509898893",
            "contentType": "1",
            "content": "img/2026102010000362323.png",
            "contentUrl": null,
            "createUser": "1961da769e874aaea2519724bebc936e",
            "updateUser": "ba684dd40bb7496fbc26f739c17b65bb",
            "createTime": 1788228131000,
            "updateTime": 1792554459000,
            "schoolId": "FB628F116A0BC718E05354EDC480EF56",
            "views": "35",
            "positionCount": "1",
            "auditStatus": null,
            "address": null,
            "registrationTime": null,
            "companyProfile": null,
            "industry": null,
            "businessLicense": null,
            "addition": null,
            "auditOpinion": null
        }
    }
}

export let app_service_returnQR = {
    "code": 200,
    "msg": "",
    "data": ""
}