import {appLogin_appAutMenu} from "./appLogin_appAutMenu.js"
import {appSchoolmate_getSchoolmate} from "./appSchoolmate_getSchoolmate.js"
import {appLogin_login,schoolInfo_getSchoolSetting} from "./appLogin_login"
import { app_news_page_type, activities_page, activities_detail, activities_add, activities_unRegister, groups_detail, groups_members, homecoming_group_auditList, homecoming_group_college_page, homecoming_group_page, homecoming_group_detail, returnSchoolRegister_listSchoolmateGWY } from "./app_news_page_type.js"
import { app_images_list, app_news_page_typeLoginProtocol, app_schoolmate_pageEnterprise, app_schoolmate_enterprise_pagePosition, app_service_returnQR, app_schoolmate_detail_enterprise } from "./app_images_list"
import {dept_listCollages} from "./dept_listCollages"
import {groups_list,my_baseInfo,app_info_config_personal_get} from "./groups_list.js"
import {appAlbum_listAlbum} from "./appAlbum_listAlbum"
import {app_images_list_school} from "./app_images_list_school"
import {my_notification_pageNotification,app_news_detail,app_info_config_school,appGroupActivities_my_page,appSchoolmateCard_getExchangeReceivedCount,appSchoolmateCard_getSchoolmateCardExchange,appGroupActivities_myCreateActivitiesList} from "./my_notification_pageNotification"
import {my_getDetailedInformation,appService_returnSchoolAdd,appService_returnSchoolList,appService_returnSchoolDetail} from "./my_getDetailedInformation"
import {appSchoolmate_statisticsByProvince} from "./appSchoolmate_statisticsByProvince"
import { appService_xyMessageNotificationList, appService_contactUs } from "./appService_xyMessageNotificationList"
import { schoolCard_detail, schoolCard_save } from "./schoolCard_detail.js"

let group_type_list = {
  '{}':{"code":"200","msg":"success","data":[{"pageNum":1,"pageSize":0,"pageFlag":null,"otId":"1875FF6560774CA0E06357EDC4800F87","schoolId":"FB628F1163EDC718E05354EDC480EF56","otName":"地方校友会","otDescribe":null,"otIcon":null,"createDate":null,"creator":null,"priority":null,"category":null},{"pageNum":1,"pageSize":0,"pageFlag":null,"otId":"182A154ADC692B84E06354EDC480A977","schoolId":"FB628F1163EDC718E05354EDC480EF56","otName":"学院校友会","otDescribe":null,"otIcon":null,"createDate":null,"creator":null,"priority":null,"category":null}]}
}
// let groups_detail = {
//   '{}':{"code":"200","msg":"success","data":{"pageNum":1,"pageSize":0,"pageFlag":null,"groupsId":"5563dc968c3d4f3fb82324f8071f2344","schoolId":"FB628F1163EDC718E05354EDC480EF56","groupsName":"北京市校友会","groupsType":"1875FF6560774CA0E06357EDC4800F87","officeLocation":"北京市校友会","primaryLeader":"9fe7b2b6a9304c619fd9014b787f2385","contactInformation":"13899138999","numberOfMembers":"5","businessScope":"无","groupsProfilePicture":null,"auditStatus":"1","banStatus":"1","creator":"d426912099ca4984a5db61f700bf4cce","createTime":"2024-12-31 10:56:04","updateTime":"2025-07-17 09:45:27","associatedDeptId":null,"associatedDeptName":null,"isJoin":false,"userId":null,"groupsTypeName":null,"creatorName":null,"primaryLeaderName":null,"hasAuditRight":"0","applicationReason":null,"icons":[null],"isPrimaryLeader":null,"isAdministrator":null,"whetherToStick":"0","priority":0,"pendingAudit":"0","totalCountOfJoinedGroups":null,"category":"01","markType":"00","deleteStatus":"1"}}
// }
let groups_invite_recent = {
  '{}':{"code":"200","msg":"success"}
}
// let groups_members ={
//   '{}': {"code":500,"msg":"您不是该组织成员，无法查看成员信息"}
// }

let my_getPendingAuditStatus = {"code":"200","msg":"success","data":false}
let my_notification_getUnreadCoun = {"code":"200","msg":"success","data":"5"}
let appSchoolmateCard_getUnreadExchangeCount = {"code":"200","msg":"success","data":"0"}
let appSchoolmate_schoolmate_group = {
  "code": "200", "msg": "success", "data": [
    {
      "pageNum": 1,
      "pageSize": 0,
      "pageFlag": null,
      "groupsId": "70ae6ae3c352411080bb23ad0312c406",
      "schoolId": null,
      "groupsName": "户外运动社团校友会",
      "groupsType": "3263B5A4809FC630E06357EDC480DF9F",
      "officeLocation": null,
      "primaryLeader": null,
      "contactInformation": null,
      "numberOfMembers": null,
      "businessScope": null,
      "groupsProfilePicture": null,
      "auditStatus": null,
      "banStatus": null,
      "creator": null,
      "createTime": null,
      "updateTime": null,
      "associatedDeptId": null,
      "associatedDeptName": null,
      "isJoin": true,
      "userId": null,
      "groupsTypeName": null,
      "creatorName": null,
      "primaryLeaderName": null,
      "hasAuditRight": null,
      "applicationReason": null,
      "icons": null,
      "isPrimaryLeader": null,
      "isAdministrator": null,
      "whetherToStick": null,
      "priority": null,
      "pendingAudit": "1",
      "totalCountOfJoinedGroups": null,
      "category": null,
      "markType": null,
      "deleteStatus": null,
      "introduction": null
    },
    {
      "pageNum": 1,
      "pageSize": 0,
      "pageFlag": null,
      "groupsId": "39fd0bfebc9348e4958c4c942d75e2c3",
      "schoolId": null,
      "groupsName": "地理科学学院校友会",
      "groupsType": "3263B5A4809FC630E06357EDC480DF9F",
      "officeLocation": null,
      "primaryLeader": null,
      "contactInformation": null,
      "numberOfMembers": null,
      "businessScope": null,
      "groupsProfilePicture": null,
      "auditStatus": null,
      "banStatus": null,
      "creator": null,
      "createTime": null,
      "updateTime": null,
      "associatedDeptId": null,
      "associatedDeptName": null,
      "isJoin": true,
      "userId": null,
      "groupsTypeName": null,
      "creatorName": null,
      "primaryLeaderName": null,
      "hasAuditRight": null,
      "applicationReason": null,
      "icons": null,
      "isPrimaryLeader": null,
      "isAdministrator": null,
      "whetherToStick": null,
      "priority": null,
      "pendingAudit": "1",
      "totalCountOfJoinedGroups": null,
      "category": null,
      "markType": null,
      "deleteStatus": null,
      "introduction": null
    }
  ]
}
let activities_my_page = {"code":"200","msg":"success","data":{"total":0,"list":[],"pageNum":1,"pageSize":10,"size":0,"startRow":0,"endRow":0,"pages":0,"prePage":0,"nextPage":0,"isFirstPage":true,"isLastPage":true,"hasPreviousPage":false,"hasNextPage":false,"navigatePages":8,"navigatepageNums":[],"navigateFirstPage":0,"navigateLastPage":0}}

let school_getReturnSchoolConfig = {
    '{"schoolId": "FB628F1163EDC718E05354EDC480EF56"}':{"code":"200","msg":"success","data":{"schoolId":null,"returnschoolLimitedFlag":"0","returnschoolLimitedNumber":"0","accompanyingPersonsLimit":"2","returnSchoolTimesLimit":"20","appointmentTimePeriod":["08:01--12:01","14:02--18:02"],"banAppointmentTimePeriod":["2024-10-14 00:00--2024-10-15 00:00"]}}
}

let appLogin_getSchoolId = {
  '{}':{"code":200,"msg":"查询成功","data":{"schoolId":"FB628F1163EDC718E05354EDC480EF56","schoolName":"广东XX学校"}}
}

// '{"schoolCode":"4121010165"}'


function deepEqual(obj1, obj2) {
    if (obj1 === obj2) {
      return true;
    }
  
    if (typeof obj1 !== 'object' || obj1 === null || typeof obj2 !== 'object' || obj2 === null) {
      return false;
    }
  
    const keys1 = Object.keys(obj1);
    const keys2 = Object.keys(obj2);
  
    if (keys1.length !== keys2.length) {
      return false;
    }
  
    for (const key of keys1) {
      if (!keys2.includes(key) || !deepEqual(obj1[key], obj2[key])) {
        return false;
      }
    }
  
    return true;
  }

let ms = {
  '{}':{"code":"200","msg":"短信发送成功","data":"SUPERV202512241933113336"}
}

export const showDemoData = (url,params,config)=>{
    // console.log('app_images_list',app_images_list)
    console.log('showDemoData--url--params',url,params,config)
    let data = {
        "/appLogin/sendSms":ms,
        // "/getVerify":getVerify,
        "/appLogin/login":{
          '{}':appLogin_login
        },
        "/schoolInfo/getSchoolSetting":{
          '{"schoolId":"FB628F1163EDC718E05354EDC480EF56"}':schoolInfo_getSchoolSetting
        },
        "/app/images/list/school":app_images_list_school,
        "/appLogin/getSchoolId":appLogin_getSchoolId,
        "/appLogin/appAutMenu":appLogin_appAutMenu,
        "/my/baseInfo" : my_baseInfo,
        "/app/info/config/personal/get":app_info_config_personal_get,
      "/app/news/page/type": app_news_page_type,
      "/activities/page": activities_page,
      "/activities/detail": activities_detail,
      "/activities/add": activities_add,
      "/activities/unRegister": activities_unRegister,
      // "/appSchoolmate/schoolmate/group": schoolmate_group,
        "/app/images/list":app_images_list,
        "/app/news/page/typeLoginProtocol":{
          '{"newsType":"login_protocol","schoolId":"FB628F1163EDC718E05354EDC480EF56","pageNum":1,"pageSize":2}':app_news_page_typeLoginProtocol
        },
        "/my/notification/pageNotification":my_notification_pageNotification,
        "/my/getDetailedInformation":my_getDetailedInformation,
        "/appService/returnSchoolAdd":{
          '{"collegeName":"","college":"","contactInformation":"13413476123","description":"","numberOfAccompanyingPersons":"0","remark":"1","returningEndTime":"10:00","visitingUnit":"","returningReason":"拜访老师","returningStartTime":"08:10","numberOfAccompanyingPersonList":[],"deptName":"","userName":"","showText":"","campusUserId":"","visitorName":"","visitorIdNumber":"","plateNumber":"","campusUserEmail":"","campusUserName":"","returningDate":"2026-01-09"}':appService_returnSchoolAdd
        },
        "/appService/returnSchoolList":{
          '{"pageNum":1,"pageSize":10}':appService_returnSchoolList
        },
        "/appService/returnSchoolDetail":{
          '{"returningSchoolId":"31cbf7666393413e98aab2fe77d17a01"}':appService_returnSchoolDetail
        },
        "/appSchoolmateCard/getExchangeReceivedCount":appSchoolmateCard_getExchangeReceivedCount,
        "/appSchoolmateCard/getSchoolmateCardExchange":appSchoolmateCard_getSchoolmateCardExchange,
        "/appGroupActivities/myCreateActivitiesList":appGroupActivities_myCreateActivitiesList,
        "/appGroupActivities/my/page":appGroupActivities_my_page,
        "/appSchoolmate/statisticsByProvince":appSchoolmate_statisticsByProvince,
        "/app/info/config/school/get":app_info_config_school,
        "/app/news/detail?niId=4450c193bc804590b02760a3868f3f08":app_news_detail,

        "/school/getReturnSchoolConfig":school_getReturnSchoolConfig,
        "/appSchoolmate/getSchoolmate":appSchoolmate_getSchoolmate,
        "/dept/listCollages":dept_listCollages,
        "/group/type/list":group_type_list,
        "/groups/list":groups_list,
        "/groups/detail":groups_detail,
        "/groups/invite/recent":groups_invite_recent,
      "/groups/members": groups_members,
      "/app/homecoming/group/auditList": homecoming_group_auditList,
      "/app/homecoming/group/college/page": homecoming_group_college_page,
      "/app/homecoming/group/page": homecoming_group_page,
      "/app/homecoming/group/detail": homecoming_group_detail,
      "/app/returnSchoolRegister/listSchoolmateGWY": returnSchoolRegister_listSchoolmateGWY,
        "/appAlbum/listAlbum":appAlbum_listAlbum,
        "/my/getPendingAuditStatus":my_getPendingAuditStatus,
        "/my/notification/getUnreadCount":my_notification_getUnreadCoun,
        "/appSchoolmateCard/getUnreadExchangeCount":appSchoolmateCard_getUnreadExchangeCount,
        "/appSchoolmate/schoolmate/group":{
          '{"userId":"77c21f73bddb46319328c41b7c5e6c3e"}':appSchoolmate_schoolmate_group
        },
        "/appService/xyMessageNotificationList":appService_xyMessageNotificationList,
        "/activities/my/page":{
          '{"pageNum":1,"pageSize":10}':activities_my_page
        },
        "/appService/contactUs":appService_contactUs,
        "/appSchoolmateEnterprise/pageEnterprise": app_schoolmate_pageEnterprise,
      "/appSchoolmateEnterprise/pagePosition": app_schoolmate_enterprise_pagePosition,
      "/appSchoolmateEnterprise/detailEnterprise": app_schoolmate_detail_enterprise,
        "/appService/returnQR": app_service_returnQR,
        "/appLogin/loginLogout":{"code":"200","msg":"退出登录成功"},
      "/app/schoolCard/detail": schoolCard_detail,
      '/app/schoolCard/save': schoolCard_save
    }

    if(url == '/getVerify'){
      console.log('------',Object.keys(params).length )
    }
    // console.log("^^^^^^^@@@@@@@@@@@@@",url,params,Object.keys(params).length)
    if(Object.keys(params).length > 0){
        console.log("data[url]",url,data[url])
        for(let i in data[url]){
          console.log('***url___',url,i)
          console.log("**key*",JSON.parse(i),url)
          if(Object.keys(JSON.parse(i)).length > 0){
            console.log('1')
            let as = JSON.parse(i)
            if(deepEqual(as,params)){
                // console.log('---deepEqual---',url,data[url][i])
                return data[url][i]
            }
          }else{
            console.log('2',data[url][i])
            return data[url][i]
          }

        }
    }else{
        console.log('showDemoData',url,'^^^^^^',data[url])
        // return  Promise.resolve(data[url])
        return data[url]

    }
    
}