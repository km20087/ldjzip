export let appSchoolmate_statisticsByProvince = {
        "code": 200,
        "msg": "success",
        "data": [
            {
                "provinceName": "山东省",
                "schoolmateCount": "5"
            },
            {
                "provinceName": "上海市",
                "schoolmateCount": "7"
            },
            {
                "provinceName": "甘肃省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "湖南省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "黑龙江省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "浙江省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "福建省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "宁夏回族自治区",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "吉林省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "四川省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "青海省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "贵州省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "香港特别行政区",
                "schoolmateCount": "6"
            },
            {
                "provinceName": "北京市",
                "schoolmateCount": "6"
            },
            {
                "provinceName": "云南省",
                "schoolmateCount": "3"
            },
            {
                "provinceName": "天津市",
                "schoolmateCount": "1"
            },
            {
                "provinceName": "河南省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "陕西省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "西藏自治区",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "广东省",
                "schoolmateCount": "67"
            },
            {
                "provinceName": "内蒙古自治区",
                "schoolmateCount": "16"
            },
            {
                "provinceName": "重庆市",
                "schoolmateCount": "1"
            },
            {
                "provinceName": "安徽省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "湖北省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "江西省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "山西省",
                "schoolmateCount": "20007"
            },
            {
                "provinceName": "新疆维吾尔自治区",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "广西壮族自治区",
                "schoolmateCount": "18"
            },
            {
                "provinceName": "台湾省",
                "schoolmateCount": "1"
            },
            {
                "provinceName": "江苏省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "河北省",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "澳门特别行政区",
                "schoolmateCount": "0"
            },
            {
                "provinceName": "海南省",
                "schoolmateCount": "0"
            }
        ]
    }