import { RouteRecordRaw } from 'vue-router';

export const NewsRoute = {
  path: '/news',
  name: 'news',
  meta: {
    title: 'news',
  },
  component: () => import('@/pages/news/index.vue'),
}

export const NewsDetailRoute = {
  path: '/newsDetail',
  name: 'newsDetail',
  meta: {
    title: 'newsDetail',
  },
  component: () => import('@/pages/news/detail/index.vue'),
}

export const DynamicRoutes: Array<RouteRecordRaw> = [
  // NewsRoute,
  NewsDetailRoute,
  {
    path: '/showAlumniXX',
    name: 'showAlumniXX',
    meta: {
      title: '校友会',
      keepAlive: true,
    },
    component: () => import('@/pages/showAlumniXX/index.vue'),
  },   
  {
    path: '/actList',
    name: 'actList',
    meta: {
      title: '活动详情',
    },
    component: () => import('@/pages/actList/index.vue'),
  },
  {
    path: '/alumni_card',
    name: 'alumni_card',
    meta: {
      title: '校友卡',
    },
    component: () => import('@/pages/alumni_card/index.vue'),
  },
  {
    path: '/agreeAlumniCard',
    name: 'agreeAlumniCard',
    meta: {
      title: '已交换校友卡',
    },
    component: () => import('@/pages/agreeAlumniCard/index.vue'),
  },
  //首页-汕大校友卡
  {
    path: '/mateCardSD',
    name: 'mateCardSD',
    meta: {
      title: 'mateCardSD',
    },
    component: () => import('@/pages/home/mateCard/ShanDa/index.vue'),
  },
  //首页-汕大校友卡-申请
  {
    path: '/mateCardAP',
    name: 'mateCardAP',
    meta: {
      title: 'mateCardAP',
    },
    component: () => import('@/pages/home/mateCard/ShanDa/apply.vue'),
  },

  //首页-汕大校友卡-申请
  {
    path: '/qrcodeShow',
    name: 'qrcodeShow',
    meta: {
      title: '电子校友卡展示',
    },
    component: () => import('@/pages/home/mateCard/ShanDa/qrcode.vue'),
  },  
  //首页-汕大校友卡-申请
  {
    path: '/demoImg',
    name: 'demoImg',
    meta: {
      title: '',
    },
    component: () => import('@/pages/home/mateCard/ShanDa/demoImg.vue'),
  },  
  //agreeAlumniCard
  {
    path: '/orgDetail',
    name: 'orgDetail',
    meta: {
      title: '组织详情',
      keepAlive: true,
    },
    component: () => import('@/pages/orgDetail/index.vue'),
  },

  {
    path: '/perInfoCard',
    name: 'perInfoCard',
    meta: {
      title: 'perInfoCard',
    },
    component: () => import('@/pages/perInfoCard/index.vue'),
  },
  {
    path: '/myPerInfoCard',
    name: 'myPerInfoCard',
    meta: {
      title: 'myPerInfoCard',
    },
    component: () => import('@/pages/myPerInfoCard/index.vue'),
  },
  {
    path: '/myCardList',
    name: 'myCardList',
    meta: {
      title: 'myCardList',
    },
    component: () => import('@/pages/myCardList/index.vue'),
  },
  {
    path: '/infoConfig',
    name: 'infoConfig',
    meta: {
      title: '信息展示配置',
    },
    component: () => import('@/pages/infoConfig/index.vue'),
  },
  {
    path: '/feedback',
    name: 'feedback',
    meta: {
      title: '反馈与建议',
    },
    component: () => import('@/pages/feedback/index.vue'),
  },
  {
    path: '/selInfoConfig',
    name: 'selInfoConfig',
    meta: {
      title: '个人信息配置',
    },
    component: () => import('@/pages/infoConfig/config.vue'),
  },
  {
    path: '/editPerInfo',
    name: 'editPerInfo',
    meta: {
      title: 'editPerInfo',
    },
    component: () => import('@/pages/editPerInfo/index.vue'),
  },

  {
    //名片夹
    path: '/user_card',
    name: 'user_card',
    meta: {
      title: 'user_card',
    },
    component: () => import('@/pages/user_card/index.vue'),
  },

  //user_card
  //首页-校友卡
  {
    path: '/mateCard',
    name: 'mateCard',
    meta: {
      title: 'mateCard',
    },
    component: () => import('@/pages/home/mateCard/index.vue'),
  },
  {
    path: '/submited',
    name: 'submited',
    meta: {
      title: 'submited',
    },
    component: () => import('@/pages/submited/index.vue'),
  },
  {
    path: '/jobInfo',
    name: 'jobInfo',
    meta: {
      title: 'jobInfo',
    },
    component: () => import('@/pages/jobInfo/index.vue'),
  },
  // submited
  // {
  //   path: '/login',
  //   name: 'login',
  //   meta: {
  //     title: 'login',
  //   },
  //   component: () => import('@/pages/login/index.vue'),
  // },
  {
    path: '/joinClub',
    name: 'joinClub',
    meta: {
      title: 'joinClub',
    },
    component: () => import('@/pages/joinClub/index.vue'),
  },

  //服务-通知公告
  {
    path: '/notice',
    name: 'notice',
    meta: {
      title: 'notice',
    },
    component: () => import('@/pages/notice/index.vue'),
  },
  //服务-校友相册
  {
    path: '/matePictures',
    name: 'matePictures',
    meta: {
      title: 'matePictures',
    },
    component: () => import('@/pages/service/matePictures/index.vue'),
  },
  //组织-校友相册新增/修改
  {
    path: '/orgAlubm',
    name: 'orgAlubm',
    meta: {
      title: '校友相册新增/修改',
    },
    component: () => import('@/pages/orgAlubm/index.vue'),
  },
  //组织--校友相册列表
  {
    path: '/alubmList',
    name: 'alubmList',
    meta: {
      title: 'alubmList',
    },
    component: () => import('@/pages/alubmList/index.vue'),
  },

  //选择相册
  // selectAlubmt
  {
    path: '/selectAlubmt',
    name: 'selectAlubmt',
    meta: {
      title: '选择相册',
    },
    component: () => import('@/pages/selectAlubmt/index.vue'),
  },
  //添加校友相册图片
  {
    path: '/addPic',
    name: 'addPic',
    meta: {
      title: 'addPic',
      keepAlive: true,
    },
    component: () => import('@/pages/addAluPic/index.vue'),
  },
  {
    path: '/schoolmateWelfare',
    name: 'schoolmateWelfare',
    meta: {
      title: '校友福利',
      // keepAlive: true,
    },
    component: () => import('@/pages/news/index.vue'),
  },
  {
    path: '/schoolEnterpriseCooperation',
    name: 'schoolEnterpriseCooperation',
    meta: {
      title: '产学研合作',
    },
    component: () => import('@/pages/news/index.vue'),
  },
  //服务-校友期刊,校友会刊
  {
    path: '/serviceNews',
    name: 'serviceNews',
    meta: {
      title: 'news',
    },
    component: () => import('@/pages/news/index.vue'),
  },
  //服务-校史馆
  {
    path: '/historyNews',
    name: 'historyNews',
    meta: {
      title: 'news',
    },
    component: () => import('@/pages/news/index.vue'),
  },  
  {
    path: '/location',
    name: 'location',
    meta: {
      title: '相册地点',
    },
    component: () => import('@/pages/location/index.vue'),
  },
  //服务-联系我们
  {
    path: '/contactus',
    name: 'contactus',
    meta: {
      title: 'contactus',
    },
    component: () => import('@/pages/contactus/index.vue'),
  },
  //服务-理事会
  {
    path: '/council',
    name: 'council',
    meta: {
      title: 'council',
    },
    component: () => import('@/pages/council/index.vue'),
  },
  //服务-活动列表
  {
    path: '/activeList',
    name: 'activeList',
    meta: {
      title: 'activeList',
    },
    component: () => import('@/pages/activeList/index.vue'),
  },
  {
    path: '/activeDetail',
    name: 'activeDetail',
    meta: {
      title: '',
    },
    component: () => import('@/pages/activeList/detail/index.vue'),
  },  
  //activeDetail
  {
    path: '/groupsbuild',
    name: 'groupsbuild',
    meta: {
      title: 'groupsbuild',
    },
    component: () => import('@/pages/orgDetail/groupsbuild/index.vue'),
  },
  //服务-创建活动
  {
    path: '/buildAct',
    name: 'buildAct',
    meta: {
      title: 'buildAct',
    },
    component: () => import('@/pages/activeList/build/index.vue'),
  },
  //服务-活动报名
  {
    path: '/joinAct',
    name: 'joinAct',
    meta: {
      title: 'joinAct',
    },
    component: () => import('@/pages/activeList/join/index.vue'),
  },

  //预约返校-选择日期(广东XX学校)
  {
    path: '/reserveBackSchoolDate',
    name: 'reserveBackSchoolDate',
    meta: {
      title: 'reserveBackSchoolDate',
    },
    component: () => import('@/pages/reserveBackSchool/date.vue'),
  },
  //预约返校-信息(广东XX学校)
  {
    path: '/reserveBackSchoolInfo',
    name: 'reserveBackSchoolInfo',
    meta: {
      title: 'reserveBackSchoolInfo',
    },
    component: () => import('@/pages/reserveBackSchool/info.vue'),
  },  
  //预约返校-记录(广东XX学校)
  {
    path: '/reserveBackSchoolRecord',
    name: 'reserveBackSchoolRecord',
    meta: {
      title: 'reserveBackSchoolRecord',
    },
    component: () => import('@/pages/reserveBackSchool/record.vue'),
  },   
  //预约返校-详情(广东XX学校)
  {
    path: '/reserveBackSchoolDetailed',
    name: 'reserveBackSchoolDetailed',
    meta: {
      title: 'reserveBackSchoolDetailed',
    },
    component: () => import('@/pages/reserveBackSchool/detailed.vue'),
  },     

  //广东XX学校团队返校--首页
  {
    path: '/groupBackSchool',
    name: 'groupBackSchool',
    meta: {
      title: 'groupBackSchool',
    },
    component: () => import('@/pages/groupBackSchool/index.vue'),
  },     
  //广东XX学校团队返校--新增团队
  {
    path: '/addGroupBackSchool',
    name: 'addGroupBackSchool',
    meta: {
      title: 'addGroupBackSchool',
    },
    component: () => import('@/pages/groupBackSchool/groupReturn/edit.vue'),
  }, 
  //广东XX学校团队返校--新增团队--时间选择
  {
    path: '/addGroupBackSchoolDate',
    name: 'addGroupBackSchoolDate',
    meta: {
      title: 'addGroupBackSchoolDate',
    },
    component: () => import('@/pages/groupBackSchool/groupReturn/date.vue'),
  },   
    //广东XX学校团队返校--加入团队
  {
    path: '/joinGroupBackSchool',
    name: 'joinGroupBackSchool',
    meta: {
      title: 'joinGroupBackSchool',
    },
    component: () => import('@/pages/groupBackSchool/groupReturn/index.vue'),
  }, 
  //广东XX学校团队返校--团队详情
  {
    path: '/detailGroupBackSchool',
    name: 'detailGroupBackSchool',
    meta: { title: '团体信息' },
    component: () => import('@/pages/groupBackSchool/groupReturn/detail.vue'),
  },    
  //广东XX学校团队返校--记录页
  {
    path: '/recordGroupBackSchool',
    name: 'recordGroupBackSchool',
    meta: {
      title: 'recordGroupBackSchool',
    },
    component: () => import('@/pages/groupBackSchool/common/auditList.vue'),
  }, 
  //广东XX学校团队返校--团体信息
  {
    path: '/groupBackSchoolDetail',
    name: 'groupBackSchoolDetail',
    meta: { title: '团体信息' },
    component: () => import('@/pages/groupBackSchool/groupReturn/detail.vue'),
  },
  //广东XX学校团队返校--加入团体
  {
    path: '/groupBackSchoolDetailJoin',
    name: 'groupBackSchoolDetailJoin',
    meta: { title: '加入团体' },
    component: () => import('@/pages/groupBackSchool/groupReturn/join.vue'),
  },





  //服务-预约返校(非广东XX学校)
  {
    path: '/backSchool',
    name: 'backSchool',
    meta: {
      title: 'backSchool',
    },
    component: () => import('@/pages/service/backSchool/index.vue'),
  },
  {
    path: '/backSchool-ln',
    name: 'backSchool-ln',
    meta: {
      title: 'backSchool',
    },
    component: () => import('@/pages/service/backSchool/backSchool_LN/index.vue'),
  },
  //服务-预约返校中间页
  {
    path: '/backSchoolChoice',
    name: 'backSchoolChoice',
    meta: {
      title: 'backSchool',
    },
    component: () => import('@/pages/service/backSchoolChoice/index.vue'),
  },
  {
    path: '/backSchoolList',
    name: 'backSchoolList',
    meta: {
      title: 'backSchool',
    },
    component: () => import('@/pages/service/backSchoolList/index.vue'),
  },
  {
    path: '/backSchoolList-ln',
    name: 'backSchoolList-ln',
    meta: {
      title: 'backSchool',
    },
    component: () => import('@/pages/mine/myBackSchool/backSchoolList_LN/index.vue'),
  },
  {
    path: '/backSchoolDetail',
    name: 'backSchoolDetail',
    meta: {
      title: 'backSchool',
    },
    component: () => import('@/pages/service/backSchoolDetail/index.vue'),
  },
  {
    path: '/backSchoolDetail-ln',
    name: 'backSchoolDetail-ln',
    meta: {
      title: 'backSchool',
    },
    component: () => import('@/pages/mine/myBackSchool/backSchoolDetial_LN/index.vue'),
  },
  //服务-通知公告详情
  {
    path: '/noticeDetail',
    name: 'noticeDetail',
    meta: {
      title: 'noticeDetail',
    },
    component: () => import('@/pages/notice/detail/index.vue'),
  },
  //服务-校庆
  {
    path: '/xiaoqing',
    name: 'xiaoqing',
    meta: {
      title: '校庆',
    },
    component: () => import('@/pages/service/xiaoqing/index.vue'),
  },
  //服务-校庆-打call
  {
    path: '/makeCall',
    name: 'makeCall',
    meta: {
      title: '校庆',
    },
    component: () => import('@/pages/service/xiaoqing/makeCall/index.vue'),
  },
  //服务-校庆-上晚会
  {
    path: '/partyShow',
    name: 'partyShow',
    meta: {
      title: '校庆',
    },
    component: () => import('@/pages/service/xiaoqing/partyShow/index.vue'),
  },
  //服务-校庆-排行榜
  {
    path: '/chart',
    name: 'chart',
    meta: {
      title: '校庆',
    },
    component: () => import('@/pages/service/xiaoqing/chart/index.vue'),
  },
  //服务-审核功能
  {
    path: '/examine',
    name: 'examine',
    meta: {
      title: '审核',
    },
    component: () => import('@/pages/service/examine/index.vue'),
  },
  //服务-审核校友信息-列表
  {
    path: '/mate-examine',
    name: 'mate-examine',
    meta: {
      title: '校友信息审核',
    },
    component: () => import('@/pages/service/examine/exam-mate/index.vue'),
  },
  //服务-审核校友信息
  {
    path: '/mate-examine-detail',
    name: 'mate-examine-detail',
    meta: {
      title: '校友信息审核',
    },
    component: () => import('@/pages/service/examine/exam-mate/detail.vue'),
  },
  //服务-审核返校预约-列表
  {
    path: '/return-examine',
    name: 'return-examine',
    meta: {
      title: '预约返校审核',
    },
    component: () => import('@/pages/service/examine/exam-return/index.vue'),
  },
  //服务-审核返校预约
  {
    path: '/return-examine-detail',
    name: 'return-examine-detail',
    meta: {
      title: '预约返校审核',
    },
    component: () => import('@/pages/service/examine/exam-return/detail.vue'),
  },
  //服务-企业招聘-列表
  {
    path: '/recruitment',
    name: 'recruitment',
    meta: {
      title: '企业招聘',
    },
    component: () => import('@/pages/service/recruitment/index.vue'),
  },
  //服务-企业招聘-详情
  {
    path: '/recruitment-detail',
    name: 'recruitment-detail',
    meta: {
      title: '企业招聘详情',
    },
    component: () => import('@/pages/service/recruitment/detail.vue'),
  },
  //服务-创建企业招聘-企业端
  {
    path: '/recruitInpByEnterprise',
    name: 'recruitInpByEnterprise',
    meta: {
      title: '创建企业招聘',
    },
    component: () => import('@/pages/service/recruitment/edit.vue'),
  },
  //服务-创新创业-校友端
  {
    path: '/createBusiness',
    name: 'createBusiness',
    meta: {
      title: '创新创业',
    },
    component: () => import('@/pages/service/entrepreneurship/edit.vue'),
  },
  //服务-创业创新-列表
  {
    path: '/entrepreneurship',
    name: 'entrepreneurship',
    meta: {
      title: '创业创新',
    },
    component: () => import('@/pages/service/entrepreneurship/index.vue'),
  },
  //服务-创业创新-详情
  {
    path: '/entrepreneurship-detail',
    name: 'entrepreneurship-detail',
    meta: {
      title: '创业创新详情',
    },
    component: () => import('@/pages/service/entrepreneurship/detail.vue'),
  },
  //组织-活动报名
  {
    path: '/groupJoinAct',
    name: 'groupJoinAct',
    meta: {
      title: 'groupJoinAct',
    },
    component: () => import('@/pages/orgDetail/goupJoin/index.vue'),
  },
  //组织-活动报名汕大
  {
    path: '/groupActSD',
    name: 'groupActSD',
    meta: {
      title: '组织活动详情',
    },
    component: () => import('@/pages/orgDetail/groupActSD/index.vue'),
  },  
  // groupJoinActSD
  //我的-活动列表
  {
    path: '/myActlist',
    name: 'myActlist',
    meta: {
      title: '我的活动',
    },
    component: () => import('@/pages/mine/myActivities/index.vue'),
  },
  //我的-创建活动(辽师大)
  {
    path: '/activitiAdd',
    name: 'activitiAdd',
    meta: {
      title: '创建活动',
      // keepAlive: true,
    },
    component: () => import('@/pages/mine/myActivities/create.vue'),
  },
  //我的-活动详情(辽师大)
  {
    path: '/activitiDetail',
    name: 'activitiDetail',
    meta: {
      title: '活动详情',
    },
    component: () => import('@/pages/mine/myActivities/detail.vue'),
  },
  //首页-审核列表
  {
    path: '/activitiReview',
    name: 'activitiReview',
    meta: {
      title: '审核列表',
    },
    component: () => import('@/pages/activitiesReview/index.vue'),
  },
  //我的-邀请校友
  {
    path: '/inviteMate',
    name: 'inviteMate',
    meta: {
      title: '邀请校友',
    },
    component: () => import('@/pages/mine/inviteMate/index.vue'),
  },
  // 校友搜索页
  {
    path: '/schoolmate-search',
    name: 'schoolmate-search',
    meta: {
      title: '搜索',
      keepAlive: true,
    },
    component: () => import('@/pages/schoolmate-search/index.vue'),
  },
  {
    path: '/archive/index',
    name: 'archive/index',
    meta: { title: '档案服务' },
    component: () => import('@/pages/archive/index/index.vue'),
  },
  {
    path: '/archive/online',
    name: 'archive/online',
    meta: { title: '在线补办档案' },
    component: () => import('@/pages/archive/online/index.vue'),
  },
  {
    path: '/archive/read',
    name: 'archive/read',
    meta: { title: '查阅复印档案' },
    component: () => import('@/pages/archive/read/index.vue'),
  },
  {
    path: '/archive/record',
    name: 'archive/record',
    meta: { title: '档案补办记录' },
    component: () => import('@/pages/archive/record/index.vue'),
  },
  {
    path: '/archive/note',
    name: 'archive/note',
    meta: { title: '档案操作说明' },
    component: () => import('@/pages/archive/note/index.vue'),
  },
  {
    path: '/questionnaire',
    name: 'questionnaire',
    meta: { title: '调查问卷' },
    component: () => '',
  },
  // {
  //     path: '/archive',
  //     name: 'archive',
  //     redirect: '/archive/index',
  //     children: [
  //         {
  //             path: 'index',
  //             name: 'archive_index',
  //             meta: { title: '档案服务' },
  //             component: () => import('@/pages/archive/index/index.vue'),
  //         },
  //         {
  //             path: 'online',
  //             name: 'archive_online',
  //             meta: { title: '在线补办档案' },
  //             component: () => import('@/pages/archive/online/index.vue'),
  //         },
  //         {
  //             path: 'read',
  //             name: 'archive_read',
  //             meta: { title: '查阅复印档案' },
  //             component: () => import('@/pages/archive/read/index.vue'),
  //         },
  //         {
  //             path: 'record',
  //             name: 'archive_record',
  //             meta: { title: '档案补办记录' },
  //             component: () => import('@/pages/archive/record/index.vue'),
  //         },
  //         {
  //             path: 'note',
  //             name: 'archive_note',
  //             meta: { title: '档案操作说明' },
  //             component: () => import('@/pages/archive/note/index.vue'),
  //         },
  //     ],
  // },
  {
    path: '/backSchoolMonth',
    name: 'backSchoolMonth',
    meta: { title: '校友返校月' },
    component: () => import('@/pages/backSchoolMonth/index.vue'),
  },
  {
    path: '/groupReturn',
    name: 'groupReturn',
    meta: { title: '团体返校' },
    component: () => import('@/pages/backSchoolMonth/groupReturn/index.vue'),
  },
  {
    path: '/groupReturnAdd',
    name: 'groupReturnAdd',
    meta: { title: '创建团体' },
    component: () => import('@/pages/backSchoolMonth/groupReturn/edit.vue'),
  },
  {
    path: '/groupReturnDetail',
    name: 'groupReturnDetail',
    meta: { title: '团体信息' },
    component: () => import('@/pages/backSchoolMonth/groupReturn/detail.vue'),
  },
  {
    path: '/groupReturnJoin',
    name: 'groupReturnJoin',
    meta: { title: '加入团体' },
    component: () => import('@/pages/backSchoolMonth/groupReturn/join.vue'),
  },
  {
    path: '/groupReturnStatus',
    name: 'groupReturnStatus',
    meta: { title: '团体信息' },
    component: () => import('@/pages/backSchoolMonth/groupReturn/status.vue'),
  },
  {
    path: '/groupReturnEntry',
    name: 'groupReturnEntry',
    meta: { title: '报名情况' },
    component: () => import('@/pages/backSchoolMonth/groupReturn/entry.vue'),
  },
  {
    path: '/personalReturnAdd',
    name: 'personalReturnAdd',
    meta: { title: '个人返校报名' },
    component: () => import('@/pages/backSchoolMonth/personalReturn/edit.vue'),
  },
  {
    path: '/personalReturnStatus',
    name: 'personalReturnStatus',
    meta: { title: '预约成功' },
    component: () => import('@/pages/backSchoolMonth/personalReturn/status.vue'),
  },
  {
    path: '/backSchoolAuditEntry',
    name: 'backSchoolAuditEntry',
    meta: { title: '审核进度' },
    component: () => import('@/pages/backSchoolMonth/common/auditEntry.vue'),
  },
  {
    path: '/backSchoolAudit',
    name: 'backSchoolAudit',
    meta: { title: '审核进度' },
    component: () => import('@/pages/backSchoolMonth/common/auditList.vue'),
  },
  {
    path: '/backSchoolSchedule',
    name: 'backSchoolSchedule',
    meta: { title: '入校信息' },
    component: () => import('@/pages/backSchoolMonth/common/schedule.vue'),
  },
  {
    path: '/alumni-map',
    name: 'alumni-map',
    meta: { title: '校友地图' },
    component: () => import('@/pages/alumni-map/index.vue'),
  },

  {
    path: '/showQualification',
    name: 'showQualification',
    meta: { title: '修改学历' },
    component: () => import('@/pages/showQualification/index.vue'),
  },
  {
    path: '/editQualification',
    name: 'editQualification',
    meta: { title: '修改学历' },
    component: () => import('@/pages/editQualification/index.vue'),
  },
  {
    path: '/headLogoCheck',
    name: 'headLogoCheck',
    meta: { title: '头像审查' },
    component: () => import('@/pages/headLogoCheck/index.vue'),
  },
  {
    path: '/message',
    name: 'message',
    meta: {
      title: '我的消息',
      keepAlive: true,
    },
    component: () => import('@/pages/message/index.vue'),
  },
  {
    path: '/schoolmate-enterprise',
    name: 'schoolmate-enterprise',
    meta: { title: '校友企业' },
    component: () => import('@/pages/schoolmate-enterprise/index.vue'),
  },
  // enterprise-detail
  {
    path: '/enterprise-detail',
    name: 'enterprise-detail',
    meta: { title: '企业详情' },
    component: () => import('@/pages/enterprise-detail/index.vue'),
  },  
  //   enterprise-job
  {
    path: '/enterprise-job',
    name: 'enterprise-job',
    meta: { title: '企业岗位详情' },
    component: () => import('@/pages/enterprise-job/index.vue'),
  },    
  //classesManager
  {
    path: '/myClass',
    name: 'myClass',
    meta: {
      title: '我的班级',
      keepAlive: true,
    },
    component: () => import('@/pages/myClass/index.vue'),
  },  
  {
    path: '/classes',
    name: 'classes',
    meta: {
      title: '班级列表',
      keepAlive: true,
    },
    component: () => import('@/pages/classes/index.vue'),
  },  
  {
    path: '/cultural-product-list',
    name: 'cultural-product-list',
    meta: {
      title: '文创产品',
      keepAlive: true,
    },
    component: () => import('@/pages/service/cultural-product/list/index.vue'),
  },  
  {
    path: '/cultural-product-detail',
    name: 'cultural-product-detail',
    meta: {
      title: '文创产品',
      keepAlive: true,
    },
    component: () => import('@/pages/service/cultural-product/detail/index.vue'),
  },  
  {
    path: '/submission-list',
    name: 'submission-list',
    meta: {
      title: '校友投稿',
      keepAlive: true,
    },
    component: () => import('@/pages/service/submission/list/index.vue'),
  },
  {
    path: '/submission-detail',
    name: 'submission-detail',
    meta: {
      title: '我要投稿',
      keepAlive: true,
    },
    component: () => import('@/pages/service/submission/detail/index.vue'),
  },
  {
    path: '/submission-submit',
    name: 'submission-submit',
    meta: {
      title: '我要投稿',
      keepAlive: true,
    },
    component: () => import('@/pages/service/submission/submit/index.vue'),
  },
  {
    path: '/graduation-photo-list',
    name: 'graduation-photo-list',
    meta: {
      title: '毕业照',
      keepAlive: true,
    },
    component: () => import('@/pages/service/graduation-photo/list/index.vue'),
  },  
  {
    path: '/graduation-photo-detail',
    name: 'graduation-photo-detail',
    meta: {
      title: '毕业照',
      keepAlive: true,
    },
    component: () => import('@/pages/service/graduation-photo/detail/index.vue'),
  },   
];
