import router, { initMenu } from '@/router';
import { getToken, setSchoolCode, getSchoolCode, setUserStatus, setToken, setUserId, setSchoolId, getMenus, setLocalStorageItem, getSearchInfoFromLink } from '@/utils/index';
import Api, { fetchSchoolSetting } from '@/api/user';
import { useSettingStore, useMenuStore, returnSchoolConfigStore } from '@/store';
import { SchoolCode, AllowVisitorToUseSchoolList } from '@/constants/index';
import useCache from '@/hooks/useCache'
import { goLoginPage } from '@/utils/login';
import { WhiteList_LiaoShiDa, WhiteList_Normal_Login, WhiteList_Normal_NoLogin, WhiteList_Normal_NoLogin_Routes } from './white-list'

/**
 * 获取app设置
 */
const getSchoolSetting = async () => {
  try {
    const settingStore = useSettingStore();
    if (settingStore.isGetSetting || !settingStore.schoolId) return;
    useCache({
      key: 'SchoolSetting',
      service: fetchSchoolSetting,
      params: { schoolId: settingStore.schoolId },
      callback: (result: any) => {
        if (result.code == 200) {
          settingStore.setIsGetSettingObj(true);
          let { showTitle, showGroupProfilePicture, themeColor, uiMode } = result.data;
          settingStore.showTitle = showTitle;
          settingStore.showGroupProfilePicture = showGroupProfilePicture;
          settingStore.themeColor = themeColor;
          settingStore.uiMode = uiMode
          setLocalStorageItem('Cache__themeColor', themeColor)
          setLocalStorageItem('Cache__uiMode', uiMode)
        }
      }
    })
  } catch (err) { }
};
const getWebInfo = (variable: string) => {
  let query = window.location.search;
  if (query.lastIndexOf(variable) != -1) {
    let vars = query.split('&');
    for (let i in vars) {
      if (vars[i].lastIndexOf(variable) != -1) {
        return decodeURIComponent(vars[i].split(`${variable}=`)[1].replace('%20', '+'));
      }
    }
  }
  return false;
};

const iniwxCode = async (wxCode: string) => {
  let schoolCode = getSchoolCode() as string
  let method = schoolCode == SchoolCode.LiaoShiDa ? Api.audLogInfoLN : Api.audLogInfo
  const { data, code, msg } = await method({ schoolCode, wxCode });
  if (code == 200) {
    setToken(data.token)
    setUserId(data.user.userId)
    setUserStatus(data.user.userStatus)
    //生日祝福
    let birFlag = sessionStorage.getItem('birthdayReminder');
    if (birFlag && birFlag == 'pass') {
      //已经提示过生日祝福
      // console.log('已经提示过生日祝福')
    } else {
      sessionStorage.setItem('birthdayReminder', String(data.birthdayReminder));
    }
  } else if (code == 201) {
    sessionStorage.setItem('seOpenId', data);
  }
  return code
};

const initSchoolId = async (schoolCode: string) => {
  const settingStore = useSettingStore()
  if (getSchoolCode() == schoolCode && settingStore.schoolId)  return
  setSchoolCode(schoolCode)
  let { data, code, msg } = await Api.getSchoolId({ schoolCode });
  if (code == 200) {
    setSchoolId(data.schoolId)//后面有中学，getSchoolId接口需要新增一个获取学校类型的字段，储存学校类型
    settingStore.setSchoolInfoObj(data)
  }
};

/**是否刷新菜单 */
const isInitMenu = () => {
  const menuStore = useMenuStore()
  return menuStore.isGetMenu || menuStore.menu.length > 0
}

const getReturnSetting = () => {
  const settingStore = useSettingStore();
  const returnStore = returnSchoolConfigStore();
  if (!settingStore.schoolId) return;
  //预约返校配置
  returnStore.getConfigData(settingStore.schoolId);
}
//?channel=wechat_4132010333&code=021yCa2w3Dc6Q03Asf1w3EsJTv0yCa2u&state=undefined
//index.html?channel=wechat_4132010333&code=051BS40009EJJQ1JHM000kSAyo4BS40d&state=undefined#/register/first
router.beforeEach(async (to, _from, next) => {
  let schoolCode = getSchoolCode() as string
  await initSchoolId(schoolCode)
  // 获取学校id后再获取学校配置
  getSchoolSetting();
  getReturnSetting();
  // 菜单白名单
  let whiteList = WhiteList_Normal_Login
  if (schoolCode == SchoolCode.LiaoShiDa) {
    whiteList = WhiteList_LiaoShiDa
  } else if (AllowVisitorToUseSchoolList.includes(schoolCode)) {
    whiteList = WhiteList_Normal_NoLogin
    // 添加白名单路由
    WhiteList_Normal_NoLogin_Routes.forEach((item) => {
      if (!router.hasRoute(item.name)) {
        router.addRoute(item)
      }
    })
  }
  if (whiteList.includes(to.path)) {  
    next();
    return;
  }

  /**
   * 微信跳转
   */
  let wxCode = getWebInfo('code');
  if (wxCode) {
    // 修改location.search, 去除code等参数
    let url = location.href.replace(location.search, `?schoolCode=${schoolCode}`)
    history.replaceState(null, '', url)
    if (!getToken()) {
      //没有token时
      try {
        const res = await iniwxCode(wxCode);
        if (res == 200) {
          if (!isInitMenu()) {
            //解析wxCode成功，菜单权限还没初始化，
            await initMenu();
            next({...to, replace: true})
            return
          }
          next()
        } else {
          //201的话走H5的登录，不过多传seOpenId，其他情况就正常H5登录
          next({ name: 'first' });
        }
      } catch (err) {
        //封禁
        next({ name: 'first' });
      }
    } else {
      if (!isInitMenu()) {
        await initMenu();
        next({...to, replace: true})
        return
      }
      next()
    }
  } else if (!getToken()) {
    goLoginPage(true, {
      next: () => next({ name: 'first'})
    })
    return
  } else {
    if (!isInitMenu()) {
      await initMenu();
      next({...to, replace: true})
      return
    }
    next()
  }
});
