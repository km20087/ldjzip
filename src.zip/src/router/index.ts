import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router';
import { DynamicRoutes } from './list';
import Api from '@/api/user';
import { isLiaoShiDa } from '@/utils/customizedType';
import { useMenuStore } from '@/store';
import { getUserStatus, setButtons, setMenus, setUserStatus } from '@/utils';
//userStatus 00正常，01封禁，02删除，03待审核，04待完善资料，05审核失败，06-校友修改资料待审核，07-封禁的游客
const routes: Array<RouteRecordRaw> = [
  { path: '/', redirect: '/tab/index' },
  // { path: '/:catchAll(.*)', redirect: '/register/second' },
  { path: '/index', redirect: '/tab/index' },
  {
    path: '/tab',
    name: 'tab',
    component: () => import('@/pages/home/layout.vue'),
    redirect: '/tab/index',
    children: [
      {
        path: 'alumni',
        name: 'alumni',
        meta: { title: '校友' },
        component: () => import('@/pages/home/alumni.vue'),
      },
      {
        path: 'organization',
        name: 'organization',
        meta: { title: '组织' },
        component: () => import('@/pages/home/organization.vue'),
      },
      {
        path: 'index',
        name: 'index',
        meta: { title: '首页' },
        component: () => import('@/pages/home/index.vue'),
      },
      {
        path: 'service',
        name: 'service',
        meta: { title: '服务' },
        component: () => import('@/pages/home/service.vue'),
      },
      {
        path: 'mine',
        name: 'mine',
        meta: { title: '我的' },
        component: () => import('@/pages/home/mine.vue'),
      },
    ],
  },
  {
    path: '/register',
    name: 'register',
    meta: {
      title: 'register',
    },
    component: () => import('@/pages/register/index.vue'),
    children: [
      {
        path: 'first',
        name: 'first',
        component: () => import('@/pages/register/first/index.vue'),
      },
      {
        path: 'second',
        name: 'second',
        component: () => import('@/pages/register/second/index.vue'),
      },
      {
        path: 'third',
        name: 'third',
        component: () => import('@/pages/register/third/index.vue'),
      },
      {
        path: 'speFirst',
        name: 'speFirst',
        component: () => import('@/pages/register/special/first.vue'),
      },
      {
        path: 'type',
        name: 'type',
        component: () => import('@/pages/register/type/index.vue'),
      },
      {
        path: 'register_middle_first',
        name: 'register_middle_first',
        component: () => import('@/pages/register/LNSF-middle/index.vue'),
      },
      {
        path: 'register_middle_second',
        name: 'register_middle_second',
        component: () => import('@/pages/register/LNSF-middle/second.vue'),
      },
      {
        path: 'LNSF_second',
        name: 'LNSF_second',
        component: () => import('@/pages/register/LNSF-second/index.vue'),
      },
      {
        path: 'LNSF_revise',
        name: 'LNSF_revise',
        component: () => import('@/pages/register/LNSF-second/revise.vue'),
      },      
      // {
      //   path: 'speSecond',
      //   name: 'speSecond',
      //   component: () => import('@/pages/register/special/second.vue'),
      // },
    ],
  },
  {
    path: '/donateXX',
    name: 'donateXX',
    meta: {
      title: '捐赠详情',
      keepAlive: true,
    },
    component: () => import('@/pages/donateXX/index.vue'),
  },      
  //隐私协议
  {
    path: '/protocol',
    name: 'protocol',
    meta: { title: '隐私协议' },
    component: () => import('@/pages/protocol/index.vue'),
  },
  //职业
  {
    path: '/occupation',
    name: 'occupation',
    meta: { title: '职业' },
    component: () => import('@/pages/occupation/index.vue'),
  },
  {
    path: '/returnSuccess',
    name: 'returnSuccess',
    meta: {
      title: 'returnSuccess',
    },
    component: () =>
      isLiaoShiDa()
        ? import('@/pages/service/backSchool/backSchool_LN/success.vue')
        : import('@/pages/service/backSchool/success.vue'),
  },
  {
    path: '/returnFailed',
    name: 'returnFailed',
    meta: {
      title: 'returnFailed',
    },
    component: () =>
      isLiaoShiDa()
        ? import('@/pages/service/backSchool/backSchool_LN/failed.vue')
        : import('@/pages/service/backSchool/failed.vue'),
  },
  {
    path: '/loginOut',
    name: 'loginOut',
    meta: {
      title: '退出登录',
    },
    component: () => import('@/pages/loginOut/index.vue'),
  },
  {
    path: '/news',
    name: 'news',
    meta: {
      title: 'news',
    },
    component: () => import('@/pages/news/index.vue'),
  }  
];
/** 不同的学校NotFound页重定向不同页面 */
const addNotFoundRoute = () => {
  if (isLiaoShiDa()) {
    routes.push({ path: '/:catchAll(.*)', name: 'not-found', redirect: '/register/first' });
  } else {
    routes.push({ path: '/:catchAll(.*)', name: 'not-found', redirect: '/register/second' });
  }
}

const addVistor = () => {
  const userStatus = getUserStatus();
  if (userStatus && !['00', '06'].includes(userStatus)) {
    addNotFoundRoute()
  }
}
addVistor()

const router = createRouter({
  scrollBehavior(to, from, savedPosition) {
    return { top: 0 };
  },
  history: createWebHashHistory(), // history 模式则使用 createWebHistory()
  routes,
});

export const addMenu = () => {
  const menuStore = useMenuStore();
  for (let i in menuStore.menu) {
    let { name } = menuStore.menu[i];
    if (name && router.hasRoute(name)) continue;
    router.addRoute(menuStore.menu[i]); //所以我换了这种来动态加载路由
  }
  if (router.hasRoute('not-found')) {
    router.removeRoute('not-found');
    addVistor();
  }
};

export const initMenu = async () => {
  const menuStore = useMenuStore();
  let menuMap = new Map();
  let alList = <any>[];
  if (menuStore.menu.length === 0) {
    const { data, code, msg } = await Api.appAutMenu({});
    menuStore.isGetMenu = true
    if (code == 200 && data.menus) {
      setMenus(JSON.stringify(data.menus));
      setButtons(JSON.stringify(data.buttons))
      setUserStatus(data.userStatus)
      data.menus.forEach((item: any) => {
        menuMap.set(item.url, item);
      })
      DynamicRoutes.forEach((item: any) => {
        if (menuMap.has(item.path)){
          alList.push({...item})
        }
      })
      menuStore.menu = menuStore.menu.concat(alList);
    }
  }
  addMenu();
};

export const keepAliveList: string[] = (DynamicRoutes.filter(item => !!item?.meta?.keepAlive) || []).map(item => item?.name).filter(item => !!item) as string[]

export default router;
