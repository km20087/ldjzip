import { NewsRoute, NewsDetailRoute } from '@/router/list'
/**辽师 */
export const WhiteList_LiaoShiDa = [
  '/register/first',
  '/register/register_middle_first', //辽宁师范认证第一步
  '/register/register_middle_second',
  '/register/LNSF_second', //辽宁师范认证第二步
  '/register/LNSF_revise',
];
/**常规需要登录才能使用的学校的路由白名单 */
export const WhiteList_Normal_Login = [
  '/register/first',
  '/register/type', //汕大--优化注册
  '/register/second', //填写详细个人信息
  '/register/register_middle_first', //辽宁师范认证第一步
  '/register/register_middle_second',
  '/register/LNSF_second', //辽宁师范认证第二步
  '/register/LNSF_revise',
  '/submited',
  '/loginOut',
  '/protocol',
  '/occupation',
  '/returnSuccess',
  '/returnFailed',
  '/editPerInfo', //编辑信息
  '/schoolmate-enterprise',
  '/enterprise-detail',
  '/enterprise-job',
  '/donateXX',//象贤中学捐赠提示语页面
  '/tab/inex',
];

/**常规某些可以不登录使用的学校的额外的路由白名单 */
export const WhiteList_Normal_NoLogin = [...WhiteList_Normal_Login, '/', '/index', '/tab/index', '/news', '/newsDetail'];

/**常规某些可以不登录使用的学校的额外的路由 */
export const WhiteList_Normal_NoLogin_Routes = [NewsRoute, NewsDetailRoute]

