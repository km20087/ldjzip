import { createPinia } from 'pinia';
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';

const pinia = createPinia();
pinia.use(piniaPluginPersistedstate);

export default pinia;

export * from './modules/user';
export * from './modules/menu';
export * from './modules/setting';
export * from './modules/returnSchoolConfig'
export * from './modules/keepAlive'