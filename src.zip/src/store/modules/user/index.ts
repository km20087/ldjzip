import { defineStore } from 'pinia';
import { getMyActList } from '@/api/mine/index';

interface UserStore {
  name: string;
  myActivities: number;
  isNeedInitOccupation: boolean;
  occupation: Occupation;
}

export const useUserStore = defineStore({
  id: 'user', // id必填，且需要唯一。两种写法
  state: (): UserStore => {
    return {
      name: '郭**',
      myActivities: 0,
      isNeedInitOccupation: true,
      occupation: {
        code: '',
        occupationName: '',
        parentCode: '',
      },
    };
  },
  getters: {
    nameLength: (state) => state.name.length,
  },
  actions: {
    updateName(name: string) {
      this.name = name;
    },
    getMyactNum() {
      const listP = {
        pageNum: 1,
        pageSize: 10,
      };
      getMyActList(listP).then((res: any) => {
        this.myActivities = res.data.total;
        console.log(this.myActivities, 'this.myActivities');
      });
    },
  },
});
