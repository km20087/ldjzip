import { defineStore } from 'pinia';
import { IdentifyMode } from '@/constants';
import { getLocalStorageItem, getSchoolCode, getUserId, setLocalStorageItem } from '@/utils';

type TypeIdentifyMode = (typeof IdentifyMode)[keyof typeof IdentifyMode]

interface SchoolInfo {
  schoolId: string;
  schoolName: string;
  schoolLevel:string
}

interface SettingStore {
  h5Manager: string;
  canSwitchIdentify: boolean;
  identifyMode: TypeIdentifyMode;
  isGetSettingObj: Record<string, boolean>;
  showTitle: string;
  showGroupProfilePicture: string;
  uiMode: string;
  themeColor: string;
  schoolInfoObj: Record<string, SchoolInfo>;
  check?: boolean;
  imageInfo: { [propName: string]: ImageList };
  protocol: { [propName: string]: NewsData[] };
}

interface alP {
  albumName: string;
  groupsId: string;
  albumType: string;
  permissionScope: string;
  albumId: string;
  fromAlbumId: string;
  photoList: string[];
  type: string; //1---组织，0--服务
}

interface localP {
  name: string;
}

interface saveFlag {
  saveF: string;
  picList: string[];
}

interface rightFlag {
  orgR: string;
  serviceR: string;
}


/**从浏览器缓存中获取身份配置 */
function getCacheIdentifyMode(): Record<string, string> {
  let cache = getLocalStorageItem('Cache__identifyMode_config')
  return cache ? JSON.parse(cache) : {}
}
/**从浏览器缓存中获取当前身份配置 */
function getCacheIdentifyModeByUserId(userId = getUserId()) {
  return getCacheIdentifyMode()[userId || '']
}
/**设置身份配置到浏览器缓存中 */
function setCacheIdentifyMode(mode: TypeIdentifyMode) {
  let userId = getUserId()
  if (!userId) return
  setLocalStorageItem('Cache__identifyMode_config', JSON.stringify({
    ...getCacheIdentifyMode(),
    [userId]: mode
  }))
}

export const useSettingStore = defineStore({
  id: 'setting',
  state(): SettingStore {
    return {
      h5Manager: '0', // h5管理员
      canSwitchIdentify: false, // 是否可以切换身份
      // @ts-ignore
      identifyMode: getCacheIdentifyModeByUserId() || IdentifyMode.Schoolmate,
      isGetSettingObj: {},
      showTitle: '0',
      showGroupProfilePicture: '0',
      uiMode: getLocalStorageItem('Cache__uiMode') || '',
      themeColor:
        getLocalStorageItem('Cache__themeColor') || import.meta.env.VITE_THEME_COLOR || '#0570C9',
      schoolInfoObj: {},
      check: false,
      imageInfo: {},
      protocol: {},
    };
  },
  getters: {
    isGetSetting: (state) => state.isGetSettingObj[getSchoolCode()!] || false,
    schoolId: (state) => {
      let schoolCode = getSchoolCode()!;
      let info = state.schoolInfoObj[schoolCode]
      return info ? info.schoolId : ''
    },
    schoolName: (state) => {
      let schoolCode = getSchoolCode()!;
      let info = state.schoolInfoObj[schoolCode]
      return info ? info.schoolName : ''
    },
    schoolLevel:(state) => {
      let schoolCode = getSchoolCode()!;
      let info = state.schoolInfoObj[schoolCode]
      return info ? info.schoolLevel : ''
    },
    isSchoolmateMode: (state) => state.identifyMode == IdentifyMode.Schoolmate,
    isManagerMode: (state) => state.identifyMode == IdentifyMode.Manage,
    isShowTitle: (state) => state.showTitle == '1',
    isShowGroupProfilePicture: (state) => state.showGroupProfilePicture == '1',
  },
  actions: {
    setIsGetSettingObj(isGet: boolean) {
      this.isGetSettingObj[getSchoolCode()!] = isGet
    },
    setSchoolInfoObj(schoolInfo: SchoolInfo) {
      this.schoolInfoObj[getSchoolCode()!] = schoolInfo
    },
    setH5Manager(h5Manager: string) {
      this.h5Manager = h5Manager;
    },
    setCanSwitchIdentify(canSwitchIdentify: boolean) {
      this.canSwitchIdentify = canSwitchIdentify;
    },
    setIdentifyMode(identifyMode: TypeIdentifyMode) {
      this.identifyMode = identifyMode;
      setCacheIdentifyMode(identifyMode)
    },
    /**
     * 初始化用户的身份模式，同时记录相关信息
     * 判断能否切换身份： h5Manager == '1' && userStatus == '00'
     * 判断当前身份模式：localStorage没值的话，判断是否为h5管理员，再判断是否是校友，
     */
    initIdentifyMode(data: { h5Manager: string; userStatus: string, userId: string }) {
      let { h5Manager, userStatus, userId } = data;
      this.setH5Manager(h5Manager);
      let canSwitchIdentify = h5Manager == '1' && userStatus == '00';
      this.setCanSwitchIdentify(canSwitchIdentify);
      let Cache__identifyMode = getCacheIdentifyModeByUserId(userId)
      // 判断有缓存值的话就不处理
      if (Cache__identifyMode) return;
      this.setIdentifyMode(h5Manager == '1' ? IdentifyMode.Manage : IdentifyMode.Schoolmate);
    },
  },
  persist: {
    storage: sessionStorage,
  },
});

export const albumParam = defineStore({
  id: 'alubm',
  state(): alP {
    return {
      albumName: '',
      groupsId: '',
      albumType: '',
      permissionScope: '',
      albumId: '',
      fromAlbumId: '',
      photoList: [],
      type: '',
    };
  },
  persist: {
    storage: sessionStorage,
  },
});

export const locationP = defineStore({
  id: 'location',
  state(): localP {
    return {
      name: '',
    };
  },
  persist: {
    storage: sessionStorage,
  },
});

export const saveData = defineStore({
  id: 'saveF',
  state(): saveFlag {
    return {
      saveF: '0',
      picList: [],
    };
  },
  persist: {
    storage: sessionStorage,
  },
});

export const rightCon = defineStore({
  id: 'rightF',
  state(): rightFlag {
    return {
      orgR: '0',
      serviceR: '0',
    };
  },
  persist: {
    storage: sessionStorage,
  },
});
