import { defineStore } from 'pinia';
import { getReturnSchoolConfig } from '@/api/servive';
interface stateType {
  callbackOnce: boolean;
  accompanyingPersonsLimit: string;
  appointmentTimePeriod: Array<string>;
  banAppointmentTimePeriod: Array<string>;
  returnSchoolTimesLimit: string;
  returnschoolLimitedFlag: string;
  returnschoolLimitedNumber: string;
}
export const returnSchoolConfigStore = defineStore('returnSchoolConfigStore', {
  state: (): stateType => {
    return {
      callbackOnce: false, //是否已调用
      accompanyingPersonsLimit: '', //同行人数限制
      appointmentTimePeriod: [], //返校可选时段
      banAppointmentTimePeriod: [], //返校不可选时段
      returnSchoolTimesLimit: '', //每月返校频次
      returnschoolLimitedFlag: '', //限制人数开关
      returnschoolLimitedNumber: '', //限制人数
    };
  },
  actions: {
    getConfigData(schoolId: string) {
      if (this.callbackOnce) return;
      getReturnSchoolConfig({ schoolId }).then((res) => {
        if (res.code == 200) {
          this.callbackOnce = true;
          this.accompanyingPersonsLimit = res.data.accompanyingPersonsLimit;
          this.appointmentTimePeriod = res.data.appointmentTimePeriod;
          this.banAppointmentTimePeriod = res.data.banAppointmentTimePeriod;
          this.returnSchoolTimesLimit = res.data.returnSchoolTimesLimit;
          this.returnschoolLimitedFlag = res.data.returnschoolLimitedFlag;
          this.returnschoolLimitedNumber = res.data.returnschoolLimitedNumber;
        }
      });
    },
  },
});
