import { defineStore } from 'pinia';
import { keepAliveList } from '@/router';
import { nextTick } from 'vue';

export const useKeepAliveStore = defineStore({
  id: 'keepAlive',
  state() {
    return {
      cache: [...keepAliveList],
    };
  },
  actions: {
    add(name: string) {
      if (!name || this.cache.includes(name)) return;
      this.cache.push(name);
    },
    remove(name: string) {
      let index = this.cache.indexOf(name);
      index > -1 && this.cache.splice(index, 1);
    },
    /**更新缓存实体 */
    async removeCacheEntry(name: string) {
      this.remove(name);
			await nextTick()
			this.add(name);
    },
  },
  persist: {
    storage: sessionStorage,
  },
});
