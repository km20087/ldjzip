import { defineStore } from 'pinia';

export const useMenuStore = defineStore(
  'menuConfig',
  {
    state: () => {
      return {
        isGetMenu: false,
        menu: []
      };
    },
    getters: {},
    actions: {
      resetMenu() {
        this.menu = []
      }
    },
    // persist: {
    //   storage: sessionStorage,
    // },
  });
