declare interface Area {
  addrNo: string;
  addrName: string;
  hasChild: string;
  addrLevel: string;
}
