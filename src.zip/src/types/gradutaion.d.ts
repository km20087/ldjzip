declare interface graduationData {
    id: string
    graduationTitle: string
    graduationYear: string
    status: string
    graduationClass: string,
    content?:string,
    updateTime?:number | string,
    isOpen:boolean,
  }