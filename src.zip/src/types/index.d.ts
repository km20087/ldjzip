declare type WithUploadHandle<T> = T & UploadHandle

declare interface UploadHandle {
  discardUrls: string[]
  usefulUrls: string[]
}

declare interface selectOptions {
  label: string
  value: number | string
}

declare interface UploadSliceParams {
  file: File
  fileMd5: string
  sliceNo: string
  totalSliceNo: string
}
