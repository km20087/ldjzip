declare type roleCode = string | null
declare type leader = pageParams | {
    campusUserId: string
    contactInformation: string
    deptName: string
    email: string
    officeAddress: string
    position: string
    schoolId: string
    userId: string
    userName: string
}
declare type leaderShow = leader & {
    campusUserId: string
    deptName: string
    userName: string
}
declare interface leaderS {
    shoe: leaderShow
}