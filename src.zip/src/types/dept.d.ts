declare interface Dept {
  deptId: string;
  parentId: string;
  parentName: string;
  deptName: string;
  rank: string;
  remark: string;
  status: string;
  roleStatus?: any;
  deptLevel: string;
  hasChild: string;
  children?: Dept[];
  schoolId: string;
  deptType: string;
  notDeptType?: any;
  autDeptList?: any;
  deptIds?: any;
  roles?: any;
}
