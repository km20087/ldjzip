declare interface CulturalProduct {
  id: string
  title: string
  coverUrl: string
  status: string
  rank: string | number
  isTop: string | number
  detail: string
  updateTime: string
}