declare interface ImageList {
  imageType: string;
  isJump: string;
  imageTypeName: string;
  width: string;
  height: string;
  interval: string;
  images: ImageInfo[];
}

declare interface ImageInfo {
  pageNum: number;
  pageSize: number;
  pageFlag?: any;
  id: string;
  schoolId: string;
  imageName: string;
  imageType: string;
  fileAddress: string;
  sorting: string;
  status: string;
  updateTime: string;
  editor: string;
  jumpUrl: string;
  typeName?: any;
}
