declare interface tabPros {
  title: string;
  name: string;
  member: string | number;
  disabled: boolean;
}
declare interface myCreateActList {
  id: string;
  groupsId: string;
  auditStatus: string; //审核状态
  publishStatus: string; //发布状态
  status: string; //活动状态
  registrationFlag: string; //是否报名
  eventPoster: Array;
  actName: string;
  theme: string;
  applicant: string;
  currentNumberOfParticipants: string;
  startTime: string;
  endTime: string;
}
declare interface auditParams {
  auditAction: string;
  id: string;
  opinion: string;
}

declare interface Activities {
	pageNum: number;
	pageSize: number;
	id: string;
	schoolId: string;
	theme: string;
	organizer: string;
	startTime: string;
	endTime: string;
	registrationDeadline: string;
	introduction: string;
	requiredInformation: string;
	eventPoster?: any;
	oriEventPoster: string;
	status: string;
	createDate?: any;
	updateDate?: any;
	creator?: any;
	updateBy?: any;
	currentNumberOfParticipants: string;
	groupsId?: any;
	groupsName?: any;
	openFlag: string;
	auditStatus: string;
	userId?: any;
	registrationFlag: string;
	rejectTimes?: any;
	canDeleteFlag?: any;
	applicant?: any;
	actName?: any;
	schedule?: any;
	address?: any;
	publishStatus?: any;
	maximumParticipant?: any;
	attach?: any;
	admin: boolean;
	searchType?: any;
	auditResult?: any;
}