declare interface SchoolMate {
  userProfilePicture: string;
  name: string;
  schoolName: string;
  collegeName: string;
  classesName: string;
  cardExchangeStatus: string;
  cardExchangeId: string;
  schoolStartYear: string;
  schoolEndYear: string;
  cityName: string;
  mobile: string;
  isAdministrator: string;
  isPrimaryLeader: string;
  userId: string;
}
