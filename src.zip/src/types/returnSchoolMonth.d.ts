declare interface listMsg {
    icon: string
    title: string
    path: string
    query: any
    type?:string
}
declare type isHideContact = '0' | '1'
declare interface addData {
    auditStatus?: string,
    auditor?: string,
    collegeId: string,
    collegeName: string,
    contact: string,
    createBy?: string,
    createTime?: string,
    disbanded: string,
    endDate: string,
    gradeId: string,
    gradeName: string,
    groupName: string,
    groupSize: number,
    isHideContact: isHideContact,
    isVisitSchoolHistoryMuseum: isHideContact,
    registerDeadline: string,
    remark: string,
    scheduled: string,
    schoolId: string,
    startDate: string,
    updateBy: string,
    updateTime: string,
    visitDate: string,
    visitorNumber: number
    qrCode?:string
    returningReason?:string
    returningDate?:string
    returningStartTime?:string
    returningEndTime ?:string
    plateNumber?:string
    numberOfAccompanyingPersonList?:any
    auditStatus?:string
    majorName?:string
    major?:string
    creatorName?:string
    contactInformation?:string
    returnActivityId?:string
    auditOpinion?:string
    returningPersonnelName?:string
}
declare type ResultData = addData & {
    registerCount: number,
    id: string,
    isCreator: boolean,
    registered: boolean,
    status?:string,
}
declare interface searchP {
    groupName?: string,
    collegeId?: string,
    ended?: string
}
declare interface RegisterShoolMate {
    schoolmateName?: string
    gradeName?: string
    mobile?: string
    collegeName?: string
    majorName?:string
    name?:string
    entryMethod?:string
    schoolEndYear?:string
}
declare type PersonalAddData = RegisterShoolMate & {
    collegeId: string
    endTime: string
    otherDemand: string
    returnSchoolType: string
    startTime: string
    accompanyCount: number
    visitSchoolHistory: string
}