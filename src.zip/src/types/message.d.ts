declare interface MessageNotification {
  pageNum: number;
  pageSize: number;
  id: string;
  schoolId: string;
  messageType: string;
  noticeId: string;
  title?: string;
  content: string;
  isUrl?: string;
  contentUrl?: string;
  createDate: string;
  crateBy: string;
  readFlag: string;
  receiveId: string;
  author?: string;
}
