declare interface ArchiveBusinessType {
  appointmentTimePeriod: string;
  archiveType: string;
  bizType: string;
  get: string;
  getArr?: string[];
  id?: string;
  schoolId?: string;
}

declare interface ArchiveGetConfig {
  archiveType: string;
  periods?: string[];
}

declare interface ArchiveOnline {
  address: string;
  archiveType: string;
  certificateBack: string;
  certificateFront: string;
  certificateNo: string;
  certificateType: string;
  collegeId: string;
  collegeName?: string;
  contact: string;
  email: string;
  enrollmentYear: string;
  get: string;
  id?: string;
  leavingYear: string;
  majorId: string;
  majorName?: string;
  pageFlag: string;
  receiver: string;
  receiverAddress: string;
  schoolId?: string;
  schoolingLength: string;
  status: string;
  stuName: string;
  createDt?: string;
  reason?: string;
  remark?: string
}

declare interface ArchiveRead {
  alumniWarrant: string;
  appointmentTimePeriod: string;
  archiveType: string;
  certificateBack: string;
  certificateFront: string;
  collegeId: string;
  collegeName?: string;
  contact: string;
  id?: string;
  isDelegate: string;
  majorId: string;
  majorName?: string;
  pageFlag: string;
  principalCertificateBack: string;
  principalCertificateFront: string;
  principalContact: string;
  schoolId?: string;
  schoolingLength: string;
  status: string;
  stuName: string;
  createDt?: string;
  reason?: string;
  remark?: string
}
interface educationInfo {
  academicType: string;
  classesName: string;
  collegeId: string;
  collegeName: string;
  education: string;
  major: string;
  majorName: string;
  schoolStartYear: string;
  schoolingPeriod: string;
}
declare interface perInfo {
  name: string;
  collegeName: string;
  majorName?: string;
  schoolName: string;
  classes: string;
  userProfilePicture: string;
  classesName: string;
  mobile?: string;
  mobileDetail?: string
  educationInfoList: Array<Partial<educationInfo>>;
  bareheadedPhoto?: string;
  userStatus?: string

  campusUserId?: string
  sysDuties?: string
  sysName?: string
  pictureStatus?: string
  nameDetail?:string
  userNo?: string
  gender?: string
  schoolmateType?: string
  jobDepartment?: string
  jobTitle?: string
  jobDuration?: string
  schoolStartYear?:string
}
