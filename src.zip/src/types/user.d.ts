declare interface UserForm {
  name: string;
  cardNumber: string;
  mobile: string;
  graduationSchoolName: string;
  collegeId: string;
  provinceCity: string;
  detailedAddress?: string;
  employer: string;
  cardType: string;
  userProfilePicture?: string;
  studentIdNumber: string;

  provinceId: string;
  cityId: string;
  areaId: string;
  provinceName: string;
  cityName: string;
  areaName: string;
  occupationCode: string;
  occupationName: string;
  occupationParentCode: string;
  editType?: string//修改个人信息类型，1-基本信息，2-学历信息，3-职务信息
}
