declare interface Submission {
  id?: string
  title: string
  magazineColumnId: string
  schoolId?: string
  content: string
  status?: string
  attachUrl: string
  attachFileName: string
  name?: string
  createTime?: string
  // magazineColumnTitle: string
}


declare interface SubmissionType {
  id: string
  title: string
  priority: number | string
  status: string
  content: string
  isPinOnTop: string
  updateTime: string
  isOpen:boolean
}