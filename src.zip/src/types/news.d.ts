declare interface NewsData {
  pageNum: number;
  pageSize: number;
  pageFlag?: any;
  niId: string;
  schoolId: string;
  newsTitle: string;
  newsType: string;
  coverImage?: any;
  contentUrl?: any;
  whetherToStick: string;
  updateTime: string;
  editor: string;
  status: string;
  priority: number;
  clickCount: number;
  isUrl: string;
  content?: any;
  newsTypeName: string;
  author: string;
  authorDeptName: string;
  showEditor: string
  showTime: string
}
