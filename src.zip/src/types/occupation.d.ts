declare interface Occupation {
  code: string;
  occupationName: string;
  parentCode: string;
  hasChildren?: string;
  children?: Occupation[];
}
