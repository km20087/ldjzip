<template>
  <div class="schoolmate-list-wrap">
    <div class="alumnisection" v-for="(item, index) in list" :key="index">
      <fix-image
        class="bg-wrap"
        :src="imageCardList[index % imageCardLength]"
        :defaultSrc="getImg(`card_${index % 2}.png`)"
        :isOriginal="true"
        @click="emits('jump', item)"
        width="330"
        height="330"
      />
      <Avatar class="imgLogo" :src="item.userProfilePicture" @click="emits('jump', item)" />

      <div class="con" @click="emits('jump', item)">
        <p class="name">
          <span>{{ item.name }}</span>
          <img v-if="item.isPrimaryLeader == '1'" :src="fuzeren" class="ims"
        /></p>
        <div class="cosna" v-if="item.schoolName">
          <div class="ric"></div>
          <div class="daxue">{{ item.schoolName }}</div>
        </div>
        <div class="cosna">
          <div class="ric"></div>
          <div class="yuanxi"> {{ item.collegeName }}{{ item.classesName }}</div>
        </div>
        <div class="cosna">
          <div class="ric"></div>
          <div class="yuanxi">
            {{
              item.schoolStartYear
                ? item.schoolStartYear.endsWith('级')
                  ? item.schoolStartYear
                  : item.schoolStartYear + '级'
                : ''
            }}
          </div>
        </div>
      </div>
      <slot :item="item" />
    </div>
  </div>
</template>

<script lang="ts" setup>
  import Avatar from '@/components/avatar/index.vue';
  import fuzeren from '@/assets/img/fuzeren.png';
  import { getPictures } from '@/utils';
  const imageCardList = ref<string[]>([]);
  const imageCardLength = computed(() => imageCardList.value.length);
  const props = defineProps<{
    list: SchoolMate[];
  }>();

  const emits = defineEmits<{
    (e: 'jump', item: SchoolMate): void;
  }>();

  function getImg(name: string) {
    return new URL(`../../assets/schoolmate/${name}`, import.meta.url).href;
  }

  getPictures('SCHOOLMATE_CARD').then(
    (result: ImageList) => (imageCardList.value = result.images.map((item) => item.fileAddress))
  );
</script>

<style lang="less" scoped>
  .schoolmate-list-wrap {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;

    .alumnisection {
      /* 卡片宽度按容器百分比计算并预留 2vw 余量：
         两种机型/仿真壳下都稳定双列，不会因滚动条挤压宽度而换行 */
      position: relative;
      width: calc(50% - 5.5vw);
      height: 350px;
      margin: 60px 2vw 30px;
      border-radius: 8px;
      box-sizing: border-box;
      z-index: 1;
      .bg-wrap {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        overflow: hidden;
        z-index: -1;
      }
      &:nth-child(2n-1) {
        margin-left: 3vw;
      }
      .imgLogo {
        width: 88px;
        height: 88px;
        border: 2px solid #dfdfdf;
        position: absolute; /* 或 relative */
        top: 0; /* 向下移动元素自身高度的一半 */
        left: 50%; /* 向右移动元素自身宽度的一半 */
        transform: translate(-50%, -50%);
        border-radius: 50%;
        object-fit: cover;
        background: #fff;
      }
      .con {
        text-align: center;
        // height: 100%;
        padding: 0 20px;
        .name {
          padding-top: 30px;
          font-size: 30px;
          font-family: PingFangSC-Medium, PingFang SC;
          font-weight: 500;
          color: #333333;
          // justify-content: center;
          // text-align: center;
          display: flex;
          justify-content: center;
          align-items: center;
          .ims {
            margin-left: 5px;
            width: 28px;
            height: 28px;
          }
        }
        .ric {
          margin-top: 13px;
          width: 8px;
          height: 8px;
          background: linear-gradient(270deg, #eaeaea 0%, #aaa9a9 100%, #ffffff 100%);
        }
        .iniDiv {
          display: block;
          height: 30px;
          font-size: 0px;
        }
        .cosna {
          width: 100%;
          // height: 30px;
          display: flex;
          margin-bottom: 10px; // word-break: break-all;
          // display: -webkit-box;
          // -webkit-line-clamp: 2;
          // -webkit-box-orient: vertical;
          // over-flow: hidden;
          // word-wrap: break-word;
          // flex-wrap: wrap;
        }
        .daxue {
          margin-left: 8px;
          font-size: 24px;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          color: #666666;
        }
        .yuanxi {
          width: 100%;
          // height: 30px;
          margin-left: 8px;
          font-size: 24px;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          color: #666666;
          text-align: left;
          // word-break: break-all;
          word-break: break-all;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      }
    }
  }
</style>
