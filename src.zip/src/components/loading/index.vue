<template>
  <div class="custom-loading">
    <img class="img" src="./loading.png" />
  </div>
</template>

<script setup lang="ts">
  console.log('cus-loading');
</script>

<style lang="less" scoped>
  .custom-loading {
    position: fixed;
    left: 0;
    top: 0;
    z-index: 99999;
    background: #fff;
    width: 100vw;
    height: 100vh;
    display: none;
    &.show {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
  }
  .img {
    width: 100px;
    height: 100px;
    transition: all 1s ease In;
    transform: rotate(360deg);
    animation: rotation 2s linear infinite;
  }
  @keyframes rotation {
    from {
      -webkit-transform: rotate(0deg);
    }
    to {
      -webkit-transform: rotate(360deg);
    }
  }
</style>
