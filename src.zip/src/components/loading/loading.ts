import { createApp } from 'vue';
import Loading from './index.vue';

let LoadingDomId = 'custom-transition-loading';
const $loading = createApp(Loading).mount('#' + LoadingDomId);

export function show() {
  console.log('call loading show');
  $loading.$el?.classList.add('show');
}

export function hide() {
  console.log('call loading hide');
  $loading.$el?.classList.remove('show');
}
