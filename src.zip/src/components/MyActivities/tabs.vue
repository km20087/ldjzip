<template>
    <van-tabs type="card" sticky swipeable>
        <van-tab v-for="item in data" :key="item.name" :title="item.title" :name="item.name"
            :disabled="item.disabled"></van-tab>
    </van-tabs>
</template>
<script lang="ts" setup>
const props = withDefaults(
    defineProps<{
        data?: Array<Partial<tabPros>>
    }>(),
    {
        data: () => [{ title: "我发起的活动", name: "create", disabled: false }, { title: "我参加的活动", name: "join", disabled: false }]
    }
)

</script>
<style lang="less" scoped>
:deep(.van-tabs__nav--card) {
    line-height: 80px;
    margin: 0;
    border-radius: 16px;
    overflow: hidden;
    --van-tabs-default-color: var(--theme-color);
}

:deep(.van-tab--disabled) {
    opacity: .5;
}
</style>