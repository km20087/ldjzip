<template>
    <div class="list van-hairline--bottom" @click="toDetail">
        <div class="up">
            <div class="l">
                <fix-image :default-src="img1" :src="item?.eventPoster[0]" class="pic"></fix-image>
                <div class="status" v-if="actType == 'create'">
                    <div v-if="item?.auditStatus == '4'">申请驳回</div>
                    <div class="auditStatus-0" v-if="item?.auditStatus == '0'">审核中</div>
                    <div class="auditStatus-1" v-if="item?.auditStatus == '1'">审核通过</div>
                    <div class="auditStatus-3" v-if="item?.auditStatus == '2'">拒绝备案</div>
                    <div class="auditStatus-3" v-if="item?.auditStatus == '3'">草稿</div>
                </div>
                <div class="status" v-else>
                    <div class="status-1" v-if="item?.status == '1'">进行中</div>
                    <div class="status-2" v-if="item?.status == '2'">报名中</div>
                    <div class="status-3" v-if="item?.status == '3'">未开始</div>
                    <div class="status-4" v-if="item?.status == '4'">已结束</div>
                    <div class="status-5" v-if="item?.status == '5'">中止</div>
                </div>
            </div>
            <div class="r">
                <div class="tit van-multi-ellipsis--l2">{{ item.actName }}</div>
                <div class="msg">活动主题：{{ item.theme }}</div>
                <div class="msg">发起人：{{ item.applicant }}</div>
                <div class="msg">已报名：{{ item.currentNumberOfParticipants }}人</div>
                <div class="msg">活动时间：{{ item.startTime }}至{{ item.endTime }}</div>
                <div v-if="actType == 'create'">
                    <div class="btn" v-if="item?.auditStatus == '4'">查看原因</div>
                    <div class="btn btn-detail"
                        v-if="item?.auditStatus == '0' || item?.auditStatus == '2' || item?.auditStatus == '3'">查看详情</div>
                    <!-- <div class="btn btn-detail" v-if="item?.auditStatus == '2'">查看详情</div> -->
                    <div class="btn btn-publish"
                        v-if="item?.auditStatus == '1' && item?.publishStatus == '0' && item.status !== '5'">发布</div>
                    <div class="btn btn-detail"
                        v-if="item?.auditStatus == '1' && item?.publishStatus == '1' && item.status !== '5'">查看详情</div>
                    <div class="btn btn-stop"
                        v-if="item?.auditStatus == '1' && item?.publishStatus == '0' && item.status == '5'">活动中止</div>
                    <!-- <div class="btn btn-detail" v-if="item?.auditStatus == '3'">查看详情</div> -->
                </div>
                <div v-else>
                    <div class="btn btn-unjoin" v-if="item?.registrationFlag == '0'">未报名</div>
                    <div class="btn btn-joined" v-if="item?.registrationFlag == '1'">已报名</div>
                </div>
            </div>
        </div>
        <div class="down" v-if="item?.auditStatus == '4'">
            温馨提示：活动申请被驳回，请点击进入活动详情查看驳回原因，修改后可重新发起申请。当本活动被驳回三次后，活动会被自动终止。
        </div>
    </div>
</template>
<script lang="ts" setup>
import img1 from "@/assets/img/birthday.jpg"
const router = useRouter()
const props = withDefaults(
    defineProps<{
        item: Partial<myCreateActList>
        isManage?: boolean
        actType?: string
    }>(),
    {
        item: () => ({}),
        isManage: false,
        actType: "create"
    }
)
const emits = defineEmits(['toDetail'])
const toDetail = () => {
    emits('toDetail')
}
</script>
<style lang="less" scoped>
.list {
    padding: 30px 0;
    margin: 0 30px;
    font-size: 24px;

    .up {
        display: flex;

        .l {
            position: relative;
            width: 140px;
            height: 180px;
            border-radius: 16px;
            margin-right: 20px;
            overflow: hidden;

            .pic {
                width: 100%;
                height: 100%;
            }

            .status {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                line-height: 46px;
                text-align: center;
                color: #fff;
                background: #FE6F5D;

                .auditStatus-0 {
                    background: #FF8300;
                }

                .auditStatus-1 {
                    background: #0F9400;
                }

                .auditStatus-3 {
                    background: #999999;
                }

                .status-1 {
                    // color: #fff;
                    background: fade(#FE6F5D, 18%);
                }

                .status-2 {
                    background: fade(#0F9400, 18%);
                }

                .status-3 {
                    background: fade(#f0f012, 18%);
                }

                .status-4 {
                    background: #999999;
                }

                .status-5 {
                    background: #999999;
                }
            }

        }

        .r {
            position: relative;
            flex: 1;

            // max-width: 70%;
            .tit {
                font-size: 32px;
                font-weight: 500;
                color: #333;
                margin-bottom: 10px;
                max-width: 288px;
            }

            .msg {
                line-height: 36px;
                color: #666;
            }

            .btn {
                position: absolute;
                font-size: 28px;
                font-weight: 500;
                top: 0;
                right: 0;
                color: #fff;
                line-height: 60px;
                padding: 0 30px;
                background-color: #FC341B;
                border-radius: 30px;

                &-detail {
                    color: var(--theme-color);
                    background: rgba(var(--theme-color-rgb), .2);
                }

                &-publish {
                    background: var(--theme-color);
                }

                &-stop {
                    color: #666;
                    background: fade(#666, 20%);
                }

                &-joined {
                    color: #3CCF9C;
                    // background: rgba(60, 207, 156, .2);
                    background: fade(#3CCF9C, 20%);
                }

                &-unjoin {
                    color: var(--theme-color);
                    background: rgba(var(--theme-color-rgb), .2);
                }
            }
        }
    }

    .down {
        padding: 20px 0 0;
        color: #ff0000;
    }
}
</style>