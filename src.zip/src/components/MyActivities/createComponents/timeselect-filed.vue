<template>
    <div class="tr noBottom">
        <div class="preference">{{ title }}</div>
        <div class="inputArea">
            <van-field v-model="datac.startTime" input-align="center" readonly name="startTime" placeholder="点击选择"
                @click="showFun('s')" />
            <span> 至 </span>
            <van-field v-model="datac.endTime" input-align="center" readonly name="endTime" placeholder="点击选择"
                @click="showFun('e')" />
            <van-popup v-model:show="showCalendar2" position="bottom" round>
                <van-datetime-picker v-model="currentDate" type="datetime" title="选择日期" :min-date="minDate"
                    @confirm="onConfirm2" @cancel="showCalendar2 = false" />
            </van-popup>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { useVModel } from '@/hooks/useVModel';
import { fommatDate } from '@/utils/fommatDate';

const showCalendar2 = ref(false)
const currentDate = ref(new Date());
const minDate = ref(new Date());
const whatTime = ref('s')
const props = withDefaults(
    defineProps<{
        title?: string
        data?: any
    }>(),
    {
        data: () => { }
    }
)
const emit = defineEmits<{ (e: 'update:data', data: any): void }>();
const datac = useVModel(props, 'data', emit)

const showFun = (t: string) => {
    showCalendar2.value = true;
    whatTime.value = t
}
const onConfirm2 = (date: any) => {
    if (whatTime.value == 's') {
        datac.value.startTime = fommatDate(date, 'yyyy-MM-dd')
    } else {
        datac.value.endTime = fommatDate(date, 'yyyy-MM-dd')

    }
    // actForm.value.startTime = fommatDate(date, 'yyyy-MM-dd hh:mm:ss');

    showCalendar2.value = false;
};
</script>
<style lang="less" scoped>
@import './detail.less';
</style>