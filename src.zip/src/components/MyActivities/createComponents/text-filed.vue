<template>
    <div class="tr noBottom">
        <div class="preference">{{ title }}</div>
        <div class="inputArea">
            <van-field rows="1" autosize type="textarea" placeholder="(默认 管理员账号所在地区地方校友会)例如:大连校友会" v-bind="$attrs" />
        </div>
    </div>
</template>
<script lang="ts" setup>
const props = withDefaults(
    defineProps<{
        title?: string
    }>(),

    {}
)
</script>
<style lang="less" scoped>
@import './detail.less';
</style>