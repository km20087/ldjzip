<template>
    <div class="tr noBottom">
        <div class="preference">{{ title }}</div>
        <div class="inputArea">
            <van-stepper min="0" integer v-bind="$attrs" />
        </div>
    </div>
</template>

<script lang="ts" setup>
const props = withDefaults(
    defineProps<{
        title?: string
    }>(),

    {}
)
</script>
<style lang="less" scoped>
@import './detail.less';
</style>