<template>
    <div class="title" v-if="isShowTitle">{{ title }}</div>
    <van-field v-model="datac" input-align="left" rows="5" autosize type="textarea" maxlength="500" placeholder="请输入返校活动安排"
        show-word-limit v-bind="$attrs" />
</template>
<script lang="ts" setup>
import { useVModel } from '@/hooks/useVModel';

const props = withDefaults(
    defineProps<{
        data?: string
        isShowTitle?: boolean
        title?: string
    }>(),
    {
        isShowTitle: true,
        title: '返校活动安排'
    }
);
const emit = defineEmits<{ (e: 'update:data', data: String): void }>();
const datac = useVModel(props, 'data', emit)
</script>
<style lang="less" scoped>
.title {
    font-family: PingFangSC-Regular;
    font-size: var(--van-cell-font-size);
    color: #666666;
    letter-spacing: 0;
    line-height: 32px;
    margin: var(--van-cell-vertical-padding) var(--van-cell-horizontal-padding);
}

:deep(.van-field__value) {
    border: 1px solid #dfdfdf;
    border-radius: 20px;
    padding: 20px;
}
</style>