<template>
  <img :src="imgSrc" v-bind="$attrs" class="tesewe12s" />
</template>

<script lang="ts" setup name="fix-image">
const BaseFileUrl = import.meta.env.VITE_APP_PIC_BASE_URL;
const DfsFileUrl = import.meta.env.VITE_APP_API_DFS_URL;
const isDevFileServer = import.meta.env.VITE_APP_IS_DEV_FILE_SERVER;
const isDemo = import.meta.env.VITE_IS_DEMO  == '1'
const props = withDefaults(
  defineProps<{
    src?: string;
    defaultSrc?: string;
    width?: string | number;
    height?: string | number;
    /**是否展示原图 */
    isOriginal?: boolean
  }>(),
  {
    isOriginal: false
  }
);

const imgSrc = computed(() => {
  console.log('imgSrc--isDemo',isDemo)
  if(isDemo){
    if (!props.src) {
      return props.defaultSrc || '';
    }else{
      if (props.src.startsWith('http')) {
        return props.src;
      }
      return location.origin + location.pathname.replace(/index\.html/, '') + props.src
    }
  }else{
    if (!props.src) {
      return props.defaultSrc || '';
    }

    if (props.src.startsWith('http')) {
      return props.src;
    }

    let prefixUrl = /\?token/.test(props.src) ? DfsFileUrl : BaseFileUrl

    // 若配置是相对地址的话， 补充当前页面的host地址
    if (!prefixUrl.startsWith('http')) {
      prefixUrl = location.origin + prefixUrl
    }

    let src = props.src.startsWith('/') ? props.src.substring(1) : props.src;

    if (props.isOriginal) {
      return prefixUrl + src;
    }

    if (isDevFileServer === 'true') {
      return prefixUrl + src;
    }

    let fullPath = prefixUrl + src
    let u = new URL(fullPath)
    // 根据配置判断是否裁剪加密服务器的图片资源
    let isCropDfsImage = import.meta.env.VITE_APP_CROP_DFS_IMAGE === '1'
    let matchStr = isCropDfsImage ? u.pathname : fullPath
    let result = matchStr.match(/(.*)\.(png|jpeg|jpg)$/i);
    // 有传宽高且能匹配上后缀就修改src的路径，否则原样返回
    if (props.width && props.height && result) {
      let [, prePath, suffix] = result;
      return (isCropDfsImage ? u.origin : '' ) + `${prePath}_${props.width}x${props.height}.${suffix}` + u.search;
    }
  }
  
});
</script>
