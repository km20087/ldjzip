<template>
    <div class="item" @click="goPage(path, query)">
        <div class="lf">
            <img class="icon" :src="url" />
            <span class="txt">{{ title }}</span>
        </div>
        <img class="rt-icon" :src="icon" v-if="icon" />
        <div class="text-arrow" v-if="!icon">
            <span>查看详情 </span>
            <van-icon size="16" color="var(--theme-color)" name="arrow"></van-icon>
        </div>
    </div>
</template>
<script lang="ts" setup>
const router = useRouter()
const props = withDefaults(
    defineProps<{
        url?: string;
        title?: string
        icon?: string
        path?: string
        query?: any
    }>(),
    {
        url: '',
        title: '',
        icon: '',
        path: ''
    }
);

const goPage = (path: string, query?: any): void => {
    router.push({ path, query })
}

</script>
<style lang="less" scoped>
.item {
    margin: 50px 0 0;
    padding: 30px 33px;
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0px 2px 14px 0px rgba(0, 0, 0, 0.08);
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;

    .lf {
        display: flex;
        flex-direction: row;
        align-items: center;

        .icon {
            width: 100px;
            height: 100px;
        }

        .txt {
            margin-left: 43px;
            font-size: 36px;
            font-weight: 600;
            color: #3f547f;
        }
    }

    .rt-icon {
        width: 44px;
        height: 44px;
    }

    .text-arrow {
        display: flex;
        align-items: center;
        color: var(--theme-color);
        font-size: 24px;
    }
}
</style>