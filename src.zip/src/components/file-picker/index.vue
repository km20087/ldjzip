<template>
    <van-field v-model="datac" readonly name="stepper" label="校史馆参观安排" @click="showPicker = true" v-bind="$attrs"
        label-width="8.2em">
        <template #right-icon>
            <slot name="ricon"></slot>
        </template>
    </van-field>
    <van-popup v-model:show="showPicker" position="bottom" :style="{ height: 'auto' }">
        <van-picker :columns="columns" v-bind="$attrs" @cancel="showPicker = false" @confirm="onConfirm" />
    </van-popup>
</template>
<script lang="ts" setup>
import { useVModel } from '@/hooks/useVModel';

const showPicker = ref<boolean>(false)
const props = withDefaults(
    defineProps<{
        data?: String
        ricon?: boolean
        columns?: any
    }>(),
    {
        ricon: true,
        columns: []
    }
);
const emit = defineEmits<{ (e: 'update:data', data: String): void }>();
const datac = useVModel(props, 'data', emit)

const onConfirm = (v: any) => {
    datac.value = v
    showPicker.value = false
    // props.ricon = 
}
</script>