<template>
  <div ref="pdfContainer" class="pdf-container">
    <canvas
      v-for="pageNum in displayedPages"
      :data-page-number="pageNum"
      :key="pageNum"
      :ref="el => canvasRefs[pageNum - 1] = el"
      class="pdf-page"
      @click="onClickCanvas(pageNum)"
    />
  </div>
  <van-image-preview v-model:show="showPreviewImage" :images="previewImage" :startPosition="startPosition" />
</template>

<script setup lang="ts">
import { ref, watchEffect, computed } from 'vue'
import { useLoadPdf } from './useLoadPdf'
const props = withDefaults(
  defineProps<{
    isShowAllPage?: boolean
    source: string
    page?: number
  }>(),
  {
    isShowAllPage: true,
    page: 1,
  }
)

const { previewImage, canvasRefs, loadPdf, totalPages } = useLoadPdf()

const displayedPages = computed(() => (props.isShowAllPage ? totalPages.value : 1))

const showPreviewImage = ref(false)
const startPosition = ref(0)

const onClickCanvas = (pageNum: number) => {
  console.log('Clicked on page:', pageNum)
  showPreviewImage.value = true
  startPosition.value = pageNum - 1
}

watchEffect(() =>{
  loadPdf({source: props.source, isShowAllPage: props.isShowAllPage, page: props.page})
})

</script>

<style scoped></style>
