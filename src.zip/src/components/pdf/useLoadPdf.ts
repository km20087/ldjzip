import { onUnmounted, ref } from 'vue'
// @ts-ignore
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.min.js'
import workerSrc from 'pdfjs-dist/legacy/build/pdf.worker.min.js?url'

interface ILoadParams {
  source: string
  isShowAllPage?: boolean
  lazy?: boolean
  page: number
  [param: string]: any
}

export function useLoadPdf() {
  pdfjsLib.GlobalWorkerOptions.workerSrc = workerSrc
  const dpr = window.devicePixelRatio || 1

  const previewImage = ref<any>([])
  const canvasRefs = ref<Array<any>>([])
  let pdfDoc: pdfjsLib.PDFDocumentProxy
  const totalPages = ref<number>(0)
  const loadingProgress = ref(0)

  let mergeConfig = {
    source: '',
    isShowAllPage: true,
    lazy: true,
    page: 1,
  }

  let canvasStyleInfo = {
    width: 0,
    height: 0,
  }

  const loadPdf = async (params: ILoadParams) => {
    mergeConfig = { ...mergeConfig, ...params }
    const { source } = mergeConfig
    if (!source) {
      console.error('PDF source is required')
      return
    }
    let loadingTask = pdfjsLib.getDocument({
      url: source,
      cMapUrl: '/pdfjs-dist/cmaps/', // cMap文件路径，cMap文件用于支持PDF中的特殊字符集
      cMapPacked: true, // 是否使用cMap压缩文件
    })

    // 监听加载进度
    loadingTask.onProgress = (progressData: any) => {
      loadingProgress.value = Math.round((progressData.loaded / progressData.total) * 100)
      console.log(`Loading progress: ${loadingProgress.value}%`)
    }

    // 获取PDF文档
    pdfDoc = await loadingTask.promise
    totalPages.value = pdfDoc.numPages

    // 渲染页面
    await renderPage()
  }

  const renderPage = async () => {
    try {
      let { isShowAllPage, lazy, page } = mergeConfig
      if (!isShowAllPage) {
        await renderSinglePage(1)
        return
      }
      // 渲染所有页面
      for (let pageNum = 1; pageNum <= totalPages.value; pageNum++) {
        await renderSinglePage(pageNum)
      }
    } catch (err) {
      console.error('渲染页面错误:', err)
    }
  }
  const setCanvasStyleConfig = (viewport: HTMLCanvasElement) => {
    const canvas = canvasRefs.value[0]
    if (!canvas) return
    const parentNodeRect = (canvas.parentNode as HTMLElement).getBoundingClientRect()
    const rotio = parentNodeRect.width / viewport.width
    const width = viewport.width * rotio
    const height = viewport.height * rotio
    canvasStyleInfo = {
      width,
      height,
    }
  }

  const renderSinglePage = async (pageNum: number) => {
    const page = await pdfDoc.getPage(pageNum)

    // 获取canvas元素
    let canvas = canvasRefs.value[pageNum - 1]
    if (!canvas) {
      console.warn(`Canvas for page ${pageNum} not found`)
      return
    }
    const context = canvas.getContext('2d')!

    const viewport = page.getViewport({ scale: dpr })

    canvas.width = viewport.width
    canvas.height = viewport.height

    if (!canvasStyleInfo.width || !canvasStyleInfo.height) {
      setCanvasStyleConfig(viewport)
    }

    canvas.style.width = `${canvasStyleInfo.width}px`
    canvas.style.height = `${canvasStyleInfo.height}px`

    // 渲染页面
    const renderContext = {
      canvasContext: context,
      viewport: viewport,
      canvas,
    }

    await page.render(renderContext).promise
    previewImage.value[pageNum - 1 ] = canvas.toDataURL('image/png')
  }

  onUnmounted(() => {
    // 清理资源
    if (pdfDoc) {
      pdfDoc.destroy()
    }
  })

  return {
    previewImage,
    canvasRefs,
    loadPdf,
    totalPages,
  }
}
