<template>
  <van-button :color="settingStore.themeColor" v-bind="$attrs">
    <slot />
  </van-button>
</template>

<script lang="ts" setup>
  import { useSettingStore } from '@/store';
  const settingStore = useSettingStore();
</script>
