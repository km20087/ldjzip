<template>
  <div class="card" @click="jumpAl" @touchstart="touchStart" @touchend="touchEnd">
    <fix-image
      class="imgLogo"
      v-if="!props.src || /\.(png|jpeg|jpg)$/.test(props.src)"
      :src="props.src"
      :defaultSrc="picNone"
      :width="props.width"
      :height="props.height"
      :isOriginal="true"
      alt="相册封面"
    />
    <div class="video-wrap" v-else>
      <video class="imgLogo" :src="getRealFilePath(props.src)"></video>
      <van-icon class="icon-play" name="play-circle-o" />
    </div>
    <span class="albums-name"
      >{{ name }}
    </span>
    <span class="albums-num">
      <div class="numC">
          <popOrg class='imSvg'/>
          <p class="mar0">{{ number }}</p>
      </div>

      <div class='thum'>
          <!-- <van-icon name='like-o' v-if='thumbsUpCount == "0"'/> -->
          <van-icon name='like'  color='#ee0a24'/>
          <p class="poi">{{thumbsUpCount}}</p>        
      </div>
      </span>
  </div>
</template>
<script lang="ts" setup>
import picNone from "@/assets/img/picNone.png";
import popOrg from "@/assets/icons/popOrg.svg";
import { getRealFilePath } from '@/utils';

const props = defineProps({
  radius: {
    type: String,
    default: "8"
  },
  width: {
    type: String,
    default: "165"
  },
  height: {
    type: String,
    default: "165"
  },
  src: {
    type: String,
    default: () => ""
  },
  name: {
    type: String,
    default: ""
  },
  number: {
    type: String,
    default: ""
  },
  thumbsUpCount: {
    type: String,
    default: "0"
  }
});
const emit = defineEmits([
  "jumpAlubmList",
  "sureTrans",
  "touchStart",
  "touchEnd"
]);
const jumpAl = () => {
  emit("jumpAlubmList");
  emit("sureTrans");
};
const touchStart = () => {
  emit("touchStart");
};
const touchEnd = () => {
  emit("touchEnd");
};
onMounted(() => {
  console.log(props.src);
});
</script>
<style lang="less" scoped>
.imgLogo {
  width: 330px;
  height: 330px;
  border-radius: 16px;
}
.video-wrap{
  width: 330px;
  height: 330px;
  border-radius: 16px;
  position: relative;
  background-color: rgba(0,0,0,0.5);
  z-index: -1;
  .icon-play{
    position: absolute; 
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #fff;
    font-size: 80px;
  }
}
.card {
  width: 50%;
  display: flex;
  flex-direction: column;
  padding-bottom: 20px;
  align-items: center;
  font-size: 0px;
  .albums-name {
    margin-top: 20px;
    padding-left: 10px;
    display: inline-block;
    width: 100%;
    color: #333;
    font-size: 28px;
    // line-height: 80px;
    text-align: left;
    word-break: break-all;
  }
  .albums-num {
    padding-left: 10px;
    width: 100%;
    display: flex;
    justify-content: space-between;
    color: #999;
    font-size: 24px;
    text-align: left;
    .numC {
      display: flex;
      .mar0 {
        margin: 0px;
        margin-left: 10px;
      }
      .imSvg {
        width: 30px;
        height: 30px;
      }
    }

    .thum {
      display: flex;
      margin-right: 20px;
      /deep/ .van-icon {
        font-size: 30px;
      }
      text-align: center;
      .poi {
        // color: #ffffff;
        margin: 0;
        font-size: 24px;
        margin-left: 5px;
      }
    }
  }
}
</style>
