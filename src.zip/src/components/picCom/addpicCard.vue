<template>
  <div class="card" @click="jumpUrl"> <p class="iasd">新增相册</p> </div>
</template>
<script lang="ts" setup>
  import picNone from '@/assets/img/picNone.png';
  const emit = defineEmits(['jumpAddOrEditPhoto']);
  const jumpUrl = () => {
    emit('jumpAddOrEditPhoto');
  };
</script>

<style lang="less" scoped>
  .card {
    // width: 50%;
    width: 330px;
    height: 330px;
    display: flex;
    flex-direction: column;
    padding-bottom: 20px;
    // align-items: center;
    // background-color: #f5f5f5;
    border-radius: 16px;
    background: #f5f5f5 url('@/assets/img/picNone.png') no-repeat;
    background-size: 80px 80px;
    background-position: 50% 40%;
    .albums-name {
      color: #333;
      font-size: 28px;
      line-height: 80px;
    }
    .albums-num {
      color: #999;
      font-size: 24px;
    }
    .iasd {
      position: relative;
      top: 160px;
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #666666;
      text-align: center;
    }
  }
</style>
