<template>
  <div class="xiaoxun-wrap" v-if="imgSrc">
    <fix-image :key="imgSrc" class="xiaoxun" :style="cssHome.schoolMotoStyle" :src="imgSrc" />
  </div>
</template>

<script lang="ts" setup>
  import { onBeforeMount } from 'vue'
  import { homeSwipePic } from '@/api/home';
  import useCache from '@/hooks/useCache'
  import { useSkin2 } from '@/pages/home/useSkin2'

const { cssHome } = useSkin2()
  const imgSrc = ref('')

  onBeforeMount(() => {
    useCache({
      key: 'SCHOOL_MOTTO',
      service: homeSwipePic,
      params: {
        imageType: 'SCHOOL_MOTTO'
      },
      callback: ({ code, data, msg }: any) => {
        if (data?.images?.length > 0) {
          imgSrc.value = data.images[0].fileAddress
        }
      }
    })
  })

</script>

<style lang="less" scoped>
.xiaoxun-wrap{
  // margin-bottom: 60px;
  // height: 128px;
  background-color: #fff;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  .xiaoxun {
    width: 190px;
    height: 52px;
  }
}
</style>