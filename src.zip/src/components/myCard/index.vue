<template>
  <div class="content">
    <div class="back"> </div>
    <div class="tran"> </div>
    <div class="kia">
      <div class="workInfo">
        <div class="info" v-if="isLiaoShiDa()">
          <SvgPhone class="ims" />
          <span class="tips">{{ showDis(perInfoData.contactNumber || '******') }}</span>
        </div>
        <div class="info" v-else>
          <SvgPhone class="ims" />
          <span class="tips">{{ showDis(perInfoData.mobile || '******') }}</span>
        </div>
        <div class="info mar20" v-if="isLiaoShiDa()">
          <SvgQQ class="ims" />
          <span class="tips">{{ showDis(perInfoData.qq || '******') }}</span>
        </div>
        <div class="info mar20" v-else>
          <SvgWeChat class="ims" />
          <span class="tips">{{ showDis(perInfoData.wechat || '******') }}</span>
        </div>
        <div class="info mar20">
          <SvgEnvelope class="ims" />
          <span class="tips">{{ showDis(perInfoData.emailAddress || '******') }}</span>
        </div>
        <div class="info mar20">
          <SvgJob class="ims" />
          <span class="tips">{{ showDis(perInfoData.employer || '******') }}</span>
        </div>
        <div class="info mar20" v-if="isLiaoShiDa()">
          <SvgLocation class="ims" />
          <span class="tips">{{ showDis(perInfoData.residentArea || '******') }}</span>
        </div>
        <div class="info mar20" v-else>
          <SvgLocation class="ims" />
          <span class="tips">{{ showDis(perInfoData.officeAddress || '******') }}</span>
        </div>
      </div>
      <div class="perInfo">
        <div class="cardName">
          {{ perInfoData.name }}
        </div>
        <Avatar class="imgLogo" :src="perInfoData.userProfilePicture" />
        <div class="edit" @click="jumpInfoconfig" v-if="showEdit">
          <img :src="editLogo" alt="" class="ims" />
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import ApiConfig from '@/api/config';
import { reactive, ref } from 'vue';
import Avatar from '@/components/avatar/index.vue';
import editLogo from '@/assets/icons/editLogo.png';
import SvgEnvelope from '@/assets/icons/envelope.svg';
import SvgJob from '@/assets/icons/job.svg';
import SvgLocation from '@/assets/icons/location.svg';
import SvgWeChat from '@/assets/icons/weChat.svg';
import SvgPhone from '@/assets/icons/phone.svg';
import SvgQQ from '@/assets/icons/qqLogo.svg';
import { isLiaoShiDa } from '@/utils/customizedType';
interface per {
  name: string;
  schoolName: string;
  userProfilePicture: string;
  collegeName: string;
  classes: string;
  classesName: string;
  emailAddress: string;
  jobTitle: string;
  officeAddress: string;
  employer: string;
  mobile: string;
  wechat: string;
  qq: string;
  contactNumber: string;
  residentArea: string;
}
const props = defineProps<{
  perInfo: per;
  showEdit: boolean;
  cardExchangeStatus: string;
}>();
const router = useRouter();
const perInfoData = ref({
  name: '',
  schoolName: '',
  userProfilePicture: '',
  collegeName: '',
  classes: '',
  classesName: '',
  emailAddress: '',
  jobTitle: '',
  officeAddress: '',
  employer: '',
  mobile: '',
  wechat: '',
  qq: '',
  contactNumber: '',
  residentArea: '',
});
const jumpInfoconfig = () => {
  if (!props.showEdit) {
    return;
  }
  router.push({ path: '/infoConfig' });
};
const showDis = (val: any) => {
  //0-待对方确认，1-已交换，2-拒绝交换，3-待自己确认，null未发起过交换
  if (props.cardExchangeStatus == '1') {
    return val;
  } else {
    return '*****';
  }
};
// const emit = defineEmits(['jumpAlubmList', 'sureTrans', 'touchStart', 'touchEnd']);
onMounted(() => {
  perInfoData.value = props.perInfo;
});
</script>
<style lang="less" scoped>
.content {
  position: relative;
  width: 100%;
  // height: 100%;
}
.mar20 {
  margin-top: 20px;
}
.back {
  position: relative;
  width: 100%;
  height: 285px;
  background: var(--theme-color);
  // border-radius: 0 0 10% 10%;
}
.tran {
  width: 0;
  height: 0;
  border-top: 96px solid var(--theme-color);
  border-right: 50vw solid transparent;
  border-left: 50vw solid transparent;
}
.kia {
  position: absolute;
  top: 135px;
  width: 92.6%;
  left: 50%;
  padding-left: 41px;
  transform: translate(-50%, 0%);
  // margin: 0 auto;

  height: 402px;
  background: url('@/assets/img/bacCard.png') no-repeat;
  background-size: 100%;
  display: flex;
  justify-content: space-between;
  .workInfo {
    margin-top: 59px;

    width: 60%;
    .info {
      display: flex;
      // align-items: center;
      // word-break: break-all;
      flex-wrap: wrap;
      .ims {
        // width: 40px;
        // height: 40px;
        width:40px;
        height:40px;
      }
      .tips {
        width: 80%;
        margin-left: 20px;
        font-size: 28px;
        font-family: PingFang-SC-Medium, PingFang-SC;
        font-weight: 500;
        color: #222222;
        // word-wrap:;
        word-break: break-all;
        text-overflow: ellipsis;
        overflow: hidden;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2; /* 这里是超出几行省略 */
      }
    }
  }
  .perInfo {
    width: 40%;
    position: relative;
    .cardName {
      width: 100%;
      margin-top: 94px;
      text-align: center;
      border-bottom: 2px solid var(--theme-color);
      font-size: 44px;
      font-family: PingFangSC-Semibold, PingFang SC;
      font-weight: 600;
      color: #222222;
    }
    .imgLogo {
      // position: relative;
      // right: 17px;
      margin-left: 50px;
      margin-top: 39px;
      width: 130px;
      height: 130px;
      border-radius: 50%;
      object-fit: cover;
      background: #fff;
    }
    .edit {
      position: absolute;
      right: 41px;
      bottom: 31px;
      .ims {
        width: 36px;
        height: 34px;
        // width:20px;
        // height:20px;
      }
    }
  }
}
</style>
