<template>
  <div class="con">
    <div
      class="kia"
      :class="list.length > 4 ? (claFlag == index ? 'showAll pos' : 'pos') : ''"
      v-for="(item, index) in list"
      :key="index"
      @click="changeStatus(index, item)"
    >
      <div class="workInfo">
        <div class="info">
          <SvgPhone class="ims" />
          <span class="tips">{{ showDis(item.mobile || '******') }}</span>
        </div>
        <div class="info mar20">
          <SvgWeChat class="ims" />
          <span class="tips">{{ showDis(item.wechat || '******') }}</span>
        </div>
        <div class="info mar20">
          <SvgEnvelope class="ims" />
          <span class="tips">{{ showDis(item.emailAddress || '******') }}</span>
        </div>
        <div class="info mar20">
          <SvgJob class="ims" />
          <span class="tips">{{ showDis(item.employer || '******') }}</span>
        </div>
        <div class="info mar20">
          <SvgLocation class="ims" />
          <span class="tips">{{ showDis(item.detailedAddress || '******') }}</span>
        </div>
      </div>
      <div class="perInfo">
        <div class="tipState">
          <img :src="yidu" alt="" v-if="item.cardExchangeType == '0'" class="ims" />
          <img :src="changed" alt="" v-else-if="item.cardExchangeType == '1'" class="ims" />
          <img :src="yiduUnhandled" alt="" v-else-if="item.cardExchangeType == '2'" class="ims" />
          <!-- <span v-else-if="item.cardExchangeStatus == '2'" class="imais"> 已拒绝</span> -->
          <img :src="refuseChange" alt="" v-else-if="item.cardExchangeStatus == '2'" class="ims" />
        </div>
        <div class="cardName">
          {{ item.name }}
        </div>
        <Avatar class="imgLogo" :src="item.userProfilePicture" />
        <div
          class="button"
          v-if="
            !!props.cardExchangeType &&
            (item.cardExchangeType == '2' || item.cardExchangeType == '0')
          "
        >
          <div class="iad" @click="refuseHandle(item.cardExchangeId)">
            <SvgAgree class="ims" />
            <span class="font">拒绝</span>
          </div>
          <div class="iad" @click="agreeHandle(item.cardExchangeId)">
            <SvgAgree class="ims" />
            <span class="font">同意</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
  import { reactive, ref } from 'vue';
  import Avatar from '@/components/avatar/index.vue';
  import SvgAgree from '@/assets/icons/agree.svg';
  import SvgRefuse from '@/assets/icons/refuse.svg';
  import bacCard from '@/assets/img/bacCard.png';
  import editLogo from '@/assets/icons/editLogo.png';
  import SvgEnvelope from '@/assets/icons/envelope.svg';
  import SvgJob from '@/assets/icons/job.svg';
  import SvgLocation from '@/assets/icons/location.svg';
  import SvgWeChat from '@/assets/icons/weChat.svg';
  import SvgPhone from '@/assets/icons/phone.svg';
  import yidu from '@/assets/img/yidu.png';
  import changed from '@/assets/img/changed.png';
  import refuseChange from '@/assets/img/refuseChange.png';
  import yiduUnhandled from '@/assets/img/yiduUnhandled.png';
  import { Toast } from 'vant';
  import Api, { per } from '@/api/schoolmate';
  const router = useRouter();
  const props = defineProps<{
    perInfo: per[];
    cardExchangeStatus?: string;
    cardExchangeType: string | undefined;
  }>();

  //cardExchangeType----校友名片交换状态类型   0-收到的未读名片，1-收到的已交换名片，2-收到的未交换名片
  const emit = defineEmits(['giveCard', 'refuseCard']);
  const list = ref([] as per[]);
  const claFlag = ref(0);
  const changeStatus = (index: number, val: any) => {
    // claFlag.value = index;
    // return;
    if (claFlag.value != index && list.value.length > 4) {
      claFlag.value = index;
    } else {
      if (val.cardExchangeType == '1') {
        router.push({ path: '/agreeAlumniCard', query: { userId: val.userId } });
      }
    }
  };
  const exP = ref({
    id: '', //名片交换记录id
    exchangeResult: '', //0-拒绝，1-同意
  });
  const showDis = (val: any) => {
    //0-待对方确认，1-已交换，2-拒绝交换，3-待自己确认，null未发起过交换
    if (props.cardExchangeStatus == '1') {
      return val;
    } else {
      return '*****';
    }
  };
  const refuseHandle = (id: string) => {
    emit('refuseCard', id);
    // console.log(props);
    // console.log(emit);
  };
  const agreeHandle = (id: string) => {
    emit('giveCard', id);
  };
  onBeforeMount(() => {
    list.value = props.perInfo;
    console.log(list.value);
  });
</script>
<style lang="less" scoped>
  .con {
    width: 100%;
    height: 100%;
    overflow-y: scroll;
  }
  .pos {
    // position: relative;
    // top: -193px;
    //193px
    height: 209px !important;
    overflow-y: hidden;
  }
  // .pos:nth-child(2) {
  //   height: 402px !important;
  // }
  .showAll {
    height: 402px !important;
  }
  .kia {
    padding-left: 45px;
    width: 92.6%;
    margin: 0 auto;
    height: 402px;
    background: url('@/assets/img/bacCard.png') no-repeat;
    background-size: 100%;
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
    // box-shadow: 10px 10px 10px rgba(0, 0, 0, 0.5);
    // box-shadow: 1px 10px #000;
    .workInfo {
      padding-top: 58px;
      // margin-top: 59px;

      width: 60%;
      .mar20 {
        margin-top: 20px;
      }
      .info {
        display: flex;
        // align-items: center;
        // word-break: break-all;
        flex-wrap: wrap;
        .ims {
          width: 40px;
          height: 40px;
        }
        .tips {
          width: 80%;
          margin-left: 20px;
          font-size: 28px;
          font-family: PingFang-SC-Medium, PingFang-SC;
          font-weight: 500;
          color: #222222;
          // word-wrap:;
          word-break: break-all;
          text-overflow: ellipsis;
          overflow: hidden;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2; /* 这里是超出几行省略 */
        }
      }
    }
    .perInfo {
      width: 40%;
      position: relative;
      .weidu {
        color: #dadde2;
        background: #dadde2;
      }
      .yidu {
      }
      .changed {
      }
      .tipState {
        position: absolute;
        top: 0px;
        right: 0px;
        // width: 124px;
        height: 50px;
        line-height: 50px;
        text-align: center;
        .ims {
          height: 50px;
          width: auto;
        }
        .imais {
          width: 130px;
          height: 50px;
          text-align: center;
          line-height: 50px;
          font-size: 18px;
          font-weight: 500;
          background-color: rgb(253, 226, 226);
          color: #f56c6c;
          border-radius: 0px 18px;
          display: inline-block;
        }
      }
      .cardName {
        width: 100%;
        margin-top: 80px;
        text-align: center;
        border-bottom: 2px solid #035790;
        font-size: 44px;
        font-family: PingFangSC-Semibold, PingFang SC;
        font-weight: 600;
        color: #222222;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .imgLogo {
        // position: relative;
        // right: 17px;
        margin-left: 50px;
        margin-top: 39px;
        width: 130px;
        height: 130px;
        border-radius: 50%;
        object-fit: cover;
        background: #fff;
      }
      .button {
        width: 100%;
        display: flex;
        justify-content: space-around;
        align-items: center;
        .iad {
          display: flex;
          align-items: center;
          width: 106px;
          height: 44px;
          background: #f1f4f6;
          box-shadow: 1px 1px 8px 0px rgba(0, 0, 0, 0.04);
          border-radius: 22px;
          text-align: center;
          line-height: 44px;

          .ims {
            // margin-left: 14px;
            margin-left: 15%;
            width: 26px;
            height: 26px;
            // position: relative;
            // top: 10%;
          }
          .font {
            font-size: 24px;
            font-family: PingFangSC-Medium, PingFang SC;
            font-weight: 500;
            color: #035790;
          }
        }
      }
    }
  }
</style>
