<template>
  <XiaoXun />
  <div class="fix-bottom-cont" :style="{background: fixBottomContBg}"></div>
  <div class="bottom-cont">
    <van-tabbar v-model="active" inactive-color="#666666" @change="onChange">
      <van-tabbar-item v-for="(item, index) in dataList" :key="index" :name="item.name">
        <span class="circle-container" v-if="item.label == '我的' && tipFlag && schoolCode !== SchoolCode.GuangWenYi"> </span>
        <van-tag class="redNum" v-if="item.label == '我的' && unReadCount > 0 && schoolCode == SchoolCode.GuangWenYi" type="danger" round>{{ unReadCount }}</van-tag>
        <span>{{ item.label }} </span>
        <template #icon="props">
          <div v-if="item.name == 'index'" class="baricon-index" :class="{'baricon-index-label': homeLabel.length > 0}">
            <img :src="logoImg" class="bansize" alt="logo" />
          </div>       
          <component v-else :is="item.svg" class="smalltab"
            :style="{ fill: props.active ? 'var(--theme-color)' : '#bfbfbf' }" />
        </template>
      </van-tabbar-item>
    </van-tabbar>
  </div>
</template>
<script lang="ts" setup>
import { ref } from "vue";
import { appAutMenu } from "@/api/user";
import { initMenu } from "@/router";
import { useRouter } from 'vue-router'
import { useMenuStore, useSettingStore } from "@/store";
import { DynamicRoutes } from "@/router/list";
import { getPendingAuditStatus } from "@/api/my";
import useCache from '@/hooks/useCache'
import { homeSwipePic } from '@/api/home'
import { useDataList } from './useDataList'
import XiaoXun from '@/components/xiaoxun/index.vue'
import { getSchoolCode, getToken, getUserStatus, setButtons, setMenus, setUserStatus } from '@/utils'
import { SchoolCode } from "@/constants";
import { isAllowVisitorToUseSchool } from "@/utils/customizedType";
import { Dialog } from "vant";
import { goLoginPage } from "@/utils/login";
import { useUnRead } from '@/pages/home/useUnRead';
const { getUnReadCount, unReadCount } = useUnRead();
const router = useRouter()
const isDemo = import.meta.env.VITE_IS_DEMO  == '1'
const schoolCode = getSchoolCode()

const settingStore =  useSettingStore()

const { homeLabel, dataList, dataListToObj } = useDataList()

const fixBottomContBg = computed(() => {
  if (active.value != 'index') return 'transparent'
  return schoolCode == SchoolCode.GuangWenYi || SchoolCode.XiangXianZhongXue ? '#fff' : 'rgba(0, 0, 0, 0.04)'
})

const setGuangWenYi_MineCss = ()=>{
  if(schoolCode == SchoolCode.GuangWenYi){
    getUnReadCount();
  }
}

const props = defineProps<{
  active: string;
}>();
const active = ref(props.active);
const tipFlag = ref(false);
const picUrl = process.env.VITE_APP_PIC_BASE_URL;

function onChange(name: string) {
  let to = dataListToObj.value[name]
  if (isAllowVisitorToUseSchool() && !getToken() && to != '/tab/index'){
    Dialog.confirm({ title: '温馨提示', message: '该功能需登录后方可使用，是否跳转登录页' })
      .then(() => {
        goLoginPage();
      })
      .catch(() => {
        active.value = 'index'
      });
    return 
  }
  router[isReplace(to) ? 'replace' : 'push'](to)
}

const initAppMenu = async () => {
  let userCode = getUserStatus() as string;
  const menuUrlList = useMenuStore();
  if (
      (settingStore.isSchoolmateMode && userCode != "00")  || 
      (settingStore.isManagerMode && menuUrlList.menu.length == 0)
  ){
    sessionStorage.setItem("setTime", JSON.stringify(new Date().getTime()));
    useCache({
      key: 'appAutMenu',
      service: appAutMenu,
      params: {},
      callback: ({code, data, msg}: any) => {
        if (code == 200) {
          setUserStatus(data.userStatus as string);
          setMenus(JSON.stringify(data.menus));
          setButtons(JSON.stringify(data.buttons));
          let menulist = [...(data.menus || [])]
          let alList = <any>[];
          for (let i in menulist) {
            for (let u in DynamicRoutes) {
              if (menulist[i].url == DynamicRoutes[u].path) {
                alList.push({
                  ...DynamicRoutes[u]
                });
                break
              }
            }
          }
          menuUrlList.menu = menuUrlList.menu.concat(alList);
          initMenu();
        }
      }
    })
  }
};

/**要是跳转注册类型页则不使用replace模式进行跳转，其他路由则使用replace模式跳转页面 */
function isReplace(rou: string) {
  return !['/register/type', "/register/register_middle_first"].includes(rou)
}

const logoImg = ref("");

onMounted(async () => {
  console.log("onMounted-bottom");
  setGuangWenYi_MineCss()
  // 非游客学校 或者 已经登录的用户
  if (!isAllowVisitorToUseSchool() || getToken()) {
    initAppMenu();
  }
  if (props.active == 'mine') {
    useCache({
      key: 'getPendingAuditStatus',
      service: getPendingAuditStatus,
      params: {},
      callback: ({data}: any) => {
        tipFlag.value = data;
      }
    })
  }
  
  useCache({
    key: 'HOME_BOTTOM_ICON',
    service: homeSwipePic,
    params: {
      imageType: 'HOME_BOTTOM_ICON'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        if (data.images.length > 0 && !isDemo) {
          logoImg.value = picUrl + data.images[0].fileAddress
        }else{
           logoImg.value = data.images[0].fileAddress
        }

      }
    }
  })
});
</script>
<style lang="less" scoped>
// .xiaoxun-wrap{
//   margin-top: 60px;
//   display: flex;
//   flex-direction: row;
//   justify-content: center;
//   .xiaoxun {
//     width: 410px;
//     height: 52px;
//   }
//   }
.van-hairline--top-bottom:after {
  border-width: 0 !important;
}
.fix-bottom-cont {
  padding-top: 154px;
}
.bottom-cont {
  width: 750px;
  height: 154px;
  position: fixed;
  background-image: url("@/assets/img/old_PX@1x.png");
  background-size: 100%;
  background-repeat: no-repeat;
  background-position: center center;
  left: 0;
  bottom: 0;
  z-index: 9999;

  :deep(.van-tabbar) {
    position: fixed;
    --van-tabbar-height: 98px;
    &::before {
      content: "";
      position: absolute;
      left: 0;
      top: -56px;
      width: 750px;
      height: 154px;
      background-image: url("@/assets/img/old_PX@1x.png");
      background-size: 100%;
      background-repeat: no-repeat;
      background-position: center center;
      z-index: -1;
    }
  }

  :deep(.van-tabbar-item) {
    position: relative;
  }
  :deep(.van-badge--top-right){
    transform: translate(70%,-40%);
  }
  .smalltab {
    width: 40px;
    height: 40px;
  }

  

  .baricon-index {
    display: flex;
    justify-content: center;
    align-items: center;
    padding-bottom: 20px;
    .bansize {
      width: 92px;
      height: 92px;
    }
    &.baricon-index-label{
      margin-top: -38px;
      padding: 0;
      .bansize{
        width: 84px;
        height: 84px;
      }
    }
  }
  
}

.circle-container {
  position: absolute;
  right: 50px;
  top: 10px;
  display: inline-block;
  width: 14px;
  height: 14px;
  background: #ff0000;
  border-radius: 50%;
  // position: relative;
  // top: -2px;
}
.redNum{
  position: absolute;
  // transform: translate(70%,-40%);
  right: 30px;
  top: 10px;
}
</style>
