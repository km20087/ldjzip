import SvgXiaoYou from '@/assets/tab/xiaoyou.svg?component';
import SvgZuZhi from '@/assets/tab/zuzhi.svg?component';
import SvgFuWu from '@/assets/tab/fuwu.svg?component';
import SvgWoDe from '@/assets/tab/wode.svg?component';
import SvgZhaoXiaoYou from '@/assets/tab/zhaoxiaoyou.svg?component';
import { getToken, getUserStatus } from '@/utils/index';
import { useGoIdentifyPage } from '@/pages/home/useGoIdentifyPage';
import { storeToRefs } from 'pinia';
import { useSettingStore } from '@/store';
import { getSchoolCode } from '@/utils'
import { SchoolCode, UseSkin2SchoolList, ShowHomeLabelSchoolList } from "@/constants";
import { isAllowVisitorToUseSchool } from '@/utils/customizedType';

export function useDataList() {
  const schoolCode = getSchoolCode()
  const settingStore = useSettingStore();
  const { isManagerMode } = storeToRefs(settingStore);
  const { getIdentifyPath } = useGoIdentifyPage();

  const homeLabel = computed(() => {
    return ShowHomeLabelSchoolList.includes(schoolCode!) ? '首页' : ''
  })

  const dataList = computed(() => {
    let token = getToken()
    // let mineLabel = '认证'
    let mineLabel = '我的'
    if (isAllowVisitorToUseSchool() && !token) { // 未登录游客
      mineLabel = '我的'
    } else if ((token && getUserStatus() != '04' && getUserStatus() != '05') || isManagerMode.value) {
      mineLabel = '我的'
    } 

    const NormalTabList = [
      { svg: SvgXiaoYou, label: '校友', name: 'alumni', type: 'normal', to: '/tab/alumni' },
      {
        svg: SvgZuZhi,
        label: '组织',
        name: 'organization',
        type: 'normal',
        to: '/tab/organization',
      },
      { svg: '', label: homeLabel.value, name: 'index', type: 'noFont', to: '/tab/index' },
      { svg: SvgFuWu, label: '服务', name: 'service', type: 'normal', to: '/tab/service' },
      { svg: SvgWoDe, label: mineLabel, name: 'mine', type: 'normal', to: getMyRoutePath() },
    ];
    const Skin2TabList = [
      { svg: SvgFuWu, label: '服务大厅', name: 'service', type: 'normal', to: '/tab/service' },
      {
        svg: SvgZuZhi,
        label: '组织',
        name: 'organization',
        type: 'normal',
        to: '/tab/organization',
      },
      { svg: '', label: homeLabel.value, name: 'index', type: 'noFont', to: '/tab/index' },
      { svg: SvgZhaoXiaoYou, label: '找校友', name: 'alumni', type: 'normal', to: '/tab/alumni' },
      { svg: SvgWoDe, label: mineLabel, name: 'mine', type: 'normal', to: getMyRoutePath() },
    ];   
    if (UseSkin2SchoolList.includes(schoolCode!)){      
      return Skin2TabList
    }else{
      return NormalTabList
    }
  });

  const dataListToObj = computed<Record<string, string>>(() => dataList.value.reduce((obj: any, item) => (obj[item.name] = item.to, obj), {}))

  function getMyRoutePath() {
    if (isManagerMode.value) return '/tab/mine';
    const userStatus = getUserStatus() as string;
    //00正常，01封禁，02删除，03待审核，04待完善资料，05审核失败，06-校友修改资料待审核，07-封禁的游客;
    if (userStatus == '00' || userStatus == '06') {
      return '/tab/mine';
    } else if (userStatus == '03' || userStatus == '06' || userStatus == '05') {
      return '/submited';
    } else if (userStatus == '04') {
      return getIdentifyPath();
    } else {
      return '/index';
    }
  }

  return {
    homeLabel,
    dataList,
    dataListToObj,
  };
}
