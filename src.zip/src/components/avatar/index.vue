<template>
  <fix-image v-if="src" :src="src" width="200" height="200" alt="头像" v-bind="$attrs" />
  <DefaultAvatar v-else v-bind="$attrs" />
</template>

<script setup lang="ts">
  import DefaultAvatar from '@/assets/mine/default-avatar.svg';
  import { reactive, ref } from 'vue';
  import { SchoolCode } from '@/constants';  
  import { getSchoolCode } from '@/utils';
  const schoolCode = getSchoolCode();
  const props = withDefaults(
    defineProps<{
      src?: string;
    }>(),
    {
      src: '',
    }
  );
</script>
