<template>
    <van-field v-model="datac" readonly clickable name="calendar" label="日历" placeholder="点击选择日期"
        @click="showCalendar = true" v-bind="$attrs">
        <template #right-icon v-if="ricon">
            <slot name="ricon"></slot>
        </template>
    </van-field>
    <van-calendar v-model:show="showCalendar" color="var(--theme-color)" @confirm="onConfirm" />
</template>
<script lang="ts" setup>
import { useVModel } from '@/hooks/useVModel';

const showCalendar = ref<boolean>(false)
const props = withDefaults(
    defineProps<{
        data?: string
        ricon?: boolean
    }>(),
    {
        ricon: true
    }
);
const emit = defineEmits<{ (e: 'update:data', data: string): void }>();
const datac = useVModel(props, 'data', emit)
const onConfirm = (v: any) => {
    datac.value = `${v.getFullYear()}-${v.getMonth() + 1}-${v.getDate()}`
    showCalendar.value = false
}
</script>