<template>
  <van-uploader v-if="hasDefaultSlot" :before-read="beforeRead" :accept="accept" v-bind="$attrs">
    <slot />
  </van-uploader>
  <van-uploader v-else :before-read="beforeRead" :accept="accept" v-bind="$attrs" />
</template>

<script setup lang="ts">
  import { computed, useSlots } from "vue";
  import Compressor from "compressorjs";
  import { Toast } from 'vant';
  import { ExtensionToMineTypeObj } from '@/constants'

  const slot = useSlots();
  const hasDefaultSlot = computed(() => "default" in slot);

  const props = withDefaults(
    defineProps<{
      checkOrientation?: boolean
      accept?: string
      maxSize?:number
    }>(),
    {
      checkOrientation: true,
      accept: '.jpg,.jpeg,.png',
      maxSize:0
    }
  );

  const typeLimit = computed(() => {
    return props.accept.split(',').reduce((arr: string[], item: string) => (arr.push(...(ExtensionToMineTypeObj[item.substring(1)] || [])), arr), [])
  })

  const typeLimitMsg = computed(() => {
    return '文件规格仅限' + props.accept.split(',').map((item: string) => (item.substring(1))).join(',')
  })

  function beforeRead(file: File | File[]): Promise<any> | undefined {
    // console.log('beforeRead', file)
    if (Array.isArray(file)) {
       let promiseArr = []
      for(let i in file){
        if(!typeLimit.value.includes(file[i].type)){
          Toast.fail(typeLimitMsg.value);
          return
        }else{
          promiseArr.push(preProcessFile(file[i]));
        }
      }
      return Promise.all(promiseArr);
    } else {
      if(props.maxSize > 0 && file.size > props.maxSize){
        let num = props.maxSize/1024/1024
        Toast.fail(`文件大小不能大于${num}MB`);
        return
      }
      if(typeLimit.value.includes(file.type)){
        return preProcessFile(file)
      }else{
        Toast.fail(typeLimitMsg.value);
        return
      }
    }
  }

  /**
   * 统一将文件后缀从大写转成小写
   * @param file 
   */
   function formatFileName(file: File) {
    const arr = file?.name.split('.')
    const typeName = arr.pop()!.toLowerCase()
    const newName = arr.join('') + '.' + typeName
    const newFile = new File([file], newName, {
      type: file.type
    })
    return newFile;
  }

  function preProcessFile(file: File) {
    file = formatFileName(file)
    return file.type.startsWith('image') ? compress(file) : Promise.resolve(file)
  }

  function compress(file: File) {
    return new Promise(resolve => {
      // compressorjs 默认开启 checkOrientation 选项 会将图片修正为正确方向
      new Compressor(file, {
        quality: 0.8, // 仅对jpeg、webp图片生效
        convertTypes: ['image/png', 'image/jpg'],
        convertSize: props.maxSize,
        checkOrientation: props.checkOrientation,
        success(data: any) {
          let dataType = Object.prototype.toString
            .call(data)
            .slice(8, -1)
            .toLowerCase();
          resolve(
            dataType == "blob"
              ? new window.File([data], data.name, { type: data.type })
              : data
          );
        },
        error(err) {
          console.log("compressor err", err);
        }
      });
    });
  }
</script>
<style lang="less" scoped>
  .tips {
    position: absolute;
    bottom: 20px;
    // width:550px;
    font-size: 14px;
    color: #ee0a24;
    top: 100%;
    left: 30%;
    transform: translate(-50%, -20%);
  }
</style>