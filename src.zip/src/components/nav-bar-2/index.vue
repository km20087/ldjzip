<template>
  <van-nav-bar class="nav" v-bind="$attrs" />
  <div class="fix-nav" />
</template>

<style lang="less" scoped>
  .nav {
    width: 100vw;
    position: fixed;
    left: 0;
    top: 0;
  }
  .fix-nav {
    width: 1px;
    height: var(--van-nav-bar-height);
  }
</style>
