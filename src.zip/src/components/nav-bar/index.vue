<template>
  <van-nav-bar v-if="isShowTitle" v-bind="$attrs" />
</template>

<script setup lang="ts">
  import { useSettingStore } from '@/store';
  import { storeToRefs } from 'pinia';

  const settingStore = useSettingStore();
  const { isShowTitle } = storeToRefs(settingStore);
</script>

<style></style>
