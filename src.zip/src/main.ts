import App from './App.vue';
import router, { initMenu } from '@/router';
import store from '@/store';
import 'amfe-flexible';
import 'vant/lib/index.css';
import '@/styles/index.less';
import '@/router/permission';
import FixImage from '@/components/fix-image/index.vue';
import CompressUploader from '@/components/compress-uploader/index.vue';
import NavBar from '@/components/nav-bar/index.vue';
import NavBar2 from '@/components/nav-bar-2/index.vue';
import Vant from 'vant';
// import { ifMinProgram, setSchoolCode, setToken } from './utils';
// import trackPoint from './utils/track-point';
import { useGoIdentifyPage } from '@/pages/home/useGoIdentifyPage'
import Api, { LoginParams, sendParams } from '@/api/user';
// import { getToken } from '@/utils/index';
import { ifMinProgram, setSchoolCode, getSchoolCode, getSchoolId, MenuKey, removeSessionStorageItem, setButtons, setMenus, setToken, getToken,setUserId, setUserInfo, setUserStatus } from '@/utils';



function render() {
  const app = createApp(App);

  app.use(router);
  app.use(Vant);
  app.use(store);
  // trackPoint.run(router)
  app.component('FixImage', FixImage);
  app.component('CompressUploader', CompressUploader);
  app.component('NavBar', NavBar);
  app.component('NavBar2', NavBar2);

  app.mount('#app');
}

async function _init() {
  // let isMiniProgram = ifMinProgram()
  // let params = new URLSearchParams(window.location.search);
  // let token = params.get('token')
  // let schoolCode = params.get('schoolCode')
  // let channel = params.get('channel')
  // let userStatus = params.get('userStatus')
  // const PassChannel = ['emt']
  // // 常熟的逻辑， 暂时弃用
  // // if (!schoolCode && channel && channel.startsWith('wechat_')) {
  // //   schoolCode = channel.split('wechat_')[1] || '';
  // // }
  // schoolCode && setSchoolCode(schoolCode)
  // if (
  //   (isMiniProgram && !token) || 
  //   (!isMiniProgram && (!channel || !PassChannel.includes(channel)))
  // ) {
  //   render()
  //   return
  // }
  // setToken(token)
  // const { getIdentifyPath } = useGoIdentifyPage()
  // if (channel && PassChannel.includes(channel)) {
  //   location.hash = userStatus == '04' ? `#${getIdentifyPath()}`  : ''
  // }
  render()


   }
_init()