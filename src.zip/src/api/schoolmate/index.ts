import http, { res } from '@/utils/http/index';
// import trackPoint from '@/utils/apiTrack';
// h5校友列表接口
export interface mate {
  type?: string;
  keyWord?: string;
  major?: string;
  collegeId?:string;
  pageSize?: number;
  pageNum?: number;
}
export interface cardParam {
  cardExchangeStatus?: number | string; // ，0-待对方确认，1-已交换，2-拒绝交换，3-待自己确认
  cardExchangeSendType?: string; // 校友名片交换发起类型   0-我发起的，1-我收到的
  cardExchangeType?: string; //校友名片交换状态类型   0-收到的未读名片，1-收到的已交换名片，2-收到的未交换名片
  pageSize?: number;
  pageNum?: number;
}
export interface exchangeParam {
  userId: string;
  exchangeResult: string;
}

export interface exchangeParam2 {
  id: string;
  exchangeResult: string;
}

//cardExchangeId
// /appSchoolmate/getSchoolmateCard
export interface userParam {
  userId?: string;
}
export interface per {
  name: string;
  schoolName: string;
  userProfilePicture: string;
  collegeName: string;
  classes: string;
  classesName: string;
  emailAddress: string; //邮箱
  jobTitle: string; //职务
  detailedAddress: string; //  详细地址
  employer: string; //单位名称
  mobile: string; //联系方式
  cardExchangeType?: string;
  cardExchangeId: string;
  wechat?: string;
  cardExchangeStatus?: string;
  // cardExchangeType?:string
}

export interface cardFlagP {
  exchangeCardFlag: string; //0-不允许，1-允许
}

export default {
  async listCollegeAndMajorByKeyword(params: { keyWord: string }) {
    return await http.post<res>('/appSchoolmate/listCollegeAndMajorByKeyword', params);
  },
  async getSchoolMate(params: mate) {
    let type:string | number = params.type || ""
    // trackPoint.run('/appSchoolmate/getSchoolmate',type)
    return await http.post<res>('/appSchoolmate/getSchoolmate', params);
  },
  async getSchoolmateCardExchange(params: cardParam) {
    return await http.post<res>('/appSchoolmateCard/getSchoolmateCardExchange', params);
  },
  async exchangeSchoolmateCard(params: exchangeParam) {
    return await http.post<res>('/appSchoolmate/exchangeSchoolmateCard', params);
  },
  async getDetailedInformation(params: {}): Promise<res> {
    return http.post<res>('/my/getDetailedInformation', params);
  },
  async getSchoolmateCard(params: userParam) {
    return await http.post<res>('/appSchoolmate/getSchoolmateCard', params);
  },
  async getUnreadExchangeCount(params: {}) {
    return await http.post<res>('/appSchoolmateCard/getUnreadExchangeCount', params);
  },
  ///appSchoolmateCard/auditSchoolmateCardExchange
  async auditSchoolmateCardExchange(params: exchangeParam2) {
    return await http.post<res>('/appSchoolmateCard/auditSchoolmateCardExchange', params);
  },
  //  名片数量接口
  async getExchangeReceivedCount(params: {}) {
    return await http.post<res>('/appSchoolmateCard/getExchangeReceivedCount', params);
  },
  //是否允许陌生人交换名片接口
  //my/editExchangeCardFlag
  async editExchangeCardFlag(params: cardFlagP) {
    return await http.post<res>('/my/editExchangeCardFlag', params);
  },
};
