import http, { res } from '@/utils/http';

/**获取未读消息数 */
export const fetchUnreadCount = () => http.post<res>('/my/notification/getUnreadCount');

/**分页获取消息列表 */
export const pageNotification = (params: { pageNum: number; pageSize: number }) =>
  http.post<res>('/my/notification/pageNotification', params);

/**消息标记为已读 */
export const readNotification = (params: { id: string }) =>
  http.post<res>('/my/notification/readNotification', params);
