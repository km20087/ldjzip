import http from '@/utils/http/index';

// 创建返校团体
export function addGroup(data: Partial<addData>) {
    return http.post('/app/homecoming/group/add', data);
}

//获取校史馆参观时间
export function getVisitTime(data: { startTime?: string, endTime?: string }) {
    return http.post('/app/returnSchoolRegister/getVisitTime', data);
}

//获取返校团体列表
export function getGroupList(data: searchP & Partial<pageParams>) {
    return http.post('/app/homecoming/group/page', data);
}

//获取学院列表
export function getCollegeList(data?: any) {
    return http.post('/app/homecoming/group/college/page', data);
}

//获取团体详情
export function getroupdetail(data?: any) {
    return http.post('/app/homecoming/group/detail', data);
}

//获取个人预约团体详情
export function getRegisterDetailGWY(data?: any) {
    return http.post('/app/returnSchoolRegister/getRegisterDetailGWY', data);
}
//获取团体人员详情
export function listSchoolmateGWY(data?: any) {
    return http.post('/app/returnSchoolRegister/listSchoolmateGWY', data);
}

//邀请校友新接口--app_rsr_invit,params:returnActivityId,userId
export function invitSchoolmate(data?: any) {
    return http.post('/app/returnSchoolRegister/invitSchoolmate', data);
}


//  /app/returnSchoolRegister/invitSchoolmate

//编辑团体信息
export function updategroup(data?: any) {
    return http.post('/app/homecoming/group/update', data);
}

//加入团体
export function joingroup(data?: any) {
    return http.post('/app/returnSchoolRegister/add', data);
}


//获取报名人列表
export function getJoinorList(data?: any) {
    return http.post('/app/returnSchoolRegister/listSchoolmate', data);
}


//取消预约
export function cancelBook(data: { id: string, userId?:string }) {
    return http.post('/app/returnSchoolRegister/cancel', data);
}

//解散团体
export function cancelGroup(data: { id: string }) {
    return http.post('/app/homecoming/group/disbanded', data);
}

//设为管理员接口
export function updateCreateBy(data: {id: string,userId:string}) {
    return http.post('/app/homecoming/group/updateCreateBy', data);
}


//审核进度列表
export function getauditList(data: any) {
    return http.post('/app/homecoming/group/auditList', data);
}

//报名和预约审核进度(个人预约报名)
export function listAuditRecord(data: any) {
    return http.post('/app/returnSchoolRegister/listAuditRecord', data);
}

//入校二维码
export function getqrCode(data: any) {
    return http.post('/app/returnSchoolRegister/qrCode', data);
}

//获取个人预约详情
export function getRegisterDetail(id: any) {
    return http.post('/app/returnSchoolRegister/getRegisterDetail', id);
}