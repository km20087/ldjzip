import http, { res } from '@/utils/http/index';
export default {
    async randomListAiAudit(params: {}) {
        // randomListAiAudit
        return await http.post<res>('/schoolmateAudit/randomListAiAudit', params);
    },
    // 查询待审核头像校友列表
    async pageAuditPictureSchoolmate(params: any) {
        // randomListAiAudit
        return await http.post<res>('/schoolmateAudit/pageAuditPictureSchoolmate', params);
    },

    //  分页获取待审核头像列表
    async pageAllPictureRecord(params: any) {
        return await http.post<res>('/schoolmateAudit/pageAllPictureRecord', params);
    },

    // 头像审核撤回
    async revokeAuditPicture(params: any) {
        // randomListAiAudit
        return await http.post<res>('/schoolmateAudit/revokeAuditPicture', params);
    },
    // 头像审核
    async auditPicture(params: any) {
        // randomListAiAudit
        return await http.post<res>('/schoolmateAudit/auditPicture', params);
    },

}