import http from '@/utils/http/index';

// 查询校友地图
export function statisticsByProvince() {
  return http.post('/appSchoolmate/statisticsByProvince', {});
}
