import http, { res } from '@/utils/http/index';



export default {
// 获取企业信息  （AppSchoolmateEnterprise_Page）
  async pageEnterprise(params: any) {
    return await http.post<res>('/appSchoolmateEnterprise/pageEnterprise', params);
  },
//  查询企业信息详情（AppSchoolmateEnterprise_Detail）
    async detailEnterprise(params: any) {
        return await http.post<res>('/appSchoolmateEnterprise/detailEnterprise', params);
    },

//  分页查询企业职位信息（AppEnterprisePosition_Page）
    async pagePosition(params: any) {
        return await http.post<res>('/appSchoolmateEnterprise/pagePosition', params);
    }, 

//  增加企业浏览量（AppSchoolmateEnterprise_AddViews）    
    async addEnterpriseViews(params: any) {
      return await http.post<res>('/appSchoolmateEnterprise/addEnterpriseViews', params);
  }, 


//  增加岗位浏览量（AppSchoolmateEnterprise_AddViews）    
      async addPositionViews(params: any) {
        return await http.post<res>('/appSchoolmateEnterprise/addPositionViews', params);
      },   
}
