import http, { res } from '@/utils/http/index';
export interface photoParm {
  albumName: string,
  albumType: string,//0-校友相册，1-组织相册
  coverImage: string,//封面图片
  groupsId: string,//组织id，校友相册为空
  permissionScope: string,//权限范围，0-全校可见，1-组织内可见
  schoolId: string,//所属学校id
  status?: string,//相册状态，0-正常，1-已删除
}

export interface photoAddParm {
  albumName: string,
  albumType: string,//0-校友相册，1-组织相册
  permissionScope: string,//权限范围，0-全校可见，1-组织内可见
  groupsId: string
}
export interface photoParmByDelete {
  albumId: string,
  groupsId?: string,//组织id，校友相册为空

}

interface photoList {
  photoId: string,
  albumId?: string,
  photoUrl?: string
}

export interface photoListByDelete {
  albumId: string,
  groupsId?: string,//组织id，校友相册为空
  albumPhotoList?: photoList[]
}
export interface photoListByList {
  albumType: string,//0-校友相册，1-组织相册
  groupsId?: string,//组织id，校友相册为空
  pageNum: Number,
  pageSize: Number,
}
export interface listAlbumPhotosP {
  albumId: string,
  albumType?: string,//0-校友相册，1-组织相册
  pageNum: number,
  pageSize: number
}

export interface upPhotosP {
  albumId: string,
  address: string,
  describe: string,
  photoList: string[],
  permissionScope?: string,
  flag?: string
}

export interface deletePhotosP {
  albumId: string,
  photoList: string[]
}
export interface transPhotosP {
  fromAlbumId: string,
  toAlbumId: string
  photoList: string[]
}

export interface editPhotosP {
  albumId: string,
  status?: string   //删除传1，修改不传
  albumName?: string // 修改时必传
  permissionScope?: string // 修改时必传
}

export interface thumbP {
  photoId: string,
  isThumbsUp: string
}


export default {
  async thumbUpPhoto(params: thumbP) {//相册点赞
    return await http.post<res>('/appAlbum/thumbUpPhoto', params);
  },
  // /appAlbum/addAlbum
  async addAlbum(params: photoAddParm) {//创建相册
    return await http.post<res>('/appAlbum/addAlbum', params);
  },
  async deleteGroupAlbum(params: photoParmByDelete) {//删除组织相册
    return await http.post<res>('/appAlbum/deleteAlbum', params);
  },
  async deleteGroupAlbumPhotos(params: photoListByDelete) {//删除组织相册图片
    return await http.post<res>('/appAlbum/deleteAlbumPhotos', params);
  },
  async editPhotos(params: photoListByDelete) {//修改相片信息
    return await http.post<res>('/appAlbum/editPhotos', params);
  },
  async listAlbum(params: photoListByList) {//查询组织相册
    return await http.post<res>('/appAlbum/listAlbum', params);
  },
  async listAlbumPhotos(params: listAlbumPhotosP) {//查询组织相册图片
    return await http.post<res>('/appAlbum/listAlbumPhotos', params);
  },
  async uploadPhotos(params: upPhotosP) {//上传相册图片
    return await http.post<res>('/appAlbum/uploadPhotos', params);
    params.flag = "Y"
    let res = await http.post<res>('/appAlbum/uploadPhotos', params)
    if (res.code == 200) {
      const { code, data, msg } = res
      let tokenUrl = data.tokenUrl
      let ms = msg
      let form = {
        code: "200",
        data: {
          url: tokenUrl,
          tokenUrl: tokenUrl,
          uploadUrl: tokenUrl
        },
        msg: ms
      }
      console.log(form)
      return form
    } else {
      return res
    }
  },
  // /appAlbum/listAlbumPhotos
  //   /appAlbum/deleteAlbumPhotos
  async deleteAlbumPhotos(params: deletePhotosP) {//删除相册图片
    return await http.post<res>('/appAlbum/deleteAlbumPhotos', params);
  },
  //   /appAlbum/transferPhotos
  async transferPhotos(params: transPhotosP) {//转移相册图片
    return await http.post<res>('/appAlbum/transferPhotos', params);
  },
  //  /appAlbum/editAlbum
  async editAlbum(params: editPhotosP) {//修改/删除改册
    return await http.post<res>('/appAlbum/editAlbum', params);
  },
  //  ///appAlbum/isSchoolAdmin
  async isSchoolAdmin(params: {}) {// 判断校友身份
    return await http.post<res>('/appAlbum/isSchoolAdmin', params);
  },
}





