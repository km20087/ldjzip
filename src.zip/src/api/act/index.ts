import http, { res } from '@/utils/http/index';
export interface userAct {
  searchType?: string;
  groupsId: string;
  pageNum: number;
  pageSize: number;
}

export interface addAct {
  groupsId: string;
  theme: string;
  organizer?: string;
  startTime: string;
  endTime: string;
  registrationDeadline: string;
  introduction?: string;
  requiredInformation: string;
  openFlag: string;
  eventPoster: string;
}

export default {
  async listGroupActivities(params: userAct) {
    //组织活动列表接口
    return await http.post<res>('/appGroupActivities/listGroupActivities', params);
  },
  async addGroupActivities(params: addAct) {
    //组织活动列表接口
    return await http.post<res>('/appGroupActivities/addGroupActivities', params);
  },
};
