import http, { res } from '@/utils/http/index';

export interface sugP {
  academicType?: string
  classesName?: string
  collegeId?: string
  collegeName?: string
  diplomaFile?: string
  education?: string
  major?: string
  majorName?: string
  // schoolStartYear?: string
  schoolingPeriod?: string
  educationType:string
  startYear:string
  rejectReason:string
}


export default {
    async apply(params: sugP) {//修改学历
        return await http.post<res>('/appEducationCorrection/apply',params);
    },
    //  /appEducationCorrection/applyAll
    async applyAll(params: sugP) {//修改学历
      return await http.post<res>('/appEducationCorrection/applyAll',params);
  },    
}