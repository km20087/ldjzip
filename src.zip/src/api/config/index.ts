import http, { res } from '@/utils/http/index';

export interface groupListP {
  groupsType?:string
}
export interface userP {
  userId?:string
}

interface schoolConfigParam {
  enable?:string//1--获取启用的，0是获取停用的，不传是获取全部
}

export default {
  //获取个人信息配置
  async infoConfigPerGet(params: userP) {
    return await http.post<res>('/app/info/config/personal/get', params);
  },
  //新增或更新个人信息配置
  async infoConfigPerSave(params: any) {
    return await http.post<res>('/app/info/config/personal/save', params);
  },
  // 获取校友信息配置-学校 
  async infoConfigSchoolGet(params: schoolConfigParam) {
    return await http.postP<res>('/app/info/config/school/get', {},params);
  },
}

