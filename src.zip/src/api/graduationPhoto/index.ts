import http, { res } from '@/utils/http/index';
 interface graduationPhotoD {
    pageNum: number,
    pageSize: number,
    graduationTitle?: string,
    graduationYear?: string,
    graduationClass?: string,
    status?: string
}
 interface graduationPhotoList {
    schoolId:string,
    graduationTitle: string,
    graduationYear: string,
    graduationClass: string,
    yearSorting:string | number,
    classSorting:string | number,
    status: string, 
    createTime:string,
    updateTime:string,
    editor:string,
    creator:string,
    content:string,
    id:string,
}

interface yearList {
    label:string,
    value:string
}

/** 获取毕业照详情 --GRADUATION_PHOTO_DETAIL_APP*/
export function graduationPhotoDetail (data: any) {
    return http.post<res>('/app/graduationPhoto/detail', data)
  }

/** 获取毕业照年级列表 --GRADUATION_PHOTO_PAGE_YEAR_APP*/
export function graduationYearPage (data: any) {
    return http.post<res>('/app/graduationPhoto/graduationYearPage', data)
  }  

/** 获取毕业照班级列表 --GRADUATION_PHOTO_PAGE_CLASS_APP*/
export function graduationClassPage (data: any) {
  return http.post<res>('/app/graduationPhoto/graduationClassPage', data)
}    