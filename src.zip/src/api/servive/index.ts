import http, { res } from '@/utils/http';
interface page {
    pageNum: number,
    pageSize: number,
}
export interface listParams {
    pageNum: number,
    pageSize: number,
    status?: string,
    groupsId?:string
}
export interface noticeP {
    pageNum: number,
    pageSize: number,
}
//活动报名
export const registerAct = async (params: any) => {
    return await http.post<res>('/activities/register', params)
}
//预约返校
export const backSchool = async (params: any) => {
    return await http.post<res>('/appService/returnSchoolAdd', params)
}

//取消活动报名
export const unRegisterAct = async (params: { actId: string }) => {
    return await http.post<res>('/activities/unRegister', params)
}

//预约返校列表
export const backSchoolList = async (params: any) => {
    return await http.post<res>('/appService/returnSchoolList', params)
}

//预约返校列表
export const backSchoolDetailGWY = async (params: any) => {
    return await http.post<res>('/appService/returnSchoolDetailGWY', params)
}

//预约详情-回显
export const detailHX = async (params: any) => {
    return await http.post<res>('/appService/detailHX', params)
}

//修改-预约返校信息表
export const returnSchoolAddUpdate = async (params: any) => {
    return await http.post<res>('/appService/returnSchoolAddUpdate', params)
}

//预约返校-被访人列表
export const getappAuditList = async (params: { roleCode: roleCode }) => {
    return await http.post<res>('/sysUser/appAuditList', params)
}

//预约返校配置
export const getReturnSchoolConfig = async (params: any) => {
    return await http.post<res>('/school/getReturnSchoolConfig', {}, { params })
}

//我要捐赠-加密接口
export const getSecret = async (params: any) => {
    return await http.post<res>('/appLogin/toSecret', params)
}

//毕业会场
export const toSecretZHC = async (params: any) => {
    return await http.post<res>('/appLogin/toSecretZHC', params)
}

//华住会
export const genBasicLogin = async (params: any) => {
    return await http.post<res>('/appService/genBasicLogin',params)
}

export const returnSchoolDetail = async (params: any): Promise<res> => {
    return  http.post<res>('/appService/returnSchoolDetail', params)
}
export const returnSchoolList = async (params: noticeP) => {
    return await http.post<res>('/appService/returnSchoolList', params)
}

//通知公告-列表
export const getNoticeList = async (params: any) => {
    return await http.post<res>('/appService/xyMessageNotificationList', params)
}
//服务-联系我们
export const contactUs = async (params: any) => {
    return await http.post<res>('/appService/contactUs', params)
}
//服务-理事会
export const getCouncilRosterByYear = async (params: any) => {
    return await http.post<res>('/appCouncilRoster/getCouncilRosterByYear', params)
}
//通知公告-详情
export const getNoticeDetail = async (params: any) => {
    return await http.post<res>('/appService/xyMessageNotificationDetail', params)
}
//校友信息审核列表
export const getExamMateList = async (params: any) => {
    return await http.post<res>('/schoolmateAudit/listUnauditSchoolmate', params)
}
//获取活动列表
export const getActiveList = async (params: listParams) => {
    return await http.post<res>('/activities/page', params);
}
// 获取终身学历url
export const getLearnUrl = () => http.post('/school/getLearnUrl')
export default {
    getActiveList,
    async xyMessageNotificationList(params: noticeP) { //h5通知公告列表接口
        return await http.post<res>('/appService/xyMessageNotificationList', params);
    },
    async xyMessageNotificationDetail(params: noticeP) { //h5通知公告详情
        return await http.post<res>('/appService/xyMessageNotificationDetail', params);
    },

    //创建活动
    async addActivities(params: any) {
        return await http.post<res>('/activities/add', params)
    },

    //详情-直接,ACTIVITIES_DETAIL
    async detailActivities(params: any) {
        return await http.post<res>('/activities/detail', params)
    },

    //详情报名人员列表（新）,ACTIVITY_MEMBER_PAGE_APP
    async activityMemberPageApp(params: any) {
        return await http.post<res>('/activities/activityMemberPageApp', params)
    },

    //未审核撤回（新）,ACTIVITIES_MANAGE_AUDIT_CH
    async auditCHActivities(params: any) {
        return await http.post<res>('/activities/auditCH', params)
    },     
    

    //删除活动,ACTIVITIES_DELETE
    async deleteActivities(params: any) {
        return await http.post<res>('/activities/delete', params)
    },       

    //重新发起,ACTIVITIES_MANAGE_AUDIT_CXFQ
    async auditCXFQ(params: any) {
        return await http.post<res>('/activities/auditCXFQ', params)
    },       

    //校庆-功能入口配置
    async getfunction(params: any) {
        return await http.post<res>('/app/school/celebration/function', params)
    },

    //校庆-获取弹幕
    async getbarrage(params: any) {
        return await http.post<res>('/app/school/celebration/query', params)
    },
    //校庆-发送弹幕
    async sendbarrage(params: any) {
        return await http.post<res>('/app/school/celebration/send', params)
    },
    //校庆-获取动态
    async getStateList(params: any) {
        return await http.post<res>('/app/celebrationBlessing/list', params)
    },//校庆-发送动态
    async sendStateList(params: any) {
        return await http.post<res>('/app/celebrationBlessing/add', params)
    },
    //企业招聘-列表
    async getRecruitmentList(params: any) {
        return await http.post<res>('/appEnterpriseRecruitment/getEnterpriseRecruitmentList', params)
    },
    //企业招聘-详情
    async getRecruitmentDetail(params: any) {
        return await http.post<res>('/appEnterpriseRecruitment/getEnterpriseRecruitmentDetail', params)
    },
    //企业招聘-新增
    async publishEnterpriseRecruitment(params: any) {
        return await http.post<res>('/appEnterpriseRecruitment/publishEnterpriseRecruitment', params);
    },
    //企业招聘-编辑
    async editRecruitment(params: any) {
        return await http.post<res>('/appEnterpriseRecruitment/editEnterpriseRecruitment', params);
    },
    //企业招聘-删除
    async deleteRecruitment(params: any) {
        return await http.post<res>('/appEnterpriseRecruitment/deleteEnterpriseRecruitment', params);
    },
    //创业创新-列表
    async getEnterpriseList(params: any) {
        return await http.post<res>('/appInnovationEnterpreneurship/getInnovationEnterpreneurshipList', params)
    },
    //创新创业-详情
    async getEnterpriseDetail(params: any) {
        return await http.post<res>('/appInnovationEnterpreneurship/getInnovationEnterpreneurshipDetail', params)
    },
    //创业创新-新增
    async publishInnovationEnterpreneurship(params: any) {
        return await http.post<res>('/appInnovationEnterpreneurship/publishInnovationEnterpreneurship', params);
    },
    //企业招聘-编辑
    async editEnterprise(params: any) {
        return await http.post<res>('/appInnovationEnterpreneurship/editInnovationEnterpreneurship', params);
    },
    //企业招聘-删除
    async deleteEnterprise(params: any) {
        return await http.post<res>('/appInnovationEnterpreneurship/deleteInnovationEnterpreneurship', params);
    },
}