import http from '@/utils/http/index';

export const getOccupationInfo = (params: { code: string }) =>
  http.post('/my/getOccupationInfo', {}, { params });
