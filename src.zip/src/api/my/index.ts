import http, { res } from '@/utils/http/index';
import { useSettingStore } from '@/store'

export interface userGroupP {
  userId: string;
}
// 获取待看信息
export function getPendingAuditStatus(params: {}) {
  return http.post<res>('/my/getPendingAuditStatus', params);
}

export function fetchBaseInfo(params: {}): Promise<res> {
  // 个人信息详情
  return new Promise((resolve, reject) => {
    http.post<res>('/my/baseInfo', params)
    .then(result => {
      const data = result.data     
      if (result.code == 200) {
        const settingStore = useSettingStore()
        settingStore.initIdentifyMode(data)
      }
      resolve({
        ...result,
        data,
      })
      resolve(result)
    })
    .catch((err) => {
      reject(err);
    });

  })
}

export default {
  baseInfo: fetchBaseInfo,
  //  /my/getAuditInformation
  // 个人信息详情
  async getDetailedInformation(params = {}): Promise<res> {
    return  http.post<res>('/my/getDetailedInformation', params)
  },
  async getAuditInformation(params: {}) {
    // 个人信息详情
    return await http.post<res>('/my/getAuditInformation', params);
  },
  async editAuditInformation(params: WithUploadHandle<UserForm>) {
    // 个人信息编辑
    return await http.post<res>('/my/editAuditInformation', params);
  },

  // 获取待看信息
  getPendingAuditStatus,
  async urgeAudit(params: {}) {
    // 获取待看信息
    return await http.post<res>('/my/urgeAudit', params);
  },
    // 广东XX学校注册时获取草稿
  async getDraft(params: {}) {
    return await http.post<res>('/my/getDraft', params);
  },
    // 广东XX学校注册时保存草稿
    async saveDraft(params: {}) {
      return await http.post<res>('/my/saveDraft', params);
    },  
};
