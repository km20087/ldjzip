import http from '@/utils/http/index';

// 查询档案领取方式配置
export function fetchGetConfig(data: { bizType: string }) {
  return http.post('/archive/replace/gets', data);
}

export function add(data: ArchiveOnline & UploadHandle) {
  return http.post('/archive/replace/add', data);
}

// 在线办理和查阅的记录
export function list(data: pageParams) {
  return http.post('/archive/replace/record/page', data);
}
