import http from '@/utils/http/index';

export function add(data: ArchiveRead & UploadHandle) {
  return http.post('/archive/query/add', data);
}

interface mobileP {
  mobile:string,
  schoolId:string,
}

interface checkMobileP {
  mobile:string,
  schoolId:string,
  verCode:string,
  id:string,
}

/***
 * 发送短信
 * 权限 SEND_SMS_PHONE
*/
export function sendSmsPhone(data: mobileP) {
  return http.post('/appLogin/sendSmsPhone', data);
}

/***
 * 校验短信
 * 权限 CHECK_SMS_PHONE
*/
export function checkSmsPhone(data: checkMobileP) {
  return http.post('/appLogin/checkSmsPhone', data);
}