import http, { res } from '@/utils/http';
//获取我的活动列表
export const getMyActList = async (params: any) => {
  return await http.post<res>('/activities/my/page', params);
};
//辽师大发起的活动列表
export const getMyCreateActivitiesList = async (params: any) => {
  return await http.post<res>('/appGroupActivities/myCreateActivitiesList', params);
};
//辽师大参加的活动列表
export const getJoinedActivitiesList = async (params: any) => {
  return await http.post<res>('/appGroupActivities/my/page', params);
};
//辽师大活动详情
export const getMyActivitiesDetail = async (params: any) => {
  return await http.post<res>('/appGroupActivities/detail', params);
};
//辽师大审核活动列表
export const getActivitiesAdminList = async (params: any) => {
  return await http.post<res>('/appGroupActivities/activitiesAdminList', params);
};
//辽师大审核活动
export const auditGroupActivities = async (params: any) => {
  return await http.post<res>('/appGroupActivities/auditGroupActivities', params);
};
//辽师大撤回活动
export const cancelGroupActivities = async (params: any) => {
  return await http.post<res>('/appGroupActivities/cancel', params);
};
//辽师大更新活动
export const updateGroupActivities = async (params: any) => {
  return await http.post<res>('/appGroupActivities/update', params);
};
//辽师大终止活动
export const stopGroupActivities = async (params: any) => {
  return await http.post<res>('/appGroupActivities/stopActivity', params);
};
//辽师大发布活动
export const publishGroupActivities = async (params: any) => {
  return await http.post<res>('/appGroupActivities/publish', params);
};

//辽师大未邀请校友列表
export const getNonMember = async (params: any) => {
  return await http.post<res>('/activities/nonMember/list', params);
};
//辽师大活动邀请校友
export const inviteMate = async (params: any) => {
  return await http.post<res>('/activities/invite/add', params);
};
//辽师大活动报名
export const joinLiaoNingAct = async (params: any) => {
  return await http.post<res>('/appGroupActivities/register', params);
};
