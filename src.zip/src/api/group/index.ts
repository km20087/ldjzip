import http, { res } from '@/utils/http/index';
// import trackPoint from '@/utils/apiTrack';
export interface userGroupP {
  userId: string
}

export interface groupListP {
  groupsType?: string
  markType?:string
}

export interface grouP {
  groupsId: string
}
export interface grouMbP {
  groupsId: string,
  pageNum: number,
  pageSize: number
}
export interface addP {
  groupsId: string,
  reason?: string
}
export interface applyPage {
  groupsId: string,
  pageNum: Number,
  pageSize: Number,
  // reason?:string
}
export interface applyDetail {
  id: string,
  groupsId: string
  // reason?:string
}
export interface auditP {
  auditStatus: string,//审核状态：0-待审核，1-通过，2-拒绝
  id: string
}
export interface userPa {
  userId: string,
  groupsId: string
  // reason?:string
}
export interface removePa {
  userId: string,
  groupsId: string
}

export type NonMemberParam = Partial<pageParams> & {
  groupsId: string
  collegeId?: string
  major?: string
  name?: string
}

/** 未加入组织的校友 */
export function fetchNonMemberList (data: NonMemberParam) {
  return http.post<res>('/groups/nonMember/list', data)
}

/** 邀请校友 */
export function fetchInviteAdd (data: { groupsId: string, schoolmateIds: string[] }) {
  return http.post<res>('/groups/invite/add', data)
}

/** 校友处理邀请 */
export function fetchInviteHandle (data: {id: string, status: string}) {
  return http.post<res>('/groups/invite/handle', data)
}

/** 获取待处理的邀请 */
export function fetchInviteRecent (data: {groupsId: string}) {
  return http.post<res>('/groups/invite/recent', data)
}


//groupsId
export default {
  fetchNonMemberList,
  fetchInviteAdd,
  fetchInviteHandle,
  fetchInviteRecent,
  async getGroupType(params: {}) {
    return await http.post<res>('/group/type/list', params);
  },
  async userGroup(params: userGroupP) {
    return await http.post<res>('/appSchoolmate/schoolmate/group', params);
  },
  async groupsList(params: groupListP) {//
    // trackPoint.run('/groups/list',"")
    return await http.post<res>('/groups/list', params);
  },
  async groupsDetail(params: grouP) {//
    return await http.post<res>('/groups/detail', params);
  },
  async groupsMembers(params: grouMbP): Promise<res> {//
    return http.post<res>('/groups/members', params)
  },
  async groupsAdd(params: addP) {//加入组织
    return await http.post<res>('/groupsApply/add', params);
  },
  async groupsAudit(params: auditP) {//审核申请
    return await http.post<res>('/groupsApply/audit', params);
  },
  async groupsDelete(params: addP) {//删除申请
    return await http.post<res>('/groupsApply/delete', params);
  },
  async groupsApplyDetail(params: applyDetail) {//申请详情
    return await http.post<res>('/groupsApply/detail', params);
  },
  async groupsApplyPage(params: applyPage) {//待审核的加入申请列表
    return await http.post<res>('/groupsApply/page', params);
  },
  async removeAdmin(params: userPa) {//移除管理员
    return await http.post<res>('/groups/administrator/remove', params);
  },
  async setupAdmin(params: userPa) {//设置管理员
    return await http.post<res>('/groups/administrator/setup', params);
  },
  async removeMember(params: removePa) {//移除成员
    return await http.post<res>('/groups/member/remove', params);
  },
  async isApply(params: addP) {// 查询是否有正在申请的记录 权限码GROUPS_APPLY_ADD（和申请加入组织接口一致）
    return await http.post<res>('/groupsApply/isApply', params);
  },
  // /groups/member/remove

}
 // /groupsApply/add  申请加入组织





