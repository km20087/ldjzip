import http from '@/utils/http';

export const getProtocolList = (data: {
  newsType: string;
  schoolId: string;
  pageNum?: string | number;
  pageSize?: string | number;
}) => http.post('/app/news/page/typeLoginProtocol', data);

export const getProtocolDetail = (params: { niId: string }) =>
  http.post('/app/news/detailLoginProtocol', {}, { params });
