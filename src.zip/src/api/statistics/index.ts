import http, { Response, res } from '@/utils/http';

export default{
  async provinceStatistics(params: {}) {
    return await http.post<res>('/app/school/celebration/statistics/province', params);
  },
  async groupStatistics(params: {}) {
    return await http.post<res>('/app/school/celebration/statistics/group', params);
  },
  async cityStatistics(params: any) {
    return await http.post<res>('/app/school/celebration/statistics/city', params);
  },
}