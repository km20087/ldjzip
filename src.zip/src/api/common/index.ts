//   /dept/list  查询部门列表
import http, { res } from '@/utils/http';

export interface school {
  schoolId?: string,
  parentId?:string//parentId传deptId，查询结果是部门
  schoolYear?:string,//河北师范获取院系和专业
  college?:string//河北师范获取专业
  grade?:string//河北师范获取院系和专业
  allDept?:string |number
}

export interface chengdu {
  schoolId?: string,
  deptName:string
}

export interface areaP {
  parentNo?: string,
  addrLevel:string//1-查询省，2-查询市，3-查询区
  addrName?:string,
  pageNum:number,
  pageSize:number
}

export default {
  async deptList(params: school) {
    return await http.post<res>('/dept/listCollages',params);
  },
  async areaList(params: areaP) {
    return await http.post<res>('/areaCode/list',params);
  },
  async industryList(params:any){
    return await http.post<res>('/dict/listAllApp',params);
  },
  async getCollage(params: school) {
    return await http.post<res>('/appLogin/getCollage',params);
  },
  async getMajor(params: school) {
    return await http.post<res>('/appLogin/getMajor',params);
  },    
  // /appLogin/getCollageBylike
  async getCollageBylike(params: chengdu) {
    return await http.post<res>('/appLogin/getCollageBylike',params);
  },  
};


