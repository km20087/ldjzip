import http, { Response, res } from '@/utils/http';
import axios from 'axios';
import { getToken } from '@/utils/index';
export interface LoginParams {
  mobile: string;
  schoolId: string;
  id: string;
  verCode: string;
  transid: string;
  wxCode?: string;
  seOpenId?: string;
  codeKey?: string;
  code?: string;
  loginType?: string;
  clientId?:string;
  redirectUrl?:string;
  redirectUri?:string;
  schoolCode?:string
}

export interface sendParams {
  mobile: string;
  schoolId: string;
  codeKey: string;
  code: string;
  // loginType
}

export interface wxP {
  schoolCode: string;
  wxCode: string;
}

export interface userP {
  schoolCode: string;
}

export interface inpBasicP {
  // schoolCode: string;
  name: string;
  cardType: string;
  cardNumber: string;
  mobile: string;
  provinceId: string;
  cityId: string;
  areaId?: string;
  employer: string;
  jobTitle?: string;
  emailAddress: string;
}
//辽宁师范传参
export interface inpBasicP_LN {
  name: string;
  gender: string;
  birthday: string;
  formerName?: string;
  diplomaImage?: string;
  type?:string
}

// /appLogin/loginLogout   注销登陆

export function appAutMenu(params: {}) {
  return http.post<res>('/appLogin/appAutMenu', params);
}

export function fetchSchoolSetting(data: { schoolId: string }) {
  return http.post<res>('/schoolInfo/getSchoolSetting', data);
}

export default {
  async login(params: LoginParams) {
    return await http.post<res>('/appLogin/login', params);
  },

  async loginCas(params: LoginParams) {
    return await http.post<res>('/login/cas', params);
  },

  async loginLogout(params: {}) {
    return await http.post<res>('/appLogin/loginLogout', params);
  },
  async sendSms(params: sendParams) {
    return await http.post<res>('/appLogin/sendSms', params);
  },
  //
  async completeSchoolmateInformation(params: WithUploadHandle<UserForm>) {
    return await http.post<res>('/appLogin/completeSchoolmateInformation', params);
  },
  appAutMenu,
  //   /appLogin/audLogInfo   微信授权登录接口(常熟理工)
  async audLogInfo(params: wxP) {
    return await http.post<res>('/appLogin/audLogInfo', params);
  },
  //   /appLogin/audLogInfo   微信授权登录接口(常熟理工)
  async audLogInfoLN(params: wxP) {
    return await http.post<res>('/appLogin/gzhLogin', params);
  },
  //常熟理工注册第一步
  // async inputBasicInformation(params: inpBasicP) {
  //   return await http.post<res>('/appLogin/inputBasicInformation', params);
  // },
  async inputBasicInformation(params: inpBasicP | inpBasicP_LN): Promise<res> {
    return new Promise((resolve, reject) => {
      http
        .post<res>('/appLogin/inputBasicInformation', params)
        .then((result) => {
          sessionStorage.setItem('data1', JSON.stringify(result.data));
          resolve({
            ...result,
          });
        })
        .catch((err) => {
          reject(err);
        });
    });
  },
  // /alumniAssocian/listAll
  async listAll(params: {}) {
    return await http.post<res>('/manager/alumniAssociation/listAll', params);
  },
  async fetchImgCode() {
    return axios({
      url: import.meta.env.VITE_APP_API_BASE_URL + `/getVerify`,
      method: 'post',
      responseType: 'arraybuffer',
    });
  },
  async getSchoolId(params: userP) {
    return await http.post<res>('/appLogin/getSchoolId', params);
  },
  //appLogin/getSchoolId
  fetchSchoolSetting,
  async uentry(params: string) {
    return axios({
      url: import.meta.env.VITE_APP_DCWJ_URL + `/dcwj/api/uentry?channelCode=${params}`,
      method: 'post',
      // responseType: 'arraybuffer',
      // params
      headers: {
        Authorization: getToken() || '',
      },
    });
  },
  /**
   * 辽师大更正信息申请
   */
  async applyEduCorrection(data: {
    description: string;
    proofFile: string;
    lnsdSchoolmateId: string;
  }) {
    return await http.post<res>('/my/applyEduCorrection', data);
  },
};
