import http, { res } from '@/utils/http/index';

/**   HOLIDAY_BLESSINGS_DATE  imageType 1-生日祝福，2-节日祝福 */
export function holidayBlessings (data: any) {
    return http.post<res>('/app/holiday/blessings/selectByDate', data)
  }