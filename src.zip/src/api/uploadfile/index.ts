import http, { res } from '@/utils/http';
export default {
  //文件上传
  async uploadFile(params: FormData) {
    return await http.post<res>('/fastDfsUtil/upload', params);
    // params.append('flag', 'Y');
    // let res = await http.post<res>('/fastDfsUtil/upload', params);
    // if (res.code == 200) {
    //   let tokenUrl = res.data.tokenUrl;
    //   return {
    //     ...res,
    //     data: {
    //       url: tokenUrl,
    //       tokenUrl: tokenUrl,
    //       uploadUrl: tokenUrl,
    //     },
    //   };
    // } else {
    //   return res;
    // }
  },
  async uploadSlice(params: any) {
    return http.post<res>('/fastDfsUtil/uploadSlice', params)
  },
};
