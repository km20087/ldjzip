import { getSchoolId } from '@/utils';
import http, { res } from '@/utils/http';
import { isAllowVisitorToUseSchool } from '@/utils/customizedType';

//记录新闻列表点击次数
export interface school {
  newsType: string,
  isReturnContent?: string,
  pageNum: number,
  pageSize: number,
}
export interface detail {
  niId: string
}

export function homeSwipePicSchool(params: any) {
  return http.post<res>('/app/images/list/school', params)
}
export function homeSwipePic(params: any) {
  let url = '/app/images/list'
  if (isAllowVisitorToUseSchool()) {
    url = '/app/images/listFX'
    params && (params['schoolId'] = getSchoolId())
  }
  return http.post<res>(url, params)
}
export function getSchoolNews(params: school & { schoolId?: string }) {
  let url = '/app/news/page/type'
  if (isAllowVisitorToUseSchool()) {
    url = '/app/news/page/typeFX'
    params && (params['schoolId'] = getSchoolId()!)
  }
  return http.post<res>(url, params);
}
//汕大-校友卡数据
export function getCardList(params: any) {
  return http.post<res>('/app/schoolCard/detail', params)
}
export function clickNum({ niId }: detail) {
  let url = `/app/news/click?niId=${niId}`
  if (isAllowVisitorToUseSchool()) {
    url = `/app/news/clickFX?niId=${niId}&schoolId=${getSchoolId()}`
  }
  return http.post<res>(url)
}
export function getNewsDetail({ niId }: detail) {
  let url = `/app/news/detail?niId=${niId}`
  // if (isAllowVisitorToUseSchool()) {
  //   url = `/app/news/detailFX?niId=${niId}&schoolId=${getSchoolId()}`
  // }
  return http.post<res>(url)
}
export default {
  clickNum,
  getSchoolNews,
  getNewsDetail,
  //获取用户信息
  async getUserInfo() {
    return await http.post<res>('/my/card/info')
  },
  //获取校友卡二维码
  async getMateQRcode() {
    return await http.post<res>('/my/card/qrcode', {}, { 'responseType': 'blob' })
  },
  //轮播图
  homeSwipePic,
  //汕大-校友卡数据
  getCardList,
  //汕大-校友卡样式切换
  async updateCardbg(params: any) {
    return await http.post<res>('/app/schoolCard/update', params)
  },
  //汕大-校友卡申请
  async cardapply(params: any) {
    return await http.post<res>('/app/schoolCard/save', params)
  },
  homeSwipePicSchool
};