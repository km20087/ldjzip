import http, { res } from '@/utils/http/index'

export const fetchSubmissionTypeList = (params: { title: string, status?: string, pageSize: number; pageNum: number }) =>
  http.post<res>('/app/magazineColumn/page', params)
  
export const fetchSubmissionTypeDetail = (params: { id: string }) =>
  http.post<res>('/app/magazineColumn/detail', params)

export const saveSubmission = (params: any) =>
  http.post<res>('/article/add', params)
