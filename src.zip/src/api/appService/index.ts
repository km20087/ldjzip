import http, { res } from '@/utils/http/index';

export interface sugP {
    email?: string,
    detailPhoto: string,
    detailText: string,
    feedbackType: string,
    phone?: string,
    qqWechat?: string,
    schoolId: string

}


export default {
    async feedbackAndSuggestions(params: sugP) {//反馈与建议
        return await http.post<res>('/appService/feedbackAndSuggestions',params);
    },
    async returnQR(params: any) {//校友广东XX学校二维码展示  --  APP_RETURN_QR
        return await http.post<res>('/appService/returnQR',params);
    },    
}