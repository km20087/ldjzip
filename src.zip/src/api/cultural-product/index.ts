import http, { res } from '@/utils/http/index'

export const fetchCulturalProductList = (params: { pageSize: number; pageNum: number }) =>
  http.post<res>('/appCulturalProduct/page', params)
  
export const fetchCulturalProductDetail = (params: { id: string }) =>
  http.post<res>('/appCulturalProduct/detail', params)
