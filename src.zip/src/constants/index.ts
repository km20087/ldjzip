import { getSchoolCode } from '@/utils';
export const CardList = [
  { text: '居民身份证', cardId: '1010' },
  { text: '中国护照', cardId: '1051' },
  { text: '外国护照', cardId: '1052' },
  { text: '香港身份证', cardId: '1140' },
  { text: '澳门居民身份证', cardId: '1150' },
  { text: '台湾居民身份证', cardId: '1160' },
  { text: '其他', cardId: '8888' },
];

export enum DeptTypeLevel {
  root = '1',
  school = '2',
  college = '3',
  major = '4',
}

export const showSchoolMateType: Record<number, string> =  {
  0:"毕业生",
  1:"在校生",
  2:"教职工",
  3:"企业",
}

export const ExtensionToMineTypeObj: Record<string, string[]> = {
  'jpg': ['image/jpg'],
  'jpeg': ['image/jpeg'],
  'png': ['image/png'],
  'pdf': ['application/pdf'],
  'mp4': ['video/mp4'],
  'avi': ['video/x-msvideo', 'video/avi'],
  'mov': ['video/quicktime'],
  'wmv': ['video/x-ms-wmv'],
  'mkv': ['video/x-matroska'],
}

export enum SchoolCode {
  ShanDa = '4144010560',
  ChangShu = '4132010333',
  GuangWenYi = '4144013707',
  LiaoShiDa = '4121010165',
  ChengDuYiXueYuan = '4151013705',
  HeBeiShiFan = '4113010094',
  ShenYangShiFan = '4121010166',
  WuLuMuQiZhiYeDaXue = '4165011565',
  XiangXianZhongXue = '4401130302',
  HeBeiZhongYiYao = '4113014432',
  BeiHuaHangTianGongYe = '4113011629',
  BaoTouZhiYeJiShu = '4115012057',
  LiaoShiFuShuZhongXue = '4121000165',
  ShenYangYaoKeDaXue = '4121010163',
  PeiYingZhongXue = '4401130303',
  ShiJiaZhuangYiZhong = '4113010601',
  ChengDeYiXueYuan = '4113010093',
  GuangDongShuiLiXueYuan = '4144010862'
}

/** 在学校logo下方展示"首页"的学校*/
export const ShowHomeLabelSchoolList: string[] = [SchoolCode.XiangXianZhongXue]

/**使用第二套UI皮肤的学校 */
export const UseSkin2SchoolList: string[] = [SchoolCode.GuangWenYi,SchoolCode.WuLuMuQiZhiYeDaXue,SchoolCode.XiangXianZhongXue,SchoolCode.PeiYingZhongXue,SchoolCode.ShenYangYaoKeDaXue,SchoolCode.GuangDongShuiLiXueYuan]//SchoolCode.BaoTouZhiYeJiShu,SchoolCode.PeiYingZhongXue

/**
 * 使用第二套UI皮肤的学校的配置信息对象
 * skin2AssetsPrefix 放置静态图片的文件夹名称
 * skin2NewsTypeSuffix 专属新闻类型的后缀
 */
export const Skin2Config: Record<string, Record<string, string>> = {
  [SchoolCode.GuangWenYi]: {
    skin2AssetsPrefix: 'guangwenyi', 
    skin2NewsTypeSuffix: 'gwy',
  },
  [SchoolCode.WuLuMuQiZhiYeDaXue]: {
    skin2AssetsPrefix: 'wulumuqizhiyedaxue', 
    skin2NewsTypeSuffix: 'wlmqzydx',
  },
  [SchoolCode.XiangXianZhongXue]: {
    skin2AssetsPrefix: 'xiangxianzhongxue', 
    skin2NewsTypeSuffix: 'xxzx',
  },  
  [SchoolCode.PeiYingZhongXue]: {
    skin2AssetsPrefix: 'peiyingzhongxue', 
    skin2NewsTypeSuffix: 'pyzx',
  },  
  [SchoolCode.ShenYangYaoKeDaXue]: {
    skin2AssetsPrefix: 'shenyangyaoke', 
    skin2NewsTypeSuffix: 'syyk',
  },    
  [SchoolCode.GuangDongShuiLiXueYuan]:{
    skin2AssetsPrefix: 'guangdongshuilidianli', 
    skin2NewsTypeSuffix: 'gdsldl',
  }
}

export const UseHomeConfigByCSS: Record<string, Record<string, string>> = {
  [SchoolCode.GuangWenYi]:{
    contentHome:"white",
    iconBoxHome:"row",
    headerImgBgHome:"header-img-bg",
    headerImgBgLogo:"header-img-logo",
    enterpriseListCss:"row",
    enterpriseListBg:'1',
    serviceTop:"",
    ecardCss:"",
    noticeWrap:"notice-wrap",
    schoolMotoStyle:"",
  },
  [SchoolCode.GuangDongShuiLiXueYuan]:{
    contentHome:"white",
    iconBoxHome:"row",
    headerImgBgHome:"header-img-bg",
    headerImgBgLogo:"header-img-logo",
    enterpriseListCss:"rowBySmall",
    enterpriseListBg:'0',
    serviceTop:"",
    ecardCss:"",
    noticeWrap:"notice-wrap",
    schoolMotoStyle:"width:220px;height:26px",
  },  
  [SchoolCode.ShenYangYaoKeDaXue]:{
    contentHome:"white",
    iconBoxHome:"row",
    headerImgBgHome:"header-img-bg",
    headerImgBgLogo:"hide",
    enterpriseListCss:"row",
    enterpriseListBg:'1',
    serviceTop:"",
    ecardCss:"",
    noticeWrap:"hide",
    schoolMotoStyle:"",
  },
    
  [SchoolCode.WuLuMuQiZhiYeDaXue]:{
    contentHome:"white",
    iconBoxHome:"row",
    headerImgBgHome:"header-img-bg",
    headerImgBgLogo:"header-img-logo",
    enterpriseListCss:"row",
    enterpriseListBg:'1',
    serviceTop:"",
    ecardCss:"",
    noticeWrap:"notice-wrap",
    schoolMotoStyle:"",
  },    
  [SchoolCode.XiangXianZhongXue]:{
    contentHome:"white",
    iconBoxHome:"flex3By2Line",
    headerImgBgHome:"header-img-Xiangxian",
    headerImgBgLogo:"header-img-logo-Xiangxian",
    enterpriseListCss:"rowBySmall",
    enterpriseListBg:'0',
    serviceTop:"XiangxianService",
    ecardCss:"whitePart",
    noticeWrap:"notice-wrap",
    schoolMotoStyle:"",
  },   
  [SchoolCode.PeiYingZhongXue]:{
    contentHome:"white",
    iconBoxHome:"row",
    headerImgBgHome:"header-img-bg",
    headerImgBgLogo:"header-img-logo",
    enterpriseListCss:"row",
    enterpriseListBg:'1',
    serviceTop:"",
    ecardCss:"whitePart",
    noticeWrap:"notice-wrap",
    schoolMotoStyle:"",
  },  
}

export const UseHomeConfigByItems: Record<string, Record<string, boolean>> = {
  [SchoolCode.GuangWenYi]:{
    enterpriseFlag:true,//校友企业
    schoolMateShowFlag:true,//校友风采或级社风采
    schoolMateWorkFlag:false,//培英风采
    lastNewsFlag:true,//最新动态
    activeListFlagFlag:true,//校友活动
    schoolHistoryShowFlag:false,//辉煌校史
    headerImgWrapFlag:true,//首页顶部banner,就培英中学的首页banner不一样
    schoolDonateFlag:false,
    lastesDonateFlag:false,
  },
  [SchoolCode.GuangDongShuiLiXueYuan]:{
    enterpriseFlag:true,//校友企业
    schoolMateShowFlag:true,//校友风采或级社风采
    schoolMateWorkFlag:false,//培英风采
    lastNewsFlag:true,//最新动态
    activeListFlagFlag:true,//校友活动
    schoolHistoryShowFlag:false,//辉煌校史
    headerImgWrapFlag:true,//首页顶部banner,就培英中学的首页banner不一样
    schoolDonateFlag:false,
    lastesDonateFlag:false,
  },  
  [SchoolCode.ShenYangYaoKeDaXue]:{
    enterpriseFlag:false,//校友企业
    schoolMateShowFlag:true,//校友风采或级社风采
    schoolMateWorkFlag:false,//培英风采
    lastNewsFlag:false,//最新动态
    activeListFlagFlag:true,//校友活动
    schoolHistoryShowFlag:false,//辉煌校史
    headerImgWrapFlag:true,//首页顶部banner,就培英中学的首页banner不一样
    schoolDonateFlag:true,
    lastesDonateFlag:true,
  },
  [SchoolCode.WuLuMuQiZhiYeDaXue]:{
    enterpriseFlag:true,//校友企业
    schoolMateShowFlag:true,//校友风采或级社风采
    schoolMateWorkFlag:false,//培英风采
    lastNewsFlag:true,//最新动态
    activeListFlagFlag:true,//校友活动
    schoolHistoryShowFlag:false,//辉煌校史
    headerImgWrapFlag:true,//首页顶部banner,就培英中学的首页banner不一样
    schoolDonateFlag:false,
    lastesDonateFlag:false,
  },
  [SchoolCode.XiangXianZhongXue]:{
    enterpriseFlag:true,//校友企业
    schoolMateShowFlag:true,//校友风采或级社风采
    schoolMateWorkFlag:false,//培英风采
    lastNewsFlag:true,//最新动态
    activeListFlagFlag:true,//校友活动
    schoolHistoryShowFlag:false,//辉煌校史
    headerImgWrapFlag:true,//首页顶部banner,就培英中学的首页banner不一样
    schoolDonateFlag:false,
    lastesDonateFlag:false,
  },
  [SchoolCode.PeiYingZhongXue]:{
    enterpriseFlag:false,//校友企业
    schoolMateShowFlag:true,//校友风采或级社风采
    schoolMateWorkFlag:true,//培英风采
    lastNewsFlag:false,//最新动态
    activeListFlagFlag:true,//校友活动
    schoolHistoryShowFlag:true,//辉煌校史--培英转悠
    headerImgWrapFlag:false,//首页顶部banner,就培英中学的首页banner不一样
    schoolDonateFlag:false,
    lastesDonateFlag:false,
  },
}

const ZhongXueConfig:string[] = [
  SchoolCode.LiaoShiFuShuZhongXue,
  SchoolCode.PeiYingZhongXue
]

export function UseResConfigByCSS (){
  const schoolCodeRef = ref(getSchoolCode() || '');
  return {
    blackTitle:ZhongXueConfig.includes(schoolCodeRef.value),
    noRegister:ZhongXueConfig.includes(schoolCodeRef.value)
  }
}
/**需要不登录即可粗略查询页面信息的学校 */
export const AllowVisitorToUseSchoolList: string[] = [ SchoolCode.ChengDuYiXueYuan, SchoolCode.HeBeiZhongYiYao,SchoolCode.LiaoShiFuShuZhongXue,SchoolCode.ShiJiaZhuangYiZhong,SchoolCode.ChengDeYiXueYuan ]


/**组织的类型 */
export enum GroupCategory {
  College = '00',
  Local = '01'
}

/**身份模式 */
export enum IdentifyMode {
  Schoolmate = '0',
  Manage = '1'
}

/**联系我们的数据获取方式 */
export enum ConcatUsMode {
  UserManage = '1', // 从后管用户管理的通讯录获取数据
  SchoolContactManage = '2' // 从后管校内电话菜单获取数据
}

/**从用户管理获取联系我们数据的学校 */
export const ConcatUsDataFromUserManageSchoolList: string[] = []

export const schoolEducationMode: string[] = [ SchoolCode.LiaoShiDa ]


export const NoSkinConfig:Record<string, Record<string, any>> = {
  [SchoolCode.ChengDeYiXueYuan]:[
    {
      name:"聚焦母校",
      type:"focus_school",
    },    
    {
      name:"校友动态",
      type:"schoolmate_news_cdyxy",
    },
    {
      name:"校友风采",
      type:"schoolmate_show_cdyxy",
    },    
  ]
}