import { Toast } from "vant";
export default function copyText(t: string = '复制了个寂寞') {
    if (document.execCommand('copy')) {
        let textArea = document.createElement('textarea');
        textArea.value = t;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        textArea.style.left = '-9999999999999px'
        textArea.style.top = '-9999999999999px'
        document.body.appendChild(textArea)
        textArea.focus();
        textArea.select();
        return new Promise((res, rej) => {
            document.execCommand('copy') ? res('复制成功') : rej();
            textArea.remove()
        }).then(res => {
            Toast.success(res as string)
        }).catch(err => {
            console.log(err);

        })

    } else if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        Toast.success('复制成功')
        return navigator.clipboard.writeText(t)
    }

}