import { getLocalStorageItem, setLocalStorageItem } from "@/utils";
const isDemo = import.meta.env.VITE_IS_DEMO == '1'


interface UseCache {
  key: string;
  service: Function;
  params: any;
  callback: Function;
}
export default async function useCache({ key, service, params, callback }: UseCache) {
  // console.log('key, service, params, callback',key, service, params, callback)
  if (isDemo) {
    const StorageKey = `Cache__` + key;
    const fetchData = async () => {
      const result = await service(params);
      console.log('useCache---result', result)
      setLocalStorageItem(StorageKey, JSON.stringify(result))
      callback(result);
    };
    fetchData();
  } else {
    try {
      const StorageKey = `Cache__` + key;
      const fetchData = async () => {
        const result = await service(params);
        setLocalStorageItem(StorageKey, JSON.stringify(result))
        callback(result);
      };

      let storageData = getLocalStorageItem(StorageKey);
      if (!storageData) {
        await fetchData();
        return;
      }
      // 缓存中有旧值的话
      callback(JSON.parse(storageData));

      // 在空闲时间更新数据
      if (typeof window.requestIdleCallback == 'function') {
        window.requestIdleCallback(() => {
          fetchData();
        });
      } else {
        setTimeout(() => {
          fetchData();
        }, 0);
      }
    } catch (err) {
      console.log(`${key} getCache err`, err);
    }
  }

}
