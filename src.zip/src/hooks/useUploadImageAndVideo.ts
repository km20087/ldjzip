import { type Ref } from 'vue'
import ApiUpload from '@/api/uploadfile'
import { fragmentFile } from '@/utils/file-slice'

export function useUploadImageAndVideo(picList: Ref<string[]>) {
  const MaxRetryTime = 2
  // 视频上传最大并发数
  const MaxConcurren = 3
  // 视频最大分片大小
  const MaxChunkSize = 1024 * 1024 * 1

  const isComplete = ref(false);

  const genUploadVideoRequest = async (file: File) => {
    let { fileHash, chunkList, total, suffix } = await fragmentFile(file, MaxChunkSize)
    return chunkList.map(({ chunk, chunkName }, index) => {
      return () => {
        let formData = new FormData()
        formData.set('fileMd5', fileHash)
        formData.set('file', chunk, chunkName)
        formData.set('sliceNo', (index + 1).toString())
        formData.set('totalSliceNo', total.toString())
        return ApiUpload.uploadSlice(formData as unknown as UploadSliceParams)
      }
    })
  }
  const genUploadImageRequest = (file: File) => {
    let formData = new FormData()
    formData.set('file', file)
    return () => ApiUpload.uploadFile(formData)
  }
  const genUploadRequest = async (file: File) => {
    return file.type.startsWith('image')
      ? [genUploadImageRequest(file)]
      : await genUploadVideoRequest(file)
  }
  const startConcurrentRequest = (fileItem: any, uploadRequestFnList: Function[]) => {
    return new Promise<void>(async (resolve) => {
      const fileType = fileItem.file.type
      const isImage = fileType.startsWith('image')
      const isVideo = fileType.startsWith('video')
      let requestLength = uploadRequestFnList.length
      let poolLength = requestLength > MaxConcurren ? MaxConcurren : requestLength - 1 || 1
      // 创建线程池
      let pool = Array.from({ length: poolLength }, (_, i) => i)
      let successCount = 0
      let uploadStatus = 'success'

      const next = (retry: number = 1) => {
        while (pool.length > 0 && uploadRequestFnList.length > 0) {
          const poolIndex = pool.shift() as number
          const uploadRequestFn = uploadRequestFnList.shift() as Function
          uploadRequestFn()
            .then(({ code, data, msg }: any) => {
              if (code == 200) {
                // 增加上传成功记录
                successCount++
                // 请求完成就释放线程池
                pool.unshift(poolIndex)
                // 若是图片或者视频全部请求成功
                if (isImage || (isVideo && successCount == requestLength)) {
                  fileItem.status = 'done'
                  fileItem.message = '上传成功'
                  picList.value.push(isImage ? data.uploadUrl : data)
                  resolve()
                  return
                }
                if (isVideo) {
                  // 若有分片上传失败则中断后续操作
                  if (uploadStatus == 'failed') {
                    return
                  }
                  // 若不是最后一个分片或者是最后一个分片且其他都已成功上传了)
                  if (uploadRequestFnList.length > 1 || successCount == requestLength - 1) {
                    next()
                  }
                  return
                }
              } else {
                // 超过重试次数, 上传失败
                if (retry >= MaxRetryTime) {
                  uploadStatus = 'failed'
                  fileItem.status = 'failed'
                  fileItem.message = '上传失败'
                  picList.value.push('')
                  resolve()
                  return
                } else {
                  // 若有分片上传失败则中断后续操作
                  if (uploadStatus == 'failed') {
                    return
                  }
                  // 请求完成就释放线程池
                  pool.unshift(poolIndex)
                  // 继续重试当前请求
                  uploadRequestFnList.unshift(uploadRequestFn)
                  next(retry + 1)
                }
              }
            })
            .catch((err: any) => {
              console.log('uploadRequestFn', err, uploadRequestFn)
              uploadStatus = 'failed'
              fileItem.status = 'failed'
              fileItem.message = '上传失败'
              picList.value.push('')
              resolve()
            })
        }
      }
      next()
    })
  }

  const upload = async (file: any) => {
    // 若是上传单个文件， 同意转成多个文件的数组类型进行处理
    if (toString.call(file) == '[object Object]') {
      file = [file];
    }
    // 给每个文件补充上传状态
    file.forEach((item: any) => {
      item.status = 'uploading';
      item.message = '上传中';
    });
    for await (const fileItem of file) {
      let uploadRequestFnList = await genUploadRequest(fileItem.file);
      await startConcurrentRequest(fileItem, uploadRequestFnList)
    }
    isComplete.value = true;
  }

  return {
    upload,
    isComplete
  }
}
