import { Dialog } from 'vant';
import { goLoginPage } from '@/utils/login';

export function useLoginDialog() {
  function showLoginDialog() {
    Dialog.confirm({ title: '温馨提示', message: '该功能需登录后方可使用，是否跳转登录页' })
      .then(() => {
        goLoginPage();
      })
      .catch(() => {});
  }

  return {
    showLoginDialog,
  };
}
