import { useRouter } from 'vue-router';

export function useGoBack() {
  const router = useRouter();
  function goBack() {
    router.back()
  }

  return {
    goBack,
  };
}
