import { ref, onMounted } from 'vue'
import useCache from '@/hooks/useCache'
import { homeSwipePic } from '@/api/home'
import { getRealFilePath } from '@/utils'

export function useCacheImage(imageType: string) {
  let img = ref('')

  onMounted(() => {
    useCache({
      key: imageType,
      service: homeSwipePic,
      params: {
        imageType,
      },
      callback: ({ code, data, mag }: any) => {
        if (code == 200 && data.images.length) {
          img.value = getRealFilePath(data.images[0].fileAddress)
        }
      },
    })
  })

  return {
    img,
  }
}
