import { ref } from 'vue';
import { Base64 } from 'js-base64';
import { getProtocolList, getProtocolDetail } from '@/api/news';
import { useRouter } from 'vue-router';
import { storeToRefs } from 'pinia';
import { useSettingStore } from '@/store';

export function useProtocol() {
  const router = useRouter();
  const settingStore = useSettingStore();
  const { schoolId } = storeToRefs(settingStore);

  const list = ref<any[]>([]);
  const detail = ref<any>('');

  async function getListData(schoolId: string) {
    let protocolList = settingStore.protocol[schoolId];
    if (protocolList) {
      list.value = protocolList;
      return;
    }
    const result = await getProtocolList({
      newsType: 'login_protocol',
      schoolId,
      pageNum: 1,
      pageSize: 2,
    });
    if (result.code == 200) {
      list.value = result.data.list;
      settingStore.protocol[schoolId] = result.data.list;
    }
  }

  async function getDetailData(niId: string) {
    const result = await getProtocolDetail({ niId });
    if (result.code == 200) {
      detail.value = decodeURIComponent(
        Base64.decode(Base64.decode(Base64.decode(Base64.decode(result.data.content))))
      );
    }
  }

  function goProtocolPage({ isUrl, contentUrl, niId }: NewsData) {
    if (isUrl == '1') {
      window.location.href = contentUrl;
    } else {
      router.push({ path: '/protocol', query: { niId } });
    }
  }

  function getListDataByWatchSchoolId() {
    watchEffect(() => {
      getListData(schoolId.value);
    });
  }

  return {
    list,
    getListData,
    detail,
    getDetailData,
    goProtocolPage,
    getListDataByWatchSchoolId,
  };
}
