import { computed } from 'vue';
import { SchoolCode } from '@/constants';
import { getSchoolCode,getLocalStorageItem } from '@/utils';
// import { hex2Rgba } from '@/utils/hex2rgba';
// import { useSettingStore } from '@/store';
const BaseFileUrl = import.meta.env.VITE_APP_PIC_BASE_URL;
/**组织卡样背景颜色使用主题色填充 */
export function useOrgCard() {
  const schoolCode = getSchoolCode();
// const settingStore = useSettingStore();

  const orgCardStyle = computed(() => {
    let style = {};

    if (schoolCode == SchoolCode.GuangWenYi) {
      style = {
        ...style,
        background: `
          linear-gradient(45deg, var(--theme-color-0-6), rgba(255, 255, 255, 0.8)),
          radial-gradient(circle at 10px 15px, rgba(255, 255, 255, 0.6) 20%, var(--theme-color-0-2) 0%),
          radial-gradient(circle at 340px 5px, rgba(255, 255, 255, 0.8) 15%, var(--theme-color-0-2) 0%)
          `,
        'border-radius': '18px',
      };
    }else if (schoolCode == SchoolCode.XiangXianZhongXue){   
      let url = ''
      let storageData = JSON.parse(getLocalStorageItem('Cache__ECARD_BACKGROUND') as string) 
      url = BaseFileUrl + storageData.data.images[0].fileAddress || ''
      style = {
        // ...style,
        background: `url(${url})  no-repeat`,
        'background-size': `100% 100%`
      }
    }

    return style;
  });

  return {
    orgCardStyle,
  };
}
