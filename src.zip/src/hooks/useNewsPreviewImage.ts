import { ref, onMounted, onBeforeUnmount  } from 'vue'

/**
 * 新闻内容图片预览
 * @param parentSelector 父元素css选择器
 * @returns 
 */
export function useNewsPreviewImage(parentSelector: string) {
  let imgDomList:NodeListOf<HTMLImageElement>
  const previewImage = ref<string[]>([])
  const showPreviewImage = ref(false)
  const onPreviewImage = (e: any) => {
    previewImage.value = [e.target.src]
    showPreviewImage.value = true
  }

  onMounted(() => {
    imgDomList = document.querySelectorAll(`${parentSelector} img`)
    if(!imgDomList.length) return
    imgDomList.forEach(el => el.addEventListener('click', onPreviewImage))
  })

  onBeforeUnmount(() => {
    if(!imgDomList.length) return
    imgDomList.forEach(el => el.removeEventListener('click', onPreviewImage))
  })

  return {
    previewImage,
    showPreviewImage,
  }
}