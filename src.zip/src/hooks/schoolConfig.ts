import { SchoolCode, ConcatUsDataFromUserManageSchoolList } from '@/constants'
import { getSchoolCode } from '@/utils'

/**
 * 获取学校的一些名词配置
 * @param val 菜单
 * @param type 类型
 * @returns
 */
export const schoolConfig = (val: string, type?: string) => {
  console.log('schoolConfig', val, type)
  let schoolCode = getSchoolCode()!
  if (val == 'contactus') {
    const ShanDaConfig = {
      title: '校内电话',
      connect: 'contactInformation',
      addressName: '所在校区',
    }
    const DefaultConfig = {
      title: '联系我们',
      connect: ConcatUsDataFromUserManageSchoolList.includes(schoolCode)
        ? 'mobile'
        : 'contactInformation',
      addressName: '地址',
    }
    return (
      {
        [SchoolCode.ShanDa]: ShanDaConfig,
      }[schoolCode] || DefaultConfig
    )
  }

  if (val == 'matePictures') {
    const DefaultConfig = {
      title: '校友相册',
    }
    const ShanDaConfig = {
      title: '印象汕大',
    }
    const XiangXianConfig = {
      title: '象贤拾忆',
    }
    const BaotouConfig = {
      title: '校园风光',
    }
    return (
      {
        [SchoolCode.ShanDa]: ShanDaConfig,
        [SchoolCode.XiangXianZhongXue]: XiangXianConfig,
        [SchoolCode.BaoTouZhiYeJiShu]: BaotouConfig,
      }[schoolCode] || DefaultConfig
    )
  }

  if (val == 'news') {
    // 这里放全部学校通用的配置, 其他学校的个性化名称独自书写对应的配置变量
    const DefaultConfig = {
      focus_school: { title: '聚焦母校' },
    }

    const ShanDaConfig = {
      shoolmate_welfare: { title: '校友福利' },
      schoolmate_journal: { title: '校友会刊' },
      focus_school: { title: '母校要闻' },
      countryside_beauty: { title: '桑浦文苑' },
      schoolmate_work: { title: '校友工作' },
      schoolmate_show: { title: '校友风采' },
      school_enterprise_cooperation: { title: '产学研合作' },
    }

    const BaoTouConfig = {
      schoolmate_show_BTZY: { title: '校友风采' },
      campus_scenery_BTZY: { title: '校园风光' },
      school_history: { title: '云上校史馆' },
      focus_school: { title: '通知公告' },
    }

    const PeiYingConfig = {
      schoolmate_show_pyzx: { title: '级社风采' },
      history_pyzx: { title: '辉煌校史' },
      schoolmate_work_pyzx: { title: '培英风采' },
      cost_pyzx: { title: '缴费服务' },
      donate_pyzx: { title: '爱心捐赠' },
    }

    const XiangxianConfig = {
      donateXX: { title: '捐赠详情' },
      schoolmate_show_xxzx: { title: '校友风采' },
      latest_news_xxzx: { title: '新闻动态' },
    }

    const BeiHuaHangTianConfig = {
      donate_newsBH: { title: '爱心捐赠' },
    }

    const GuangWenYiConfig = {
      latest_news_gwy: { title: '最新动态' },
      schoolmate_show_gwy: { title: '校友风采' },
      campus_scenery_gwy: { title: '校园风光' },
    }

    const GuangDongShuiLiConfig = {
      // latest_news_gwy: { title: '最新动态' },
      schoolmate_show_gdsldl: { title: '校友风采' },
      // campus_scenery_gwy: { title: '校园风光' },
    }
    const ShenYangYaoKeConfig = {
      // latest_news_gwy: { title: '最新动态' },
      schoolmate_show_syyk: { title: '期队风采' },
      // campus_scenery_gwy: { title: '校园风光' },
    }    

    const WuLuMuQiZhiYeDaXueConfig = {
      latest_news_wlmqzydx: { title: '最新动态' },
      schoolmate_show_wlmqzydx: { title: '校友风采' },
      campus_scenery_wlmqzydx: { title: '校园风光' },
    }

    const ChengDeYiXueYuanConfig = {
      schoolmate_news_cdyxy: { title: '校友动态' },
      schoolmate_show_cdyxy: { title: '校友风采' },
      donate_cdyxy: { title: '捐赠详情' },
    }    

    let finallyTypeConfig: Record<string, any> =
      {
        [SchoolCode.ShanDa]: ShanDaConfig,
        [SchoolCode.BaoTouZhiYeJiShu]: BaoTouConfig,
        [SchoolCode.PeiYingZhongXue]: PeiYingConfig,
        [SchoolCode.XiangXianZhongXue]: XiangxianConfig,
        [SchoolCode.BeiHuaHangTianGongYe]: BeiHuaHangTianConfig,
        [SchoolCode.GuangWenYi]: GuangWenYiConfig,
        [SchoolCode.WuLuMuQiZhiYeDaXue]: WuLuMuQiZhiYeDaXueConfig,
        [SchoolCode.ChengDeYiXueYuan]: ChengDeYiXueYuanConfig,
        [SchoolCode.GuangDongShuiLiXueYuan]: GuangDongShuiLiConfig,
        [SchoolCode.ShenYangYaoKeDaXue]: ShenYangYaoKeConfig,
      }[schoolCode] || {}

    let mergeConfig: Record<string, any> = {
      ...DefaultConfig,
      ...finallyTypeConfig,
    }
    return mergeConfig[type!] || { title: '校友期刊' }
  }
  if (val == 'home') {
    const DefaultConfig = {
      title: '聚焦母校',
    }
    const ShandaConfig = {
      title: '母校要闻',
    }
    const BaoTouConfig = {
      title: '通知公告',
    }
    return (
      {
        [SchoolCode.ShanDa]: ShandaConfig,
        [SchoolCode.BaoTouZhiYeJiShu]: BaoTouConfig,
      }[schoolCode] || DefaultConfig
    )
  }
}

export interface config {
  title: string
  connect: string
  addressName: string
}
