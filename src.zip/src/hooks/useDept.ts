import ApiDept from '@/api/common';
import { useSettingStore } from '@/store';

export function useDept() {
  const settingStore = useSettingStore();
  const schoolId = settingStore.schoolId;

  async function getDept(parentId: string = '') {
    const {
      data = [],
      msg,
      code,
    } = await ApiDept.deptList({
      schoolId,
      parentId,
    });
    return data;
  }
  return {
    getDept,
  };
}
