/**router:路由
 * name：跳转目的地的名字
 * query：携带的参数
 * defaultBackUrl：匹配不上时默认跳转的地方
 * **/
export function nameHasRouter(router: any, name: string, path: string, query?: any, defaultBackUrl?: string) {
    if (router.hasRoute(name)) {
        // router.push({ name })
        if (query) {
            router.push({ path, query })
        } else {
            router.push({ path })
        }
    } else {
        if (defaultBackUrl) {
            router.push({ path: defaultBackUrl })
        } else {
            // router.push({ name: 'first' })
        }
    }
}


export function nameHasRouterByFn(router: any, name: string, path: string, fnJump: Function,query?: any, ) {
    if (router.hasRoute(name)) {
        if (query) {
            router.push({ path, query })
        } else {
            router.push({ path })
        }
    } else {
        fnJump()
    }
}