import { storeToRefs } from 'pinia';
import { useUserStore } from '@/store';
import { useRouter } from 'vue-router';
import { deepClone } from '@/utils/util';
export function useOccupation(formData: any, listParam?: any) {
  const router = useRouter();
  const userStore = useUserStore();
  const { occupation } = storeToRefs(userStore);

  function initOccupation() {
    userStore.occupation = {
      code: formData.occupationCode || '',
      occupationName: formData.occupationName || '',
      parentCode: formData.occupationParentCode || '',
    };
  }

  function goOccupationPage(val?: string) {
    sessionStorage.setItem('cacheFormData', JSON.stringify(formData));
    sessionStorage.setItem('cacheListData', JSON.stringify(listParam));
    if (val !== '1') {
      router.push('/occupation');
    } else {
      userStore.isNeedInitOccupation = false
    }

  }


  function getDataFromCache() {
    // let formData1 = JSON.parse(JSON.stringify(sessionStorage.getItem('data1')))
    let formData1 = deepClone(sessionStorage.getItem('data1'))
    if (!!formData1) {
      // let b = sessionStorage.getItem('cacheFormData');
      // if (b) {
      //   return JSON.parse(sessionStorage.getItem('cacheFormData') as string);
      // } else {
      //   return JSON.parse(formData1 as string);
      // }
      sessionStorage.removeItem('data1')
      return JSON.parse(formData1 as string);
    } else {
      // console.log(JSON.parse(sessionStorage.getItem('cacheFormData') as string))

      return JSON.parse(sessionStorage.getItem('cacheFormData') as string);
    }

  }
  function getDataListCache() {
    return JSON.parse(sessionStorage.getItem('cacheListData') as string);
  }

  function pickOccupationToSubmit() {
    formData.occupationCode = occupation.value.code;
  }

  return {
    occupation,
    initOccupation,
    goOccupationPage,
    getDataListCache,
    pickOccupationToSubmit,
    getDataFromCache,
  };
}
