import { computed } from 'vue';

export function useVModel(props: any, key: any, emit: any) {
  const model = computed({
    get() {
      return props[key];
    },
    set(value: any) {
      emit(`update:${key}`, value);
    },
  });
  return model;
}
