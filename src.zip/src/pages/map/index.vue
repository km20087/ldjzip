<template>
  <div class="map-address">
    <van-nav-bar title="地图" left-text="" left-arrow @click-left="onClickLeft" />
    <div id="container" class="mapSize"></div>
    <div class="list">
      <van-tabs v-model:active="active" title-active-color="#02548E" color="#02548E">
        <van-tab title="全部祝福" name="1"></van-tab>
        <van-tab title="校友祝福" name="2"></van-tab>
      </van-tabs>
      <div class="con">
        <div class="title">
          <div class="op" v-if="active == '1'">祝福地区</div>
          <div class="op" v-if="active == '2'">校友会</div>
          <div class="op">祝福数</div>
        </div>
        <div v-if="active == '1'">
          <div class="listData" v-for="(item, index) in proList" :key="index">
            <div class="listCss porName">{{ item.provinceName }}</div>
            <div class="listCss">{{ item.count }}</div>
          </div>
        </div>
        <div v-if="active == '2'">
          <div class="listData" v-for="(item, index) in aluList" :key="index">
            <div class="listCss porName">{{ item.groupName }}</div>
            <div class="listCss">{{ item.count }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import { ref, reactive, shallowRef } from 'vue';
  import Api from '@/api/statistics';
  import AMapLoader from '@amap/amap-jsapi-loader';
  import proAddList from './data';
  import dataDetailList from './saveData';
  import locationAddress from '@/assets/icons/locationAddress.png';
  import { locationP } from '@/store';
  const locationSetting = locationP();
  const router = useRouter();
  let AMap: any = null;
  // let map: any = null;
  let map: any = shallowRef(null);
  //shallowRef
  const position: any = ref(null);
  const address_list = <any>ref([]);
  const keyWords = ref('');
  const showFlag = ref(false);
  const proName = ref('');
  const proList = ref([] as any);
  const proDo = ref([] as any);
  const aluList = ref([] as any);
  const cityList = ref([] as any);
  // const proDataList = ref([] as any);
  const active = ref('1');
  // declare const window: any;
  const content = ref({
    address: '',
    district: '',
    name: '',
  });
  const initProviceData = async () => {
    const { data, code, msg } = await Api.provinceStatistics({});
    console.log(data);
    proDo.value = data;
    for (let i in data) {
      if (data[i].count > 0) {
        for (let a in proAddList) {
          if (proAddList[a].name == data[i].provinceName) {
            proList.value.push({
              provinceName: data[i].provinceName as string,
              count: data[i].count,
              address: proAddList[a].address,
              provinceId: data[i].provinceId,
            });
          }
        }
      }
    }
    console.log(proList.value);
    console.log(proDo.value);
    initAMap();
  };
  const initGroupData = async () => {
    const { data, code, msg } = await Api.groupStatistics({});
    console.log(data);
    aluList.value = data;
  };
  const initCityData = async (id: string) => {
    const { data, code, msg } = await Api.cityStatistics({ provinceId: id });
    // cityList.value = data;
    for (let i in data) {
      for (let a in dataDetailList) {
        if (data[i].count > 0 && data[i].cityName == dataDetailList[a].name) {
          cityList.value.push({ name: dataDetailList[a].name, address: dataDetailList[a].addres });
        }
      }
    }
    console.log(cityList.value);
    circleMarker(cityList.value);
  };
  const onClickLeft = () => {
    locationSetting.name = '';
    router.back();
  };
  const initAMap = () => {
    // let that = this
    const win: any = window;
    win._AMapSecurityConfig = {
      securityJsCode: '8a4931bec7543c742723339bd4fa5db2', //8a4931bec7543c742723339bd4fa5db2    461c0a8910d54d894acfa2e9c39f34b2
    };

    AMapLoader.load({
      key: '61e60ce47ee77e4dc67245e44eef5993', //申请好的Web端开发者Key，首次调用 load 时必填
      version: '2.0', //61e60ce47ee77e4dc67245e44eef5993   cb5cfb3a96c0317b53acbc3de59cec28
      plugins: [],
    })
      .then((Amap: any) => {
        AMap = Amap;
        // 其他功能同h5
        map = new AMap.Map('container', {
          // viewMode: "3D",
          center: [106.230909, 38.487193], // 银川
          // center: [105.602725, 37.076636], //初始化地图中心点位置
          // certer: [120.619585, 31.299379], //
          // center: [113.264385, 23.129112], //广州
          // center: [120.631898, 31.264212], //苏州
          zoom: 3.3, // 地图缩放级别
          mapStyle: 'amap://styles/fresh',
        });
        // console.log(map.getCenter());
      })
      .catch((e) => {
        console.log('高德地图加载错误', e);
      })
      .finally(() => {
        circleMarker();
        map.on('moveend', logMapinfo);
      });
  };
  const circleMarker = (val?: any) => {
    if (!val) {
      for (let i in proList.value) {
        let cir = new AMap.Marker({
          position: new AMap.LngLat(proList.value[i].address[0], proList.value[i].address[1]),
          title: proList.value[i].name,
          icon: locationAddress,
          offset: new AMap.Pixel(-10, -10),
          size: new AMap.Size(20, 20), // 图标尺寸
          // imageSize: new AMap.Size(20, 20), // 根据所设置的大小拉伸或压缩图片
        });
        map.add(cir);
      }
    } else {
      for (let i in val) {
        let cir = new AMap.Marker({
          position: new AMap.LngLat(val[i].address[0], val[i].address[1]),
          title: val[i].name,
          icon: locationAddress,
          offset: new AMap.Pixel(-10, -10),
          size: new AMap.Size(20, 20), // 图标尺寸
          // imageSize: new AMap.Size(20, 20), // 根据所设置的大小拉伸或压缩图片
        });
        map.add(cir);
      }
    }
  };
  const logMapinfo = () => {
    let zoom = map.getZoom(); //获取当前地图级别，小于或等于8就是市级，大于或4就是国家级
    //zoom要大于或等于4，小于或等于8。在5.8就会显示城市名，在6时调cityStatistics接口查询
    console.log(zoom);
    // map.getCity()
    map.getCity(function (info: any) {
      console.log(info);
      if (!proName.value) {
        proName.value = info.province;
      } else if (proName.value !== info.province) {
        proName.value = info.province;
      }
    });
  };
  const getProId = (val: string) => {
    let provinceId = '';
    console.log(proList.value);
    for (let i in proList.value) {
      if (proList.value[i].provinceName == val) {
        provinceId = proList.value[i].provinceId;
      }
    }
    // console.log(provinceId);
    initCityData(provinceId);
  };
  watch(proName, (newVal, oldVal) => {
    // console.log(newVal);
    getProId(newVal);
    // debounce(getProId(newVal), 500, { trailing: true });
  });
  onMounted(() => {
    initProviceData();
    initGroupData();
    // initAMap();
  });
</script>

<style lang="less" scoped>
  .list {
    position: relative;
    // top: -20px;
    width: 100%;
    // height: 100%;
    border-radius: 40px 40px 0px 0px;
  }
  .con {
    width: 100%;
    // height: 100%;
    padding: 0px 50px;
    .title {
      margin-top: 21px;
      // width: 650px;
      width: 100%;
      height: 70px;
      background: #f5f5f5;
      border-radius: 8px;
      display: flex;
      line-height: 70px;
      padding: 0px 111px 0px 32px;
      justify-content: space-between;
      .op {
        font-size: 28px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #333333;
        // line-height: 28px;
      }
    }
    .porName {
      width: 60%;
      margin-right: 18%;
    }
    .listData {
      // padding: 0px 20px;
      width: 100%;
      height: 70px;
      line-height: 70px;
      display: flex;
      // justify-content: space-between;
      padding-left: 32px;
      padding-right: 60px;
      box-shadow: 0px 1px 0px 0px rgba(223, 223, 223, 0.5);
      .listCss {
        font-size: 28px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 500;
        color: #333333;
      }
    }
  }
  #container {
    width: 100%;
    height: 700px;
  }
  // .mapSize {
  //   /deep/.amap-layer {
  //     height: 700px !important;
  //     width: 100%;
  //   }
  // }
  /deep/.amap-icon img {
    width: 40px;
  }

  .van-row {
    margin-top: 10px;
  }
  .van-col {
    /deep/ .van-button {
      width: 300px;
    }
  }
  .amap-container {
    width: 100%;
    // height: 100vh;
    height: 600px;
  }
  .map-address {
    height: inherit;
    .container {
      width: 100px;
      height: 398px;
    }
    .search {
      position: relative;
    }
    .address-list {
      position: absolute;
      top: 200px;
      width: 100%;
      // left: 35px;
      background-color: #fff;
      // height: 238px;
      // overflow: auto;
      overflow-y: scroll;
      .tsad {
        // text-align: center;
      }
      ul {
        li {
          padding: 6px;
          border-bottom: 1px solid #ddd;
          p:nth-of-type(1) {
            color: #333;
            font-size: 14px;
          }
          p:nth-of-type(2) {
            color: #666;
            font-size: 12px;
          }
        }
      }
    }
  }
</style>
