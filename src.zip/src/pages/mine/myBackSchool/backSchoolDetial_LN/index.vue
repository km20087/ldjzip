<template>
  <van-sticky>
    <van-nav-bar title="预约详情" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="gray-bg">
    <!-- <div class="nav" v-if="dataList[0].auditStatus == '1'">
      <van-image class="icon" :src="success" />
      <span class="result">预约成功</span>
      <span class="tips">审核通过，请根据预约时段合理安排返校事宜</span>
    </div>
    <div class="nav" v-if="dataList[0].auditStatus == '0'">
      <van-image class="icon" :src="success" />
      <span class="result">已提交</span>
      <span class="tips">待审核，请耐心等待。。。</span>
    </div>
    <div class="nav" v-if="dataList[0].auditStatus == '2'">
      <van-image class="icon" :src="failed" />
      <span class="result">预约失败</span>
      <span class="tips">审核不通过，{{ message }}</span>
    </div>
    <div class="nav" v-if="dataList[0].auditStatus == '3'">
      <van-image class="icon" :src="failed" />
      <span class="result">已失效</span>
      <span class="tips">该预约已失效</span>
    </div>
    <div class="nav" v-if="dataList[0].auditStatus == '4'">
      <van-image class="icon" :src="failed" />
      <span class="result">预约失败</span>
      <span class="tips">预约名额已满，请另行选择返校时间</span>
    </div> -->
    <div class="banner">
      <FixImage :default-src="bannerBG" class="banner-bg" />
    </div>
    <div class="main-top">
      <div class="status get" v-if="!dataList[0]?.expired && dataList[0]?.auditStatus == '0'">待审核</div>
      <div class="status get" v-else-if="!dataList[0]?.expired && dataList[0]?.auditStatus == '1'">预约成功</div>
      <div class="status lose" v-else-if="!dataList[0]?.expired && dataList[0]?.auditStatus == '2'">审核不通过</div>
      <div class="status lose" v-else-if="!dataList[0]?.expired && dataList[0]?.auditStatus == '4'">名额已满</div>
      <div class="status lose" v-else>已 过 期</div>
      <div class="showTime">{{ currentTime }}</div>
      <div class="qrCode-cont">
        <!-- <img class="qrcode" :src="returnMsg.qrCode" />
                <div class="expired" v-if="returnMsg.expired">
                    <FixImage :default-src="expiredPic" class="pic" />
                    <span>已过期</span>
                </div> -->
        <ECard :per-info="perInfo" />
      </div>
    </div>
    <div class="main">
      <div class="title">预约信息</div>
      <van-cell title="返校事由" :value="dataList[0].returningReason"></van-cell>
      <van-cell title="返校日期" :value="dataList[0].returningDate"></van-cell>
      <van-cell title="返校时段" :value="`${dataList[0].returningStartTime}-${dataList[0].returningEndTime}`"></van-cell>
      <van-cell title="同行人数" :value="dataList[0].numberOfAccompanyingPersons"
        :is-link="viewMember.length > 0 ? true : false" :arrow-direction="isFold ? 'up' : 'down'"
        @click="isFold = !isFold">
      </van-cell>
      <van-cell-group v-if="!isFold">
        <van-cell title="" v-for="(item, index) in viewMember" :key="index">
          <template #label>
            <p>
              <span>姓名：&ensp;</span>
              <span>{{ item.returningPersonnelName }}</span>
            </p>
            <!-- <p>
              <span>身份证号：&ensp;</span>
              <span>{{ item.cardNumber }}</span>
            </p>
            <p>
              <span>联系方式：&ensp;</span>
              <span>{{ item.contactInformation }}</span>
            </p> -->
            <p>
              <span>性别：&ensp;</span>
              <span v-if="item.sex == '1'">男</span>
              <span v-if="item.sex == '0'">女</span>
            </p>
            <p>
              <span>同行人关系：&ensp;</span>
              <span>{{ item.relationship }}</span>
            </p>
          </template>
        </van-cell>
      </van-cell-group>
    </div>
  </div>
</template>
<script lang="ts" setup>
import success from '@/assets/img/success.png';
import failed from '@/assets/img/failed.png';
import bannerBG from '@/assets/returnSchoolMonth/BANNER@2X.png'
import { returnSchoolDetail } from '@/api/servive';
import { fommatDate } from '@/utils/fommatDate'
import ApiMy from '@/api/my';
import ECard from '../../../home/component/ECard.vue'

interface list {
  auditStatus?: string;
  returningReason?: string;
  expired?: string
  returningDate?: string;
  returningStartTime?: string;
  returningEndTime?: string;
  numberOfAccompanyingPersons?: string;
  cardNumber?: string;
  sex?: string
  returningPersonnelName?: string;
  relationship?: string;
  contactInformation?: string;
}
const $router = useRouter();
const $route = useRoute();
const onClickLeft = () => $router.back();
const id = ref($route.query.id);
const dataList = ref<list[]>([{}]);
const viewMember = ref([] as list[]);
const isFold = ref<boolean>(false);
const message = ref('');
let currentTime = ref<string>('')
const sexObj = ref<any>({ '0': '女', '1': '男' })
const perInfo = ref<perInfo>({
  name: '',
  collegeName: '',
  schoolName: '',
  classes: '',
  userProfilePicture: '',
  classesName: '',
  mobile: '',
  educationInfoList: [],
});
const initDetail = async () => {
  const { data, code, msg } = await returnSchoolDetail({
    returningSchoolId: id.value,
  });
  if (code == 200) {
    dataList.value = [...data];
    viewMember.value = dataList.value.filter((item, index) => {
      return index > 0;
    });
    console.log(dataList.value, 'dataList.value');

  } else {
    message.value = msg;
  }
};
initDetail();

const initMy = async () => {
  const { data, msg, code } = await ApiMy.baseInfo({});
  if (data?.educationInfoList) {
    data.educationInfoList = data.educationInfoList.filter(
      (item: any) => Object.getOwnPropertyNames(item).length != 0
    );
  }
  Object.assign(perInfo.value, data);
};
initMy()

onMounted(() => {
  setInterval(() => {
    currentTime.value = fommatDate(new Date(), '年月日时分秒')
  }, 1000);
});
</script>
<style lang="less" scoped>
.nav {
  background: #fff;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 50px 0;
  margin-bottom: 24px;

  .icon {
    width: 120px;
    height: 120px;
    margin: 15px;
  }

  .result {
    font-size: 36px;
    color: #333333;
    font-weight: 600;
    padding: 15px;
  }

  .tips {
    font-size: 28px;
    color: #666666;
  }
}

.main {
  margin: 20px 24px 24px;
  box-shadow: 0 0 8px 0 rgba(5, 112, 201, 0.08);
  border-radius: 15px;
  background: #fff;
  padding: 30px;

  .title {
    font-size: 32px;
    color: #333333;
    font-weight: 600;
    padding: 0 20px;
    border-left: 5px solid var(--theme-color);
    line-height: 32px;
    margin-bottom: 20px;
  }
}

.banner-bg {
  width: 100vw;
  height: 209px;
}

.main-top {
  margin: 20px 24px 24px;
  padding-bottom: 24px;
  background: #FFFFFF;
  box-shadow: 0 0 8px 0 rgba(5, 112, 201, 0.08);
  border-radius: 15px;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;

  .status {
    font-size: 36px;
    letter-spacing: 0;
    text-align: center;
    line-height: 24px;
    font-weight: 500;
    padding: 30px 0 34px;
  }

  .get {
    color: #00CB2B;
  }

  .lose {
    color: #FF0000;
  }

  .showTime {
    font-weight: 500;
    font-size: 36px;
    color: #3A62A4;
    padding: 5px 0 30px;
  }

  .qrCode-cont {
    // width: 350px;
    // height: 350px;
    // position: relative;
    width: 100%;

    :deep(.E-card) {
      padding: 0 25px;
      background: none;
      height: 452px;
    }

    .qrcode {
      width: 100%;
      height: 100%;
      align-items: center;
    }

    .expired {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, .7);
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      color: #FFFFFF;
      font-size: 30px;
      line-height: 80px;
      font-weight: 500;

      .pic {
        width: 70px;
        height: 70px;
      }
    }
  }

  .detail {
    padding: 24px;
    width: 100%;
    margin-top: 34px;
    color: #666;
    border-top: 2px dashed #999;

    .one {
      display: flex;
      justify-content: space-between;
      line-height: 58px;

      .b {
        color: #222;
      }
    }
  }
}
</style>