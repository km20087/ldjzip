<template>
  <div class="back-list">
    <div class="up">
      <div class="l">
        <van-image :src="url" class="icon" />
        <span>{{ date }}</span>
      </div>
      <div class="r">查看详情 <van-icon name="arrow" color="#999" size="15" /></div>
    </div>
    <div class="down">
      <span>{{ reason }}</span>
      <span>同行{{ people }}人</span>
    </div>
  </div>
</template>
<script lang="ts" setup>
const props = withDefaults(
  defineProps<{
    url?: string;
    date?: string;
    reason?: string;
    people?: string;
  }>(),
  {}
);
</script>
<style lang="less" scoped>
.back-list {
  background: #ffffff;
  border-radius: 16px;
  padding: 20px 24px;
  .up,
  .down {
    display: flex;
    justify-content: space-between;
    padding: 12px 0;
    .l,
    .r {
      display: flex;
      align-items: center;
      font-size: 24px;
      color: #666;
      .icon {
        width: 156px;
        height: 44px;
        margin-right: 20px;
      }
    }
    .r {
      color: #999;
    }
  }
}
</style>