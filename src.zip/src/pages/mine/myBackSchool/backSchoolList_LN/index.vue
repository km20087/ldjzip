<template>
  <van-sticky>
    <van-nav-bar title="我的预约" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="back-cont gray-bg">
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
        <backlist v-for="(item, index) in backList" :key="index" :url="item.url" :date="item.returningDate"
          :reason="item.returningReason" :people="String(Number(item.numberOfAccompanyingPersons) - 1)"
          @click="toDetail(item.returningSchoolId)" />
      </van-list>
    </van-pull-refresh>
  </div>
</template>
<script lang="ts" setup>
import backlist from '../components/backlist.vue';
import successIcon from '@/assets/appointment/successIcon.png';
import failedIcon from '@/assets/appointment/failedIcon.png';
import expireIcon from '@/assets/appointment/expireIcon.png';
import { returnSchoolList } from '@/api/servive';
import { Toast } from 'vant';
import { isLiaoShiDa } from '@/utils/customizedType';
import { nameHasRouter } from '@/hooks/hasRouter';

const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const backList = ref([] as any[]);
const listP = {
  pageNum: 1,
  pageSize: 10,
};

const $router = useRouter();
const onClickLeft = () => $router.back();

const onRefresh = () => {
  // 清空列表数据
  finished.value = false;

  // 重新加载数据
  // 将 loading 设置为 true，表示处于加载状态
  loading.value = true;
  listP.pageNum = 1;
  backList.value = [];
  onLoad();
};
const onLoad = async () => {
  // 异步更新数据
  let { code, data, msg } = await returnSchoolList(listP);
  if (code == 200) {
    data.list.forEach((item: any) => {
      item.url = !item.expired
        ? item.auditStatus == 0 || item.auditStatus == 1
          ? successIcon
          : failedIcon
        : expireIcon;
    });
    backList.value = backList.value.concat(data.list);
    listP.pageNum++;
    loading.value = false;
    if (backList.value.length >= data.total) {
      finished.value = true;
    }
  } else {
    Toast.fail(msg);
    finished.value = true;
  }
  refreshing.value = false;
};
const toDetail = (id: any) => {
  if (isLiaoShiDa()) {
    nameHasRouter($router, 'backSchoolDetail-ln', '/backSchoolDetail-ln', { id });
  } else {
    nameHasRouter($router, 'backSchoolDetail', '/backSchoolDetail', { id });
  }
};
</script>
<style lang="less" scoped>
.back-cont {
  padding: 24px 30px;
  width: 100%;
  height: 100%;
}
</style>