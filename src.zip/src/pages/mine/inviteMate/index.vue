<template>
    <div class="container">
        <van-sticky>
            <van-nav-bar title="邀请校友" left-arrow @click-left="onClickLeft" />
        </van-sticky>
        <van-search v-model="keyWord" @search="onSearch" placeholder="请输入搜索关键词" />
        <div class="banner">
            <div class="title">{{ groupsName }}</div>
            <van-checkbox v-model="checkedAll" @click="toggleAll" shape="square" label-position="left">全选</van-checkbox>
        </div>
        <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
            <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad" :offset="50">
                <van-checkbox-group v-model="checked" ref="checkboxGroup">
                    <van-cell-group>
                        <van-cell v-for="(item, index) in matesList" clickable :key="item" :title="item.name"
                            :label="`${item.schoolStartYear}`" center @click="toggle(index)">
                            <template #icon>
                                <fix-image class="mate-head" :default-src="DefaultAvatar" :src="item.avatar"></fix-image>
                            </template>
                            <template #right-icon>
                                <van-checkbox label-position="left" :disabled="item.inviteStatus == '02'"
                                    class="cancelEvent" shape="square" :name="item" :ref="el => checkboxRefs[index] = el"
                                    @click.stop>{{
                                        item.inviteStatus ==
                                        '02' ? '未接受邀请' :
                                        ''
                                    }}</van-checkbox>
                            </template>
                        </van-cell>
                    </van-cell-group>
                </van-checkbox-group>
            </van-list>
        </van-pull-refresh>
    </div>
    <van-sticky :offset-bottom="50" position="bottom">
        <div class="invite-sticky-btn">
            <van-button icon="plus" round block type="primary" @click="invite">一键邀请</van-button>
        </div>
    </van-sticky>
</template>
<script lang="ts" setup>
import { getNonMember, inviteMate } from "@/api/mine/index"
import DefaultAvatar from '@/assets/img/default-avatar.png';
import { Toast } from "vant";

const $router = useRouter();
const route = useRoute()
const keyWord = ref<string>("")
const checkedAll = ref<boolean>(false)
const checked = ref([]);
const checkboxRefs = ref<any>([]);
const checkboxGroup = ref<any>(null)
const matesList = ref<any[]>([])
const listP = ref<pageParams>({ pageNum: 1, pageSize: 10 })
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);

const onClickLeft = () => $router.back();
const toggle = (index: string | number) => {
    checkboxRefs.value[index].toggle();
    if (checked.value.length == matesList.value.length) {
        checkedAll.value = true
    } else {
        checkedAll.value = false
    }

};
const toggleAll = () => {
    let v = checkedAll.value
    checkboxGroup.value && checkboxGroup.value.toggleAll(v);

}
const getList = async (name?: string) => {
    let groupsId = route.query.groupsId
    let actId = route.query.actId
    let params = { ...listP.value, name, groupsId, actId }
    const { code, data, msg } = await getNonMember(params)
    if (code == 200) {
        matesList.value = matesList.value.concat(data.list);
        matesList.value.map((item: any) => item.schoolStartYear = item.schoolStartYear ?? '')
        listP.value.pageNum++;
        loading.value = false;
        if (matesList.value.length >= data.total) {
            finished.value = true;
        }
    } else {
        Toast.fail(msg);
        finished.value = true;
    }
    refreshing.value = false;
}
const onRefresh = () => {
    // 清空列表数据
    finished.value = false;

    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    loading.value = true;
    listP.value.pageNum = 1;
    matesList.value = [];
    onLoad();
};
const onLoad = () => {
    getList()
}
const onSearch = () => {
    matesList.value = []
    listP.value.pageNum = 1
    getList(keyWord.value)
}
const invite = async () => {
    if (checked.value.length == 0) return Toast('请选择校友！')
    let schoolmateIds = checked.value.map((item: any) => {
        return item.userId
    })
    let actId = route.query.actId
    let params = { actId, schoolmateIds }
    const { code, data, msg } = await inviteMate(params)
    if (code == 200) {
        Toast.success('邀请已发送，请耐心等待回复！')
        $router.back()
    } else {
        Toast.fail(msg)
    }
}
onBeforeUpdate(() => {
    checkboxRefs.value = [];
});
const groupsName = computed(() => {
    return route.query.groupsName
})
</script>
<style lang="less" scoped>
.container {
    height: 100%;
    overflow-y: auto;
}

.title {
    color: #333333;
    font-weight: 600;
    padding: 0 20px;
    border-left: 5px solid var(--theme-color);
    line-height: 32px;
}

.banner {
    font-size: 28px;
    padding: 35px 32px;
    background: #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.mate-head {
    width: 88px;
    height: 88px;
    border-radius: 50%;
    margin-right: 20px;
}

.cancelEvent {
    pointer-events: none;
}

.invite-sticky-btn {
    padding: 0 24px !important;
}
</style>