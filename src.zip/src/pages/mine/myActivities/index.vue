<template>
    <component :is="asyncChild" />
</template>
<script lang="ts" setup>
import { isLiaoShiDa } from '@/utils/customizedType';

const asyncChild = shallowRef<any>(null)
onMounted(async () => {
    const module = isLiaoShiDa() ? await import('./LN_index.vue') : await import('./SD_index.vue')
    //@ts-ignore
    asyncChild.value = module.default
})
</script>