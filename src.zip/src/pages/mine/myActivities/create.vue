<template>
    <van-sticky>
        <van-nav-bar title="创建活动" left-arrow @click-left="onClickLeft" />
    </van-sticky>
    <div class="gray-bg">
        <div class="table bg-white">
            <textFiled input-align="center" v-model="actForm.applicant" title="申请人"
                placeholder="(默认 管理员账号所在地区地方校友会)例如:大连校友会" />
            <textFiled input-align="center" v-model="actForm.actName" title="活动名称" placeholder="(按实际情况填写)" />
            <textFiled input-align="center" v-model="actForm.theme" title="活动主题" placeholder="(按实际情况填写)" />
            <timeselectFiled title="活动时间" v-model:data="actForm" />
            <textFiled input-align="center" v-model="actForm.schedule" title="日程安排" placeholder="（为非必填选项，持续2天以上的时间须填写此栏）" />
            <textFiled input-align="center" v-model="actForm.address" title="活动地点" placeholder="(按实际情况填写)" />
            <step-filed v-model="actForm.maximumParticipant" title="参加人数" />
            <div class="tr noBottom">
                <div class="text">活动简介</div>
            </div>
            <div class="tr hasBottom">
                <textarea v-model="actForm.introduction" class="txtArea" cols="30" rows="10"></textarea>
            </div>
        </div>
        <div class="upFile bg-white">
            <div class="imgArea">
                <div class="tit">活动海报</div>
                <div class="tip">只能上传jpg/png文件，且不超过500kb</div>
                <compress-uploader v-model="actForm.fileList" multiple max-count="3" :after-read="afterRead"
                    :max-size="500 * 1024" @oversize="onOversize" @delete="realDelete">
                    <div class="summit-btn">
                        <van-image :src="pic_plus" width="23" height="23" />
                        <span>上传</span>
                    </div>
                </compress-uploader>
            </div>
            <div class="fileArea">
                <span class="label">附件上传</span>
                <van-uploader max-count="1" :after-read="afterReadEnclosure">
                    <van-button round color="var(--theme-color)">点击上传</van-button>
                </van-uploader>
                <div class="flist" v-if="actForm.attach">
                    <div class="upPic">
                        <fix-image :default-src="pic_enclosure"></fix-image>

                    </div>
                    <div class="msg">
                        <div class="name">附件</div>
                        <div class="detail">点击可查看</div>
                    </div>
                    <div class="preview">
                        <fix-image :default-src="pic_preview" @click="previewFile"></fix-image>
                    </div>
                    <div class="delete">
                        <fix-image :default-src="pic_delete" @click="deleteFile"></fix-image>
                    </div>
                </div>
            </div>
        </div>
        <div class="some-opr">
            <van-button block round icon="guide-o" color="var(--theme-color)" @click="onSubmit('1')">提交</van-button>
        </div>
    </div>
</template>
<script lang="ts" setup>
import FileHandle from '@/utils/file-handle';
import pic_plus from "@/assets/archive/plus@2x.png"
import pic_enclosure from "@/assets/myActivities/enclosure@2x.png"
import pic_preview from "@/assets/myActivities/preview@2x.png"
import pic_delete from "@/assets/myActivities/close@2x.png"
import Api from '@/api/uploadfile';
import groupActivities from '@/api/act/index';
import compressUploader from "@/components/compress-uploader/index.vue"
import timeselectFiled from "@/components/MyActivities/createComponents/timeselect-filed.vue"
import textFiled from "@/components/MyActivities/createComponents/text-filed.vue"
import stepFiled from "@/components/MyActivities/createComponents/step-filed.vue"
import { Toast, UploaderFileListItem } from "vant";
import { useKeepAliveStore } from '@/store';
import { deepClone, getRealFilePath } from '@/utils'
import { downLoadFile } from '@/utils/tool/downLoad-file';

defineOptions({
    name: 'activitiAdd',
    beforeRouteEnter(to, from) {
        const keepAliveStore = useKeepAliveStore()
        let formName = from.name as string

        if (formName && ['orgDetail'].includes(formName)) {
            keepAliveStore.removeCacheEntry('activitiAdd')
        }
    }
})

const $router = useRouter();
const route = useRoute()
const groupsId = ref(route.query.groupsId)
const groupsName = ref(route.query.groupsName)
const actForm = ref<any>({ fileList: [], groupsId: groupsId.value, applicant: groupsName, startTime: '', endTime: '', eventPoster: [] })
let fileHandle = new FileHandle(['eventPoster', 'attach']);

const onClickLeft = () => $router.back();
const afterRead: any = async (file: any) => {
    let formData = new FormData();

    formData.append('file', file.file);
    file.status = 'uploading';
    file.message = '上传中...';
    await Api.uploadFile(formData)
        .then((res) => {
            if (res.code == 200) {
                file.status = '';
                file.message = '';
                nextTick(() => {
                    if (
                        res.data.tokenUrl &&
                        res.data.tokenUrl == '' &&
                        res.data.tokenUrl == undefined &&
                        res.data.tokenUrl == null
                    ) {
                        actForm.value.eventPoster.push(res.data.tokenUrl as string);
                    } else {
                        actForm.value.eventPoster.push(res.data.uploadUrl as string);
                    }
                });

                Toast.success('上传成功');
            } else {
                file.status = 'failed';
                file.message = '上传失败';
                Toast.fail(res.msg);
            }
        })
        .catch((err) => {
            file.status = 'failed';
            file.message = '上传失败';
            Toast.fail(`上传失败：${err}`);
        });
};
const onOversize = (file: File | File[]) => {
    Toast('图片大小不能超过500kb');
};
const realDelete = (_: any, detail: any) => {
    if (actForm.value.eventPoster.length == 0) return
    actForm.value.eventPoster.splice(detail.index, 1);
    sessionStorage.setItem('createActForm', JSON.stringify(actForm.value))
}
//上传附件成功
const afterReadEnclosure: any = async (file: UploaderFileListItem) => {
    let formData = new FormData();
    formData.append('file', file.file!);
    file.status = 'uploading';
    file.message = '上传中...';
    await Api.uploadFile(formData)
        .then((res) => {
            if (res.code == 200) {
                file.status = '';
                file.message = '';
                nextTick(() => {
                    if (
                        res.data.tokenUrl &&
                        res.data.tokenUrl == '' &&
                        res.data.tokenUrl == undefined &&
                        res.data.tokenUrl == null
                    ) {
                        actForm.value['attach'] = res.data.tokenUrl as string;
                    } else {
                        actForm.value['attach'] = res.data.uploadUrl as string;
                    }
                });

                Toast.success('上传成功');
            } else {
                file.status = 'failed';
                file.message = '上传失败';
                Toast.fail(res.msg);
            }
        })
        .catch((err) => {
            file.status = 'failed';
            file.message = '上传失败';
            Toast.fail(`上传失败：${err}`);
        });

}
const previewFile = () => {
    sessionStorage.setItem('createActForm', JSON.stringify(actForm.value))
    if (actForm.value.attach) {
        if (actForm.value.attach.indexOf('.pdf') !== -1 || actForm.value.attach.indexOf('.PDF') !== -1) {
            // downLoadFile(getRealFilePath(actForm.value.attach))
            window.open(getRealFilePath(actForm.value.attach), "_blank")
        }
    } else {
        window.location.href = getRealFilePath(actForm.value.attach)
    }
}
const deleteFile = () => {
    actForm.value.attach = ''
}
const onSubmit = async (action: string) => {
    actForm.value.action = action
    delete actForm.value.fileList
    const { code, data, msg } = await groupActivities.addGroupActivities({
        ...actForm.value,
        ...fileHandle.compare(actForm.value),
    });
    if (code == 200) {
        Toast.success(msg);
        $router.go(-1);
    } else {
        Toast.fail(msg);
    }
    sessionStorage.removeItem('createActForm')
};
onMounted(() => {
    actForm.value.fileList = []
    if (sessionStorage.getItem('createActForm')) {
        let cacheActForm = JSON.parse(sessionStorage.getItem('createActForm') || '')
        cacheActForm.fileList = deepClone(cacheActForm.eventPoster)
        cacheActForm.fileList = cacheActForm.fileList.map((item: any) => { return { url: getRealFilePath(item) } })
        actForm.value = cacheActForm
    }
})
</script>
<style lang="less" scoped>
@import './detail.less';
// .bg-white {
//     background-color: #fff;
// }

// .noBottom {
//     border-width: 2px 2px 0 2px;
//     border-color: #999;
//     border-style: solid;
// }

// .hasBottom {
//     border: 2px solid #999;
// }

// @font-size-30: 30px;
// @font-weight-500: 500;

// .content() {
//     padding: 20px;
//     min-height: 112.5px;
// }

// .vartical-middle() {
//     display: flex;
//     flex-direction: column;
//     justify-content: center;
//     align-items: center;
// }

// .title() {
//     font-size: @font-size-30 + 6px;
//     font-weight: @font-weight-500;
//     line-height: 88px;
// }

// .all-title {
//     .title()
// }

// .table {
//     padding: 16.5px;

//     .tr {
//         display: flex;
//         align-items: center;


//         .preference {
//             flex: 3;
//             // border-right: 2px solid #999;
//             font-size: @font-size-30;
//             font-weight: @font-weight-500;
//             .vartical-middle();
//             .content()
//         }

//         .inputArea {
//             flex: 7;
//             border-left: 2px solid #999;
//             display: flex;
//             align-items: center;
//             justify-content: center;
//             .content()
//         }

//         .text {
//             width: 100%;
//             text-align: center;
//             line-height: 70px;
//             font-size: 30px;
//             font-weight: 500;
//             color: #222;
//         }

//         .txtArea {
//             border: none;
//             width: 100%;
//             padding: 20px;
//         }
//     }
// }

// .deal-steps,
// .deal-idea,
// .mate-list,
// .upFile {
//     padding: 16.5px;
//     margin-top: 20px;

//     .imgArea {
//         .tit {
//             .title()
//         }

//         .tip {
//             font-size: @font-size-30 - 6px;
//             color: #999;
//         }

//         .summit-btn {
//             width: 140px;
//             height: 140px;
//             border-radius: 16px;
//             background: #f5f5f5;
//             .vartical-middle();
//             // margin: 24px 0;

//             span {
//                 font-size: @font-size-30 -2px;
//                 font-weight: @font-weight-500;
//                 color: #999;
//                 line-height: 44px;
//             }
//         }
//     }

//     .fileArea {
//         margin-top: 40px;
//         display: flex;
//         align-items: center;
//         flex-wrap: wrap;

//         .label {
//             font-size: @font-size-30 + 6px;
//             font-weight: @font-weight-500;
//             line-height: 88px;
//             padding-right: 20px;
//         }

//         .flist {
//             border: 2px solid #DFDFDF;
//             border-radius: 8px;
//             padding: 24px;
//             margin: 24px 0;
//             display: flex;
//             align-items: center;
//             width: 100vw;

//             .upPic {
//                 flex: 1;

//                 img {
//                     width: 54px;
//                     height: 54px;
//                 }
//             }

//             .msg {
//                 flex: 7;

//                 .name {
//                     font-size: @font-size-30 - 2px;
//                     font-weight: @font-weight-500;
//                     color: #333;
//                     line-height: 36px;
//                 }

//                 .detail {
//                     font-size: @font-size-30 - 10px;
//                     color: #999;
//                 }
//             }

//             .preview,
//             .delete {
//                 flex: 1;

//                 img {
//                     width: 40px;
//                     height: 40px;
//                 }
//             }

//         }
//     }

//     .tit-on {
//         display: flex;
//         justify-content: space-between;
//     }

//     .txt {
//         .title();
//     }

//     .head-list {
//         display: flex;
//         align-items: center;
//         margin-top: 40px;
//         justify-content: space-between;

//         .head-cont {
//             display: flex;
//             align-items: center
//         }

//         .head {
//             .vartical-middle();
//             margin-right: 24px;

//             .head-img {
//                 width: 80px;
//                 height: 80px;
//                 border-radius: 50%;
//             }

//             .user-name {
//                 font-size: @font-size-30 - 6px;
//                 line-height: @font-size-30 + 24px;
//             }
//         }

//         .jiantou {
//             width: 36px;
//             height: 117.56px;
//         }
//     }

//     .deal-area {
//         border: 1px solid #dfdfdf;
//         border-radius: 16px;
//         padding: 24px;
//     }

//     .status-word {
//         font-size: @font-size-30 + 6px;
//         font-weight: @font-weight-500;
//     }

//     .deal-time {
//         font-size: @font-size-30 - 6px;
//         color: #999;
//         margin-top: 20px;
//     }
// }

// .some-opr {
//     padding: 105px 24px;
// }

// :deep(.van-cell) {
//     padding: 0;

//     .van-field__control {
//         font-size: @font-size-30 - 2px;
//         text-align: center;
//     }
// }

// :deep(.van-uploader__wrapper) {
//     padding: 24px 0;
// }

// :deep(.van-uploader__preview-image) {
//     width: 140px;
//     height: 140px;
// }
</style>