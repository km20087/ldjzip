<template>
    <van-sticky>
        <van-nav-bar title="我的活动" left-arrow @click-left="onClickLeft" />
    </van-sticky>
    <div class="boas">
        <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
            <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
                <subVue v-for="(item, index) in actList" :tabindex="item.status" :key="index"
                    :url="picUrl + item.eventPoster" :introduction="item.introduction" :organizer="item.organizer"
                    :theme="item.theme" :currentNumberOfParticipants="item.currentNumberOfParticipants"
                    :registrationFlag="item.registrationFlag" :startTime="item.startTime" :endTime="item.endTime"
                    :registrationDeadline="item.registrationDeadline" />
            </van-list>
        </van-pull-refresh>
    </div>
</template>
<script lang="ts" setup>
import subVue from "@/pages/activeList/components/subComponents/sub.vue";
import { reactive, ref } from "vue";
import { getMyActList } from "@/api/mine/index";
import { Toast } from "vant";
const $router = useRouter();
const onClickLeft = () => $router.back();
const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
let actList = <any>reactive([]);
const listP = {
    pageNum: 1,
    pageSize: 10
};
const onLoad = async () => {
    // 异步更新数据
    let { code, data, msg } = await getMyActList(listP);
    if (code == 200) {
        actList = actList.concat(data.list);
        listP.pageNum++;
        loading.value = false;
        if (actList.length >= data.total) {
            finished.value = true;
        }
    } else {
        Toast.fail(msg);
        finished.value = true;
    }
    refreshing.value = false;
};
const onRefresh = () => {
    // 清空列表数据
    finished.value = false;

    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    loading.value = true;
    listP.pageNum = 1;
    actList = [];
    onLoad();
};
</script>
<style lang="less" scoped>
.boas {
    width: 100%;
    height: 100%;
    padding: 0 30px;
}
</style>
