<template>
  <van-sticky>
    <van-nav-bar title="我的活动" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="gray-bg">
    <div class="tabs-cont">
      <Tabs @click="tabsClick" :data="tabsData" />
    </div>
    <div class="list-cont">
      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
          <ActList v-for="item in actList" :key="item.id" :item="item" :act-type="tabName"
            @to-detail="toDetail(item.id, item.groupsId, tabName)" />
          <div class="tips" v-if="tabName == 'create'"><span class="red">温馨提示：</span>
            <span v-if="identifyMode == '1'">发起的活动连续终止三次，系统限制将限制您90天内不得发起活动，45天内不得审批活动，请谨慎选择。</span>
            <span v-else>发起活动连续中止三次，系统将限制您180天内不得发起活动，请谨慎选择。</span>
          </div>
        </van-list>
      </van-pull-refresh>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { Toast } from "vant";
import Tabs from "@/components/MyActivities/tabs.vue"
import ActList from "@/components/MyActivities/list.vue"
import { getMyCreateActivitiesList, getJoinedActivitiesList } from "@/api/mine/index"
import { useSettingStore } from "@/store";
import { storeToRefs } from 'pinia';

const tabsData = ref<Array<Partial<tabPros>>>([
  { title: "我发起的活动(0)", name: "create" }, { title: "我参加的活动(0)", name: "join" }
])
let { identifyMode } = storeToRefs(useSettingStore())
const actList = ref<any>([])
const listP = ref<pageParams>({ pageNum: 1, pageSize: 10 })
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const tabName = ref('create')

const $router = useRouter();
const onClickLeft = () => $router.back();
const tabsClick = (name: string = '', title: string = '') => {
  tabName.value = name
  initLoad()
}
let setDisabled = (b: boolean) => {
  tabsData.value.map(item => {
    item.disabled = b
  })
}
const initLoad = () => {
  finished.value = false;
  loading.value = false;
  listP.value.pageNum = 1;
  actList.value = [];
  // onLoad()
}
const getCreateList = async () => {
  try {
    setDisabled(true)
    let { code, data, msg } = await getMyCreateActivitiesList(listP.value)
    if (code == 200) {
      actList.value = actList.value.concat(data.list);
      listP.value.pageNum++;
      loading.value = false;
      tabsData.value.map(item => {
        if (item.name == "create") return item.title = `我发起的活动(${data.total})`
      })
      if (actList.value.length >= data.total) {
        finished.value = true;
      }
    } else {
      Toast.fail(msg);
      finished.value = true;
    }
    refreshing.value = false;
  } catch (error) {

  } finally {
    setDisabled(false)
  }

}
const getJoinList = async () => {
  let { code, data, msg } = await getJoinedActivitiesList(listP.value)
  if (code == 200) {
    actList.value = actList.value.concat(data.list);
    listP.value.pageNum++;
    loading.value = false;
    tabsData.value.map(item => {
      if (item.name == "join") return item.title = `我参加的活动(${data.total})`
    })
    if (actList.value.length >= data.total) {
      finished.value = true;
    }
  } else {
    Toast.fail(msg);
    finished.value = true;
  }
  refreshing.value = false;
}
const onRefresh = () => {
  // 清空列表数据
  finished.value = false;

  // 重新加载数据
  // 将 loading 设置为 true，表示处于加载状态
  loading.value = true;
  listP.value.pageNum = 1;
  actList.value = [];
  onLoad();
};
const onLoad = () => {
  if (tabName.value == 'create') {
    getCreateList()
  } else {
    getJoinList()
  }
}
const toDetail = (id: string, groupsId: string, tabName: string) => {
  $router.push({ path: 'activitiDetail', query: { id, groupsId, tabName } })
}
</script>
<style lang="less" scoped>
.bg-white() {
  background: #fff;
}

@padding-24: 24px;

.red {
  color: #ff0000
}

.tabs-cont {
  .bg-white();
  padding: @padding-24;
  margin-bottom: 20px;
}

.list-cont {
  .bg-white();
  height: 100vh;
  overflow-y: scroll;
  margin-top: 20px;

  .tips {
    margin: 24px 30px;
    padding: 24px 30px;
    border-radius: 6px;
    background: #f7f7f7;
    font-size: 24px;
    line-height: 38px;
    color: #666;
  }
}
</style>
