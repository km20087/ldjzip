<template>
  <van-sticky>
    <van-nav-bar title="活动详情" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="gray-bg">
    <div class="table bg-white">
      <textFiled input-align="center" v-model="actForm.applicant" :readonly="!writeable" title="申请人"
        placeholder="(默认 管理员账号所在地区地方校友会)例如:大连校友会" />
      <textFiled input-align="center" v-model="actForm.actName" :readonly="!writeable" title="活动名称"
        placeholder="(按实际情况填写)" />
      <textFiled input-align="center" v-model="actForm.theme" :readonly="!writeable" title="活动主题"
        placeholder="(按实际情况填写)" />
      <timeselectFiled title="活动时间" :readonly="!writeable" v-model:data="actForm" />
      <textFiled input-align="center" v-model="actForm.schedule" :readonly="!writeable" title="日程安排"
        placeholder="（为非必填选项，持续2天以上的时间须填写此栏）" />
      <textFiled input-align="center" v-model="actForm.address" :readonly="!writeable" title="活动地点"
        placeholder="(按实际情况填写)" />
      <step-filed title="参加人数" v-model="actForm.maximumParticipant" v-if="writeable" />
      <textFiled input-align="center" v-model="actForm.maximumParticipant" readonly title="参加人数" placeholder="参加人数"
        v-else />
      <div class="tr noBottom">
        <div class="text">活动简介</div>
      </div>
      <div class="tr hasBottom">
        <textarea v-model="actForm.introduction" :readonly="!writeable" class="txtArea" cols="30" rows="10"></textarea>
      </div>
    </div>
    <div class="upFile bg-white">
      <div class="imgArea">
        <div class="tit">活动海报</div>
        <div class="tip">只能上传jpg/png文件，且不超过500kb</div>
        <compress-uploader v-model="fileList" multiple max-count="3" :after-read="afterRead" :max-size="500 * 1024"
          @oversize="onOversize" @delete="realDelete" :deletable="writeable">
          <div class="summit-btn"
            v-if="identifyMode == '0' && (actForm.auditStatus == '3' || actForm.auditStatus == '4')">
            <van-image :src="pic_plus" width="23" height="23" />
            <span>上传</span>
          </div>
        </compress-uploader>
      </div>
      <div class="fileArea" v-if="!isOtherMate">
        <span class="label">附件上传</span>
        <van-uploader max-count="1" :after-read="afterReadEnclosure" :disabled="!writeable">
          <van-button round color="var(--theme-color)" :disabled="!writeable">点击上传</van-button>
        </van-uploader>
        <div class="flist" v-if="actForm.attach">
          <div class="upPic">
            <fix-image :default-src="pic_enclosure"></fix-image>

          </div>
          <div class="msg">
            <div class="name">附件</div>
            <div class="detail">点击可查看</div>
          </div>
          <div class="preview">
            <fix-image :default-src="pic_preview" @click="previewFile"></fix-image>
          </div>
          <div class="delete" v-if="writeable">
            <fix-image :default-src="pic_delete" @click="deleteFile"></fix-image>
          </div>
        </div>
      </div>
    </div>

    <div class="mate-list bg-white">
      <div class="tit-on">
        <div class="txt">报名校友</div>
        <van-button icon="plus" color="var(--theme-color)" radius="16px" @click="toInvite"
          v-if="canInvite">邀请校友</van-button>
      </div>
      <div class="head-list">
        <div class="head-cont">
          <div class="head" v-for="item in actForm.members" :key="item.id">
            <fix-image class="head-img" :default-src="DefaultAvatar" :src="item.avatar"></fix-image>
            <div class="user-name">{{ item.name }}</div>
          </div>
        </div>
      </div>
    </div>
    <div class="deal-idea bg-white" v-if="withoutPendingAndResolve">
      <div class="all-title">审核回复</div>
      <van-field type="textarea" readonly v-model="actForm.recentOpinion" class="deal-area" input-align="left" cols="30"
        rows="6" auto-size></van-field>
    </div>
    <div class="deal-steps bg-white">
      <div class="all-title">流转意见</div>
      <van-steps direction="vertical" :active="actForm.auditList?.length - 1"
        :active-color="actForm.auditStatus == '1' ? '' : '#ff0000'">
        <van-step v-for="item in actForm.auditList" :key="item.id">
          <div class=" status-word" v-if="item.status == '4'">活动申请备案退回
          </div>
          <div class=" status-word" v-if="item.status == '2'">活动申请备案拒绝
          </div>
          <div class=" status-word" v-if="item.status == '1'">活动申请备案通过
          </div>
          <div class="deal-time">{{ item.createDateFormat }}</div>
        </van-step>
      </van-steps>
    </div>
    <div v-if="isCreate || isPending">
      <div class="some-opr" v-if="identifyMode == '0'">
        <van-button block round icon="edit" color="var(--theme-color)"
          v-if="actForm.auditStatus == '3' || actForm.auditStatus == '4'" @click="update">修
          改</van-button>
        <van-button block round icon="revoke" color="var(--theme-color)" v-if="actForm.auditStatus == '0'"
          @click="cancel">撤
          回</van-button>
        <van-button block round icon="guide-o" color="var(--theme-color)"
          v-if="actForm.auditStatus == '1' && actForm.publishStatus == '0'" @click="publish">发 布</van-button>
        <van-button block round icon="stop" color="var(--theme-color)"
          v-if="actForm.auditStatus == '1' && actForm.publishStatus == '1'" @click="stop">终 止</van-button>
      </div>
      <div class="some-opr multi" v-if="canAudit">
        <van-button round hairline color="#999" plain @click="audit('4')">&emsp;退 回&emsp;</van-button>
        <van-button round color="#F45608" @click="audit('2')">&emsp;不予备案&emsp;</van-button>
        <van-button round color="var(--theme-color)" @click="audit('1')">&emsp;通 过&emsp;</van-button>
      </div>
    </div>
    <div class="some-opr" v-if="isJoin && actForm?.registrationFlag == '0'">
      <van-button round block color="#999" icon="friends-o" disabled v-if="!canJoin">人数满了</van-button>
      <van-button round block color="var(--theme-color)" icon="records" @click="toJoin" v-if="canJoin">立即报名</van-button>
    </div>
    <van-popup v-model:show="popShow" closeable round close-icon-position="top-right"
      :style="{ height: 'auto', width: '80%' }">
      <div class="myPop">
        <span class="title">审核意见</span>
        <textarea class="txt-area" v-model="actForm.opinion" cols="10" rows="10" maxlength="300" />
        <div class="word-count"><span></span>{{ (actForm?.opinion)?.length }}/300</div>
      </div>
      <div class="pop-btn">
        <div class="cancel" @click="popShow = false">取消</div>
        <div class="confirm" @click="submit">提交</div>
      </div>
    </van-popup>
  </div>
</template>
<script lang="ts" setup>
import pic_plus from "@/assets/archive/plus@2x.png"
import pic_enclosure from "@/assets/myActivities/enclosure@2x.png"
import pic_preview from "@/assets/myActivities/preview@2x.png"
import DefaultAvatar from '@/assets/img/default-avatar.png';
import pic_delete from "@/assets/myActivities/close@2x.png"
import Api from '@/api/uploadfile';
import { getMyActivitiesDetail, auditGroupActivities, cancelGroupActivities, publishGroupActivities, stopGroupActivities, updateGroupActivities } from "@/api/mine/index"
import compressUploader from "@/components/compress-uploader/index.vue"
import timeselectFiled from "@/components/MyActivities/createComponents/timeselect-filed.vue"
import textFiled from "@/components/MyActivities/createComponents/text-filed.vue"
import stepFiled from "@/components/MyActivities/createComponents/step-filed.vue"
import { Toast, UploaderFileListItem } from "vant";
import { useSettingStore } from "@/store";
import { storeToRefs } from 'pinia';
import { fommatDate } from "@/utils/fommatDate";
import FileHandle from '@/utils/file-handle';
import { deepClone, getRealFilePath } from '@/utils'
import { downLoadFile } from "@/utils/tool/downLoad-file"

let fileHandle = new FileHandle(['eventPoster', 'attach']);
let { identifyMode } = storeToRefs(useSettingStore())
const $router = useRouter();
const route = useRoute()
const fileList = ref<{ url: string }[]>([])
const actForm = ref<any>({})
const popShow = ref(false)
const submitType = ref('')
const fromTab = ref(route.query.tabName)

const onClickLeft = () => $router.back();
const getDetail = async (id: string) => {
  fileList.value = []
  const { code, data, msg } = await getMyActivitiesDetail({ id })
  if (code == 200) {
    actForm.value = data
    actForm.value?.auditList.map((item: any) => {
      item.createDateFormat = fommatDate(item.createDate, 'yyyy-MM-dd hh:mm')
      item.updateDateFormat = fommatDate(item.updateDate, 'yyyy-MM-dd hh:mm')
      return item
    })

    let urls = deepClone(data.eventPoster)
    fileList.value = urls.map((item: any) => { return { url: getRealFilePath(item) } })
  } else {
    Toast(msg)
  }
}
const afterRead: any = async (file: any) => {
  let formData = new FormData();

  formData.append('file', file.file);
  file.status = 'uploading';
  file.message = '上传中...';
  await Api.uploadFile(formData)
    .then((res) => {
      if (res.code == 200) {
        file.status = '';
        file.message = '';
        nextTick(() => {
          if (
            res.data.tokenUrl &&
            res.data.tokenUrl == '' &&
            res.data.tokenUrl == undefined &&
            res.data.tokenUrl == null
          ) {
            actForm.value.eventPoster.push(res.data.tokenUrl as string);
          } else {
            actForm.value.eventPoster.push(res.data.uploadUrl as string);
          }
        });

        Toast.success('上传成功');
      } else {
        file.status = 'failed';
        file.message = '上传失败';
        Toast.fail(res.msg);
      }
    })
    .catch((err) => {
      file.status = 'failed';
      file.message = '上传失败';
      Toast.fail(`上传失败：${err}`);
    });
};
const onOversize = (file: File | File[]) => {
  Toast('图片大小不能超过500kb');
};
const realDelete = (_: any, detail: any) => {
  actForm.value.eventPoster.splice(detail.index, 1);
}
//上传附件成功
const afterReadEnclosure: any = async (file: UploaderFileListItem) => {
  let formData = new FormData();
  formData.append('file', file.file!);
  file.status = 'uploading';
  file.message = '上传中...';
  await Api.uploadFile(formData)
    .then((res) => {
      if (res.code == 200) {
        file.status = '';
        file.message = '';
        nextTick(() => {
          if (
            res.data.tokenUrl &&
            res.data.tokenUrl == '' &&
            res.data.tokenUrl == undefined &&
            res.data.tokenUrl == null
          ) {
            actForm.value['attach'] = res.data.tokenUrl as string;
          } else {
            actForm.value['attach'] = res.data.uploadUrl as string;
          }
        });

        Toast.success('上传成功');
      } else {
        file.status = 'failed';
        file.message = '上传失败';
        Toast.fail(res.msg);
      }
    })
    .catch((err) => {
      file.status = 'failed';
      file.message = '上传失败';
      Toast.fail(`上传失败：${err}`);
    });
}
const previewFile = () => {
  if (actForm.value.attach) {
    if (actForm.value.attach.indexOf('.pdf') !== -1 || actForm.value.attach.indexOf('.PDF') !== -1) {
      // downLoadFile(getRealFilePath(actForm.value.attach))
      window.open(getRealFilePath(actForm.value.attach), "_blank")
    }
  } else {
    window.location.href = getRealFilePath(actForm.value.attach)
  }
}
const deleteFile = () => {
  actForm.value.attach = ''
}
const toInvite = () => {
  let groupsId = actForm.value.groupsId
  let actId = actForm.value.id
  let groupsName = actForm.value.organizer
  $router.push({ path: 'inviteMate', query: { groupsId, actId, groupsName } })
}
const toJoin = () => {
  $router.push({ path: '/groupJoinAct', query: actForm.value });
}
const audit = async (type: string) => {
  try {
    Toast.loading({
      message: '加载中...',
      forbidClick: true,
    })
    submitType.value = type
    if (type == '1') {
      const { code, data, msg } = await auditGroupActivities({ auditAction: type, id: actForm.value.id, opinion: actForm.value.opinion })
      if (code == 200) {
        Toast.success('审核成功！')
        $router.go(-1)
      } else {
        Toast.fail(msg)
      }
    } else {
      popShow.value = true
    }
  } catch (error) {

  } finally {
    Toast.clear()
  }

}

const submit = async () => {
  Toast.loading({
    message: '加载中...',
    forbidClick: true,
  })
  try {
    const { code, data, msg } = await auditGroupActivities({ auditAction: submitType.value, id: actForm.value.id, opinion: actForm.value.opinion })
    if (code == 200) {
      Toast.success('审核成功！')
      popShow.value = false
      $router.go(-1)
    } else {
      Toast.fail(msg)
    }
  } catch (error) {

  } finally {
    Toast.clear()

  }

}
const cancel = async () => {
  const { code, data, msg } = await cancelGroupActivities({ id: actForm.value.id })
  if (code == 200) {
    Toast.success('撤回成功！')
    $router.go(-1);
  } else {
    Toast.fail(msg)
  }

}
const update = async () => {
  const { code, data, msg } = await updateGroupActivities({
    ...actForm.value,
    ...fileHandle.compare(actForm.value), action: '1'
  })
  if (code == 200) {
    Toast.success('更新成功！')
    $router.go(-1);
  } else {
    Toast.fail(msg)
  }
}
const publish = async () => {
  const { code, data, msg } = await publishGroupActivities(actForm.value)
  if (code == 200) {
    Toast.success('发布成功！')
    $router.go(-1);
  } else {
    Toast.fail(msg)
  }
}
const stop = async () => {
  const { code, data, msg } = await stopGroupActivities(actForm.value)
  if (code == 200) {
    Toast.success('活动已终止！')
    $router.go(-1);
  } else {
    Toast.fail(msg)
  }
}
watch(
  () => route.query?.id,
  (id: any) => {
    if (id) {
      getDetail(id)
    }
  },
  { immediate: true }
)

//个人身份且审核状态未草稿/退回状态时可修改提交
const writeable = computed(() => {
  return identifyMode.value == '0' && (actForm.value.auditStatus == '3' || actForm.value.auditStatus == '4' || actForm.value.auditStatus == '' || actForm.value.auditStatus == null || actForm.value.auditStatus == undefined)
})
const canJoin = computed(() => {
  return actForm.value?.currentNumberOfParticipants < actForm.value?.maximumParticipant
})
const isCreate = computed(() => {
  return fromTab.value == 'create'
})
const isJoin = computed(() => {
  return fromTab.value == 'join'
})
const isPending = computed(() => {
  return fromTab.value == 'pending'
})
//排除待审核和审核通过状态（例：这两个状态看没有审核回复）
const withoutPendingAndResolve = computed(() => {
  return actForm.value.auditStatus !== '0' && actForm.value.auditStatus !== '1'
})
//是管理员且未审核状态时可操作审核
const canAudit = computed(() => {
  return identifyMode.value == '1' && actForm.value.auditStatus == '0'
})
//个人且非创建人
const isOtherMate = computed(() => {
  return identifyMode.value == '0' && !actForm.value.isCreator
})
//仅创建人且审核通过并发布后可邀请校友
const canInvite = computed(() => {
  return actForm.value.isCreator && actForm.value.auditStatus == '1' && actForm.value.publishStatus == '1'
})
</script>
<style lang="less" scoped>
@import './detail.less';

.myPop {
  .vartical-middle();
  padding: var(--van-popup-close-icon-margin) var(--van-popup-close-icon-margin);

  .title {
    font-size: 36px;
    font-weight: 500;
    padding-bottom: 20px;
  }

  .txt-area {
    width: 100%;
    height: 100%;
    padding: 20px;
    border: 2px solid #DFDFDF;
    border-radius: 16px;
  }

  .word-count {
    text-align: right;
    line-height: 78px;
    color: #999;
    width: 100%;

    span {
      color: var(--theme-color)
    }
  }
}

.pop-btn {
  display: flex;

  .cancel,
  .confirm {
    flex: 1;
    font-size: 36px;
    line-height: 99px;
    text-align: center;
    border-top: 1px solid #e5e5e5;
  }

  .confirm {
    border-left: 1px solid #e5e5e5;
    color: var(--theme-color);
  }
}
</style>