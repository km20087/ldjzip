import { Dialog, DialogOptions } from 'vant';

/**
 * confirm 确认事件
 * cancel  取消事件
 */
type HandleProp = DialogOptions & {
  confirm: Function;
  cancel: Function;
};

export default function useJoinDialog() {
  function showDialog({
    title = '提示',
    message,
    cancelButtonText,
    confirmButtonText,
    confirm,
    cancel,
  }: HandleProp) {
    Dialog.confirm({
      title,
      message,
      cancelButtonText,
      confirmButtonText,
    })
      .then(() => {
        typeof confirm == 'function' && confirm();
      })
      .catch(() => {
        typeof cancel == 'function' && cancel();
      });
  }

  function showLocalDialog(handleProp: HandleProp) {
    showDialog({
      ...handleProp,
      message:
        handleProp.message || '只能加入一个地区校友会，加入新组织后，原地区校友会将自动退出。',
      cancelButtonText: '取消',
      confirmButtonText: '确认',
    });
  }

  function showInfoDialog(handleProp: HandleProp) {
    showDialog({
      ...handleProp,
      message:
        handleProp.message ||
        '申请加入需向该校友会公开本人工作单位、职务（职称）、手机号码等个人信息，您是否同意？',
      cancelButtonText: '不同意',
      confirmButtonText: '同意',
    });
  }

  return {
    showLocalDialog,
    showInfoDialog,
  };
}
