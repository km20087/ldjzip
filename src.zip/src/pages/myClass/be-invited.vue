<template>
  <van-empty v-if="!inviteData?.id" description="暂无数据" />
  <div class="be-invited-box" v-else>
    <div class="wrap">
      <p class="title-wrap">
        <Mine class="icon" />
        <span class="text-wrap"
          >邀请人：<span class="highlight">{{ inviteData.inviterName }}</span></span
        >
      </p>
      <p class="message"
        >{{ inviteData.groupsName }}主要负责人{{ inviteData.inviterName }}邀请你加入该班级</p
      >
      <div class="choice">
        <van-button round type="default" class="btn ref" @click="handleInvite(InviteStatus.No)">
          拒绝
        </van-button>
        <van-button round type="primary" class="btn agree" @click="handleInvite(InviteStatus.Yes)">
          同意
        </van-button>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import Mine from '@/assets/icons/mine-circle.svg';
  import useJoinDialog from './useJoinDialog';
  import { fetchInviteHandle } from '@/api/group';
  import { GroupCategory } from '@/constants';
  import { Toast } from 'vant';
  import { InviteStatus } from './constants';

  const { showInfoDialog, showLocalDialog } = useJoinDialog();

  const props = withDefaults(defineProps<{
    inviteData: { id: string; groupsId: string; groupsName: string; inviterName: string };
    category: string;
  }>(), {
    inviteData: () => ({id: '', groupsId: '', groupsName: '', inviterName: ''})
  })

  const emits = defineEmits<{
    (event: 'refresh'): void;
    (event: 'initInviteData'): void;
  }>();

  const isLocalOrgan = computed(() => props.category == GroupCategory.Local);

  async function handleInvite(status: InviteStatus.Yes | InviteStatus.No) {
    try {
      const { code, data, msg } = await fetchInviteHandle({ id: props.inviteData.id, status });
      if (code == 200) {
        Toast.success({ message: '操作成功' });
        emits('refresh');
      } else {
        Toast({ message: msg, icon: 'none' });
      }
    } catch (err) {
      console.log(err);
    } finally {
      emits('initInviteData')
    }
  }

  /**展示个人信息是否展示的弹窗 */
  function onShowInfoDialog() {
    showInfoDialog({
      confirm() {
        handleInvite(InviteStatus.Yes);
      },
      cancel() {
        handleInvite(InviteStatus.Yes);
      },
    });
  }

  /**展示加入地区校友会时的弹窗 */
  function onShowLocalDialog() {
    showLocalDialog({
      confirm() {
        onShowInfoDialog();
      },
      cancel() {
        handleInvite(InviteStatus.No);
      },
    });
  }

  /**点击页面的同意按钮 */
  function handleClickConfirm() {
    isLocalOrgan.value ? onShowLocalDialog() : onShowInfoDialog();
  }
</script>

<style lang="less" scoped>
  .be-invited-box {
    padding: 24px;
  }
  .wrap {
    padding: 27px 24px 24px;
    background: #f7f7f7;
    border-radius: 32px;
  }
  .title-wrap {
    padding: 0;
    margin: 0 0 32px;
    display: flex;
    flex-direction: row;
    align-items: center;
    font-size: 26px;
    color: #666666;
    font-style: normal;
    .icon {
      width: 32px;
      height: 32px;
      margin: 0 12px 0 0;
    }
    .text-wrap {
      display: flex;
      flex-direction: row;
      align-items: center;
      .highlight {
        color: #333;
        font-weight: bold;
      }
    }
  }
  .message {
    padding: 0;
    margin: 0 0 32px;
    font-size: 32px;
    color: #333333;
  }
  .choice {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    .btn {
      width: 140px;
      height: 60px;
      border: 2px solid var(--theme-color);
      font-size: 28px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      text-align: center;
    }
    .ref {
      margin-right: 24px;
      background: #ffffff;
      color: var(--theme-color);
    }
    .agree {
      color: #ffffff;
      text-align: center;
    }
  }
</style>
