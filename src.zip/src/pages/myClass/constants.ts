export const enum InviteStatus {
  PendingHandle = '00', // 待处理
  Yes = '01', // 接受邀请
  No = '02', // 拒绝邀请
  OutTime = '03', // 未加入班级（超过30天未处理）
  PendingInvite = '04', // 待邀请
}
