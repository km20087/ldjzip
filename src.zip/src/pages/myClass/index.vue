<template>
  <div class="con">
    <van-nav-bar title="班级" left-text="" left-arrow @click-left="onClickLeft" />
    <div class="orgCard" :style="orgCardStyle">
      <div class="per">
        <fix-image class="ims" v-if="settingStore.isShowGroupProfilePicture && org.groupsProfilePicture"
          :src="org.groupsProfilePicture" width="88" height="88" alt="头像" />
        <div class="perdetail">
          <div class="name"> {{ org.groupsName }} </div>
          <!-- <div class="uni">简介：{{ org.jianjie }}</div> -->
          <div class="uni mar10">班级人数：{{ org.numberOfMembers }}人</div>
        </div>
      </div>
    </div>
    <van-tabs v-model:active="active" class="cenTab van-hairline--bottom">
      <van-tab name="member" title="成员"></van-tab>
      <!-- <van-tab name="active" :title-class="showTab ? 'hiddenShow' : ''" title="活动"></van-tab>
      <van-tab name="album" title="相册"></van-tab> -->

      <!-- v-if="org.hasAuditRight === '1'" -->
      <van-tab name="adminManage" v-if="org.isAdministrator === '1' || org.isPrimaryLeader === '1'">
        <template #title>
          <span v-if="isLiaoShiDa() || HeBeiShiFan()">消息</span>
          <span v-else>管理</span>
          <span v-if="redPointTips" class="circle-container"> </span>
        </template>
      </van-tab>
      <van-tab name="manage" v-if="isShowManageTab">
        <template #title>
          <span v-if="isLiaoShiDa() ||HeBeiShiFan()">消息</span>
          <span v-else>管理</span>
          <span v-if="redPointTips" class="circle-container"> </span>
        </template>
      </van-tab>
      <van-tab name="audit" title="管理" v-if="(HeBeiShiFan() || isLiaoShiDa()) && settingStore.identifyMode == IdentifyMode.Manage"></van-tab>
    </van-tabs>
    <div v-if="active === 'member'" class="siasd">
      <van-tabs class="member-tabs-wrap" type="card"
        v-if="(HeBeiShiFan() || isLiaoShiDa()) && org.isJoin && (org.isAdministrator == '1' || org.isPrimaryLeader == '1')">
        <van-tab title="已加入班级">
          <member :groupsId="gouId" :hasAuditRight="org.hasAuditRight" :isAdministrator="org.isAdministrator"
            :isPrimaryLeader="org.isPrimaryLeader" />
        </van-tab>
        <van-tab title="未加入班级">
          <SchoolmateSearch :groupsId="org.groupsId" />
        </van-tab>
      </van-tabs>

      <member v-else :groupsId="gouId" :hasAuditRight="org.hasAuditRight" :isAdministrator="org.isAdministrator"
        :isPrimaryLeader="org.isPrimaryLeader" />

      <!-- <div class="but1" v-if="!org.isJoin">
        <van-button type="primary" round @click="joinOrg">申请加入</van-button>
      </div> -->
    </div>
    <div class="siasd"
      v-else-if="active === 'adminManage' && org.isJoin && (org.isAdministrator == '1' || org.isPrimaryLeader == '1')">
      <!-- <check :groupsId="gouId" /> -->
    </div>
    <div class="siasd" v-else-if="active === 'manage' && isShowManageTab">
      <BeInvited :inviteData="inviteData" :category="org.category" @initInviteData="initInviteData" @refresh="initGroup"/>
    </div>
    <div class="sisad" v-else-if="active === 'audit'">
      <activitiesReview :groups-id="gouId" :need-title="false" cont-class="review-cont" />
    </div>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref, onDeactivated } from 'vue';
import member from './member.vue';
import ApiGroup, { userGroupP, groupListP } from '@/api/group';
// import lnsfAct from './lnsf-act.vue';
// import check from './check.vue';
// import photo from './photo.vue';
import activitiesReview from "@/pages/activitiesReview/index.vue"
import { useSettingStore } from '@/store';
import { SchoolCode } from '@/constants';
import SchoolmateSearch from './schoolmate-search/index.vue';
import BeInvited from './be-invited.vue';
import { useKeepAliveStore } from '@/store'
import { useBeInvited } from '@/pages/orgDetail/useBeInvited'
import { InviteStatus } from './constants';
import { isLiaoShiDa,HeBeiShiFan } from '@/utils/customizedType';
import { IdentifyMode } from '@/constants'
import { useOrgCard } from '@/hooks/useOrgCard'
import { getSchoolCode } from '@/utils';

const ComponentName = 'orgDetail'
const { orgCardStyle } = useOrgCard()
const { inviteData, getInviteData, initInviteData } = useBeInvited()
const isShowManageTab = computed(() => !!inviteData.value?.id && inviteData.value.status == InviteStatus.PendingHandle)

const _SchoolCode = getSchoolCode()

const settingStore = useSettingStore();
const router = useRouter();
const route = useRoute();
const active = ref('member');
const keyRe = ref(0);
const creAl = ref(false);
const showTab = ref(false);
const org = reactive({
  groupsId: '',
  groupsName: '',
  jianjie: '',
  numberOfMembers: '',
  groupsProfilePicture: '',
  isJoin: false,
  auditStatus: '',
  hasAuditRight: '',
  isAdministrator: '',
  isPrimaryLeader: '',
  groupsType: '',
  category: ''
});
const redPointTips = ref(false);
const gouId = ref('');

const onClickLeft = () => router.back()

const initGroup = async () => {
  console.log('initGroup');
  const { data, code, msg } = await ApiGroup.groupsDetail({ groupsId: gouId.value });
  if (code == 200) {
    Object.assign(org, data);
    if (org.isAdministrator == '1' || org.isPrimaryLeader == '1') {
      creAl.value = true;
      keyRe.value++;
    }
  }
};

// watch(() => active.value, (newVal) => {
//   router.replace({
//     path: '/orgDetail',
//     query: {
//       ...route.query,
//       active: newVal
//     },
//   })
// }, {
//   immediate: true
// })

function initPageLoad() {
  if (_SchoolCode == SchoolCode.ChangShu) {
    showTab.value = true;
  }
  let { groupsId, pendingAudit } = route.query
  active.value = route.query.active as string || 'member'
  gouId.value = groupsId as string;
  if (pendingAudit == "1") {
    redPointTips.value = true;
  }
  if (gouId.value != sessionStorage.getItem("gouId") || !org.groupsName) {
    initGroup();
  }
  sessionStorage.setItem("gouId", gouId.value);
}

onBeforeMount(() => {
  console.log('--> call onBeforeMount');
  initPageLoad()
  getInviteData(gouId.value)
});

</script>
<style lang="less" scoped>
/deep/ .hiddenShow {
  display: none;
  // visibility: hidden;
}

.tips {
  width: 100%;
  height: 60px;
  text-align: center;
  line-height: 60px;

  // margin-top: 10px;
  .sese {
    font-size: 30px;
    color: #969799;
  }
}

.con {
  width: 100%;
  height: 100%;
  overflow-y: scroll;

  .orgCard {
    margin: 10px 32px;
    width: 686px;
    height: 220px;
    background: url('@/assets/img/orgBac.png') no-repeat;
    background-size: 100% 100%;

    .per {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      padding-left: 8%;

      // margin: 0 auto;
      // justify-content: center;
      .ims {
        width: 88px;
        height: 88px;
        position: relative;
        top: -20px;
        border-radius: 50%;
      }

      .perdetail {
        margin-left: 30px;

        .name {
          font-size: 36px;
          font-family: PingFang-SC-Bold, PingFang-SC;
          font-weight: bold;
          color: #573201;
          line-height: 36px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
          padding-bottom: 20px;
        }

        .uni {
          font-size: 24px;
          font-family: PingFang-SC-Medium, PingFang-SC;
          font-weight: 500;
          color: #573201;
          line-height: 24px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
        }

        .mar10 {
          margin-top: 10px;
        }
      }
    }
  }

  .siasd {
    // margin-top: 80px;
    margin-top: 8px;
    position: relative;
  }

  .photo {
    text-align: center;

    .ims {
      width: 300px;
      height: 300px;
    }

    .is {
      font-weight: 500;
    }
  }
}

.member-tabs-wrap {
  margin: 16px 0 0;
  --van-tabs-default-color: rgb(180, 45, 59);

  ::v-deep(.van-tabs__content) {
    padding: 16px 0 0;
  }
}

.cenTab {
  border-color: #333;
}

.but1 {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translate(-50%, 0%);
  z-index: 9999;

  /deep/.van-button--round {
    width: 400px;
  }
}

.circle-container {
  display: inline-block;
  width: 10px;
  height: 10px;
  background: #ff0000;
  border-radius: 50%;
  position: relative;
  top: -18px;
  left: -6px;
}

.review-cont {
  background: #969799;
}
</style>
