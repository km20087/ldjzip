<template>
  <main class="wrap">
    <van-search ref="searchBoxRef" v-model="searchData" placeholder="请输入校友名字搜索" />
    <van-empty v-if="collegeList.length == 0" description="本校暂无该校友入驻" />
    <div v-else class="list-box">
      <aside class="list-wrap">
        <span
          class="dept-wrap"
          :class="{ active: activeCollegeId == item.deptId }"
          v-for="item in collegeList"
          :key="item.deptId"
          @click="changeCollege(item)"
        >
          {{ item.deptName }}
        </span>
        <div class="dept-wrap" />
        <div class="fix-btn-wrap"></div>
      </aside>
      <aside class="list-wrap" v-if="false">
        <span class="empty-txt" v-if="majorList.length == 0">暂无专业数据</span>
        <template v-else>
          <span
            class="dept-wrap"
            :class="{ active: activeMajorId == item.deptId }"
            v-for="item in majorList"
            :key="item.deptId"
            @click="changeMajor(item)"
          >
            {{ item.deptName }}
          </span>
          <div class="dept-wrap" />
          <div class="fix-btn-wrap"></div>
        </template>
      </aside>
      <aside class="list-wrap">
        <SchoolMateList
          v-model:loading="loading"
          v-model:finished="finished"
          :list="schoolMateList"
          @load="loadSchoolMate"
          v-model:schoolmateIds="schoolmateIds"
        />
        <div class="fix-btn-wrap"></div>
      </aside>
    </div>

    <div class="btn-wrap">
      <van-button class="btn" type="primary" round @click="handleInvite">邀请</van-button>
    </div>
  </main>
</template>

<script lang="ts" setup>
  import { ref, onBeforeMount, watch } from 'vue';
  import { useDept } from '@/hooks/useDept';
  import { genTree } from './util';
  import SchoolMateApi from '@/api/schoolmate';
  import SchoolMateList from './schoolmate-list.vue';
  import { Toast } from 'vant';
  import { debounce } from 'lodash-es';
  import router from '@/router';
  import { useSettingStore } from '@/store';
  import { isLiaoShiDa } from '@/utils/customizedType';
  import { fetchInviteAdd, fetchNonMemberList } from '@/api/group';

  const props = defineProps<{
    groupsId: string;
  }>();

  const settingStore = useSettingStore();

  // 辽宁师大不展示专业列
  const isShowMajor = ref(!isLiaoShiDa());

  const { getDept } = useDept();

  let cacheCollegeList: Dept[] = [];
  const collegeList = ref<Dept[]>([]);
  const activeCollege = ref<Dept>();
  const activeCollegeId = ref('');
  const majorList = ref<Dept[]>([]);
  const activeMajorId = ref('');

  const loading = ref(false);
  const finished = ref(false);
  const schoolMateList = ref([]);
  const pageNum = ref(0);
  
  const colleageId = ref('')

  let toastInstance = ref();

  const searchData = ref('');

  const schoolmateIds = ref<string[]>([])

  watch(
    () => props.groupsId,
    () => {
      if (!props.groupsId || props.groupsId == '-1') return;
      initListData();
      initCollegeListData();
    },
    { immediate: true }
  );

  function initListData() {
    cacheCollegeList = [];
    collegeList.value = [];
    majorList.value = [];
    activeCollegeId.value = '';
    activeMajorId.value = '';
    schoolMateList.value = [];
    schoolmateIds.value = []
  }

  async function searchSchoolMate() {
    const { code, data } = await SchoolMateApi.listCollegeAndMajorByKeyword({
      keyWord: searchData.value,
    });
    if (code == 200) {
      collegeList.value = genTree(data);
      if (collegeList.value.length) {
        changeCollege(collegeList.value[0]);
      }
    }
    return [];
  }
  const debounceSearchSchoolMate = debounce(searchSchoolMate, 500, { trailing: true });

  // 监听searchData的变动， 以防抖的方式请求接口
  watch(searchData, async (str: string) => {
    activeCollegeId.value = '';
    activeMajorId.value = '';
    str.length ? debounceSearchSchoolMate() : initCollegeListData();
  });

  function changeCollege(item: Dept) {
    console.log('changeCollege',item)
    // colleageId.value = item.deptId
    activeCollege.value = item;
    activeCollegeId.value = item.deptId;
  }

  function changeMajor({ deptId }: Dept) {
    activeMajorId.value = deptId;
  }

  async function loadSchoolMate() {
    loading.value = true;
    let param = isShowMajor.value
      ? { major: activeMajorId.value }
      : { collegeId: activeCollegeId.value };
    const result = await fetchNonMemberList({
      groupsId: props.groupsId,
      name: searchData.value ? searchData.value : undefined,
      // ...param,
      pageSize: 10,
      collegeId: activeCollegeId.value,
      pageNum: ++pageNum.value,
    });
    if (result.code == 200) {
      const { list, pageNum: page, pages } = result.data;
      pageNum.value = page;
      finished.value = page >= pages;
      schoolMateList.value = page == 1 ? list : [...schoolMateList.value, ...list];
    } else {
      finished.value = true;
    }
    loading.value = false;
  }

  async function reloadSchoolMate() {
    pageNum.value = 0;
    await loadSchoolMate();
    toastInstance.value.clear();
  }

  watch(activeMajorId, async () => {
    await reloadSchoolMate();
  });

  watch(activeCollegeId, async (id: string) => {
    if (!id) return;
    toastInstance.value = Toast.loading({ message: '加载中' });
    if (isShowMajor.value) {
      majorList.value = searchData.value ? activeCollege.value?.children ?? [] : await getDept(id);
      majorList.value.length && (activeMajorId.value = majorList.value[0].deptId);
    } else {
      await reloadSchoolMate();
    }
  });

  // 从接口或缓存中获取全部的学院列表信息
  async function initCollegeListData() {
    let listData = cacheCollegeList;
    if (!listData.length) {
      listData = await getDept();
      console.log('listData:',listData)
    }
    collegeList.value = listData;
    listData && (activeCollegeId.value = listData[0].deptId);
  }

  async function handleInvite() {
    try {
      const { code, data, msg } = await fetchInviteAdd({
        groupsId: props.groupsId,
        schoolmateIds: schoolmateIds.value,
      });
      if (code == 200) {
        schoolmateIds.value = []
        reloadSchoolMate()
      } else [
        Toast.fail(msg)
      ]
    } catch (err) {}
  }
</script>

<style lang="less" scoped>
  .wrap {
    width: 100vw;
    height: calc(
      100vh - var(--van-nav-bar-height) - var(--van-tabs-line-height) - var(--van-tabs-card-height) -
        250px
    );
    background: #f9f9f9;
    overflow: hidden;
  }
  :deep(.van-search) {
    --van-border-radius-sm: 200px;
    margin-bottom: 20px;
  }
  .empty-txt {
    padding: 20px;
    display: block;
  }
  .list-box {
    height: 100%;
    display: flex;
    flex-direction: row;
    .list-wrap {
      overflow-y: auto;
      &:nth-child(1) {
        flex: 0 0 208px;
        background: #efefef;
      }
      &:nth-child(2) {
        flex: 0 0 208px;
        background: #fafafa;
      }
      &:last-of-type {
        flex: 1;
        background: #fff;
        position: relative;
        min-height: 100%;
        position: relative;
      }
    }
    .dept-wrap {
      padding: 20px;
      min-height: 80px;
      font-size: 28px;
      color: #222;
      box-sizing: content-box;
      display: flex;
      flex-direction: column;
      &.active {
        font-weight: 500;
        background: #fff;
        &::after {
          content: '';
          margin-top: 10px;
          background: var(--van-button-primary-background-color);
          width: 55px;
          height: 4px;
          border-radius: 2px;
          display: inline-block;
        }
      }
    }
  }
  .fix-btn-wrap {
    width: 1px;
    height: 150px;
  }
  .btn-wrap {
    width: 100%;
    position: absolute;
    left: 0;
    bottom: 0;
    padding: 20px;
    background: #fff;
    .btn {
      width: 100%;
    }
  }
</style>
