import { DeptTypeLevel } from '@/constants';
// 将数组转换成树
export function genTree(data: Dept[]): Dept[] {
  if (data.length == 0) return [];
  let arr: Dept[] = [];
  // @ts-ignore
  let obj = data.reduce((obj, item) => ((obj[item.deptId] = item), obj), {});

  for (let item of data) {
    if (item.deptLevel == DeptTypeLevel.college) {
      arr.push(item);
      continue;
    }

    // @ts-ignore
    let parent = obj[item.parentId];
    if (!parent) continue;
    parent.children = parent.children || [];
    parent.children.push(item);
  }
  return arr;
}
