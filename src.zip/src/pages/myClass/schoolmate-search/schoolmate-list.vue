<template>
  <span class="empty" v-if="!list.length">暂无校友数据</span>
  <template v-else>
    <van-list
      class="user-list"
      v-model:loading="loadingClone"
      :finished="finishedClone"
      @load="emits('load')"
      :immediate-check="false"
    >
      <van-checkbox-group v-model="schoolmateIdsClone">
        <van-checkbox
          class="van-hairline--bottom user-wrap"
          v-for="item in list"
          :key="item.userId"
          :disabled="[InviteStatus.PendingHandle, InviteStatus.Yes, InviteStatus.No].includes(item.inviteStatus)"
          shape="square"
          icon-size="14"
          :name="item.userId"
        >
          <div class="info-content">
            <div class="info-box">
              <Avatar class="avatar" :src="item.avatar" />
              <div class="info-wrap">
                <span class="name van-ellipsis">{{ item.name }}</span>
                <span class="date">{{ item.schoolStartYear }}{{ item.schoolEndYear ? `-${item.schoolEndYear}` : '' }}</span>
              </div>
            </div>

            <span
              class="status-text"
              :style="{
                color:
                  item.inviteStatus == InviteStatus.PendingHandle ? '#999' : 'var(--theme-color)',
              }"
            >
              {{ schoolmateIdsClone.includes(item.userId) ? '邀请加入' : statusTextObj[item.inviteStatus] }}
            </span>
          </div>
        </van-checkbox>
      </van-checkbox-group>
      <div class="fix-list" />
    </van-list>
  </template>
</template>

<script setup lang="ts">
  import Avatar from '@/components/avatar/index.vue';
  import { useVModel } from '@/hooks/useVModel';
  import { InviteStatus } from '../constants';

  interface SchoolMateInviteList {
    inviteStatus: any;
    name: string;
    schoolEndYear: string;
    schoolStartYear: string;
    userId: string;
    avatar: string
  }

  const props = defineProps<{
    list: SchoolMateInviteList[];
    loading: boolean;
    finished: boolean;
    schoolmateIds: string[]
  }>();

  const emits = defineEmits<{
    (e: 'load'): void;
    (e: 'update:loading', loading: boolean): void;
    (e: 'update:finished', finished: boolean): void;
    (e: 'update:schoolmateIds', schoolmateIds: string[]): void;
  }>();

  const loadingClone = useVModel(props, 'loading', emits);
  const finishedClone = useVModel(props, 'finished', emits);
  const schoolmateIdsClone = useVModel(props, 'schoolmateIds', emits);

  const statusTextObj: any = {
    [InviteStatus.PendingInvite]: '未接受邀请',
    [InviteStatus.Yes]: '已加入',
    [InviteStatus.No]: '拒绝加入',
    [InviteStatus.OutTime]: '未加入班级',
    [InviteStatus.PendingHandle]: '未加入班级',
  };
</script>

<style lang="less" scoped>
  .empty {
    padding: 20px;
    display: inline-block;
  }
  .user-list {
    padding-left: 20px;
  }
  .user-wrap {
    padding: 20px 24px 20px 0;
    --van-border-color: #dfdfdf;
    display: flex;
    flex-direction: row;
    align-items: center;
    ::v-deep(.van-checkbox__label) {
      flex: 1;
    }
    .info-content {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
    }
    .info-box {
      display: flex;
      flex-direction: row;
      align-items: center;
      flex: 1;
      .avatar {
        margin-right: 20px;
        width: 88px;
        height: 88px;
        border-radius: 50%;
      }
      .info-wrap {
        padding: 8px 0;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        .name {
          width: 200px;
          font-size: 32px;
          color: #666666;
        }
        .date {
          font-size: 24px;
          color: #999999;
        }
      }
    }
    .status-text {
      flex: 0 0 140px;
      font-size: 24px;
    }
  }
  .fix-list {
    width: 1px;
    height: 130px;
  }
</style>
