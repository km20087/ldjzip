<template>
  <div class="alumniList">
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model:loading="loading"
        :finished="finished"
        :finished-text="finsText"
        @load="onLoad"
      >
        <SchoolMateList :list="mebList" @jump="jumpAlu">
          <template #default="{ item }">
            <div class="cosnaFla">
              <!-- <div
                class="right maR5"
                @click="changeState(item)"
                v-if="pro.isPrimaryLeader == '1' && fuzeren !== item.userId"
              >
                {{ item.isAdministrator == '1' ? '取消管理权' : '设置管理员' }}
              </div> -->
              <div
                class="right tesR"
                v-if="
                  item.isAdministrator !== '1' &&
                  (pro.isAdministrator == '1' || pro.isPrimaryLeader == '1')
                "
                @click="removeMem(item)"
              >
                移除该成员
              </div>
            </div>
          </template>
        </SchoolMateList>
      </van-list>
    </van-pull-refresh>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from "vue";
import ApiGroup, { userGroupP, groupListP } from "@/api/group";
import { Toast } from "vant";
import { Dialog } from "vant";
import SchoolMateList from "@/components/schoolmate-list/index.vue";
import { getUserId } from "@/utils";

const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
const pro = defineProps([
  "groupsId",
  "hasAuditRight",
  "isPrimaryLeader",
  "isAdministrator"
]);

const loading = ref(false);
const finished = ref(false);
const router = useRouter();
const finsText = ref("没有更多了");
const refreshing = ref(false);
const isLastPageb = ref(false);
const total = ref(0);
const pages = ref(0);
const mebList = <any>ref([]);
const fuzeren = ref("");
const mbP = reactive({
  groupsId: "",
  pageNum: 1,
  pageSize: 10
});

const onRefresh = () => {
  // 清空列表数据
  finished.value = false;

  // 重新加载数据
  // 将 loading 设置为 true，表示处于加载状态
  loading.value = true;

  onLoad();
};
const jumpAlu = (item: any) => {
  let locauser = getUserId()
  //147a9c9884304ba3acfb414d9bbbbed2
  if (locauser == item.userId) {
  } else {
    router.push({
      path: "/agreeAlumniCard",
      query: { userId: item.userId, groupsId: pro.groupsId }
    });
  }
};
const onLoad = () => {
  if (!isLastPageb.value && loading.value) {
    // loading.value = true;
    finished.value = false;
    mbP.pageNum++;
    initMembers();
    // refreshing.value = false
  } else {
    loading.value = false;
    refreshing.value = false;
  }
};
const initMembers = async () => {
  let a = pro || "";
  loading.value = true;
  mbP.groupsId = a.groupsId;
  const { data, code, msg } = await ApiGroup.groupsMembers(mbP);
  if (code == 200) {
    pages.value = data.pages;
    total.value = data.total;
    isLastPageb.value = data.isLastPage;
    if (pages.value == 1) {
      console.log("pages");
      mebList.value = [];
    }
    loading.value = false;
    if (isLastPageb.value) {
      finished.value = true;
      // loading.value = false;
    }
    mebList.value.push(...data.list);
  } else {
    if('您不是该组织成员，无法查看成员信息' == msg){
       finsText.value = '您不是该班级成员，无法查看成员信息'
    }else{
      finsText.value = msg;      
    }
    loading.value = false;
    finished.value = true;
  }
  refreshing.value = false;
};
const removeMem = async (val: any) => {
  let mes = `你要把${val.name}移除该班级吗？`;
  Dialog.confirm({
    title: "警告",
    message: mes
  })
    .then(async () => {
      // on confirm
      let a = pro.groupsId;
      const { data, msg, code } = await ApiGroup.removeMember({
        userId: val.userId,
        groupsId: a as string
      });
      Toast({ message: msg });
      if (code == 200) {
        mebList.value = [];
        initMembers();
      }
    })
    .catch(() => {
      // on cancel
    });
};
// const onLoad = () => {
//   if (!isLastPageb.value) {
//     mbP.pageNum++;
//     initMembers();
//   }
// };
const changeState = async (val: any) => {
  let msg1 = "";
  if (val.isAdministrator == "1") {
    msg1 = `你要取消${val.name}班级管理员吗？`;
  } else {
    msg1 = `你要设置${val.name}为班级管理员吗？`;
  }
  Dialog.confirm({
    title: "警告",
    message: msg1
  })
    .then(async () => {
      if (val.isAdministrator == "1") {
        const { data, code, msg } = await ApiGroup.removeAdmin({
          userId: val.userId,
          groupsId: pro.groupsId
        });
        msg1 = msg;
      } else {
        const { data, code, msg } = await ApiGroup.setupAdmin({
          userId: val.userId,
          groupsId: pro.groupsId
        });
        msg1 = msg;
      }
      Toast({ message: msg1 });
      initMembers();
    })
    .catch(() => {
      // on cancel
    });
};
onMounted(() => {
  fuzeren.value = getUserId() as string;
  initMembers();
});

</script>
<style lang="less" scoped>
.alumniList {
  width: 100%;
  height: 90vh;
  // overflow-y: auto;
  overflow-y: scroll;
  // overflow: hidden;
  :deep(.van-list) {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    .van-list__loading {
      margin: 0 auto;
      width: 100%;
    }
    .van-list__finished-text {
      width: 100%;
      text-align: center;
    }
  }
  .cosnaFla {
    width: 100%;
    display: flex;
    padding: 0 6%;
    position: absolute;
    bottom: 10px;
    justify-content: space-between;
    align-items: center;
    .right {
      width: 45%;
      font-size: 24px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #999999;
      margin-bottom: 20px;
    }
  }
}
</style>
