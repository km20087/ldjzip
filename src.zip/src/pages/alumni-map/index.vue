<template>
  <div class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="校友地图" />
    <div class="chart" ref="chartRef"></div>
  </div>
</template>

<script lang="ts" setup>
import China from '@/constants/china';
import { ref, onMounted } from 'vue';
import { type EChartsType } from 'echarts';
import echarts from './echarts';
import { statisticsByProvince } from '@/api/alumni-map';
import { useGoBack } from '@/hooks/useGoBack';
const { goBack } = useGoBack();

const chartRef = ref();
let myChart: EChartsType;

async function getData() {
  try {
    const { code, data, msg } = await statisticsByProvince();
    if (code == 200) {
      const chartData = data.map(({ provinceName, schoolmateCount }: any) => ({
        name: provinceName,
        value: schoolmateCount,
      }));
      draw(chartData);
    }
  } catch (err) { }
}

function draw(data: { name: string; value: string }[]) {
  const zoom = 3;
  const fontSize = 16;
  const max = Math.max(...data.map(({ value }) => parseInt(value)));
  const option = {
    tooltip: {
      trigger: 'item',
      formatter: '{b}<br/>{c}人',
      textStyle: { fontSize },
    },
    visualMap: {
      min: 0,
      max,
      inRange: {
        color: ['lightskyblue', 'yellow', 'orangered'],
      },
      textStyle: { fontSize },
      text: [max, 0],
    },
    series: [
      {
        type: 'map',
        map: 'china',
        roam: 'move',
        zoom,
        label: { show: true, fontSize, fontFamily: 'Arial' },
        data,
        // select:{
        //   itemStyle: {areaColor: '#f0f'}
        // }
      },
    ],
  };
  myChart.setOption(option);
}

onMounted(() => {
  // @ts-ignore
  echarts.registerMap('china', { geoJSON: China });
  // @ts-ignore
  myChart = echarts.init(chartRef.value);
  getData();
});
</script>

<style lang="less" scoped>
.wrap {
  width: 100vw;
  height: 100vh;
}

.chart {
  width: 100vw;
  height: calc(100vh - var(--van-nav-bar-height));
}
</style>
