<template>
  <div class="con">
    <div class="canOrupload">
      <span class="cancel" @click="goBack">取消</span>
      <span class="upload" @click="submmit" :style="{ color: settingStore.themeColor }">上传</span>
    </div>
    <div class="pic">
      <van-field
        v-model="upP.describe"
        rows="6"
        autosize
        label=""
        type="textarea"
        maxlength="500"
        placeholder="为你的照片加点描述吧…"
        show-word-limit
        class="poosa"
      />
      <div class="jiansu" @click="jumpMap">
        <img :src="location" class="ims" alt="" />
        <p class="location">{{ upP.address ? upP.address : '添加地点' }}</p>
      </div>
      <div class="setp2">
        <van-field
          v-model="aluName"
          is-link
          readonly
          name="picker"
          label="上传到"
          placeholder=""
          input-align="right"
          @click="jumpAlbumList"
          class="poui"
        />
        <!-- <van-field
          v-if="isShowPermissionPicker"
          v-model="perName"
          is-link
          readonly
          name="picker"
          label="权限"
          placeholder="点击选择相册权限"
          @click="showPicker = true"
          input-align="right"
          class="ooui"
        /> -->
      </div>
      <div class="uploadButton">
        <div class="uptips">{{acceptTips}}</div>
        <compress-uploader
          v-model="healthFileList"
          multiple
          max-count="20"
          :accept="accept"
          :after-read="upload"
          @delete="deletePic"
        />
      </div>

      <van-popup v-model:show="showPicker" position="bottom">
        <van-picker :columns="columns" @confirm="onConfirm" @cancel="showPicker = false" />
      </van-popup>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import location from '@/assets/img/location.png';
  import { ref, reactive } from 'vue';
  import Api from '@/api/orgPhoto';
  import { Toast } from 'vant';
  import { albumParam, locationP, saveData, useSettingStore } from '@/store';
  import { useKeepAliveStore } from '@/store'
  import { useUploadImageAndVideo } from '@/hooks/useUploadImageAndVideo'
  import { getSchoolCode } from '@/utils';
  import { SchoolCode } from '@/constants';
  
  const ComponentName = 'addPic'
  defineOptions({
    name: ComponentName,
    beforeRouteEnter(to, from) {
      const keepAliveStore = useKeepAliveStore()
      let formName = from.name as string
      if (formName && ['alubmList'].includes(formName)) {
        keepAliveStore.removeCacheEntry(ComponentName)
      }
    }
  })
  const schoolCode = getSchoolCode()
  const accept = computed(() => schoolCode == SchoolCode.ShanDa ? '.jpg,.jpeg,.png,.mp4' : '.jpg,.jpeg,.png') 
  const acceptTips = computed(() => {
    let maxImgSize = 5
    let maxVideoSize = 0
    if (schoolCode == SchoolCode.ShanDa) {
      maxImgSize = 10
      maxVideoSize = 200
    }
    let videoTips = maxVideoSize ? `视频不可超过${maxVideoSize}M` : ''
    let acceptFile = accept.value.split(',').map(item => item.substring(1)).join('、')
    return `支持上传${acceptFile}格式的文件，图片不可超过${maxImgSize}M${videoTips.length ? '，' + videoTips : ''}`
  }) 

  const settingStore = useSettingStore();
  const setAlbumParam = albumParam();
  const locationSetting = locationP();
  const setSaveData = saveData();
  const router = useRouter();
  const isShowPermissionPicker = ref(false);
  const query = ref({
    albumName: '',
    permissionScope: '', //权限范围，0-全校可见，1-组织内可见
    albumType: '1', //0-校友相册，1-组织相册
    groupsId: '',
  });
  const upP = ref({
    albumId: '',
    address: '',
    describe: '',
    permissionScope: '',
    photoList: [] as Array<string>,
  });
  const aluName = ref('');
  const picList = ref<string[]>([]);
  const { upload, isComplete } = useUploadImageAndVideo(picList);
  const perName = ref('');
  const columns = reactive([
    { text: '全校可见', id: '0' },
    { text: '组织内可见', id: '1' },
  ]);
  const showPicker = ref(false);
  const healthFileList = <any>ref([]);
  const onConfirm = (value: any) => {
    upP.value.permissionScope = value.id;
    setAlbumParam.permissionScope = value.id;
    perName.value = value.text;
    showPicker.value = false;
  };
  const submmit = async () => {
    if (!isComplete.value) {
      Toast({ message: '请等待图片上传完毕' });
      return;
    }
    upP.value.albumId = setAlbumParam.albumId as string;
    upP.value.photoList = picList.value;
    upP.value.address = locationSetting.name;
    const { data, msg, code } = await Api.uploadPhotos(upP.value);
    Toast({ message: msg });
    setSaveData.picList = []
    router.back();
  };
  const goBack = () => {
    setSaveData.saveF = '0';
    locationSetting.name = '';
    setSaveData.picList = [];
    router.back()
  };
  const jumpMap = () => {
    setSaveData.saveF = '1';
    setSaveData.picList = picList.value;
    router.push({ path: '/location' });
  };
  const jumpAlbumList = () => {
    setSaveData.saveF = '1';
    setSaveData.picList = picList.value;
    router.push({ path: '/selectAlubmt' });
  };
  const deletePic = (file: any, detail: any) => {
    console.log(detail); //index
    picList.value.splice(detail.index, 1);
    console.log(picList.value);
  };

  const initData = () => {
    let permissionScope = setAlbumParam.permissionScope as string;
    upP.value.permissionScope = permissionScope;
    // query.value.albumType = permissionScope;
    for (let i in columns) {
      if (columns[i].id === permissionScope) {
        perName.value = columns[i].text;
      }
    }
  };
  onMounted(() => {
    console.log('addAluPic onMounted')
    initData();
    isShowPermissionPicker.value = setAlbumParam.type != '0';
    
  });
  onActivated(() => {
    console.log('addAluPic onActivated')
    if (setSaveData.saveF == '1') {
      picList.value = setSaveData.picList;
      upP.value.address = locationSetting.name;
    } else {
      picList.value = [];
      upP.value.address = '';
      upP.value.describe = '';
      healthFileList.value = [];
    }
    aluName.value = setAlbumParam.albumName;
  });
</script>

<style lang="less" scoped>
  .uploadButton {
    // margin-top: 30px;
    position: relative;
    top: -10px;
    width: 100%;
    background-color: #fff;
    border-radius: 8px;
    padding-left: 20px;
    padding-top: 70px;
    /deep/ .van-uploader__preview {
      width: 200px;
      height: 220px;
      .van-uploader__preview-image {
        width: 100%;
        height: 100%;
      }
    }
    .uptips{
      // position: absolute;
      // top:20px;
      // left: 20px;
      margin: -50px 0 20px;
      font-size: 16px;
      color: #FF0000;
      font-weight: 500;      
    }

    // margin: 0 auto;
    // margin-top: 30px;
  }
  .ooui {
    background: url('@/assets/img/alubmRights.png') no-repeat;
    background-size: 36px;
    background-position: 24px 50%;
    background-color: #fff;
    /deep/.van-cell__title {
      margin-left: 30px;
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #222222;
    }
  }
  .poui {
    background: url('@/assets/img/uploadPic.png') no-repeat;
    background-size: 36px;
    background-position: 24px 50%;
    background-color: #fff;
    /deep/.van-cell__title {
      margin-left: 30px;
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #222222;
    }
  }
  .con {
    width: 100%;
    height: 100%;
    background-color: #f5f5f5;
    .canOrupload {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      height: 5%;
      padding: 0 28px;
      background-color: #fff;
      // margin-top: 32px;
      .upload {
        font-size: 32px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 400;
        color: rgb(30, 147, 239);
      }
      .cancel {
        font-size: 32px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 400;
      }
    }
    .pic {
      // padding-top: 20px;
      width: 100%;
      height: 95%;
      padding: 0 32px;
      background-color: #f5f5f5;
      .setp2 {
        // margin-top: 10px;
        position: relative;
        top: -36px;
        width: 100%;
        border-radius: 8px;
        background-color: #fff;
      }
      .poosa {
        margin-top: 32px;
      }
      .jiansu {
        position: relative;
        top: -80px;
        left: 24px;
        width: 178px;
        // max-width: 330px;

        height: 60px;
        background: #f5f5f5;
        border-radius: 25px;
        text-align: center;
        display: flex;
        justify-content: center;
        align-items: center;
        // line-height: 50px;
        .location {
          font-size: 24px;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          // max-width: 300px;
          // width: 140px;
          overflow: hidden; /*内容会被修剪，并且其余内容是不可见的*/
          text-overflow: ellipsis; /*显示省略符号来代表被修剪的文本。*/
          white-space: nowrap;
          color: #999999;
        }
        .ims {
          width: 30px;
          height: 30px;
        }
      }
    }
  }
</style>
