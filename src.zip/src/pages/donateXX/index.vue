<template>
<div>
  <van-sticky>
      <van-nav-bar :title="configTitle" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div>
    <!-- <div class="haed-bar">
        <div class="head-title van-multi-ellipsis--l2">{{ detailData.newsTitle }}</div>
    </div>   -->
    <div v-html="content" class="news-cont"></div>
  </div>
</div>
</template>
<script lang="ts" setup>
import { ref, nextTick } from 'vue';
import { useRoute } from 'vue-router';
import { Base64 } from 'js-base64';
import { clickNum, getSchoolNews, getNewsDetail,  school, detail } from "@/api/home";
import { schoolConfig } from "@/hooks/schoolConfig";
import { SchoolCode } from '@/constants';
    const $route = useRoute();
    const onClickLeft = () => history.back();
    const configTitle = ref("");
    const loginInfo = reactive<school>({
      newsType: "donateXX",
      isReturnContent: '0',
      pageNum: 1,
      pageSize: 10
    });
    let detailData = <any>ref({});
    const testList = <any>ref([]);    
    interface titleConfig {
      title: string;
    }
  const content = ref<string>('');    
    const initData =async ()=>{
      if(!!$route?.query?.type){
        loginInfo.newsType = $route?.query?.type as string
      }
      const { code, data, msg } = await getSchoolNews(loginInfo);
      if(code == 200){
        testList.value = testList.value.concat(data.list);
        getData(testList.value[0]['niId'])
      }
    }

    const getData = async (id: string) => {
      const { code, data, msg } = await getNewsDetail({niId:id});
      if (code == 200) {
        detailData.value = { ...data };
        if (detailData.value.content) {
          let contentDetail = decodeURIComponent(
            Base64.decode(Base64.decode(Base64.decode(Base64.decode(detailData.value.content))))
          );
          content.value = contentDetail.replace(/<img/gi, "<img style='width:100%;height:100%'");
          nextTick(() => {
            document.body.scrollTo(0, 0)
          })
        }        
      } else {
        // Toast.fail(msg);
      }
    };
    //  initData()
    onMounted(()=>{
      initData()
      const news_type = ref($route.query.type ? $route.query.type : "");
      // if(SchoolCode){}
      let typeTitle = news_type.value as string
      let a = (schoolConfig("news", typeTitle) as unknown) as titleConfig ||{title:"捐赠详情"};
      configTitle.value = a.title as string;
    })
</script>
<style lang="less" scoped>
  .haed-bar {
    padding: 30px;
    .head-title {
      font-size: 36px;
      font-weight: 600;
      line-height: 56px;
    }
  }
  .news-cont {
    padding: 0 30px;
    img {
      max-width: 100vw !important;
    }
  }
</style>