<template>
  <div class="con" v-if="!state">
    <van-nav-bar title="组织" left-text="" left-arrow @click-left="onClickLeft" />
    <div class="orgCard" :style="orgCardStyle">
      <div class="per">
        <fix-image
          class="ims"
          v-if="settingStore.isShowGroupProfilePicture && org.groupsProfilePicture"
          :src="org.groupsProfilePicture"
          width="88"
          height="88"
          alt="头像"
        />
        <div class="perdetail">
          <div class="name"> {{ org.groupsName }} </div>
          <!-- <div class="uni">简介：{{ org.introduction }}</div> -->
          <div class="uni">
            <div class="con11">
              简介：
            </div>
            <div class="con22" ref="conIntro">
              {{org.introduction}}
            </div>
          </div>
          <!-- <div class="uni mar10">组织人数：{{ org.numberOfMembers }}人</div> -->
          <div class="uni mar10">
            <div class="con11">
              组织人数：
            </div>
            <div class="con22" ref="conIntro">
              {{ org.numberOfMembers }}人
            </div>
          </div>          
        </div>
      </div>
    </div>
    <div class="reason">
      <div class="title">申请原因</div>
      <van-field
        v-model="perX['reason']"
        rows="6"
        autosize
        label=""
        type="textarea"
        maxlength="300"
        placeholder="请输入申请原因"
        show-word-limit
      />
    </div>
    <div class="choice">
      <!-- <div class="ref" @click="disagreefun"> 拒绝 </div>
      <div class="agree" @click="agreefun"> 同意{{ ind }} </div> -->
      <!-- <van-button round type="default" class="ref" :disabled="state" @click="disagreefun"
        >拒绝</van-button
      >
      <van-button round type="success" class="agree" @click="agreefun" :disabled="state"
        >同意</van-button
      > -->
      <van-button round type="primary" :disabled="isApplyDisabled" class="agree" @click="joinOrg">申请加入</van-button>
    </div>
  </div>
  <div class="photo" v-else-if="state">
    <img :src="nodata2" alt="" class="ims" />
    <p class="is">暂无数据</p>
  </div>
</template>
<script lang="ts" setup>
  import { reactive, ref } from 'vue';
  import nodata2 from '@/assets/img/nodata2.png';
  import ApiGroup, { userGroupP, groupListP } from '@/api/group';
  import { Toast } from 'vant';
  import { useSettingStore } from '@/store';
  import { Dialog } from 'vant';
  import { SchoolCode } from '@/constants';
  import { useRouter, useRoute } from 'vue-router';
  import { useJoin } from './useJoin'
  import { useOrgCard } from '@/hooks/useOrgCard'
  import { getSchoolCode } from '@/utils';
  
  const { orgCardStyle } = useOrgCard()
  const { handleJoin } = useJoin()
  const settingStore = useSettingStore();
  const BaseFileUrl = import.meta.env.VITE_APP_PIC_BASE_URL;
  const router = useRouter();
  const route = useRoute();
  const org = reactive({
    groupsName: '',
    jianjie: '',
    numberOfMembers: '',
    join: false,
    groupsProfilePicture: '',
    category: '',
    introduction:""
  });
  const perX = reactive({
    groupsId: '',
    reason: '',
  });
  const ind = ref(0);
  const state = ref(false);
  const isApplyDisabled = ref(false)
  const onClickLeft = () => router.back();
  const initGroup = async (groupsId: string) => {
    const { data, code, msg } = await ApiGroup.groupsDetail({ groupsId });
    if (code == 200) {
      Object.assign(org, data);
      if (org.groupsProfilePicture) {
        org.groupsProfilePicture = BaseFileUrl + org.groupsProfilePicture;
      } else {
        org.groupsProfilePicture = '';
      }
    }
  };
  const initIsApplyDisabled =async (groupsId: string)=>{
    const { data, code, msg } = await ApiGroup.isApply({ groupsId });
    if(code == 200){
      isApplyDisabled.value = data
    }
  }
  const joinOrg = async () => {
    let schoolCode = getSchoolCode();
    if (schoolCode == SchoolCode.LiaoShiDa) {
      joinByLiaoShiDa()
    } else {
      submitJoinInfo();
    }
  };

  function joinByLiaoShiDa() {
    Dialog.confirm({
      title: '提 示',
      message: '网络交友行为与平台无关，谨防上当，避免产生钱财交易',
      showCancelButton: false,
      confirmButtonText: '我已知晓',
    }).then(() => {
      handleJoin(org, submitJoinInfo)
    });
  }

  async function submitJoinInfo() {
    const { data, code, msg } = await ApiGroup.groupsAdd({
      groupsId: route.query.groupsId as string,
      reason: perX.reason,
    });
    if (code == 200) {
      Toast.success({ message: '申请成功，等待审核' });
      router.back();
    } else {
      Toast.fail({ message: msg });
    }
  }

  onMounted(() => {
    initGroup(route.query.groupsId as string);
    initIsApplyDisabled(route.query.groupsId as string)
  });
</script>
<style lang="less" scoped>
  .photo {
    text-align: center;
    .ims {
      width: 300px;
      height: 300px;
    }
    .is {
      font-weight: 500;
    }
  }
  .con {
    width: 100%;
    height: 100%;
    .perInfo {
      background-color: #f8f8f8;
      width: 90%;
      height: 220px;
      background: linear-gradient(90deg, #f2f2f2 0%, #f8f8f8 100%);
      border-radius: 16px;
      margin: 0 auto;
      .per {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        margin-left: 30px;
        .ims {
          width: 88px;
          height: 88px;
          position: relative;
          top: -20px;
        }
        .perdetail {
          margin-left: 30px;
          .name {
            font-size: 36px;
            font-family: PingFang-SC-Bold, PingFang-SC;
            font-weight: bold;
            color: #333333;
            line-height: 36px;
            text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
            padding-bottom: 20px;
          }
          .uni {
            // display: inline-block;
            display: flex;
            align-items: center;
            font-size: 24px;
            font-family: PingFang-SC-Medium, PingFang-SC;
            font-weight: 500;
            color: #666666;
            line-height: 24px;
            text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
          }
          .uni::before {
            content: '';
            margin: 3px;
            display: table;
            width: 8px;
            height: 8px;
            // background: #2090ff;
            background: linear-gradient(270deg, #eaeaea 0%, #aaa9a9 100%, #ffffff 100%);
            border-radius: 50%;
          }
          .mar10 {
            margin-top: 10px;
          }
        }
      }
    }
    .reason {
      width: 90%;
      margin: 0 auto;
      margin-top: 30px;
      .title {
        font-size: 36px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #333333;
        line-height: 36px;
      }
      /deep/ .van-cell__value--alone {
        padding: 10px 20px;
        background: #f8f8f8;
        border-radius: 16px;
        border: 1px solid #dfdfdf;
        font-size: 28px;
        font-family: PingFang-SC-Regular, PingFang-SC;
      }
    }
    .choice {
      width: 90%;
      margin: 0 auto;
      margin-top: 20px;
      display: flex;
      justify-content: space-around;
      align-items: center;
      .ref {
        width: 240px;
        height: 88px;
        background: #ffffff;
        border-radius: 44px;
        border: 2px solid #dfdfdf;
        font-size: 36px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #333333;
        text-align: center;
        line-height: 88px;
      }
      .agree {
        width: 240px;
        height: 88px;
        border-radius: 44px;
        font-size: 36px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #ffffff;
        text-align: center;
        line-height: 88px;
      }
      .van-button:before {
      }
    }
  }
  .orgCard {
    margin: 10px 32px;
    width: 686px;
    height: 220px;
    background: url('@/assets/img/orgBac.png') no-repeat;
    background-size: 100% 100%;
    .per {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      padding-left: 8%;
      // margin: 0 auto;
      // justify-content: center;
      .ims {
        width: 88px;
        height: 88px;
        position: relative;
        top: -20px;
      }
      .perdetail {
        margin-left: 30px;
        // display: flex;
        // align-items: center;
        .name {
          font-size: 36px;
          font-family: PingFang-SC-Bold, PingFang-SC;
          font-weight: bold;
          color: #573201;
          line-height: 36px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
          padding-bottom: 20px;
        }
        .uni {
          font-size: 24px;
          font-family: PingFang-SC-Medium, PingFang-SC;
          font-weight: 500;
          color: #573201;
          // line-height: 24px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
          display: flex;
          .con22{
            font-size: 24px;
            // color:#6a7074;
            // height: 104px;
            flex:1;
            display: -webkit-box;
            -webkit-box-orient:vertical;
            -webkit-line-clamp:3;
            overflow: hidden;
            text-overflow: ellipsis;
            // display: flex;
            // flex-wrap: wrap;
            
          }         
        }
        .mar10 {
          margin-top: 10px;
        }
      }
    }
  }
</style>
