import useJoinDialog from '@/pages/orgDetail/useJoinDialog';
import { GroupCategory } from '@/constants';
import { SchoolCode } from '@/constants';
import { getSchoolCode } from '@/utils';

export function useJoin() {
  const { showInfoDialog, showLocalDialog } = useJoinDialog();
  const _SchoolCode = getSchoolCode();

  let joinEvent: Function = () => {};

  function handleJoin({ category }: { category: string }, joinOrg: Function) {
    joinEvent = joinOrg;
    if (_SchoolCode == SchoolCode.LiaoShiDa) {
			let isLocalOrgan =  category == GroupCategory.Local 
			isLocalOrgan ? onShowLocalDialog() : onShowInfoDialog();
    } else {
      joinOrg();
    }
  }

  /**展示个人信息是否展示的弹窗 */
  function onShowInfoDialog() {
    showInfoDialog({
      confirm() {
        joinEvent();
      },
      cancel() {
        joinEvent();
      },
    });
  }

  /**展示加入地区校友会时的弹窗 */
  function onShowLocalDialog() {
    showLocalDialog({
      confirm() {
        onShowInfoDialog();
      },
      cancel() {},
    });
  }

  return {
    handleJoin,
  };
}
