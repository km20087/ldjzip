import { useRouter } from 'vue-router';
import { isLiaoShiDa,isShanDa } from '@/utils/customizedType';
export function useGoPage() {
  const router = useRouter();
  /**
   * 1: 邀请加入组织
   */
  const goOrganDetailManage = ['1'];

  /**
   * 18: 活动邀请
   */
  const goActivitiDetail = ['18'];

  /**
   * 28：管理员-活动待审核
   * 29：管理员-活动待复审
   */
  const goOrganDetailAudit = ['28', '29'];

  /**
   * 19：活动审批通过
   * 20：审批退回
   * 22：审批不通过
   * 23：活动已通过审核并予以备案
   */
  const goOrganDetailActive = ['19', '20', '22', '23'];

  /**
   * 6:头像已经生效
   * 17:基础信息已更正
   * 30:学历更正审核通过
   * 31:学历更正审核未通过
   */
  const goMyPerInfoCard = ['6', '17', '30', '31'];

  /**
   * 7: 修改头像
   */
  const goEditPerInfo = ['7'];

  /**
   * 8:请求交换名片
   * 9:未同意交换名片
   */
  const goUserCard = ['8', '9'];

  /**
   * 11: 团体创建成功
   * 12: 团体返校通过审核
   * 13: 团体返校须补充信息
   * 14: 报名通过
   * 32: 收到团体邀请
   */
  const goBackSchool = ['11','12', '13','32','14'];

  /**
   * 32: 我的班级邀请
   */
  const goClasses = ['32'];
  /**
   * 34: 在线补办档案
   * 35: 查阅复印档案
   */
  const goArchive = ['34', '35'];

  function goPage(item: any = {}) {
    let { jumpParams, messageType } = item;
    let { groupsId, activitiesId, id } = JSON.parse(jumpParams || '{}')
    if (goOrganDetailManage.includes(messageType)) {
      router.push({
        path: '/orgDetail',
        query: { groupsId, active: 'manage' },
      });
    } else if (goOrganDetailAudit.includes(messageType)) {
      router.push({
        path: '/orgDetail',
        query: { groupsId, active: 'audit' },
      });
    } else if (goOrganDetailActive.includes(messageType)) {
      router.push({
        path: '/orgDetail',
        query: { groupsId, active: 'active' },
      });
    } else if (goActivitiDetail.includes(messageType)) {
      router.push({
        path: '/activitiDetail',
        query: { id: activitiesId, groupsId, tabName: 'join' },
      });
    } else if (goMyPerInfoCard.includes(messageType)) {
      router.push({ path: '/myPerInfoCard' });
    } else if (goEditPerInfo.includes(messageType)) {
      router.push({ path: '/editPerInfo', query: { editType: '1' } });
    } else if (goUserCard.includes(messageType)) {
      router.push({ path: '/user_card' });
    } else if (goBackSchool.includes(messageType)) {
      if(isLiaoShiDa() || isShanDa()){
        router.push({ path: '/backSchoolAuditEntry' });
      }else{
        if(['14', '32'].includes(messageType)){
          router.push({ path: '/detailGroupBackSchool',query:{ id } });
        } else{
          router.push({ path: '/groupBackSchool' });
        }
      }
    } else if (goClasses.includes(messageType)){
      router.push({ path: '/myClass', query: { groupsId, active: 'invite' } });
    } else if (goArchive.includes(messageType)) {
      router.push({ path: '/archive/record'})
    }
  }

  return {
    goPage,
  };
}
