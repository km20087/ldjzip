<template>
  <div class="wrap">
    <van-sticky>
      <nav-bar-2 title="我的消息" left-arrow @click-left="goBack" />
    </van-sticky>
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-empty v-if="listData.length == 0" description="暂无待查看的消息" />
      <van-list v-else class="list-wrap" v-model:loading="loading" :finished="finished" @load="getListData">
        <div
          class="list-wrap_item"
          v-for="(item, index) in listData"
          :key="item.id"
          @click="handleClick(item, index)"
        >
          <h5 class="title">
            <i class="dot" v-if="item.readFlag == ReadFlag.UnRead"></i>
            {{ item.title }}
          </h5>
          <div class="content-wrap">
            <span class="label">{{ item.content }}</span>
            <div class="sub-info-wrap">
              <i class="time">{{ item.createDate }}</i>
              <div class="detail-btn-wrap">
                <i class="txt">查看详情</i>
                <van-icon name="arrow" color="#666" size="16" />
              </div>
            </div>
          </div>
        </div>
      </van-list>
    </van-pull-refresh>
  </div>
</template>

<script setup lang="ts">
  import { onMounted } from 'vue';
  import { useGoBack } from '@/hooks/useGoBack';
  import { readNotification } from '@/api/message';
  import { useList } from '@/pages/message/useList';
  import { useGoPage } from '@/pages/message/useGoPage';
  import { Toast } from 'vant';
  import { useKeepAliveStore } from '@/store'

  const ComponentName = 'message'
  defineOptions({
    name: ComponentName,
    // 当页面从我的进入时，重置当前页面缓存实例
    beforeRouteEnter(to, from) {
      const keepAliveStore = useKeepAliveStore()
      let formName = from.name as string
      if (formName && ['mine'].includes(formName)) {
        keepAliveStore.removeCacheEntry(ComponentName)
      }
    }
  })

  enum ReadFlag {
    UnRead = '0',
    Read = '1',
  }

  const { goBack } = useGoBack();

  const { page, refreshing, onRefresh,loading, finished, listData, getListData } = useList();

  const { goPage } = useGoPage();

  function handleClick(item: MessageNotification, index: number) {
    if (item.readFlag == ReadFlag.UnRead) {
      onRead(item, index);
    }
    goPage(item);
  }

  /**标记已读 */
  async function onRead({ id }: MessageNotification, index: number) {
    const { code, data, msg } = await readNotification({ id });
    if (code == 200) {
      listData.value[index].readFlag = '1';
    }
  }

  onMounted(async () => {
    const loading = Toast.loading({
      message: '加载中'
    })
    await getListData();
    loading.clear()
  });
</script>

<style lang="less" scoped>
  .wrap {
    width: 100vw;
    // min-height: 100vh;
        height: 100vh;
    overflow-y: scroll;
    background: #f5f5f5;
  }
  .list-wrap {
    padding: 24px;
    .list-wrap_item {
      margin: 0 0 24px;
      background: #fff;
      border-radius: 24px;
      font-family: PingFangSC, PingFang SC;
      font-size: 26px;
      .title {
        margin: 0;
        padding: 22px 24px;
        font-size: 26px;
        font-weight: 500;
        color: #222;
        border-bottom: 1px solid #dfdfdf;
        display: flex;
        flex-direction: row;
        position: relative;
        
        .dot {
          position: absolute;
          left: 16px;
          top: 14px;
          display: block;
          width: 8px;
          height: 8px;
          background: red;
          border-radius: 50%;
        }
      }
      .content-wrap {
        padding: 24px 24px 22px;
        .label {
          padding: 0 0 20px;
          line-height: 34px;
          color: #666666;
          border-bottom: 1px solid #dfdfdf;
          display: block;
        }
        .sub-info-wrap {
          padding-top: 22px;
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          align-items: center;
          .time {
            font-style: normal;
            color: #999999;
          }
          .detail-btn-wrap {
            display: flex;
            flex-direction: row;
            align-items: center;
            .txt {
              color: #666;
            }
          }
        }
      }
    }
  }
</style>
