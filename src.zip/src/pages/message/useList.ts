import { ref } from 'vue';
import { pageNotification } from '@/api/message';

export function useList() {
  const refreshing = ref(false)
  const loading = ref(false);
  const finished = ref(false);
  const listData = ref<MessageNotification[]>([]);

  const page = reactive({
    pageNum: 0,
    pageSize: 10,
  });

  async function getListData() {
    try {
      loading.value = true;
      const result = await pageNotification({
        pageNum: ++page.pageNum,
        pageSize: page.pageSize,
      });
      if (result.code == 200) {
        const { list, pages, pageNum } = result.data;
        finished.value = pageNum >= pages;
        listData.value = pageNum == 1 ? list : [...listData.value, ...list];
        refreshing.value = false
        page.pageNum = pageNum
      }
    } catch (err) {
      console.log('getListData err', err);
    } finally {
      loading.value = false;
    }
  }

  function onRefresh() {
    page.pageNum = 0
    finished.value = false
    getListData()
  }

  return {
    page,
    refreshing,
    onRefresh,
    loading,
    finished,
    listData,
    getListData,
  };
}
