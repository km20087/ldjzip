<template>
  <van-sticky>
    <van-nav-bar title="登录" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="login">
    <div class="login-icon-cont">
      <img src="@/assets/img/login-logo.png" alt="" />
      <span>授权</span>
    </div>
    <loginCell value="查看详情" title="授权手机号码" :iconUrl="phoneIcon" @to-jump="openAcc" />
    <loginCell value="查看详情" title="授权个人信息" :iconUrl="infoIcon" @to-jump="openAcc1" />
    <loginCell value="查看详情" title="授权地理位置" :iconUrl="weizhiIcon" @to-jump="openAcc2" />
  </div>
</template>

<script setup lang="ts">
  import phoneIcon from '@/assets/img/acc-phone.png';
  import infoIcon from '@/assets/img/acc-info.png';
  import weizhiIcon from '@/assets/img/icon-weizhi.png';
  import loginCell from './components/loginCell.vue';
  import { Toast } from 'vant';
  import { clearUserStorage } from '@/utils';
  const router = useRouter();
  const onClickLeft = () => router.back();

  const openAcc = () => {
    router.push({ path: '/register' });
  };
  const openAcc1 = () => {
    Toast({ message: '功能暂没完善' });
  };
  const openAcc2 = () => {
    Toast({ message: '功能暂没完善' });
  };
  onMounted(() => {
    clearUserStorage();
  });
</script>

<style lang="less" scoped>
  .login {
    display: flex;
    flex-direction: column;
    align-items: center;
    overflow: auto;
    padding: 30px;
    .login-icon-cont {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 200px;
      margin-bottom: 100px;
      img {
        width: 88px;
        height: 88px;
        box-shadow: 1px 1px 20px 0px rgba(0, 0, 0, 0.1);
        border-radius: 16px;
      }
      span {
        font-size: 36px;
        line-height: 88px;
        font-weight: 500;
      }
    }
    .accBtn-cont {
      width: 100%;
      padding: 10px 0;
      border: 1px solid #dedede;
      border-radius: 8px;
      .acc-icon {
        width: 40px;
        height: 40px;
        margin: 0 20px 0 0;
      }
    }
  }
</style>
