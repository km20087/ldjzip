<template>
  <div class="accBtn-cont">
    <van-cell :value="value" is-link @click="toJump">
      <template #icon>
        <img :src="iconUrl" width="20" height="20" class="acc-icon" alt="" />
      </template>
      <!-- 使用 title 插槽来自定义标题 -->
      <template #title>
        <span class="custom-title">{{ title }}</span>
      </template>
    </van-cell>
  </div>
</template>
<script lang="ts" setup>
defineProps({
  value: String,
  title: String,
  iconUrl: String,
});
const emit = defineEmits(['toJump']);
const toJump = () => {
  emit('toJump');
};
</script>
<style lang="less" scoped>
.accBtn-cont {
  width: 100%;
  padding: 10px 0;
  border: 1px solid #dedede;
  border-radius: 8px;
  margin-bottom: 30px;
  .acc-icon {
    width: 40px;
    height: 40px;
    margin: 0 20px 0 0;
  }
  .custom-title {
    font-size: 32px;
  }
  .van-cell {
    align-items: center;
  }
  .van-icon {
    display: flex;
    align-items: center;
  }
}
</style>