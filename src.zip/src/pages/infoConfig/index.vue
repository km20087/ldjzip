<template>
  <div class="content">
    <van-nav-bar title="我的" left-text="" left-arrow @click-left="onClickLeft" />
    <div class="perInfo">
      <Avatar class="imgLogo" :src="perInfo.userProfilePicture" />
      <div class="name">
        <p>{{ perInfo.name }}</p>
      </div>
    </div>
    <div class="check">
      <van-cell title="基本信息" is-link @click="jumpEdit('base')">
        <template #icon>
          <img :src="baseInfo" class="ims" alt="" />
        </template>
        <template #value>{{ perInfo.mobile }}</template>
      </van-cell>
    </div>
    <div class="check" v-if="schoolLevel !== '1'">
      <van-cell title="职位信息" is-link @click="jumpEdit('job')" v-if="schoolCode != SchoolCode.ChengDeYiXueYuan">
        <template #icon>
          <SvgJob2 class="ims" />
        </template>
        <template #value>{{ perInfo.employer }}</template>
        <!-- occupationName -->
      </van-cell>
      <van-cell title="职位信息" is-link @click="jumpEdit('job')" v-else>
        <template #icon>
          <SvgJob2 class="ims" />
        </template>
        <template #value>{{ perInfo.schoolDuties }}</template>
        <!-- occupationName -->
      </van-cell>      
    </div>
    <div class="check" v-if="!isLiaoShiDa()">
      <van-cell title="学历信息" is-link @click="jumpEdit('stu')">
        <template #icon>
          <img :src="stuStatus" class="ims" alt="" />
        </template>
        <template #value>{{ perInfo.studentStatusInfo }}</template>
      </van-cell>
    </div>
    <div class="check">
      <van-cell title="允许接受陌生人名片">
        <!-- is-link -->
        <template #icon>
          <img :src="showInfo" class="ims1" alt="" />
        </template>
        <template #value>
          <van-switch v-model="perInfo.exchangeCardFlag" active-value="1" inactive-value="0"
            @update:model-value="onUpdateValue" size="24px" />
        </template>
      </van-cell>
    </div>
    <div class="check">
      <van-cell title="对外信息展示" is-link @click="showInfoConfig" to="selInfoConfig">
        <template #icon>
          <img :src="acceptInfo" class="ims" alt="" />
        </template>
        <!-- <template #value>{{ perInfo.mobile }}</template> -->
      </van-cell>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import Avatar from '@/components/avatar/index.vue';
import stuStatus from '@/assets/icons/stuStatus.png';
import showInfo from '@/assets/icons/showInfo.png';
import baseInfo from '@/assets/icons/baseInfo.png';
import acceptInfo from '@/assets/icons/acceptInfo.png';
import SvgJob2 from '@/assets/icons/job2.svg';
import Api from '@/api/schoolmate';
import ApiConfig from '@/api/config';
import { Toast } from 'vant';
import { isLiaoShiDa } from '@/utils/customizedType';
import {schoolShowConfig} from "@/utils/schoolLevelShow"
import {  SchoolCode } from "@/constants";
import { getSchoolCode } from '@/utils';
const schoolCode = getSchoolCode();
const router = useRouter();
const schoolLevel = ref('')
const perInfo = ref({
  name: '',
  mobile: '',
  employer: '', // 工作单位/单位名称
  jobTitle: '', //职务
  studentStatusInfo: '', //学历信息
  userProfilePicture: '',
  schoolDuties:"",
  exchangeCardFlag: '1', //是否允许陌生人交换名片，0或者null-不允许，1-允许
});
const InfoConfigFlag = ref(false);
const initPerConfig = async () => {
  const { data, code, msg } = await ApiConfig.infoConfigPerGet({});
};
const initSchoolConfig = async () => {
  const { data, code, msg } = await ApiConfig.infoConfigSchoolGet({enable:'1'});
};
const onClickLeft = () => {
  router.back();
};
const jumpEdit = (type: string) => {
  if (type == 'base') {
    router.push({ path: '/editPerInfo', query: { editType: '1' } });
  } else if (type == 'job') {
    router.push({ path: '/editPerInfo', query: { editType: '3' } });
  } else if (type == 'stu') {
    router.push({ path: '/editPerInfo', query: { editType: '2' } });
  }
};
const showInfoConfig = async () => {
  InfoConfigFlag.value = true;
};
const onUpdateValue = async (newValue: string) => {
  const { data, code, msg } = await Api.editExchangeCardFlag({ exchangeCardFlag: newValue });
  // Toast({ message: msg });
  if (code == 200) {
    // if (newValue == '1') {
    //   Toast({ message: '允许和陌生人交换名片' });
    // } else {
    //   Toast({ message: '禁止和陌生人交换名片' });
    // }
  } else {
    Toast({ message: '修改失败' });
  }
};
const initPer = async () => {
  const { data, code, msg } = await Api.getDetailedInformation({});
  if (code == 200) {
    Object.assign(perInfo.value, data);
    perInfo.value.exchangeCardFlag =
      perInfo.value.exchangeCardFlag == null ? '1' : perInfo.value.exchangeCardFlag;
  }
};
onMounted(() => {
  initPer();
  schoolLevel.value =  schoolShowConfig() as string
  // initPerConfig();
  // initSchoolConfig();
});
</script>
<style lang="less" scoped>
.content {
  width: 100%;
  height: 100%;
  background: #f9f9f9;
}

.perInfo {
  width: 92%;
  height: 150px;
  font-size: 0px;
  margin: 0 auto;
  background: #ffffff;
  border-radius: 8px;
  display: flex;
  padding-top: 27px;
  padding-left: 25px;
  align-items: center;

  .imgLogo {
    width: 88px;
    height: 88px;
    border-radius: 50%;
    object-fit: cover;
  }

  .name {
    font-size: 36px;
    font-family: PingFangSC-Semibold, PingFang SC;
    font-weight: 600;
    color: #222222;
    margin-left: 20px;
  }
}

.check {
  width: 92%;
  height: 88px;
  line-height: 88px;
  margin: 0 auto;
  margin-top: 16px;
  background: #ffffff;
  border-radius: 8px;
}

// --clickable
.van-cell {
  align-items: center;
  background: none;

  .ims {
    width: 30px;
    height: 30px;
  }

  /deep/.van-cell__title {
    margin-left: 20px;
    font-size: 28px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #333333;
  }

  /deep/.van-cell__value {
    font-size: 28px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #999999;
  }
}

.ims1 {
  width: 30px;
  height: 30px;
}

/deep/.van-cell__value {
  display: flex;
  justify-content: right;
  align-items: center;
  // width: 88px;
  // height: 44px;
}
</style>
