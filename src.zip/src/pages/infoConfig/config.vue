<template>
  <div class="content">
    <van-nav-bar title="我的" left-text="" left-arrow @click-left="onClickLeft" />
    <div class="itemList">
      <div class="item" v-for="(item, index) in showList" :key="index">
        <div class="label">
          <p>{{ item.cnName }}</p>
        </div>
        <van-switch v-model="item.code" active-value="3" inactive-value="2" @click="onUpdateValue(item)" size="24px" />
      </div>
    </div>
    <div class="button">
      <van-button round class="bu1" @click="onClickLeft"> 返回</van-button>
      <theme-button round class="bu1 bu2" @click="submmit"> 保存</theme-button>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive } from 'vue';
import { useRouter } from 'vue-router';
import ApiConfig from '@/api/config';
// import listForm from './data';
import listForm from "@/utils/dataList/infoConfig"
import ThemeButton from '@/components/theme-button/index.vue';
const router = useRouter();
const tedt = ref('');
const list = <any>ref([]);
const schoolList = <any>ref([]);
const perList = <any>ref([]);
const showList = <any>ref([]);
const onClickLeft = () => {
  router.back();
};

const init = async () => {
  const { data, code, msg } = await ApiConfig.infoConfigPerGet({});
  if (code == 200) {
    perList.value = data;
    for (let i in list.value) {
      if (perList.value[list.value[i].enLabel] != '1' && perList.value[list.value[i].enLabel] != null && perList.value[list.value[i].enLabel] != undefined && perList.value[list.value[i].enLabel] != '') {
        showList.value.push({
          enLabel: list.value[i].enLabel,
          cnName: list.value[i].cnName,
          code: perList.value[list.value[i].enLabel],
        });
      }
    }
  }
};
const onUpdateValue = (newValue: any) => {
  perList.value[newValue.enLabel] = newValue.code;
};
const submmit = async () => {
  const { data, code, msg } = await ApiConfig.infoConfigPerSave(perList.value);
  if (code == 200) {
    router.back();
  }
};
onMounted(() => {
  list.value = listForm.listForm().list;
  // console.log(list.value.list);
  init();
});
</script>

<style lang="less" scoped>
.content {
  width: 100%;
  height: 100%;
  background: #f9f9f9;
  // padding: 0 30px;
  overflow-y: scroll;

  .itemList {
    width: 92%;
    margin: 0 auto;

    // display: flex;
    .item {
      width: 100%;
      height: 88px;
      background: #ffffff;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 32px;
      margin-top: 16px;

      .label {
        font-size: 28px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #333333;
      }
    }
  }

  .button {
    display: flex;
    width: 100%;
    padding: 0 110px;
    justify-content: space-between;
    align-items: center;
    margin-top: 80px;
    margin-bottom: 30px;

    .bu1 {
      width: 240px;
      height: 88px;
      background: #ffffff;
      border-radius: 44px;
      border: 2px solid #dfdfdf;
    }

    .bu2 {
      background: #00558e;
      color: #fff;
    }
  }
}
</style>
