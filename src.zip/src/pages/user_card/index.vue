<template>
  <div class="content">
    <van-nav-bar title="名片夹" left-text="" left-arrow @click-left="onClickLeft" />
    <div class="info">
      <div class="tabtwo">
        <van-tabs v-model:active="active">
          <van-tab name="1">
            <template #title>
              我收到的名片 <span v-if="redPointFlag" class="circle-container"> </span>
            </template>
          </van-tab>
          <van-tab title="我递送的名片" name="0"></van-tab>
        </van-tabs>
      </div>
      <div class="cardList" v-if="active == '1'">
        <div class="itemCard">
          <van-cell title="未读名片" is-link to="index" @click="jumpCardList('未读名片', '0', '1')">
            <template #icon>
              <img :src="greenMsg" class="ims" alt="" />
            </template>
            <template #value>
              <span class="f28">{{ count.receiveExchangeUnreadCount }}</span>
            </template>
          </van-cell>
        </div>
        <div class="itemCard">
          <van-cell
            title="已交换名片"
            is-link
            to="index"
            @click="jumpCardList('已交换名片', '1', '1')"
          >
            <template #icon>
              <img :src="orangeMsg" class="ims" alt="" />
            </template>
            <template #value>
              <span class="f28">{{ count.receiveExchangeSuccessCount }}</span>
            </template>
          </van-cell></div
        >
        <div class="itemCard">
          <van-cell
            title="未交换名片"
            is-link
            to="index"
            @click="jumpCardList('未交换名片', '2', '1')"
          >
            <template #icon>
              <img :src="redMsg" class="ims" alt="" />
            </template>
            <template #value>
              <span class="f28">{{ count.receiveExchangeReadCount }}</span>
            </template>
          </van-cell></div
        >
        <div class="itemCard">
          <van-cell title="处理记录" is-link to="index" @click="jumpCardList('处理记录', '', '1')">
            <template #icon>
              <img :src="blueMsg" class="ims" alt="" />
            </template>
            <template #value>
              <span class="f28">{{ count.receiveExchangeCount }}</span>
            </template>
          </van-cell></div
        >
      </div>
      <div class="sendCard" v-if="active == '0'">
        <div class="" v-if="dataList.length > 0">
          <van-list
            v-model:loading="loading"
            :finished="finished"
            finished-text="没有更多了"
            @load="onLoad"
            :offset="100"
          >
            <cardList :perInfo="dataList" :cardExchangeType="cardExchangeType"></cardList>
            <!--               @give-card="giveCard"
              @refuse-card="refuseCard" -->
          </van-list>
        </div>
        <div v-else class="noData">
          <img :src="noneData" alt="" class="ims" />
          <div class="poTip">暂无数据~</div>
        </div>
        <!-- <cardList @give-card="giveCard" @refuse-card="refuseCard" :perInfo="dataList"></cardList> -->
        <!--         :key="lol" -->
      </div>
      <!-- <div class="transform-fix">
        <template v-if="dataList.length > 0">
          <SchoolMateList :list="dataList" @jump="jumpAlCard">
            <template #default="{ item }">
              <div class="status" v-if="active == '0'">
                <p class="iasd sd" v-if="item.cardExchangeStatus == '0'">待同意交换</p>
                <p class="iasd paso" v-else-if="item.cardExchangeStatus == '1'">已交换</p>
                <p class="iasd sd" v-else-if="item.cardExchangeStatus == '2'">已拒绝交换</p>
                <div v-else class="flexR">
                  <p class="iasd paso mar5" @click="giveCard(item.cardExchangeId)">同意交换</p>
                  <p class="iasd paso mar5" @click="refuseCard(item.cardExchangeId)">拒绝交换</p>
                </div>
              </div>
            </template>
          </SchoolMateList>
        </template>
        <div v-else class="nodata">
          <img :src="nodata2" alt="" class="ims" />
          <p>暂无数据</p>
        </div>
      </div> -->
    </div>
  </div>
</template>
<script lang="ts" setup>
import greenMsg from "@/assets/icons/greenMsg.png";
import blueMsg from "@/assets/icons/blueMsg.png";
import redMsg from "@/assets/icons/redMsg.png";
import orangeMsg from "@/assets/icons/orangeMsg.png";
import noneData from "@/assets/img/noneData.png";
import Api, { mate, cardParam, per } from "@/api/schoolmate";
import bacPerLogo from "@/assets/img/bacPerLogo.png";
import nodata2 from "@/assets/img/nodata2.png";
import cardList from "@/components/cardList/index.vue";
import { useRouter } from "vue-router";
import { Toast } from 'vant';
// import SchoolMateList from '@/components/schoolmate-list/index.vue';
const active = ref("1");

const loading = ref(false);
const finished = ref(false);
const isLastPageb = ref(false);

const count = ref({
  receiveExchangeUnreadCount: "0", // 收到的未读名片数
  receiveExchangeSuccessCount: "0", // 收到的已交换名片数
  receiveExchangeReadCount: "0", //收到的已读未交换名片数
  receiveExchangeCount: "0" // 收到的名片数（处理记录数）
});
const cardExchangeType = ref("2");
const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
const exP = reactive({
  id: "", //名片交换记录id
  exchangeResult: "" //0-拒绝，1-同意
});
const perInfo = reactive({
  name: "",
  schoolName: "",
  userProfilePicture: "",
  collegeName: "",
  classes: "",
  classesName: ""
});
const mateParam = ref<cardParam>({
  // cardExchangeStatus: active.value,
  cardExchangeSendType: active.value,
  pageSize: 10,
  pageNum: 1
});
const dataList = ref([] as per[]);
const redPointFlag = ref(false);
const router = useRouter();
const route = useRoute();
const init = async () => {
  const { data, code, msg } = await Api.getSchoolmateCardExchange(
    mateParam.value
  );
  // dataList.length = 0;
  dataList.value = [];
  if (code == 200) {
    dataList.value = dataList.value.concat(data.list);
  }
};

const onLoad = async () => {
  if (!isLastPageb.value && loading.value) {
    finished.value = false;
    mateParam.value.pageNum = (mateParam.value.pageNum as number) + 1;
    // await init();
    // let albumId = $route.query.albumId as string;
    await getChange();
  } else {
    loading.value = false;
    finished.value = true;
  }
};

const giveCard = async (id: string) => {
  exP.id = id;
  exP.exchangeResult = "1";
  const { data, code, msg } = await Api.auditSchoolmateCardExchange(exP);
  Toast({ message: msg });
  if (code == 200) {
    init();
  }
};
const refuseCard = async (id: string) => {
  console.log("asd");
  exP.id = id;
  exP.exchangeResult = "0";
  const { data, code, msg } = await Api.auditSchoolmateCardExchange(exP);
  Toast({ message: msg });
  if (code == 200) {
    init();
  }
};
const jumpCardList = (
  title: string,
  cardExchangeType: string,
  cardExchangeSendType: string
) => {
  router.push({
    path: "/myCardList",
    query: { title: title, cardExchangeType, cardExchangeSendType }
  });
};
const jumpAlCard = (item: any) => {
  if (active.value == "1") {
    router.push({ path: "alumni_card", query: { userId: item.userId } });
  }
};
const initCount = async () => {
  const { data, code, msg } = await Api.getExchangeReceivedCount({});
  count.value.receiveExchangeUnreadCount = data.receiveExchangeUnreadCount;
  count.value.receiveExchangeSuccessCount = data.receiveExchangeSuccessCount;
  count.value.receiveExchangeReadCount = data.receiveExchangeReadCount;
  count.value.receiveExchangeCount = data.receiveExchangeCount;
};
const onClickLeft = () => {
  router.back();
};
const imgNOFind = (e: any) => {
  e.target.src = bacPerLogo;
};
const getChange = async () => {
  loading.value = true;
  const { data, code, msg } = await Api.getSchoolmateCardExchange({
    ...mateParam.value,
    cardExchangeSendType: '0'
  }
  );
  if (mateParam.value.pageNum == 1) {
    dataList.value = [];
  }
  if (code == 200) {
    isLastPageb.value = data.isLastPage;
    loading.value = false;
    // dataList.push(...data.list);
    dataList.value = dataList.value.concat(data.list);
  } else {
    Toast({
      message: msg,
      icon: "none"
    });
  }
  if (isLastPageb.value) {
    loading.value = false;
    finished.value = true;
  }
};
onMounted(() => {
  initCount();
  getChange()
  // init();
  console.log(route.query.redTips);
  if (route.query.redTips == "1") {
    redPointFlag.value = true;
  }
});
</script>
<style lang="less" scoped>
.content {
  width: 100%;
  height: 100%;
  overflow-y: scroll;
  background: #f9f9f9;
}
.info {
  width: 100%;
  height: 280px;
  .bac {
    width: 100%;
    height: 170px;
    background: url("@/assets/img/mine-top_bg.png") no-repeat;
    background-size: 100% 170px;
    position: relative;
  }
  .card {
    width: 690px;
    height: 220px;
    margin: 0 auto;
    position: relative;
    // left: 220px;
    background: url("@/assets/img/perinfo.png") no-repeat;
    background-size: 100% 220px;
    top: -110px;
    .per {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      margin-left: 30px;
      .ims {
        width: 88px;
        height: 88px;
        position: relative;
        top: -20px;
        border-radius: 50%;
      }
      .perdetail {
        margin-left: 30px;
        .name {
          font-size: 36px;
          font-family: PingFang-SC-Bold, PingFang-SC;
          font-weight: bold;
          color: #573201;
          line-height: 36px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
          padding-bottom: 20px;
        }
        .uni {
          font-size: 24px;
          font-family: PingFang-SC-Medium, PingFang-SC;
          font-weight: 500;
          color: #573201;
          line-height: 24px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
        }
        .mar10 {
          margin-top: 10px;
        }
      }
    }
  }
  .bor {
    width: 100%;
    height: 24px;
    background-color: #dfdfdf;
    position: relative;
  }
  .tabtwo {
    width: 100%;
    position: relative;
    // top: -80px;
    border-bottom: 1px solid #dfdfdf;
  }
  .cardList {
    // padding: 0px 30px;

    width: 100%;
    height: 100%;
    .itemCard {
      width: 92%;
      height: 88px;
      background: #ffffff;
      margin: 0 auto;
      margin-top: 24px;
      // display: flex;
      // justify-content: space-between;
      // align-items: center;
      .van-cell--clickable {
        align-items: center;
      }
      .f28 {
        font-size: 28px;
      }
      .ims {
        width: 30px;
        height: 30px;
        margin-right: 20px;
      }
      .cardTips {
        font-size: 28px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #333333;
      }
    }
  }
}
.transform-fix {
  // transform: translateY(-72px);
}

.status {
  position: absolute;
  left: 0;
  bottom: 20px;
  width: 100%;
  .iasd {
    width: 200px;
    height: 52px;
    line-height: 52px;
    margin: 0 auto;
    border-radius: 30px;
    font-size: 26px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    color: #995700;
    border-radius: 30px;
    text-align: center;
  }
  .paso {
    background: linear-gradient(180deg, #fff6e5 0%, #e4c894 100%);
  }
  .mar5 {
    margin: 0 5px;
  }

  .flexR {
    width: 100%;
    display: flex;
    justify-content: space-around;
    align-items: center;
  }
  .sd {
    background: linear-gradient(180deg, #f8f8f8 0%, #c9c9c9 100%);
    color: #5b5b5b !important;
  }
}
.nodata {
  width: 100%;
  height: 100%;
  font-size: 24px;
  font-weight: 500;
  text-align: center;
  .ims {
    width: 200px;
    height: 200px;
  }
}
.circle-container {
  display: inline-block;
  width: 10px;
  height: 10px;
  background: #ff0000;
  border-radius: 50%;
  position: relative;
  top: -18px;
  left: -6px;
}
.noData {
  width: 100%;
  height: 100%;
  text-align: center;
  .ims {
    margin-top: 300px;
    width: 400px;
    height: 270px;
  }
  .poTip {
    font-size: 28px;
    font-family: PingFang-SC-Medium, PingFang-SC;
    font-weight: 500;
    color: #999999;
  }
}
</style>
