<template>
    <div class="gray-bg">
        <div class="banner">
            <FixImage :default-src="schoolFlagSD?shandaBannerAlumni2:bannerBG" class="banner-bg" />
        </div>
        <div class="main">
            <div class="status get" v-if="!returnMsg.expired">审核通过</div>
            <div class="status lose" v-else>已 过 期</div>
            <div class="showTime">{{ currentTime }}</div>
            <div class="qrCode-cont">
                <!-- <img class="qrcode" :src="returnMsg.qrCode" />
                <div class="expired" v-if="returnMsg.expired">
                    <FixImage :default-src="expiredPic" class="pic" />
                    <span>已过期</span>
                </div> -->
                <ECard :per-info="perInfo" v-if="!schoolFlagSD" />
                <div :class="detail.auditStatus == '1'?'card-bg':'cardL card-bg'" ref="cardBG" v-else>
                    <div class="user">
                    <fix-image
                        class="header"
                        :src="detail.userProfilePicture"
                        object-fit="fill"
                        v-if="detail.userProfilePicture && detail.auditStatus == '1'"
                    ></fix-image>

                    <van-image class="header" :src="defaultSrc" v-else-if="!detail.userProfilePicture && detail.auditStatus == '0'" />
                    <ul v-if="detail.auditStatus == '1'" class='sawadw'>
                        <template v-if="userInfo.schoolmateType == '2'">
                        <li>姓名：{{ detail.username }}</li>
                        <li>部门：{{ detail.jobDepartment }}</li>
                        <li>职务：{{ detail.jobTitle }}</li>
                        <li>入职时间：{{ detail.jobDuration }}</li>
                        </template>
                        <template v-else>
                        <li>姓名：{{ detail.username }}</li>
                        <li>院系：{{ detail.collegeName }}</li>
                        <li>专业：{{ detail.majorName }}</li>
                        <li>年级：{{ detail.schoolStartYear }}</li>
                        </template>
                    </ul>
                    <div class="card" v-else>
                        <UserCard :perInfo="perInfo" />
                    </div>  
                    </div>
                </div>
                        <!-- <div class="card" v-else>
                            <UserCard :perInfo="perInfo" />
                        </div>   -->                    
            </div>
            <div class="detail">
                <div class="one">
                    <span>返校学院</span>
                    <span class="b">{{ returnMsg.collegeName }}</span>
                </div>
                <div class="one">
                    <span>返校年级</span>
                    <span class="b">{{ returnMsg.gradeName }}</span>
                </div>
                <div class="one">
                    <span>姓&emsp;&emsp;名</span>
                    <span class="b">{{ returnMsg.schoolmateName }}</span>
                </div>
                <div class="one">
                    <span>返校时间</span>
                    <span class="b">{{ returnMsg.startTime }}至{{ returnMsg.endTime }}</span>
                </div>
                <div class="one">
                    <span>预约状态</span>
                    <span class="lose" v-if="returnMsg.expired">已过期</span>
                    <span class="get" v-else>已通过</span>
                </div>
                <!-- <van-notice-bar scrollable text="温馨提示：凭此二维码可进出校园，无需携带身份证件" /> -->
            </div>
        </div>
        <div class="btn">
            <van-button block round color="var(--theme-color)" @click="goBack">返 回</van-button>
        </div>

    </div>
</template>
<script lang="ts" setup>
import bannerBG from '@/assets/returnSchoolMonth/BANNER@2X.png'
import shandaBannerAlumni from '@/assets/returnSchoolMonth/shandaBannerAlumni.jpg';
import shandaBannerAlumni2 from '@/assets/returnSchoolMonth/shandaBannerAlumni2.jpg';
import { getqrCode } from '@/api/backSchoolMonth/index'
import expiredPic from "@/assets/returnSchoolMonth/icon-expired.png"
import { useGoBack } from '@/hooks/useGoBack'
import topbg from "@/assets/mine/default-avatar.png"
import { fommatDate } from '@/utils/fommatDate'
import ApiMy from '@/api/my';
import ECard from '../../home/component/ECard.vue'
import { getSchoolCode,getUserInfo} from '@/utils/util';
import {  SchoolCode } from '@/constants';
import UserCard from '@/pages/home/component/UserCard.vue'
import Api from '@/api/home'
const { goBack } = useGoBack()
const returnMsg = ref<any>({})
let currentTime = ref<string>('')
const schoolFlagSD = ref(false)
let cardBG = ref();
const defaultSrc = <any>ref()
const userInfo = JSON.parse(getUserInfo() || '{}')
let schoolCode = getSchoolCode()
  interface obj {
    id: string
    username: string
    collegeName: string
    classesName: string
    schoolStartYear: string
    userProfilePicture: string
    backgroundPicture: string
    majorName: string
    auditStatus: string
    rejectReason: string
    userNO?: string
    jobDepartment?: string
    jobTitle?: string
    jobDuration?: string
  }
const perInfo = ref<perInfo>({
    name: '',
    collegeName: '',
    schoolName: '',
    classes: '',
    userProfilePicture: '',
    classesName: '',
    mobile: '',
    educationInfoList: [],
});
let detail = ref<Partial<obj>>({
    username: '',
    collegeName: '',
    schoolStartYear: ''
})
const route = useRoute()
const judegeFlag = ()=>{
    if (schoolCode == SchoolCode.ShanDa){
        schoolFlagSD.value = true
        getList()
    }
    initMy()  
}
const getList = async () => {
    let { code, data, msg } = await Api.getCardList({})
    console.log('cardBG.value',cardBG.value)
    if (code == 200) {
        detail.value = data        
        if(detail.value.auditStatus == '1'){
            cardBG.value.style.backgroundImage = `url(${import.meta.env.VITE_APP_PIC_BASE_URL + data?.backgroundPicture})`
        }
        
    }
    defaultSrc.value =  topbg

}
onMounted(() => {
    console.log('userInfo',userInfo)
    judegeFlag()
    setInterval(() => {
        currentTime.value = fommatDate(new Date(), '年月日时分秒')
    }, 1000);
})

const getQRcode = async () => {
    let { code, msg, data } = await getqrCode({ id: route.query.id, returnActivityId: route.query.returnActivityId })
    if (code == 200) {
        returnMsg.value = data
    }
}
getQRcode()

const initMy = async () => {
    const { data, msg, code } = await ApiMy.baseInfo({});
    if (data?.educationInfoList) {
        data.educationInfoList = data.educationInfoList.filter(
            (item: any) => Object.getOwnPropertyNames(item).length != 0
        );
    }
    Object.assign(perInfo.value, data);
};
// initMy()
</script>
<style lang="less" scoped>
.banner-bg {
    width: 100vw;
    height: 209px;
}

.main {
    margin: 20px 24px 0;
    background: #FFFFFF;
    box-shadow: 0 0 8px 0 rgba(5, 112, 201, 0.08);
    border-radius: 15px;
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
        .card-bg {
            width: 100%;
            height: 400px;
            padding: 20px;
            background-position: center center;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            border-radius: 16px;
            overflow: hidden;
            display: flex;
            align-items: flex-end;
            position: relative;

            .user {
                display: flex;
                align-items: center;

                .header {
                    width: 146px;
                    height: 204px;
                    margin: 20px;
                }

                ul>li {
                    line-height: 48px;
                    color: #fff;
                    font-size: 28px;
                    font-size: 500;
                }
            }
        }
    .status {
        font-size: 36px;
        letter-spacing: 0;
        text-align: center;
        line-height: 24px;
        font-weight: 500;
        padding: 30px 0 34px;
    }

    .showTime {
        font-weight: 500;
        font-size: 36px;
        color: #3A62A4;
        padding: 5px 0 30px;
    }

    .qrCode-cont {
        // width: 350px;
        // height: 350px;
        // position: relative;
        width: 100%;

        :deep(.E-card) {
            padding: 0 25px;
            background: none;
            height: 452px;
        }

        .qrcode {
            width: 100%;
            height: 100%;
            align-items: center;
        }

        .expired {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, .7);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: #FFFFFF;
            font-size: 30px;
            line-height: 80px;
            font-weight: 500;

            .pic {
                width: 70px;
                height: 70px;
            }
        }
    }

    .detail {
        padding: 24px;
        width: 100%;
        margin-top: 34px;
        color: #666;
        border-top: 2px dashed #999;

        .one {
            display: flex;
            justify-content: space-between;
            line-height: 58px;

            .b {
                color: #222;
            }
        }
    }
}

.btn {
    margin: 40px 60px;
}

.get {
    color: #00CB2B;
}

.lose {
    color: #FF0000;
}
  .card {
    position: absolute;
    // top: 60px;
    // left: 30px;
    width: 690px;
    height: 220px;
    left: 50%;
    top:50%;
    transform: translate(-50%,-50%);
  }
  .cardL{
    height: 320px !important;
  }
</style>