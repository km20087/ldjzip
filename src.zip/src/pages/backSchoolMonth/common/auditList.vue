<template>
    <van-sticky>
        <nav-bar :title="mYtitle" left-arrow @click-left="onClickLeft" />
    </van-sticky>
    <div class="back-cont gray-bg">
        <!-- <van-tabs v-model:active="activeName" color="var(--theme-color)" style="margin-bottom: 15px;" @click-tab="onLoad">
            <van-tab title="我的团体" name="createGroup"></van-tab>
            <van-tab title="报名入团" name="join"></van-tab>
            <van-tab title="个人预约" name="personal"></van-tab>
        </van-tabs> -->
        <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
            <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
                <backlist v-for="(item, index) in backList" :key="index" :url="item.url"
                    :date="`${item.startDate}-${item.endDate}`" reason="" :people="item.groupSize || 0"
                    :status="activeName == 'createGroup' ? item.auditStatus : item.status"
                    @click="toDetail(item.id, activeName == 'join' ? item.returnActivityId : '', activeName == 'createGroup' ? item.auditStatus : item.status)" />
            </van-list>
        </van-pull-refresh>
    </div>
</template>
<script lang="ts" setup>
import backlist from './components/backlist.vue';
import successIcon from '@/assets/appointment/successIcon.png';
import failedIcon from '@/assets/appointment/failedIcon.png';
import expireIcon from '@/assets/appointment/expireIcon.png';
import { getauditList, getroupdetail, listAuditRecord } from '@/api/backSchoolMonth/index';
import { Toast } from 'vant';
import { nameHasRouter } from '@/hooks/hasRouter';
import { formatDate, formatDateTime } from '@/utils/tool/time';

type actN = 'createGroup' | 'join' | 'personal'
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const backList = ref([] as any[]);
const listP = {
    pageNum: 1,
    pageSize: 99,
};
const activeName = ref<actN>('createGroup')
const mYtitle = ref<string>('')

const $router = useRouter();
const $route = useRoute()

const onClickLeft = () => $router.back();
const onRefresh = () => {
    // 清空列表数据
    finished.value = false;

    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    loading.value = true;
    listP.pageNum = 1;
    backList.value = [];
    onLoad();
};
const dateforAll = (s: string): string => {
    return s.replace(/-/g, '/')
}
const onLoad = async () => {
    let Api = activeName.value !== 'createGroup' ? activeName.value == 'join' ? listAuditRecord({ ...listP, returnSchoolType: '0' }) : listAuditRecord({ ...listP, returnSchoolType: '1' }) : getauditList(listP)
    // 异步更新数据
    backList.value = []
    let { code, data, msg } = await Api;
    if (code == 200) {
        if (activeName.value == 'createGroup') {
            backList.value = data.list.filter((sub: any) => {
                return sub.auditStatus != 0
            }).map((item: any) => {
                return { ...item, url: (item.ended == '1' || item.disbanded == '1') ? expireIcon : (item.auditStatus == 0 || item.auditStatus == 1) ? successIcon : failedIcon }
            })

        } else {
            let date = dateforAll(formatDate(Date.now()))//因为ios的浏览器不支持含'-'格式
            let currentDate = new Date(date).getTime()
            backList.value = data.filter((sub: any) => {
                return sub.status != "0"
            })
                .map((item: any) => {
                    return { id: item.id, status: item.status, returnActivityId: item.returnActivityId, startDate: item.startTime, endDate: item.endTime, groupSize: activeName.value == 'join' ? item.groupSize : String(Number(item.accompanyCount) + 1), url: new Date(dateforAll(item.endTime)).getTime() >= currentDate ? item.status == 0 || item.status == 1 ? successIcon : failedIcon : expireIcon }
                })
        }
        loading.value = true;
        finished.value = true;
        // backList.value = backList.value.concat(data);
        // listP.pageNum++;
        // loading.value = false;
        // if (backList.value.length >= data.total) {
        //     finished.value = true;
        // }
    } else {
        Toast.fail(msg);
        // finished.value = true;
    }
    // refreshing.value = false;
};
const toDetail = async (id: string = '', gid?: string, std?: any) => {
    if (std == 2) return
    if (activeName.value == 'createGroup') {
        await getDetail(id)
        nameHasRouter($router, 'groupReturnStatus', '/groupReturnStatus', { id: '', returnActivityId: id });
    } else if (activeName.value == 'join') {
        await getDetail(gid)
        nameHasRouter($router, 'groupReturnStatus', '/groupReturnStatus', { id, returnActivityId: gid });
    } else {
        nameHasRouter($router, 'personalReturnStatus', '/personalReturnStatus', { id, returnActivityId: '' });
    }
};
const getDetail = async (id: any): Promise<void> => {
    const { code, msg, data } = await getroupdetail({ id })
    if (code == 200) {
        sessionStorage.removeItem('groupDetail')
        sessionStorage.setItem('groupDetail', JSON.stringify(data))//保存起来，后面的报名或编辑的时候使用
    } else {
        Toast.fail(msg)
    }
}

watch(() => $route.query, (val: any) => {
    if (!val) return
    activeName.value = val.type
    mYtitle.value = val.type == 'createGroup' ? '我的团体' : val.type == 'join' ? '报名入团' : '个人预约'
}, { immediate: true, deep: true })
</script>
<style lang="less" scoped>
.back-cont {
    padding: 24px 30px;
    width: 100%;
    height: 100%;
}
</style>