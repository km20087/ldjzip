<template>
    <van-sticky>
        <nav-bar title="我的预约" left-arrow @click-left="onClickLeft" />
    </van-sticky>
    <div class="">
        <ECard :per-info="perInfo" v-if="!schoolFlagSD" />
      <div class="card" v-else>
        <UserCard :perInfo="perInfo" />
      </div>
        <div class="entry-tit">快捷入口</div>
        <div class="list-cont" v-if="!schoolFlagSD">
            <stepJump v-for="(item, index) in list" :key="index" :url="getImg(item.icon as string)" :title="item.title"
                :path="item.path" :style="{ backgroundColor: hex2Rgba(settingStore.themeColor, 0.08) }"
                :query="item.query" />
        </div>    
        <div class="list-cont" v-else>
            <!-- <stepJump v-for="(item, index) in listSD" :key="index" :url="getImg(item.icon as string)" :title="item.title"
                :path="item.path" :style="{ backgroundColor: hex2Rgba(settingStore.themeColor, 0.08) }"
                :query="item.query" 
                :showThemeColor="true"
                /> -->
              <template  v-for="(item, index) in listSD" :key="index">
                <div class="itemNew" @click="goPageNew(item.path, item.query)">
                    <div class="lf">
                            <myGroup class="icon ims" v-if="item.type == 'my_Group'" />
                            <joinGroup class="icon ims" v-else-if="item.type == 'join_group'" />                        
                        <span class="txt">{{ item.title }}</span>
                    </div>
                    <div class="text-arrow" >
                        <span>查看详情 </span>
                        <van-icon size="16" color="var(--theme-color)" name="arrow"></van-icon>
                    </div>                    
                </div>                
              </template>
        </div>             
    </div>
</template>
<script setup lang="ts">
import ECard from '@/pages/home/component/ECard.vue';
import ECard2 from '@/components/E-card/index.vue'
import stepJump from '@/components/stepJump/index.vue'
import { useSettingStore } from "@/store";
import { hex2Rgba } from '@/utils/hex2rgba';
import { getImg ,getSchoolCode} from '@/utils/util';
import {  SchoolCode } from '@/constants';
import UserCard from '@/pages/home/component/UserCard.vue'
import myGroup from "@/assets/returnSchoolMonth/my_Group.svg"
import joinGroup from "@/assets/returnSchoolMonth/join_group.svg"
import ApiMy from '@/api/my';
import Api from '@/api/schoolmate';
const $router = useRouter();
const router = useRouter()
const schoolFlagSD = ref(false)
const perInfo = ref<perInfo>({
    name: '',
    collegeName: '',
    schoolName: '',
    classes: '',
    userProfilePicture: '',
    classesName: '',
    mobile: '',
    educationInfoList: [],
});
const list = ref<Partial<listMsg>[]>([
    {
        title: '我的团体', icon: 'returnSchoolMonth/my_Group.svg', path: 'backSchoolAudit', query: { type: 'createGroup' }
    },
    {
        title: '报名入团', icon: 'returnSchoolMonth/join_group.svg', path: 'backSchoolAudit', query: { type: 'join' }
    },
    {
        title: '个人预约', icon: 'returnSchoolMonth/my_review.svg', path: 'backSchoolAudit', query: { type: 'personal' }
    }
])

const listSD = ref<Partial<listMsg>[]>([
    {
        title: '我的团体', icon: 'returnSchoolMonth/my_Group.svg', type:"my_Group",path: 'backSchoolAudit', query: { type: 'createGroup' }
    },
    {
        title: '报名入团', icon: 'returnSchoolMonth/join_group.svg', type:"join_group",path: 'backSchoolAudit', query: { type: 'join' }
    },
])
const settingStore = useSettingStore();

const onClickLeft = () => $router.back();
const initMy = async () => {
    const { data, msg, code } = await ApiMy.baseInfo({});
    if (data?.educationInfoList) {
        data.educationInfoList = data.educationInfoList.filter(
            (item: any) => Object.getOwnPropertyNames(item).length != 0
        );
    }
    Object.assign(perInfo.value, data);
    if(!perInfo.value?.educationInfoList){
        perInfo.value.educationInfoList = []
    }
    console.log('perInfo',perInfo.value)
};


const judegeFlag = ()=>{
    let schoolCode = getSchoolCode()
    if (schoolCode == SchoolCode.ShanDa){
        schoolFlagSD.value = true
    }
}
const goPageNew = (path: string | undefined, query?: any): void => {
    router.push({ path, query })
}
onMounted(()=>{
    initMy()  
    judegeFlag()  
})
</script>
<style lang="less" scoped>
.entry-tit {
    font-size: 38px;
    font-weight: 600;
    // line-height: 106px;
    padding: 34px 43px 0;
}

.list-cont {
    padding: 0 43px 43px;
}

:deep(.item) {

    .lf {
        .txt {
            color: var(--theme-color) !important;
        }
    }
}
  .card {
    margin:30px 28px;
  }
.itemNew {
    margin: 50px 0 0;
    padding: 30px 33px;
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0px 2px 14px 0px rgba(0, 0, 0, 0.08);
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;

    .lf {
        display: flex;
        flex-direction: row;
        align-items: center;

        .icon {
            width: 100px;
            height: 100px;
        }

        .txt {
            margin-left: 43px;
            font-size: 36px;
            font-weight: 600;
            color: #3f547f;
        }
    }
    .text-arrow {
        display: flex;
        align-items: center;
        color: var(--theme-color);
        font-size: 24px;
    }    
}  
          .ims {
            // width: 100%;
            // height: auto;
            width: 100px;
            height: 100px;
            fill: #000;
            :deep(circle){
                fill: var(--theme-color);
            }
            // :deep(path:last-child) {
            //   fill: var(--theme-color);
            // }

            &.change-first {
            //   :deep(path:first-child) {
            //     fill: var(--theme-color);
            //   }

              :deep(path:last-child) {
                fill: #000;
              }
            }
          }
</style>