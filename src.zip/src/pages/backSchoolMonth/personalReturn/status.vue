<template>
    <div class="gray-bg">
        <van-sticky>
            <nav-bar title="个人预约" left-arrow @click-left="goBack" />
        </van-sticky>
        <div class="banner">
            <successTips />
        </div>
        <div class="exist-list">
            <van-row :gutter="30">
                <van-col :span="12" v-for="(item, index) in existList" :key="index">
                    <exist :src="item.src" :label="item.label" :path="item.path" :params="item.params" />
                </van-col>
            </van-row>
        </div>
    </div>
</template>
<script lang="ts" setup>
import successTips from './components/successTips.vue'
import LOGO_GROUP from '@/assets/returnSchoolMonth/logo-group.png'
import LOGO_CANCEL from '@/assets/returnSchoolMonth/logo-cancel.png'
import LOGO_QRCODE from '@/assets/returnSchoolMonth/logo-qrcode.png'
import exist from '../groupReturn/components/exist.vue'
import { existMsg, existType } from '../groupReturn/status'
import { useGoBack } from '@/hooks/useGoBack'

const route = useRoute()
const { goBack } = useGoBack()
const existList = ref<Partial<existMsg>[]>([
    { src: LOGO_GROUP, label: existType.exist6, path: 'personalReturnAdd', params: { id: route.query.id } },
    { src: LOGO_QRCODE, label: existType.exist2, path: 'backSchoolSchedule', params: { id: route.query.id, returnActivityId: route.query.returnActivityId } },
    { src: LOGO_CANCEL, label: existType.exist7, path: 'personal_cancel', params: { id: route.query.id } }
])

</script>
<style lang="less" scoped>
.banner {
    background-color: #fff;
    margin-bottom: 24px;
}

.exist-list {
    padding: 0 32px;
    background-color: #fff;
    max-height: 100vh;
}
</style>