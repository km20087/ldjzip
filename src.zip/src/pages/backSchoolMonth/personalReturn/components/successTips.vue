<template>
    <div class="success">
        <div class="word">
            <span class="title">预约返校成功</span>
            <span>感谢您对母校的支持！</span>
        </div>
        <img :src="getImg('returnSchoolMonth/logo-success.png')" alt="">
    </div>
</template>
<script lang="ts" setup>
import { getImg } from '@/utils/util'
</script>
<style lang="less" scoped>
.success {
    width: 100vw;
    height: 200px;
    background: var(--theme-color);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-left: 36px;

    .word {
        font-size: 28px;
        color: #FFFFFF;
        display: flex;
        flex-direction: column;

        .title {
            font-size: 44px;
            font-weight: 500;
            line-height: 88px;
        }
    }

    img {
        width: 182px;
        height: 182px;
        margin: 0 18px;
    }
}
</style>