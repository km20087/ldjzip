<template>
    <van-sticky>
        <nav-bar title="个人预约返校" left-arrow @click-left="goBack" />
    </van-sticky>
    <van-form @submit="onSubmit" input-align="right">
        <van-field v-model="queryForm.collegeName" name="collegeName" label="返校学院" placeholder="请输入返校学院"
            :rules="[{ required: true, message: '请填写返校学院' }]" is-link disabled />
        <van-field v-model="queryForm.gradeName" name="gradeName" label="返校年级" placeholder="请输入返校年级" is-link disabled />
        <van-field v-model="queryForm.schoolmateName" name="schoolmateName" label="返校校友" placeholder="请输入返校校友"
            :rules="[{ required: true, message: '请填写返校校友' }]" disabled />
        <van-field v-model="queryForm.mobile" name="mobile" label="联系电话" placeholder="请输入联系电话"
            :rules="[{ required: true, message: '请填写联系电话' }]" />
        <van-field name="stepper" label="陪同人数">
            <template #input>
                <van-stepper v-model="queryForm.accompanyCount" min="0" max="2" @overlimit="onOverLimit" />
            </template>
        </van-field>
        <fileCalendar v-model:data="queryForm.startTime" label="返校开始时间" label-width="7.1em" @on-confirm="">
            <template #ricon>
                <van-icon name="todo-list-o" color="var(--theme-color)" size="20px" />
            </template>
        </fileCalendar>
        <fileCalendar v-model:data="queryForm.endTime" label="返校结束时间" label-width="7.1em">
            <template #ricon>
                <van-icon name="todo-list-o" color="var(--theme-color)" size="20px" />
            </template>
        </fileCalendar>
        <van-field readonly name="registerDeadline" label="校史馆参观" @click="toJoinPage" label-width="8.2em">
            <template #right-icon>
                <span style="color:var(--theme-color)">查看</span>
            </template>
        </van-field>
        <filedTextarea title="其他需求" v-model:data="queryForm.otherDemand" placeholder="请输入其他需求" />
        <div class="opr-area">
            <van-button color="#333" plain round style="border: 1px solid #dedede;" @click="onCancel">{{ isDetail ? '返回' :
                '取 消' }}</van-button>
            <van-button color="var(--theme-color)" round native-type="submit" v-if="!isDetail">提 交</van-button>
        </div>
    </van-form>
</template>
<script lang="ts" setup>
import filePicker from '@/components/file-picker/index.vue'
import fileCalendar from '@/components/file-calendar/index.vue'
import filedTextarea from '@/components/filed-textarea/index.vue'
import { Dialog, Toast } from 'vant'
import ApiMy from '@/api/my';
import { joingroup, getRegisterDetail } from '@/api/backSchoolMonth'
import { useGoBack } from '@/hooks/useGoBack';

const { goBack } = useGoBack()
const router = useRouter()
const route = useRoute()
const isDetail = ref<boolean>(false)
const queryForm = ref<Partial<PersonalAddData>>({ returnSchoolType: '1', visitSchoolHistory: '0', accompanyCount: 0 })

watch(() => route.query.id, (val: any) => {
    if (val) {
        isDetail.value = true
        getRegisterDetail({ id: val }).then(res => {
            queryForm.value = res.code == 200 ? res.data : { returnSchoolType: '1', visitSchoolHistory: '0' }
        })
    }
}, { immediate: true })
const initMy = async (): Promise<void> => {
    const { data, msg, code } = await ApiMy.baseInfo({});
    if (data?.educationInfoList) {
        data.educationInfoList = data.educationInfoList.filter(
            (item: any) => Object.getOwnPropertyNames(item).length != 0
        );
        queryForm.value.collegeName = data.educationInfoList[0].collegeName
        queryForm.value.collegeId = data.educationInfoList[0].collegeId
        queryForm.value.gradeName = data.educationInfoList[0].schoolStartYear
    }
    queryForm.value.schoolmateName = data?.name
    queryForm.value.mobile = data?.mobileDetail
}
initMy()
const onOverLimit = () => {
    Toast('陪同人数可选范围为0~2人')
}
const onSubmit = () => {
    Dialog.alert({
        title: '温馨提示',
        message: '您的申请信息将提交学院管理员审核，审核结果将通过公众号进行通知，请留意查看。',
        confirmButtonText: '我知道了',
        confirmButtonColor: 'var(--theme-color)',
    }).then(async () => {
        // on close
        const { code, data, msg } = await joingroup(queryForm.value)
        if (code == 200) {
            Toast.success(msg)
            goBack()
        }
    });
}
const onCancel = () => {
    goBack()
}
const toJoinPage = () => {
    Dialog.alert({
        title: '温馨提示',
        message: '无法以个人身份申请参加校史馆，可申请加入其他团体返校参观。',
        closeOnClickOverlay: true,
        confirmButtonText: '去报名',
        confirmButtonColor: 'var(--theme-color)',
        showCancelButton: true,
        cancelButtonText: '关闭'
    }).then(() => {
        router.push('groupReturn')
    })
}
</script>
<style lang="less" scoped>
:deep(.van-stepper__minus),
:deep(.van-stepper__plus) {
    color: var(--theme-color);
}

:deep(.van-stepper__minus--disabled),
:deep(.van-stepper__plus--disabled) {
    color: var(--van-stepper-button-disabled-icon-color);
    background-color: var(--van-stepper-button-disabled-color);
    cursor: not-allowed;
}

.opr-area {
    display: flex;
    justify-content: space-around;
    padding: 20px;

    .van-button {
        flex: 1;
        margin: 20px;
    }
}
</style>