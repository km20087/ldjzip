<template>
  <van-sticky>
    <nav-bar title="校友返校月" left-arrow @click-left="goBack" />
  </van-sticky>
  <div class="gray-bg">
    <div class="banner">
      <FixImage :src="bannerData" :default-src="defaultBanner" class="banner-bg" />
    </div>
    <div class="list-cont">
      <stepJump
        v-for="(item, index) in listConfig"
        :key="index"
        :url="getImg(item.icon as string)"
        :title="item.title"
        :icon="icon"
        :path="item.path"
      />
    </div>
  </div>
</template>
<script lang="ts" setup>
  import { getImg, getSchoolCode } from '@/utils/util'
  import stepJump from '@/components/stepJump/index.vue'
  import { homeSwipePic } from '@/api/home'
  import { useGoBack } from '@/hooks/useGoBack'
  import bannerBG from '@/assets/returnSchoolMonth/schoolBanner.png'
  import alumniBanner from '@/assets/img/alumniBanner.png'
  import { SchoolCode } from '@/constants'
  import useCache from '@/hooks/useCache'
  const schoolCode = getSchoolCode()
  const { goBack } = useGoBack()
  const onlyGroupFlag = ref(false)

  const bannerData = ref('')
  const defaultBanner = computed(() => (onlyGroupFlag.value ? alumniBanner : bannerBG))

  const listConfig = computed(() => {
    const listGroup = [
      { title: '团体返校', icon: 'returnSchoolMonth/sdA1.jpg', path: 'groupReturn' },
      { title: '审核进度', icon: 'returnSchoolMonth/sdA3.jpg', path: 'backSchoolAuditEntry' },
    ]
    const list = [
      { title: '团体返校', icon: 'returnSchoolMonth/group_return.png', path: 'groupReturn' },
      {
        title: '个人返校',
        icon: 'returnSchoolMonth/personal_return.png',
        path: 'personalReturnAdd',
      },
      {
        title: '审核进度',
        icon: 'returnSchoolMonth/Review_progress.png',
        path: 'backSchoolAuditEntry',
      },
    ]
    return onlyGroupFlag.value ? listGroup : list
  })
  const icon = computed(() => {
    return onlyGroupFlag.value
      ? getImg('returnSchoolMonth/rightArrow.jpg')
      : getImg('returnSchoolMonth/arrow-right.png')
  })

  const initTopBanner = () => {
    useCache({
      key: 'returnSchoolBanner',
      service: homeSwipePic,
      params: {
        imageType: 'returnSchoolBanner',
      },
      callback: ({ code, data, msg }: any) => {
        if (code == 200) {
          bannerData.value = data?.images[0].fileAddress
        }
      },
    })
  }

  onMounted(() => {
    onlyGroupFlag.value = ([SchoolCode.ShanDa] as string[]).includes(schoolCode!)
    if (onlyGroupFlag.value) {
      initTopBanner()
    }
  })
</script>
<style lang="less" scoped>
  .banner-bg {
    width: 100vw;
    height: 350px;
  }

  .list-cont {
    padding: 0 33px;
  }
</style>
