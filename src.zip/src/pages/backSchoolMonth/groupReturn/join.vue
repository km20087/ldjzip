<template>
    <van-sticky>
        <nav-bar title="报名" left-arrow @click-left="goBack" />
    </van-sticky>
    <van-form @submit="onSubmit" input-align="right">
        <van-field v-model="queryForm.collegeName" name="collegeName" label="返校学院" placeholder="请输入返校学院" is-link readonly />
        <van-field v-model="queryForm.gradeName" name="gradeName" label="返校年级" placeholder="请输入返校年级" is-link readonly />
        <van-field v-model="queryForm.schoolmateName" name="schoolmateName" label="返校校友" placeholder="请输入返校校友" readonly />
        <van-field v-model="queryForm.mobile" name="mobile" label="联系电话" placeholder="请输入联系电话" />
        <fileCalendar v-model="queryForm.startTime" label="返校开始时间" label-width="7.1em" @on-confirm="" readonly>
            <!-- <template #ricon>
                <van-icon name="todo-list-o" color="var(--theme-color)" size="20px" />
            </template> -->
        </fileCalendar>
        <fileCalendar v-model="queryForm.endTime" label="返校结束时间" label-width="7.1em" readonly>
            <!-- <template #ricon>
                <van-icon name="todo-list-o" color="var(--theme-color)" size="20px" />
            </template> -->
        </fileCalendar>
        <van-field name="switch" label="是否参观校史馆" v-if="schoolCode != SchoolCode.ShanDa" label-width="8.6em">
            <template #input>
                <van-switch active-color="var(--theme-color)" v-model="queryForm.visitSchoolHistory" size="20"
                    active-value="1" inactive-value="0" @change="visitChange" />
            </template>
        </van-field>
        <fileCalendar v-model="queryForm.visitTime" label="参观时间"  v-if="queryForm.isVisitSchoolHistoryMuseum == '1'" label-width="7.1em" @click="">
            <!-- <template #ricon>
                <van-icon name="clock-o" color="var(--theme-color)" size="20px" />
            </template> -->
        </fileCalendar>
        <filedTextarea v-model:data="queryForm.scheduled" readonly />
        <filedTextarea title="其他需求" v-model:data="queryForm.otherDemand" readonly placeholder="请输入其他需求" />
        <div class="opr-area">
            <van-button color="#333" plain round style="border: 1px solid #dedede;" @click="onCancel">取 消</van-button>
            <van-button color="var(--theme-color)" round native-type="submit">提 交</van-button>
        </div>
    </van-form>
</template>
<script lang="ts" setup>
import fileCalendar from '@/components/file-calendar/index.vue'
import filedTextarea from '@/components/filed-textarea/index.vue'
import { joingroup } from '@/api/backSchoolMonth'
import { Dialog } from 'vant'
import ApiMy from '@/api/my';
import { useGoBack } from '@/hooks/useGoBack';
import { Toast } from 'vant'
import { getImg ,getSchoolCode} from '@/utils/util';
import {  SchoolCode } from '@/constants';
import { useConfirmDialog } from './useConfirmDialog'
const { showConfirmDialog } = useConfirmDialog()
let schoolCode = getSchoolCode()
const router = useRouter()
const queryForm = ref<any>({})
const { goBack } = useGoBack()
const initMy = async (): Promise<void> => {
    const { data, msg, code } = await ApiMy.baseInfo({});

    if (data?.educationInfoList) {
        data.educationInfoList = data.educationInfoList.filter(
            (item: any) => Object.getOwnPropertyNames(item).length != 0
        );
        queryForm.value.collegeName = data.educationInfoList[0].collegeName
        queryForm.value.collegeId = data.educationInfoList[0].collegeId
        queryForm.value.gradeName = data.educationInfoList[0].schoolStartYear
        queryForm.value.gradeId = data.educationInfoList[0].schoolStartYear
    }else{
        queryForm.value.collegeName = data.collegeName
        queryForm.value.collegeId = data.collegeId
        queryForm.value.gradeName = data.schoolEndYear
        queryForm.value.gradeId = data.schoolEndYear        
    }
    queryForm.value.schoolmateName = data?.name
    queryForm.value.mobile = data?.mobileDetail
}
initMy()
const onSubmit = () => {
    showConfirmDialog().then(async () => {
        try {
            const { code, msg, data } = await joingroup(queryForm.value)
            if (code == 200) {
                Toast.success(msg)
                goBack()
            } else {
                Toast.fail(msg)
            }
        } catch (error) {

        }
    });
}
const visitChange = (v: any) => {
    if (queryForm.value.initVisitSchoolHistory == '0' && v !== queryForm.value.initVisitSchoolHistory)
        Dialog.alert({
            title: '温馨提示',
            message: '团队设置了不参观校史馆，如需参观，请报名其他相关团体！',
            confirmButtonText: '确认',
            confirmButtonColor: 'var(--theme-color)',
            showCancelButton: true,
            cancelButtonText: '取消'
        }).then(async () => {
            queryForm.value.visitSchoolHistory = 0
        })

}
const onCancel = () => {
    goBack()
}

onMounted(async () => {
    if (sessionStorage.getItem('groupDetail')) {
        let { id, startDate, endDate, scheduled, visitDate, remark, isVisitSchoolHistoryMuseum } = JSON.parse(<any>sessionStorage.getItem('groupDetail'))
        queryForm.value = { ...queryForm.value, scheduled, returnActivityId: id, returnSchoolType: '0', startTime: startDate, endTime: endDate, visitTime: visitDate, otherDemand: remark, visitSchoolHistory: isVisitSchoolHistoryMuseum, initVisitSchoolHistory: isVisitSchoolHistoryMuseum }
    }
})
</script>
<style lang="less" scoped>
:deep(.van-stepper__minus),
:deep(.van-stepper__plus) {
    color: var(--theme-color);
}

:deep(.van-stepper__minus--disabled),
:deep(.van-stepper__plus--disabled) {
    color: var(--van-stepper-button-disabled-icon-color);
    background-color: var(--van-stepper-button-disabled-color);
    cursor: not-allowed;
}

.opr-area {
    display: flex;
    justify-content: space-around;
    padding: 20px;

    .van-button {
        flex: 1;
        margin: 20px;
    }
}
</style>