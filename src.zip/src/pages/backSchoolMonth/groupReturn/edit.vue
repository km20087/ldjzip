<template>
    <van-sticky>
        <nav-bar title="创建团体信息" left-arrow @click-left="goBack" />
    </van-sticky>
    <van-form @submit="onSubmit" input-align="right">
        <van-field v-model="queryForm.collegeName" name="collegeName" label="返校学院" placeholder="请输入返校学院"
            :rules="[{ required: false, message: '请填写返校学院' }]" is-link disabled />
        <van-field v-model="queryForm.gradeName" name="gradeName" label="返校年级" placeholder="请输入返校年级" is-link disabled />
        <van-field v-model="queryForm.createBy" name="username" label="召集人" placeholder="请输入召集人"
            :rules="[{ required: false, message: '请填写召集人' }]" disabled />
        <van-field v-model="queryForm.contact" name="username" label="联系电话" placeholder="请输入联系电话"
            :rules="[{ required: false, message: '请填写联系电话' }]" />
        <van-field name="switch" label="是否隐藏联系电话" label-width="8.6em">
            <template #input>
                <van-switch active-color="var(--theme-color)" active-value="1" inactive-value="0"
                    v-model="queryForm.isHideContact" size="20" />
            </template>
        </van-field>
        <van-field name="stepper" label="返校人数">
            <template #input>
                <van-stepper v-model="queryForm.groupSize" min="10" />
            </template>
        </van-field>
        <fileCalendar v-model:data="queryForm.startDate" label="返校开始时间" label-width="7.1em">
            <template #ricon>
                <van-icon name="todo-list-o" color="var(--theme-color)" size="20px" />
            </template>
        </fileCalendar>
        <fileCalendar v-model:data="queryForm.endDate" label="返校结束时间" label-width="7.1em">
            <template #ricon>
                <van-icon name="todo-list-o" color="var(--theme-color)" size="20px" />
            </template>
        </fileCalendar>
        <van-field v-model="queryForm.registerDeadline" readonly name="registerDeadline" label="报名截止时间"
            placeholder="请选择截止日期" @click="showDateTimePicker = true" label-width="8.2em">
            <template #right-icon>
                <van-icon name="todo-list-o" color="var(--theme-color)" size="20px" />
            </template>
        </van-field>
        <van-popup v-model:show="showDateTimePicker" position="bottom" :style="{ height: 'auto' }">
            <van-datetime-picker v-model="nowTime" type="datetime" @cancel="showDateTimePicker = false"
                @confirm="onDateTimerConfirm" />
        </van-popup>
        <van-field name="switch" label="是否参观校史馆" v-if="schoolCode != SchoolCode.ShanDa" label-width="8.6em">
            <template #input>
                <van-switch active-color="var(--theme-color)" v-model="queryForm.isVisitSchoolHistoryMuseum" size="20"
                    active-value="1" inactive-value="0" />
            </template>
        </van-field>
        <filePicker title="可预约时段" label="参观时间" :columns="timeList" v-if="queryForm.isVisitSchoolHistoryMuseum == '1'" @click="getTimes()" v-model:data="queryForm.visitDate">
            <template #ricon>
                <van-icon name="clock-o" color="var(--theme-color)" size="20px" />
            </template>
        </filePicker>
        <!-- <van-field name="stepper" label="参观人数" v-if="isEdit">
            <template #input>
                <van-stepper v-model="queryForm.visitorNumber" />
            </template>
        </van-field> -->
        <filedTextarea v-model:data="queryForm.scheduled" />
        <filedTextarea title="其他需求" v-model:data="queryForm.remark" placeholder="请输入其他需求" />
        <div class="opr-area">
            <van-button color="#333" plain round style="border: 1px solid #dedede;" @click="onCancel">取消</van-button>
            <van-button color="var(--theme-color)" round native-type="submit">确认</van-button>
        </div>
    </van-form>
</template>
<script lang="ts" setup>
import fileCalendar from '@/components/file-calendar/index.vue'
import filedTextarea from '@/components/filed-textarea/index.vue'
import { Dialog, Toast } from 'vant'
import ApiMy from '@/api/my';
import { addGroup, getVisitTime, updategroup } from '@/api/backSchoolMonth'
import filePicker from '@/components/file-picker/index.vue'
import { useGoBack } from '@/hooks/useGoBack';
import { fommatDate } from '@/utils/fommatDate';
import { getSchoolCode} from '@/utils/util';
import {  SchoolCode } from '@/constants';
import { useConfirmDialog } from './useConfirmDialog'
const { showConfirmDialog } = useConfirmDialog()
const schoolCode = getSchoolCode()
const route = useRoute()
const router = useRouter()
const nowTime = ref<Date>(new Date())
const queryForm = ref<Partial<addData>>({ isHideContact: '0', isVisitSchoolHistoryMuseum: '0' })
const perInfo = ref<Partial<perInfo>>({
    name: '',
    collegeName: '',
    mobile: '',
    educationInfoList: []
});
const timeList = ref([])
const { goBack } = useGoBack()
const showDateTimePicker = ref<boolean>(false)
const isEdit = ref<boolean>(false)

const onDateTimerConfirm = (v: any) => {
    queryForm.value.registerDeadline = fommatDate(v, 'yyyy-MM-dd hh:mm:ss')
    showDateTimePicker.value = false
}
const initMy = async (): Promise<void> => {
    const { data, msg, code } = await ApiMy.baseInfo({});
    if (data?.educationInfoList) {
        data.educationInfoList = data.educationInfoList.filter(
            (item: any) => Object.getOwnPropertyNames(item).length != 0
        );
        queryForm.value.collegeName = data.educationInfoList[0].collegeName
        queryForm.value.collegeId = data.educationInfoList[0].collegeId
        queryForm.value.gradeName = data.educationInfoList[0].schoolStartYear
        queryForm.value.gradeId = data.educationInfoList[0].schoolStartYear
    }else{
        queryForm.value.collegeName = data.collegeName
        queryForm.value.collegeId = data.collegeId
        queryForm.value.gradeName = data.schoolEndYear
        queryForm.value.gradeId = data.schoolEndYear        
    }
    Object.assign(perInfo.value, data);
    queryForm.value.createBy = perInfo.value?.name
    queryForm.value.contact = perInfo.value?.mobileDetail
}
initMy()
const getTimes = async (): Promise<void> => {
    const { code, msg, data } = await getVisitTime({ startTime: queryForm.value.startDate, endTime: queryForm.value.endDate })
    if (code == 200) {
        timeList.value = data
    } else {
        Toast.fail(msg)
    }

}
const onSubmit = (values: any): void => {
    showConfirmDialog().then(async () => {
        if (route.query?.flag == 'edit') {
            const { code, msg, data } = await updategroup(queryForm.value)
            if (code == 200) {
                Toast.success(msg)
                goBack()
            } else {
                Toast.fail(msg)
            }
        } else {
            const { code, msg, data } = await addGroup(queryForm.value)
            if (code == 200) {
                Toast.success(msg)
                goBack()
            } else {
                Toast.fail(msg)
            }
        }

    });
}
const onCancel = () => {
    goBack()
}

onMounted(async () => {
    if (route.query?.flag == 'edit') {
        if (sessionStorage.getItem('groupDetail')) {
            queryForm.value = { ...JSON.parse(<any>sessionStorage.getItem('groupDetail')) }
        }
        isEdit.value = true
    }
})
</script>
<style lang="less" scoped>
:deep(.van-stepper__minus),
:deep(.van-stepper__plus) {
    color: var(--theme-color);
}

:deep(.van-stepper__minus--disabled),
:deep(.van-stepper__plus--disabled) {
    color: var(--van-stepper-button-disabled-icon-color);
    background-color: var(--van-stepper-button-disabled-color);
    cursor: not-allowed;
}

.opr-area {
    display: flex;
    justify-content: space-around;
    padding: 20px;

    .van-button {
        flex: 1;
        margin: 20px;
    }
}
</style>