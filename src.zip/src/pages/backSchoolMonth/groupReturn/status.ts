export interface existMsg {
    src: string
    label: string
    path: string
    params?: Record<string, any>
}
export enum existType {
    exist1 = '团体信息',
    exist2 = '入校信息',
    exist3 = '报名情况',
    exist4 = '邀请校友',
    exist5 = '解散团队',
    exist6 = '返校信息',
    exist7 = '取消预约',
}