<template>
    <van-sticky>
        <nav-bar title="团体返校" left-arrow @click-left="goBack" />
    </van-sticky>
    <div class="gray-bg">
        <div class="banner">
            <card :name="detailData.groupName" :collega="detailData.collegeName" :phone="detailData.contact"
                :member="detailData.registerCount" :total="detailData.groupSize"
                :isShowCP="detailData.isHideContact == '0' ? true : false" />
        </div>
        <div class="exist-list">
            <van-row :gutter="30">
                <van-col :span="12" v-for="(item, index) in existList" :key="index">
                    <exist :src="item.src" :label="item.label" :path="item.path" :params="item?.params" />
                </van-col>
            </van-row>
        </div>
    </div>
</template>
<script lang="ts" setup>
import card from './components/card.vue'
import LOGO_GROUP from '@/assets/returnSchoolMonth/logo-group.png'
import LOGO_CANCEL from '@/assets/returnSchoolMonth/logo-cancel.png'
import LOGO_ENTRY from '@/assets/returnSchoolMonth/logo-entry.png'
import LOGO_INVITE from '@/assets/returnSchoolMonth/logo-invite.png'
import LOGO_QRCODE from '@/assets/returnSchoolMonth/logo-qrcode.png'
import exist from './components/exist.vue'
import { existMsg, existType } from './status'
import { useGoBack } from '@/hooks/useGoBack'

const route = useRoute()
const { goBack } = useGoBack()

const detailData = ref<Partial<ResultData>>({})
const existList = ref<Partial<existMsg>[]>([
    { src: LOGO_GROUP, label: existType.exist1, path: 'groupReturnDetail', params: { id: route.query.returnActivityId } },
    { src: LOGO_QRCODE, label: existType.exist2, path: 'backSchoolSchedule', params: { id: route.query.id, returnActivityId: route.query.returnActivityId } },
    { src: LOGO_ENTRY, label: existType.exist3, path: 'groupReturnEntry' },
    // { src: LOGO_INVITE, label: existType.exist4, path: 'invite' },
    { src: LOGO_CANCEL, label: existType.exist5, path: 'cancel', params: { id: route.query.returnActivityId } }
])

onMounted(async () => {
    if (sessionStorage.getItem('groupDetail')) {
        detailData.value = JSON.parse(<any>sessionStorage.getItem('groupDetail'))
        let { isCreator, disbanded } = detailData.value
        if (!isCreator) {
            existList.value.pop()
        }
        if (disbanded == '1') {
            existList.value.splice(1, 1)
            existList.value.pop()
        }
    }
})
</script>
<style lang="less" scoped>
.banner {
    padding: 30px;
    background-color: #fff;
    margin-bottom: 24px;
}

.exist-list {
    padding: 0 32px;
    background-color: #fff;
    max-height: 100vh;
}
</style>