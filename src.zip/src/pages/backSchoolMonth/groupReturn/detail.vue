<template>
    <div class="gray-bg">
        <van-sticky>
            <nav-bar title="团体信息" left-arrow @click-left="goBack" />
        </van-sticky>
        <div class="banner">
            <card :name="detailData.groupName" :collega="detailData.collegeName" :phone="detailData.contact"
                :member="detailData.registerCount" :total="detailData.groupSize"
                :isShowCP="detailData.isHideContact == '0' ? true : false" />
        </div>
        <div class="main">
            <div class="group-msg">
                <div class="list">
                    <fix-image :default-src="iconduring" />
                    <div class="text">
                        <span>活动时间：</span>
                        <span class="b">{{ detailData.startDate }}至{{ detailData.endDate }}</span>
                    </div>
                </div>
                <div class="list">
                    <fix-image :default-src="icondeadline" />
                    <div class="text">
                        <span>报名截止时间：</span>
                        <span class="b">{{ detailData.registerDeadline }}</span>
                    </div>
                </div>
                <div class="list" v-if="!schoolFlagSD">
                    <fix-image :default-src="iconlibrary" />
                    <div class="text colums">
                        <span class="b">校史馆参观</span><span v-if="detailData.registered">：{{
                            detailData.visitorNumber }}人</span>
                    </div>
                </div>
                <div class="list" v-if="!schoolFlagSD">
                    <div class="text sub">
                        <span>校史馆参观安排：{{ detailData.visitDate }}</span>
                    </div>
                </div>
            </div>
            <div class="group-msg">
                <div class="btit">活动日程安排：</div>
                <div class="qmjnb">
                    {{ detailData.scheduled }}
                </div>
            </div>
            <div class="opr-area" v-if="!detailData.isCreator && !detailData.registered">
                <van-button color="#333" plain round style="border: 1px solid #dedede;" @click="onCancel">取消</van-button>
                <van-button color="var(--theme-color)" round @click="toJoin">报 名</van-button>
            </div>
            <div class="opr-area" v-else-if="!detailData.isCreator && detailData.registered">
            </div>
            <div class="opr-area" v-else-if="detailData.auditStatus == '2'">
                <van-button color="var(--theme-color)" round block size="large" icon="edit" @click="toEdit">编
                    辑</van-button>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
import card from './components/card.vue'
import iconlibrary from '@/assets/returnSchoolMonth/icon-library.png'
import icondeadline from '@/assets/returnSchoolMonth/icon-deadline.png'
import iconduring from '@/assets/returnSchoolMonth/icon-during.png'
import { getroupdetail } from '@/api/backSchoolMonth/index'
import { Toast } from 'vant'
import { useGoBack } from '@/hooks/useGoBack';
import { getSchoolCode} from '@/utils/util';
import {  SchoolCode } from '@/constants';

const route = useRoute()
const router = useRouter()
const { goBack } = useGoBack()
const detailData = ref<Partial<ResultData>>({})
const schoolFlagSD = ref(false)
const getDetail = async (id: any): Promise<void> => {
    const { code, msg, data } = await getroupdetail({ id })
    if (code == 200) {
        sessionStorage.removeItem('groupDetail')
        detailData.value = data
        sessionStorage.setItem('groupDetail', JSON.stringify(detailData.value))//保存起来，后面的报名或编辑的时候使用
    } else {
        Toast.fail(msg)
    }
}
getDetail(route.query.id)
const onCancel = () => {
    goBack()
}
const toJoin = () => {
    router.push('groupReturnJoin')
}
const toEdit = () => {
    router.push({ path: 'groupReturnAdd', query: { flag: 'edit' } })
}
const judegeFlag = ()=>{
    let schoolCode = getSchoolCode()
    if (schoolCode == SchoolCode.ShanDa){
        schoolFlagSD.value = true
    }
}
onMounted(()=>{
    judegeFlag()
})
</script>
<style lang="less" scoped>
.banner {
    padding: 30px;
    background-color: #fff;
}

.main {
    padding: 30px;

    .group-msg {
        background: #FFFFFF;
        border-radius: 16px;
        padding: 32px;
        margin-bottom: 24px;

        .list {
            display: flex;
            align-items: center;

            img {
                width: 32px;
                height: 32px;
            }

            .text {
                margin-left: 20px;
                line-height: 56px;
                color: #666;

                .b {
                    color: #333;
                }

                &.colums {
                    margin-top: 10px;
                }

                &.sub {
                    padding-left: 32px;
                }
            }
        }

        .btit {
            font-size: 32px;
            font-weight: 500;
        }

        .qmjnb {
            padding: 24px 0;
            line-height: 46px;
        }
    }

    .opr-area {
        display: flex;
        justify-content: space-around;
        padding: 20px;
        margin-top: 60px;

        .van-button {
            flex: 1;
            margin: 20px;
        }
    }
}
</style>