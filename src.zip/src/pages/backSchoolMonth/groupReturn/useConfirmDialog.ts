import { Dialog } from 'vant'
import { getSchoolCode } from '@/utils/util'
import { SchoolCode } from '@/constants'

export function useConfirmDialog() {
  const schoolCode = getSchoolCode()
  const showConfirmDialog = () => {
    return new Promise((resolve, reject) => {
      let allowHtml = false
      let message = '您的申请信息将提交学院管理员审核，审核结果将通过公众号进行通知，请留意查看。'
      if (([SchoolCode.ShanDa] as string[]).includes(schoolCode!)) {
        message =
          '<span style="font-family: PingFangSC, PingFang SC;">您的申请信息将提交管理员审核，审核结果将在“我的”-“我的信息”栏进行通知，请留意查看。</span>'
          allowHtml = true
      }
      Dialog.alert({
        title: '温馨提示',
        message,
        confirmButtonText: '确认',
        confirmButtonColor: 'var(--theme-color)',
        showCancelButton: true,
        cancelButtonText: '取消',
        allowHtml,
      })
        .then(resolve)
        .catch(reject)
    })
  }

  return {
    showConfirmDialog,
  }
}
