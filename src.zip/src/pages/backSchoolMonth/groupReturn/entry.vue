<template>
    <div class="gray-bg">
        <van-sticky>
            <nav-bar title="报名情况" left-arrow @click-left="goBack" />
        </van-sticky>
        <div class="banner">
            <card :name="detailData.groupName" :collega="detailData.collegeName" :phone="detailData.contact"
                :member="detailData.registerCount" :total="detailData.groupSize"
                :isShowCP="detailData.isHideContact == '0' ? true : false" />
        </div>
        <van-row :gutter="12" class="list-row">
            <van-col span="12" v-for="(item, index) in memberData" :key="index">
                <member-card :data="item" />
            </van-col>
        </van-row>
    </div>
</template>
<script lang="ts" setup>
import card from './components/card.vue'
import memberCard from './components/member-card.vue';
import { getJoinorList } from '@/api/backSchoolMonth/index'
import { useGoBack } from '@/hooks/useGoBack';
import { Toast } from 'vant'

const detailData = ref<Partial<ResultData>>({})
const { goBack } = useGoBack()
const memberData = ref<RegisterShoolMate>({})

const getList = async (id: string) => {
    const { code, msg, data } = await getJoinorList({ pageNum: 1, pageSize: 99, returnActivityId: id })
    if (code == 200) {
        memberData.value = data.filter((item: any) => {
            return item.status != '2'
        })
    } else {
        Toast.fail(msg)
    }

}
onMounted(async () => {
    if (sessionStorage.getItem('groupDetail')) {
        detailData.value = JSON.parse(<any>sessionStorage.getItem('groupDetail'))
    }
    getList(detailData.value.id as string)
})
</script>
<style lang="less" scoped>
.banner {
    padding: 30px;
    background-color: #fff;
}

.list-row {
    padding: 0 24px;
}
</style>