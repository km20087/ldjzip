<template>
    <div class="gray-bg">
        <van-sticky>
            <nav-bar title="校友返校月" left-arrow @click-left="goBack" />
        </van-sticky>
        <div class="search-bar">
            <van-search v-model="queryForm.groupName" shape="round" @search="onSearch" placeholder="请输入搜索关键词" />
            <div class="create-btn">
                <span>没找到我的团体？那创建一个吧</span>
                <van-button @click="createGroup" color="var(--theme-color)" plain round size="mini"
                    :style="{ backgroundColor: hex2Rgba(settingStore.themeColor, 0.14), marginLeft: '10px' }">&ensp;创
                    建&ensp; </van-button>
            </div>
        </div>
        <div class="main">
            <div class="tabs">
                <van-tabs type="card" background="#f5f5f5" v-model:active="queryForm.ended" @click-tab="getList"
                    title-inactive-color="#333">
                    <van-tab title="报名中" name="0"></van-tab>
                    <van-tab title="已结束" name="1"></van-tab>
                </van-tabs>
            </div>
            <van-tree-select v-model:main-active-index="activeIndex" :items="collegeList" height="100%"
                @click-nav="doGetList" v-if="collegeList.length > 0">
                <template #content>
                    <div class="tree-list" v-if="groupList.length">
                        <list @jump-func="jumpFunc(item?.id)" v-for="(item, index) in groupList" :data="item" :key="index"
                            :is-ended="isEnded" />
                    </div>
                    <span v-else>暂无数据</span>
                </template>
            </van-tree-select>
            <van-empty v-else description="暂无数据" />
        </div>
    </div>
</template>
<script lang="ts" setup>
import { hex2Rgba } from '@/utils/hex2rgba';
import { useSettingStore } from "@/store";
import list from './components/list.vue';
import { Dialog, Toast } from 'vant'
import { useGoBack } from '@/hooks/useGoBack';
import { getGroupList, getCollegeList } from '@/api/backSchoolMonth/index'
import ApiMy from '@/api/my';
import {  SchoolCode } from '@/constants';
import { getSchoolCode} from '@/utils/util';
const { goBack } = useGoBack()
const settingStore = useSettingStore();
const queryForm = ref<searchP & pageParams>({
    groupName: '',
    collegeId: '',
    ended: '',
    pageNum: 1,
    pageSize: 99
})
const activeIndex = ref(0);
const collegeList = ref<{ text: string; id: string }[]>([])
const router = useRouter()
const groupList = ref<Partial<ResultData>[]>([])
const isEnded = ref<boolean>(false)

const createGroup = () => {
    let schoolCode = getSchoolCode()
    if (schoolCode == SchoolCode.ShanDa){
         router.push('groupReturnAdd')
    }else{
        Dialog.alert({
            title: '温馨提示',
            message: '创建团体报名后，如响应人数在报名截止前未超过10人，则自动解散该报名团体，已响应人员转为个人返校。',
            confirmButtonText: '我知道了',
            confirmButtonColor: 'var(--theme-color)'
        }).then(() => {
            // on close
            router.push('groupReturnAdd')
        });
    }
}
const jumpFunc = (id?: string) => {
    if (id) {
        router.push({ path: 'groupReturnDetail', query: { id } })
    }
}
const getList = async () => {
    isEnded.value = queryForm.value?.ended == '0' ? true : false
    const result = await getGroupList({ ...queryForm.value, collegeId: collegeList?.value[activeIndex.value]?.id })
    if (result?.code == 200) {
        groupList.value = result?.data?.list
    } else {
        Toast.fail(result.msg)
    }
}
//点击学院查询--这里的索引值才即时响应
const doGetList = (index: number) => {
    activeIndex.value = index
    getList()
}
const onSearch = async () => {
    await getCollege()
    await getList()
}
const initMy = async (): Promise<void> => {
    const { data, msg, code } = await ApiMy.baseInfo({});
    if (data?.educationInfoList) {
        data.educationInfoList = data.educationInfoList.filter(
            (item: any) => Object.getOwnPropertyNames(item).length != 0
        );
        queryForm.value.collegeId = data.educationInfoList[0].collegeId
    }
}
const getCollege = async () => {
    const { code, data, msg } = await getCollegeList({ pageNum: 1, pageSize: 99, groupName: queryForm.value?.groupName })
    collegeList.value = data.list
    for (let i = 0; i < data.list.length; i++) {
        if (queryForm.value.collegeId == data.list[i]?.collegeId && data.list[i]?.groupTotal > 0) {
            activeIndex.value = i
        } else {
            activeIndex.value = 0
        }
    }
    collegeList.value = collegeList.value.filter((sub: any) => {
        return sub.groupTotal != 0
    }).map((item: any) => { return { text: `${item.collegeName}(${item.groupTotal})`, id: item.collegeId } })
}
onMounted(async () => {
    await initMy()
    await getCollege()
    await getList()
})
</script>
<style lang="less" scoped>
.search-bar {
    .create-btn {
        font-family: PingFangSC-Regular;
        font-size: 28px;
        color: #666666;
        display: flex;
        align-items: center;
        padding: var(--van-search-padding);
        background: var(--van-search-background-color);
    }
}

.main {
    margin-top: 20px;
    background-color: #fff;
    min-height: 100vh;

    :deep(.van-tabs__nav--card) {
        border-radius: 40px;
        overflow: hidden;
        border: none;
    }

    :deep(.van-tabs) {
        padding: 22px;
        border-bottom: 1px solid #DFDFDF;
    }

    :deep(.van-tab--card.van-tab--active) {
        background-color: var(--theme-color);
    }

    :deep(.van-tab--card) {
        border-right: none;
    }

    .tree-list {
        padding: 24px;
    }
}
</style>