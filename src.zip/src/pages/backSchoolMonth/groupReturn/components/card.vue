<template>
    <div class="card">
        <div class="left">
            <div class="left-name">{{ name }}</div>
            <div class="left-collega">学院：{{ collega }}</div>
            <div class="left-phone">联系方式：{{ phone }}<img v-if="isShowCP" :src="ICON_COPY" class="copybtn"
                    @click="copyText(phone)" /></div>
        </div>
        <div class="right">
            <div class="right-label">已报名人数</div>
            <div class="right-num"><span>{{ member }}</span>/{{ total }}</div>
        </div>
    </div>
</template>
<script lang="ts" setup>
import ICON_COPY from '@/assets/returnSchoolMonth/icon-copy.png'
import copyText from '@/hooks/useCopyText'
const props = withDefaults(
    defineProps<{
        name?: string;
        collega?: string
        phone?: string
        member?: number
        total?: number
        isShowCP?: boolean
    }>(),
    {
        name: '',
        collega: '',
        phone: '',
        member: 0,
        total: 0,
        isShowCP: false
    }
);
</script>
<style lang="less" scoped>
.card {
    width: 100%;
    padding: 20px 32px;
    background: var(--theme-color);
    border-radius: 16px;
    font-family: PingFangHK-Medium;
    color: #fff;
    display: flex;
    align-items: center;
    font-weight: 500;

    .left {
        flex: 73;

        .left-name {
            font-size: 36px;
            line-height: 72px;
        }

        .left-collega,
        .left-phone {
            font-size: 24px;
            line-height: 48px;
            display: flex;
            align-items: center;

            .copybtn {
                width: 36px;
                height: 36px;
                margin-left: 20px;
            }
        }
    }

    .right {
        flex: 27;
        position: relative;
        padding-left: 35px;

        &::before {
            content: '';
            width: 1px;
            height: 100%;
            background: linear-gradient(to bottom, transparent 0%, #fff 40%, #fff 50%, transparent 100%);
            position: absolute;
            left: 0px;
        }

        .right-label {
            font-size: 24px;
            line-height: 58px;
        }

        .right-num {
            font-size: 32px;

            span {
                font-size: 54px;
            }
        }
    }
}
</style>