<template>
    <div class="member-cont">
        <div class="rows inname">{{ data?.schoolmateName }}</div>
        <div class="rows"><span>返校学院：</span>
            <div style="max-width: 50%;">{{ data?.collegeName }}</div>
        </div>
        <div class="rows"><span>返校年级：</span>{{ data?.gradeName }}</div>
        <div class="rows"><span>联系电话：</span>{{ data?.mobile }}</div>
    </div>
</template>
<script lang="ts" setup>
const props = withDefaults(defineProps<{
    data?: any
}>(), {})
</script>
<style lang="less" scoped>
.member-cont {
    width: 339px;
    background: #FFFFFF;
    border-radius: 16px;
    margin-top: 24px;
    padding: 12px 0;

    .rows {
        padding: 12px 24px;
        font-size: 24px;
        display: flex;

        &.inname {
            font-size: 32px;
            position: relative;

            &::before {
                content: '';
                width: 8px;
                height: 32px;
                background: var(--theme-color);
                border-radius: 0 5px 5px 0;
                position: absolute;
                top: 13px;
                left: 0;
            }
        }

        span {
            color: #666;
        }
    }
}
</style>