<template>
    <div class="sub-list">
        <div class="up">
            <div class="title hasTip">{{ data?.groupName }}</div>
        </div>
        <div class="down">
            <p>活动时间：<span class="num">{{ data?.startDate }}~{{ data?.endDate }}</span></p>
            <p>截止时间：<span class="num">{{ data?.registerDeadline }}</span></p>
            <p>已报名人数：<span class="red">{{ data?.registerCount }}</span><span>/{{ data?.groupSize }}</span></p>
            <van-button color="var(--theme-color)"
                :style="{ backgroundColor: hex2Rgba(settingStore.themeColor, 0.14), border: 'none', }" block round plain
                size="small" @click="jumpFunc" v-if="isEnded">报 名</van-button>
            <van-button color="#666" :style="{ backgroundColor: '#f5f5f5', border: 'none', }" block round plain size="small"
                v-else>报名已结束</van-button>
        </div>
    </div>
</template>
<script lang="ts" setup>
import { hex2Rgba } from '@/utils/hex2rgba';
import { useSettingStore } from "@/store";
const settingStore = useSettingStore();
const emits = defineEmits(['jumpFunc'])
const props = withDefaults(defineProps<{ data?: Partial<ResultData>; isEnded?: boolean }>(), { isEnded: true })
const jumpFunc = () => {
    emits('jumpFunc')
}
</script>
<style lang="less" scoped>
.sub-list {
    background: #FFFFFF;
    border: 1px solid #DFDFDF;
    box-shadow: 1px 2px 4px 0 rgba(0, 0, 0, 0.08);
    border-radius: 24px;
    margin-bottom: 20px;

    .up {
        font-family: PingFangSC-Medium;
        font-size: 32px;
        color: #333333;
        line-height: 72px;
        font-weight: 500;
        border-bottom: 1px solid #EDEDED;
        ;

        .hasTip {
            display: flex;
            align-items: center;
            padding: 0 10px;

            &:before {
                content: '';
                width: 10px;
                height: 10px;
                border-radius: 50%;
                background-color: #B42D3B;
                margin: 0 15px;
            }
        }
    }

    .down {
        font-family: PingFangSC-Regular;
        font-size: 24px;
        color: #999999;
        line-height: 28px;
        padding: 0 24px 24px;

        .num {
            color: #333333;
        }

        .red {
            color: #B42D3B;
        }
    }
}
</style>