<template>
    <div class="exist" @click="jumpPage(path)">
        <div class="label">{{ label }}</div>
        <fix-image :default-src="src" />
    </div>
</template>
<script lang="ts" setup>
import { nameHasRouter } from '@/hooks/hasRouter';
import { Dialog, Toast } from 'vant'
import { cancelGroup, cancelBook } from '@/api/backSchoolMonth'
import { useGoBack } from '@/hooks/useGoBack'

const { goBack } = useGoBack()
const router = useRouter()
const props = withDefaults(defineProps<{
    src?: string
    label?: string
    path?: string
    params?: Record<string, string>
}>(), {
    label: '团体信息'
})
const cancelGroupFun = async (id: string) => {
    Dialog.alert({
        title: '温馨提示',
        message: '您确定解散该返校团体么？',
        confirmButtonText: '确认',
        showCancelButton: true,
        cancelButtonText: '取消',
        confirmButtonColor: 'var(--theme-color)',
    }).then(async () => {
        // on close
        const { code, msg, data } = await cancelGroup({ id })
        if (code == 200) {
            router.push('backSchoolMonth')
        }
        Toast(msg)
    });
}
const cancelOwnselfFun = async (id: string) => {
    Dialog.alert({
        title: '温馨提示',
        message: '您确定取消本次预约么？',
        confirmButtonText: '确认',
        showCancelButton: true,
        cancelButtonText: '取消',
        confirmButtonColor: 'var(--theme-color)',
    }).then(async () => {
        // on close
        const { code, msg, data } = await cancelBook({ id })
        if (code == 200) {
            goBack()
        }
        Toast(msg)
    });
}
const jumpPage = (p?: string) => {
    if (p && props.params) {
        if (p == 'cancel') {
            cancelGroupFun(props.params.id)
        } else if (p == 'personal_cancel') {
            cancelOwnselfFun(props.params.id)
        } else {
            nameHasRouter(router, p, `/${p}`, { id: props?.params?.id, returnActivityId: props?.params?.returnActivityId })
        }
    } else {
        nameHasRouter(router, p as string, `/${p}`)

    }
}
</script>
<style lang="less" scoped>
.exist {
    width: 330px;
    height: 130px;
    background: url('../../../../assets/returnSchoolMonth/logo-bg.png');
    background-repeat: no-repeat;
    background-position: center center;
    background-size: 100% 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 32px;
    margin: 15px 0;

    .label {
        font-family: PingFangSC-Semibold;
        font-size: 34px;
        color: var(--theme-color);
        letter-spacing: 0;
        font-weight: 600;
    }

    img {
        width: 76px;
        height: 76px;
    }
}
</style>