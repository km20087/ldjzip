<template>
  <van-nav-bar :title="tit" left-text="" left-arrow @click-left="onClickLeft" />
  <div class="" v-if="listData.length > 0">
    <van-list
      v-model:loading="loading"
      :finished="finished"
      finished-text="没有更多了"
      @load="onLoad"
      :offset="100"
    >
      <cardList
        @give-card="giveCard"
        @refuse-card="refuseCard"
        :perInfo="listData"
        :cardExchangeStatus="cardExchangeStatus"
        :cardExchangeType="param.cardExchangeType"
        :key="lol"
      ></cardList>
      <!-- -->
    </van-list>
  </div>
  <div v-else class="noData">
    <img :src="noneData" alt="" class="ims" />
    <div class="poTip">暂无数据~</div>
  </div>
</template>
<script lang="ts" setup>
  import { reactive, ref } from 'vue';
  import noneData from '@/assets/img/noneData.png';
  import cardList from '@/components/cardList/index.vue';
  import Api, { mate, cardParam, per } from '@/api/schoolmate';
  import { Toast } from 'vant';
  // const param = <cardParam>ref({});

  const param = ref<cardParam>({
    cardExchangeStatus: '',
    cardExchangeSendType: '',
    cardExchangeType: '',
    pageSize: 10,
    pageNum: 1,
  });
  const cardExchangeStatus = ref('');
  const loading = ref(false);
  const finished = ref(false);
  const isLastPageb = ref(false);
  const listData = ref([] as per[]);
  const router = useRouter();
  const $route = useRoute();
  const tit = ref('');
  const lol = ref(1);
  const exP = ref({
    id: '', //名片交换记录id
    exchangeResult: '', //0-拒绝，1-同意
  });
  const giveCard = async (id: string) => {
    exP.value.id = id;
    exP.value.exchangeResult = '1';
    const { data, code, msg } = await Api.auditSchoolmateCardExchange(exP.value);
    Toast({ message: msg });
    if (code == 200) {
      initData(param.value);
    }
  };
  const refuseCard = async (id: string) => {
    console.log('asd');
    console.log(id);
    exP.value.id = id;
    exP.value.exchangeResult = '0';
    const { data, code, msg } = await Api.auditSchoolmateCardExchange(exP.value);
    Toast({ message: msg });
    if (code == 200) {
      initData(param.value);
    }
  };
  const onClickLeft = () => {
    router.back();
  };
  const onLoad = async () => {
    if (!isLastPageb.value && loading.value) {
      finished.value = false;
      param.value.pageNum = (param.value.pageNum as number) + 1;
      // await init();
      let albumId = $route.query.albumId as string;
      await initData(param.value);
    } else {
      loading.value = false;
      finished.value = true;
    }
  };
  const initData = async (value: any) => {
    loading.value = true;
    const { data, code, msg } = await Api.getSchoolmateCardExchange(value);
    cardExchangeStatus.value = data.cardExchangeStatus || '';
    if (param.value.pageNum == 1) {
      listData.value = [];
    }
    if (code == 200) {
      isLastPageb.value = data.isLastPage;
      loading.value = false;
      listData.value = listData.value.concat(data.list);
    } else {
      Toast({
        message: msg,
        icon: 'none',
      });
    }
    if (isLastPageb.value) {
      loading.value = false;
      finished.value = true;
    }

    lol.value++;
    console.log(listData.value);
  };

  onBeforeMount(() => {
    console.log($route.query.title);
    tit.value = $route.query.title as string;
    if ($route.query.cardExchangeType) {
      param.value.cardExchangeType = $route.query.cardExchangeType as string;
    }
    if ($route.query.cardExchangeSendType) {
      param.value.cardExchangeSendType = $route.query.cardExchangeSendType as string;
    }
    initData(param.value);
  });
</script>

<style lang="less" scoped>
  .noData {
    width: 100%;
    height: 100%;
    text-align: center;
    .ims {
      margin-top: 300px;
      width: 400px;
      height: 270px;
    }
    .poTip {
      font-size: 28px;
      font-family: PingFang-SC-Medium, PingFang-SC;
      font-weight: 500;
      color: #999999;
    }
  }
</style>
