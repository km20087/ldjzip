<template>
  <van-sticky>
    <van-nav-bar title="理事会" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="gray-bg1 contact-cont">
    <div class="contact-man-title">
      {{settingStore.schoolName}}校友会{{ year }}年理事会成员名单
    </div>
    <van-dropdown-menu class="dropdown-menu-wrap" active-color="var(--them-color)">
      <van-dropdown-item v-model="year" :options="yearOptions" @change="handleChangeYear">
      </van-dropdown-item>
    </van-dropdown-menu>

    <div class="list-wrap">
      <template  v-for="(item, index) in councilData" :key="index">
        <div class="list-item" :class="{column: item.position == '8'}" v-if="item.position">
          <span class="txt bold"> {{ item.positionText }}：{{ item.position == '8' ? '(按姓氏笔画排序)': '' }}</span>
          <span class="txt normal"> {{ item.name }}</span>
        </div>
      </template>
    </div>
    
    <div style="width: 1px; height: 50px" />
  </div>
</template>
<script lang="ts" setup>
import { getCouncilRosterByYear } from '@/api/servive/index';
import ApiBase from '@/api/common';
import { Toast } from 'vant';
import { deepClone } from '@/utils';
import { useSettingStore } from '@/store';

const settingStore = useSettingStore();
let councilData = ref<any>([]);
const searchData = ref();
const positionArr = ref<any[]>([]);
const currentYear = new Date().getFullYear()
const yearOptions = Array.from({length: 100}, (_, i) => ({text: `${currentYear - i}年`, value: currentYear - i}))
const year = ref(currentYear)
//获取理事会职位字典
const getpositions = async (param: string) => {
  let { data, code, msg } = await ApiBase.industryList({ dictCode: param });
  if (code == 200) {
    positionArr.value = deepClone(data);
  }
};

function handleChangeYear(val: string) {
  councilData.value = [];
  getMsg(val);
}

const getMsg = async (tenureYear?: string) => {
  let res = await getCouncilRosterByYear({ tenureYear });
  if (res.code == 200) {
    councilData.value = res.data;
    councilData.value = councilData.value.map((element: any, idx: string | number) => {
      for (let i = 0; i < positionArr.value.length; i++) {
        if (positionArr.value[i].dictCode == element.position) {
          element.positionText = positionArr.value[i].dictName;
        }
      }
      return element;
    });
  } else {
    Toast.fail(res.msg);
  }
};

onBeforeMount(async () => {
  await getpositions('COUNCIL_POSITION_ENUM');
  getMsg(String(new Date().getFullYear()));
});
const onClickLeft = () => history.back();
</script>
<style lang="less" scoped>
.gray-bg1 {
  background: #f8f8f8;
  height: 99vh;
  overflow: auto;
}

.contact-cont {
  padding: 0 30px;

  .contact-man-title {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 40px;
    font-weight: 600;
    margin: 50px 0 10px;
    text-align: center;
  }
}

.dropdown-menu-wrap {
  margin-bottom: 24px;
  --van-dropdown-menu-height: 60px;
  --van-dropdown-menu-background-color: transparent;
  --van-dropdown-menu-box-shadow: transparent;
  :deep(.van-dropdown-menu__item){
    margin: 0 20px 0 0;
    justify-content: flex-end;
  }
  
}

.list-wrap{
  .list-item {
    margin: 0 0 24px;
    display: flex;
    flex-direction: row;
    &.column{
      flex-direction: column;
      .normal{
        margin: 10px 0 0;
      }
    }
    .txt{
      display: block;
      letter-spacing: 1px;
      font-size: 30px;
      &.bold{
        flex: 0 0 auto;
        font-weight: bold;
      }
    }
  }
}
</style>