<template>
  <van-sticky>
    <van-nav-bar title="活动报名" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div>
    <van-form @failed="onFailed" @submit="onSubmit" input-align="right" error-message-align="right">
      <van-cell-group inset>
        <div v-for="(item, index) in mustJect" :key="index">
          <van-field
            v-if="item == 'QQ'"
            label="QQ"
            required
            v-model="actForm.qq"
            name="qq"
            placeholder="请输入QQ"
            :rules="[{ required: true, message: '请输入QQ' }]"
          />
          <van-field
            v-if="item == '姓名'"
            label="姓名"
            required
            v-model="actForm.name"
            name="name"
            placeholder="请输入姓名"
            :rules="[{ required: true, message: '请输入姓名' }]"
          />
          <van-field
            v-if="item == '院系' && schoolLevel !=='1'"
            v-model="actForm.collageName"
            readonly
            required
            is-link
            name="collage"
            label="院系"
            placeholder="请选择院系"
            @click="showData('collage')"
            :rules="[{ required: true, message: '请选择院系' }]"
          />
          <!-- majorName -->
          <van-field
            v-if="item == '专业' && schoolLevel !=='1'"
            v-model="actForm.majorName"
            required
            readonly
            is-link
            name="major"
            label="专业"
            placeholder="请选择专业"
            @click="showData('major')"
            :rules="[{ required: true, message: '请选择专业' }]"
          />         
          <van-field
            v-if="item == '班级'"
            v-model="actForm.classes"
            required
            name="classes"
            label="班级"
            placeholder="请输入班级"
            :rules="[{ required: true, message: '请输入班级' }]"
          />
          <van-field
            v-if="item == '入学年级'"
            v-model="actForm.schoolStartYear"
            required
            readonly
            is-link
            @click="startTimeFlag = true"
            name="schoolStartYear"
            label="入学年级"
            placeholder="请选择入学年级"
            :rules="[{ required: true, message: '请选择入学年级' }]"
          />            
          <van-field
            v-if="item == '备注'"
            v-model="actForm.remark"
            required
            name="remark"
            label="备注"
            placeholder="请输入备注"
            :rules="[{ required: true, message: '请输入备注' }]"
          /> 
        <van-field
          v-if="item == '联系方式'"
          label="联系方式"
          v-model="actForm.contact"
          required
          name="contact"
          placeholder="请输入联系方式"
          :rules="[{ required: true, message: '请输入联系方式' }]"
        />
        <van-field
          v-if="item == '联系电话'"
          label="联系电话"
          v-model="actForm.contact"
          required
          name="contact"
          placeholder="请输入联系电话"
          :rules="[{ required: true, message: '请输入联系电话' }]"
        />                     
        </div>
        <!-- 通过 validator 返回错误提示 -->      
      </van-cell-group>
      <van-popup v-model:show="showCalendar2" position="bottom" >
        <van-picker
          :columns="columnData"
          :columns-field-names="{ text: 'deptName' }"
          @cancel="showCalendar2 = false"
          @confirm="onConfirm2"
        />
      </van-popup>       
      <van-popup v-model:show="startTimeFlag" position="bottom">
        <van-picker :columns="timeList" title="请选择年份" show-toolbar :default-index="select" @confirm="yearConfirmStart"
          @cancel="startTimeFlag = false" />
      </van-popup>      
      <div style="margin: 16px">
        <van-button round block type="primary" native-type="submit"> 立即报名 </van-button>
      </div>
    </van-form>
  </div>
</template>
<script lang="ts" setup>
  import { ref } from 'vue';
  import { Toast } from 'vant';
  import ApiMy from '@/api/my';
  import { useRouter } from 'vue-router';
  import activities, { registerAct } from '@/api/servive';
  import ApiDept from '@/api/common';
  import { getSchoolId,getSchoolCode } from '@/utils';
  import { SchoolCode } from '@/constants'
  import {schoolShowConfig} from "@/utils/schoolLevelShow"
  import { formatDate, formatDateTime } from '@/utils/tool/time';
  const $router = useRouter();
  const schoolCode = getSchoolCode()
  const XiangXianFlag = ref(false)
  const onClickLeft = () => history.back();
  const schoolLevel = ref('')
  const timeList = <any>reactive([]);
  const select = ref('');
  const dateValue = ref('');
  const startTimeFlag = ref(false)
  let actForm = ref({
    actId: '',
    classes: '',
    collage: '',
    contact: '',
    name: '',
    qq: '',
    collageName: '',
    schoolStartYear:'',
    majorName:"",
    major:"",
    remark:"",
  });
  const perInfo = ref({
    name: '',
    collegeId: '',
    collegeName: '',
    mobile: '',
    schoolName: '',
    classes: '',
    classesName: '',
    userProfilePicture: '',
    majorName:"",
    major:"",
    schoolStartYear:'',
  });
  const typeDialog = ref('')
  // let mustJect = ref<string[]>(['QQ', '姓名', '院系', '班级']);
  let mustJect = ref<string[]>([]);
  let columnData = ref([]);
  watch(
    () => $router.currentRoute.value.query,
    (newVal) => {
      if (newVal) {
        actForm.value.actId = newVal.id as unknown as string;
        if(!!newVal.requiredInformation){
          (newVal.requiredInformation as unknown as string).split(';').map((e: string) => {
            mustJect.value.push(e);
          });   
          (newVal.requiredInformation as unknown as string).split(',').map((e: string) => {
            mustJect.value.push(e);
          });                       
        }      
        console.log("mustJect",mustJect.value)
      }
    },
    { immediate: true, deep: true }
  );
  const getCurrentYear = () => {
  var nowTime = new Date();
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  let dateValue1 = '';
  dateValue1 = formatDate(new Date(year, month, day));
  dateValue.value = String(dateValue1.slice(0, 4));
  // this.signs(this.dateValue)
};
  const getYearData = () => {
  var nowTime = new Date(dateValue.value);
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  for (let i: number = 1900; i < 2035; i++) {
    timeList.push(i);
  }

  let years = formatDate(new Date(year, month, day));
  let Year = years.slice(0, 4);

  select.value = timeList.indexOf(Number(Year));
  console.log(select.value);
};


const yearConfirmStart = (value: string) => {
  actForm.value.schoolStartYear = value.toString();
  startTimeFlag.value = false;
};


  const initData =async (type:string)=>{
    let schoolId = getSchoolId() as string;
    columnData.value = []
    if(type =='collage'){
      const { data, msg, code } = await ApiDept.deptList({
        schoolId: schoolId,
      });
      
      columnData.value = data.map((e: any) => {
        return { deptId: e.deptId, deptName: e.deptName };
      });
    }else{
      const { data, msg, code } = await ApiDept.deptList({
        schoolId: schoolId,
        parentId:actForm.value.collage,
      });
      columnData.value = data.map((e: any) => {
        return { deptId: e.deptId, deptName: e.deptName };
      });
    }

  }

  const showData = (val:string) =>{
    console.log(val)
    typeDialog.value = val
    if(val == 'collage'){
      actForm.value.majorName = ''
      actForm.value.major = ''
    }    
    initData(val)
    showCalendar2.value = true
  }

  const initMy = async () => {
    const { data, msg, code } = await ApiMy.getDetailedInformation({});
    Object.assign(perInfo.value, data);
    actForm.value.collage = perInfo.value.collegeId;
    actForm.value.collageName = perInfo.value.collegeName;
    actForm.value.major = perInfo.value.major;
    actForm.value.majorName = perInfo.value.majorName;    
    actForm.value.name = perInfo.value.name;
    actForm.value.classes = perInfo.value.classesName;
    actForm.value.contact = perInfo.value.mobile;
    actForm.value.schoolStartYear = perInfo.value.schoolStartYear;
  };
  const onFailed = (errorInfo: any) => {
    console.log('failed', errorInfo);
  };
  const showCalendar2 = ref(false);
  const onConfirm2 = (value: any) => {
    if(typeDialog.value == 'collage'){
      actForm.value.collageName = value.deptName;
      actForm.value.collage = value.deptId;
    }else{
      actForm.value.majorName = value.deptName;
      actForm.value.major = value.deptId;
    }

    showCalendar2.value = false;
  };
  const onSubmit = async (val: FormData) => {
    const { code, data, msg } = await registerAct(actForm.value);
    if (code == 200) {
      Toast.success(msg);
      $router.push({ name: 'activeList' });
    } else {
      Toast.fail(msg);
    }
  };
  onMounted(async () => {
    // XiangXianFlag.value = schoolCode == SchoolCode.XiangXianZhongXue
    schoolLevel.value =  schoolShowConfig() as string
    initData('collage')
    initMy();
    getCurrentYear();
    getYearData();
  });  
</script>
<style lang="less" scoped>
  .upload-text {
    font-size: 28px;
    color: #004dff;
  }
  // :deep(.van-overlay){
  //   background: #3333331a;
  // }
</style>
