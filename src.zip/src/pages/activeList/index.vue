<template>
  <van-sticky>
    <van-nav-bar title="活动列表" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <van-tabs v-model:active="active" swipeable line-width="15px" @click-tab="clickTabs">
    <van-tab title="报名中">
      <templateVue tabindex="2" />
    </van-tab>
    <van-tab title="进行中">
      <templateVue tabindex="1" />
    </van-tab>
    <van-tab title="已结束">
      <templateVue tabindex="4" />
    </van-tab>
  </van-tabs>
</template>
<script lang="ts" setup>
  import { reactive, ref } from 'vue';
  import templateVue from './components/template.vue';

  const active = ref(0);
  const $router = useRouter();
  const onClickLeft = () => $router.back();
  const clickTabs = (value: any) => {
    console.log(value);
  };
</script>
