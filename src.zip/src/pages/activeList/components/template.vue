<template>
  <div class="boas">
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model:loading="loading"
        :finished="finished"
        finished-text="没有更多了"
        v-model:error="error"
        error-text="请求失败，点击重新加载"
        @load="onLoad"
      >
        <subVue
          v-for="(item, index) in actList"
          :key="index"
          :tabindex="tabindex"
          :url="item.eventPoster"
          :introduction="item.theme"
          :theme="item.theme"
          :organizer="item.organizer"
          :currentNumberOfParticipants="item.currentNumberOfParticipants"
          :registrationFlag="item.registrationFlag"
          :startTime="item.startTime"
          :endTime="item.endTime"
          :registrationDeadline="item.registrationDeadline"
          @jump-act="jumpAct(item)"
        />
        <!--         :theme="item.theme" -->
      </van-list>
    </van-pull-refresh>
    <van-sticky :offset-bottom="50" position="bottom" v-if="showB">
      <van-button type="primary" round block @click="toBuild">创建活动</van-button>
    </van-sticky>
  </div>
</template>
<script lang="ts" setup>
import subVue from "./subComponents/sub.vue";
import { reactive, ref } from "vue";
import Api, { listParams } from "@/api/servive/index";
import { useGoIdentifyPage } from '@/pages/home/useGoIdentifyPage'
import { useSettingStore } from '@/store';
import { Toast } from "vant";
import { getButtons, getUserStatus } from "@/utils";
const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
const props = defineProps({
  tabindex: String
});
const $router = useRouter();
const loading = ref(false);
const finished = ref(false);
const error = ref(false);
const refreshing = ref(false);
const showB = ref(true);
let actList = <any>reactive([]);
const listP = <listParams>{
  pageNum: 1,
  pageSize: 99,
  status: "1"
};
const settingStore = useSettingStore();
const { goIdentifyPage,getIdentifyPath } = useGoIdentifyPage()


const onLoad = async () => {
  listP.status = (props.tabindex as unknown) as string;
  // 异步更新数据
  let { code, data, msg } = await Api.getActiveList(listP);
  if (code == 200) {
    actList = actList.concat(data.list);
    listP.pageNum++;
    loading.value = false;
    if (actList.length >= data.total) {
      finished.value = true;
    }
  } else {
    Toast.fail(msg);
    finished.value = true;
    loading.value = false;
  }
  refreshing.value = false;
};
const onRefresh = () => {
  // 清空列表数据
  finished.value = false;

  // 重新加载数据
  // 将 loading 设置为 true，表示处于加载状态
  loading.value = true;
  listP.pageNum = 1;
  actList = [];
  onLoad();
};
const toBuild = () => {
  $router.push({ name: "buildAct" });
};
const jumpAct = (item: any) => {
  let userStatus = getUserStatus()
  console.log(item)
  // return
  if(userStatus == '00' || userStatus == '06' || settingStore.isManagerMode){
    // $router.push({ name: "joinAct", query: {id:item.id,requiredInformation:item.requiredInformation} });
    $router.push({ path: "/activeDetail", query: { id: item.id } });
  }else{
    goIdentifyPage().then((res)=>{
      if(res)$router.push({path:getIdentifyPath()})
    })
  }  
  // $router.push({ name: "joinAct", query: item });
};
onMounted(() => {
  // ruleGet11();
});
</script>
<style lang="less" scoped>
.boas {
  width: 100%;
  min-height: 100%;
  // overflow-y: scroll;
  padding: 0 30px;
}
</style>
