<template>
  <van-cell @click="joinAct">
    <div class="cell">
      <div class="con">
        <div class="logo">
          <span class="act-tag" v-if="tabindex == '2'"> 报名中 </span>
          <span class="act-tag ing" v-else-if="tabindex == '1'"> 进行中 </span>
          <span class="act-tag waiting" v-else-if="tabindex == '3'"> 未开始 </span>
          <span class="act-tag end" v-else> 已结束 </span>
          <img :src="url" alt="" class="ims" />
        </div>
        <div class="actDetail">
          <div class="actName">{{ theme }}</div>
          <!-- theme introduction-->
          <div class="isoa tit">发起组织：{{ organizer }}</div>
          <!-- <div class="isoa">活动类型：{{ theme }}</div> -->
          <div class="isoa">已报名人数：{{ currentNumberOfParticipants }}</div>
        </div>
        <div
          class="join green"
          v-if="registrationFlag === '1'"
        >
          <p class="pos">已报名</p>
        </div>
        <div class="unuse" v-else></div>
      </div>
      <div class="time">
        <p>活动时间:{{ startTime }}至{{ endTime }}</p>
        <p>报名截止时间:{{ registrationDeadline }}</p>
      </div>
    </div>
  </van-cell>
</template>
<script lang="ts" setup>
const $router = useRouter();
defineProps({
  tabindex: String,
  url: String,
  introduction: String,
  organizer: String,
  theme: String,
  currentNumberOfParticipants: Number,
  registrationFlag: String,
  startTime: String,
  endTime: String,
  registrationDeadline: String
});
const emit = defineEmits(["jumpAct"]);
const joinAct = () => {
  emit("jumpAct");
};
</script>
<style lang="less" scoped>
.cell {
  width: 100%;
  .con {
    font-size: 0px;
    display: flex;
    justify-content: space-around;
    .logo {
      width: 20%;
      height: 180px;
      border-radius: 16px;
      overflow: hidden;
      position: relative;
      .act-tag {
        display: inline-block;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        line-height: 46px;
        font-size: 24px;
        color: #fff;
        text-align: center;
        background: #fe6f5d8f;
      }
      .ing {
        background: #21ca0e97;
      }
      .end {
        background: #888b948d;
        color: #fff;
      }
      .waiting {
        background: #e6a23c;
        // color: #fff;
      }
      .ims {
        width: 100%;
        height: 180px;
      }
    }
    .actDetail {
      margin-left: 20px;
      width: 55%;
      height: 180px;
      .actName {
        font-size: 32px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #333333;
        width: 300px;
        overflow: hidden;
        word-break: break-all;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
      .isoa {
        font-size: 24px;
        font-family: PingFang-SC-Regular, PingFang-SC;
        font-weight: 400;
        color: #666666;
      }
      .tit {
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
      }
    }
    //占位元素
    .unuse {
      width: 20%;
    }
    .join {
      width: 20%;
      height: 60px;
      background: #d2e9fc;
      border-radius: 35px;
      text-align: center;
      color: #1e93ef;
      .pos {
        font-size: 32px;
        margin: 0px;
        line-height: 60px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
      }
    }
    .green {
      background: #d8f5eb;
      color: #3ccf9c;
    }
  }
  .time {
    margin-top: 10px;
    box-sizing: border-box;
    padding-top: 20px;
    padding-left: 20px;
    background: #f8f8f8;
    p {
      font-size: 24px;
      margin: 0;
      font-family: PingFang-SC-Regular, PingFang-SC;
      font-weight: 400;
      color: #666666;
    }
  }
}
</style>
