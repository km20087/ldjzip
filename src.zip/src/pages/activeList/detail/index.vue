<template>
  <van-sticky>
    <van-nav-bar title="活动详情" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="detail-page">
    <!-- 封面 -->
    <div class="cover-wrap">
      <img
        :src="detailInfo.eventPoster"
        alt=""
        class="cover"
        @click="onPreview([detailInfo.eventPoster])"
      />
      <div class="status-tag" v-if="detailInfo.status === '2'">报名中</div>
      <div class="status-tag ing" v-else-if="detailInfo.status === '1'">进行中</div>
      <div class="status-tag end" v-else-if="detailInfo.status === '4'">已结束</div>
    </div>

    <!-- 活动信息 -->
    <div class="info-section">
      <div class="act-title">{{ detailInfo.theme }}</div>
      <div class="organizer">发起组织：{{ detailInfo.organizer }}</div>

      <van-cell-group class="info-group" :border="false">
        <van-cell
          title="活动时间"
          :value="formatTimeRange(detailInfo.startTime, detailInfo.endTime)"
        />
        <van-cell title="报名截止时间" :value="detailInfo.registrationDeadline" />
        <van-cell title="已报名人数" :value="detailInfo.currentNumberOfParticipants || '0'" />
      </van-cell-group>
    </div>

    <!-- 活动介绍 -->
    <div class="intro-section">
      <div class="section-title">活动介绍</div>
      <div class="intro-content">{{ detailInfo.introduction || '暂无介绍' }}</div>
    </div>

    <!-- 底部操作按钮 -->
    <div class="bottom-bar" v-if="detailInfo.status == '2' && detailInfo.registrationFlag === '0'">
      <theme-button round block type="primary" @click="handleRegister"> 立即报名 </theme-button>
    </div>
    <div
      class="bottom-bar"
      v-if="
        detailInfo.registrationFlag === '1' && new Date(detailInfo.startTime).getTime() > Date.now()
      "
    >
      <theme-button class="cancel" round block @click="handleUnRegister">取消报名 </theme-button>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import { reactive, ref } from 'vue'
  import { Toast, Dialog, ImagePreview } from 'vant'
  import Api from '@/api/servive/index'
  import { registerAct, unRegisterAct } from '@/api/servive/index'

  const $router = useRouter()
  const $route = useRoute()
  const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL)
  const detailInfo = ref<any>({})

  const onClickLeft = () => history.back()

  const onPreview = (images: string[]) => {
    ImagePreview({ images })
  }

  const formatTimeRange = (start: string, end: string) => {
    if (!start && !end) return ''
    return (start || '') + ' 至 ' + (end || '')
  }

  const getDetail = async () => {
    const id = $route.query.id as string
    if (!id) return
    try {
      const { code, data, msg } = await Api.detailActivities({ id })
      if (code == 200) {
        detailInfo.value = data
        console.log('getDetail',detailInfo.value)
      } else {
        Toast.fail(msg)
      }
    } catch (err) {
      console.error(err)
    }
  }

  const handleRegister = () => {
    $router.push({
      name: 'joinAct',
      query: {
        id: $route.query.id,
        requiredInformation: detailInfo.value.requiredInformation,
      },
    })
  }

  const handleUnRegister = async () => {
    try {
      await Dialog.confirm({ message: '确定要取消报名吗？' })
    } catch {
      return
    }
    Toast.loading({ message: '处理中...', forbidClick: true })
    try {
      const { code, msg } = await unRegisterAct({ actId: $route.query.id as string })
      if (code == 200) {
        Toast.success('已取消')
        detailInfo.value.registrationFlag = '0'
        detailInfo.value.currentNumberOfParticipants--
      } else {
        Toast.fail(msg)
      }
    } catch (err) {
      Toast.fail('操作失败')
    }
  }

  onMounted(() => {
    getDetail()
  })
</script>

<style lang="less" scoped>
  .detail-page {
    width: 100%;
    min-height: 100vh;
    background: #f5f5f5;
    padding-bottom: 150px;

    .cover-wrap {
      width: 100%;
      height: 420px;
      position: relative;
      overflow: hidden;

      .cover {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .status-tag {
        position: absolute;
        top: 20px;
        right: 20px;
        padding: 8px 24px;
        background: #fe6f5d;
        color: #fff;
        font-size: 24px;
        border-radius: 30px;
        line-height: 1;
      }

      .ing {
        background: #21ca0e;
      }

      .end {
        background: #888b94;
      }
    }

    .info-section {
      background: #fff;
      padding: 30px;
      margin-bottom: 20px;

      .act-title {
        font-size: 40px;
        font-weight: 600;
        color: #333;
        line-height: 56px;
        margin-bottom: 12px;
      }

      .organizer {
        font-size: 26px;
        color: #999;
        margin-bottom: 20px;
      }

      .info-group {
        :deep(.van-cell) {
          padding: 20px 0;
          font-size: 28px;

          .van-cell__title {
            color: #666;
          }

          .van-cell__value {
            color: #333;
          }
        }
      }
    }

    .intro-section {
      background: #fff;
      padding: 30px;
      margin-bottom: 20px;

      .intro-content {
        font-size: 28px;
        color: #333;
        line-height: 48px;
      }
    }
  }

  .bottom-bar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 16px 30px;
    padding-bottom: calc(16px + env(safe-area-inset-bottom));
    background: #fff;
    box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.06);
    z-index: 10;
    .cancel {
      background: #f2f2f2;
      color: var(--theme-color);
      border: 1px solid var(--theme-color);
    }
  }

  .section-title {
    font-size: 32px;
    font-weight: 600;
    color: #333;
    padding-bottom: 16px;
    position: relative;

    &::after {
      content: '';
      position: absolute;
      left: 0;
      bottom: 0;
      width: 120px;
      height: 4px;
      background: var(--theme-color);
      border-radius: 2px;
    }
  }
</style>
