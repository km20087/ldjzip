<template>
  <div v-html="detail" class="xieyi-cont" />
  <!-- <div class="backButton">
    <van-button type="primary" class="psoad" round block @click="toBack">确 认</van-button>
  </div> -->
</template>
<script lang="ts" setup>
  import { watchEffect } from 'vue';
  import { useProtocol } from '@/hooks/useProtocol';
  import { useRoute } from 'vue-router';
  import { Toast } from 'vant';

  const { getDetailData, detail } = useProtocol();

  const route = useRoute();
  const router = useRouter();
  const toBack = () =>{
    router.back()
  }
  watchEffect(async () => {
    const toast = Toast.loading({
      message: '加载中...',
      forbidClick: true,
      duration: 0,
    });
    await getDetailData(route.query?.niId as string);
    toast.clear();
  });
</script>
<style lang="less" scoped>
  .xieyi-cont {
    padding: 20px;
    // padding-bottom: 120px;
  }
  .psoad{
    position: fixed;
    bottom: 20px;
  }
</style>
