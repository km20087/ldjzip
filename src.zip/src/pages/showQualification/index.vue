<template>
<div>
  <van-sticky>
    <nav-bar :title="tit" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class='main'>      
    <div class='eduList' v-for="(item,index) in educationInfoList" :key="index">
      <div :class="item.showFlag?'eduTitle':'eduTitle eduConDisplay'" @click='switchShowFlag(item,index)'>
        <div class='leftPart' v-if="editEducationFlag">
          <span class="tit1"></span>
          <span v-if="item.educationType == 1">第一学历：{{item.education}}</span> 
          <span v-else-if="item.educationType == 2">第二学历：{{item.education}}</span> 
          <span v-else-if="item.educationType == 3">第三学历：{{item.education}}</span> 
        </div>
        <div class="leftPart" v-else>
          <span class="tit1"></span>
          <span v-if="item.educationType == 1">第一学历：{{showEduName(item.education)}}</span> 
          <span v-else-if="item.educationType == 2">第二学历：{{showEduName(item.education)}}</span> 
          <span v-else-if="item.educationType == 3">第三学历：{{showEduName(item.education)}}</span> 
        </div>
        <van-icon name="arrow-down" v-if="item.showFlag">

        </van-icon>
        <van-icon name="arrow-up" v-else>

        </van-icon>        
      </div>
      <!-- :class="item.showFlag?'eduTitle':'eduTitle eduConDisplay'" -->
      <div class="eduCon" v-show="item.showFlag">
        <van-field
          v-model="item.academicType"
          
          readonly
          name="picker"
          label="学历性质"
          input-align="right"
          placeholder="请选择学历"
          v-if="editEducationFlag"
        >
        </van-field>
        <van-field
          v-model="item.schoolingPeriod"
          
          readonly
          name="picker"
          label="学制"
          input-align="right"
          placeholder=""
          v-if="editEducationFlag"
        >     
        </van-field>      
        <van-field
          v-model="item.collegeName"
          
          readonly
          name="picker"
          label="学院"
          input-align="right"
          placeholder=""
          
        />
        <van-field
          v-model="item.schoolStartYear"
          
          readonly
          name="picker"
          label="年级"
          input-align="right"
          placeholder=""
          
        />      
        <van-field
          v-model="item.majorName"
          readonly
          name="picker"
          label="专业"
          input-align="right"
          placeholder=""
          
        />       
        <van-field
          v-model="item.classesName"
          readonly
          name="picker"
          label="班级"
          input-align="right"
          v-if="editEducationFlag"
          placeholder=""
          
        />                      
        <van-button class="editButton" @click="editEducation(index,item.educationType)">
          <!--  v-if="editEducationFlag" -->
          <SvgXueJiIcon  class='imsIcon' />          
          <div class='editText'>修改学历信息</div>
        </van-button>
      </div>
    </div>
  </div>
</div>
</template>
<script lang="ts" setup>
import { Dialog, Toast } from "vant";
import { useRouter, useRoute } from "vue-router";
import { ref, reactive } from "vue";
import { useDept } from "./useDept";
import SvgXueJiIcon from '@/assets/icons/xuejiIcon.svg';
// import SvgAgree from '@/assets/icons/agree.svg';
// import ApiMy from "@/api/my";
import { fetchBaseInfo } from "@/api/my";
import Api from "@/api/user/index";
import { getSchoolCode, setLocalStorageItem } from "@/utils";
import {schoolEducationMode} from '@/constants' 
// getDetailedInformation
// import Api from '@/api/user/index';

const router = useRouter(); //editQualification
const { getDept } = useDept();

const tit = ref("学历修改");
const onClickLeft = () => {
  router.back();
};
const column = ref([]);
const typeMoadl = ref("");
const pickerFlag = ref(false);
const pickerValue = ref([]);

const xueyuanList = ref([]);
const eduList = ref([
  { text: '小学', value: '0' },
  { text: '初中', value: '1' },
  { text: '高中', value: '2' },
  { text: '专科', value: '3' },
  { text: '本科', value: '4' },
  { text: '硕士研究生', value: '5' },
  { text: '博士研究生', value: '6' },
]);
const description = ref("");
const proofFile = ref("");
const healthFileList = ref([]);

const editEducationFlag = ref(false)

const formData = ref({
  xueyuan: ""
});

const newMode = ref([
  '4121010165',//辽师
  // '4151013705',//成都医学院
  // '4121010166'//沈阳师范
])


const educationInfoList = ref([] as any);

const switchShowFlag = (item:any,index:number) =>{
  // for(let i in educationInfoList.value){
  //   educationInfoList.value[i].showFlag = false
  // }
  educationInfoList.value[index].showFlag = !educationInfoList.value[index].showFlag
}

const editEducation = (index:number,educationType:string) =>{
  console.log(index)
  // return
  router.push({path:"/editQualification",query:{index,educationType}})
  // sessionStorage.setItem("eduData",JSON.stringify(item))  
}

const showEduName = (val:string) => {
  for(let i in eduList.value){
    if(val == eduList.value[i].value){
      return eduList.value[i].text
    }
  }
}

const initPerinfo = async () => {
  try {
    let res = await fetchBaseInfo({});
    console.log(res,"***");
    if (res.code == 200 ) {
      if(!!res.data.educationInfoList && res.data.educationInfoList.length > 0){
        setLocalStorageItem('Cache__BaseInfo', JSON.stringify(res));
        educationInfoList.value = res.data.educationInfoList;
        for(let i in educationInfoList.value){
          educationInfoList.value[i].showFlag = false
        }
        educationInfoList.value[0].showFlag = true        
      }else{
        addItemByArr(res) 
      }
    }
  } catch (err) {}
};

const addItemByArr =(res:any) =>{
      educationInfoList.value.push({
        education:res.data.education || '',
        collegeId:res.data.collegeId || '',
        collegeName:res.data.collegeName || '',
        major:res.data.major || '',
        majorName:res.data.majorName || '',
        startYear:res.data.startYear || '',
        schoolStartYear:res.data.schoolStartYear || '',
        diplomaFile:res.data.diplomaFile || '',
        applyReason:'',
        educationType:'1',
        showFlag:true,
      })
      // let item = {
      //   education:"",
      //   collegeId:"",
      //   collegeName:"",
      //   major:"",
      //   majorName:"",
      //   startYear:"",
      //   diplomaFile:"",
      //   applyReason:"",   
      //   educationType:"2",
      //   showFlag:false,               
      // }
      // educationInfoList.value.push({...item})
      // item.educationType = '3'
      // educationInfoList.value.push({...item})
      // console.log('addItemByArr--educationInfoList',educationInfoList.value)
} 

onMounted(() => {
  initPerinfo();
  let schoolCode = getSchoolCode();
    if(schoolEducationMode.includes(schoolCode!)){//学历修改按钮暂时是辽师专用
      editEducationFlag.value = true
    }else{
      editEducationFlag.value = false
    }  
  // initXueyuan();
  // xueyuanList.value =  getDept()
});
</script>
<style lang="less" scoped>
.main {
  width: 100%;
  min-height: 100vh;
  background-color: #f5f5f5;
  padding: 0 24px;
  box-sizing: border-box;
  padding-top: 6px;
  padding-bottom: 24px;
  .eduList {
    width: 100%;
    margin-top: 24px;
    border-radius: 24px;
    // margin-top: 24px;
    // padding-top: 32px;
    background-color: #ffffff;
    // height: 100%;
    // min-height: 100vh;
    // background-color: #f5f5f5;
    // padding: 0 24px;
    // box-sizing: border-box;
  }
  .eduTitle {
    padding: 32px 40px;
    // margin-top: 32px;
    // height: 45px;

    // padding-left: 40px;
    // padding-right: 40px;
    color: #222222;
    font-size: 36px;
    background-color: #ffffff;
    font-weight: 600;
    font-style: normal;
    font-family: PingFangSC PingFang SC;
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .leftPart {
      background-color: #ffffff;
      display: flex;
      align-items: center;
    }
    .tit1 {
      width: 5px;
      height: 36px;
      background-color: #b42d3b;
      margin-right: 19px;
    }
    // margin: 24px 0;
  }
  .wrap {
    background: #f5f5f5;
    padding: 34px 30px;
    min-height: 100vh;

    .title {
      padding-left: 20px;
      margin: 0 0 33px;
      font-family: PingFangSC-Medium;
      font-size: 32px;
      color: #333333;
      letter-spacing: 0;
      line-height: 32px;
      font-weight: 500;
      border-left: 5px solid var(--theme-color);
    }

    .poosa {
      border-radius: 16px;
      margin-bottom: 40px;
      // height: 300px;
    }

    .submit-btn {
      margin: 50px 0;
    }
    :deep(.van-field__control--custom) {
      display: flex;
      flex-direction: column;
      align-items: normal;
      min-height: var(--van-cell-line-height);

      .upload-tit {
        font-size: 24px;
        line-height: 40px;

        .red {
          color: #ff0000;
        }
      }

      .tips {
        font-size: 24px;
        color: #999999;
        line-height: 40px;
      }

      .van-uploader {
        margin: 24px 0;
      }
    }
  }
}
.eduCon {
  padding-bottom: 44px;
}
.eduConDisplay {
  // display: none;
  border-radius: 24px;
  // margin-top: 24px;
  padding-bottom: 24px;
  // background-color: #ffffff;
}
.editButton {
  width: 100%;
  display: flex;
  align-items: center;
  // justify-content: center;
  padding: 0 24px;
  border: 0px;
  margin-top: 83px;

  box-sizing: border-box;
  :deep(.van-button__content) {
    width: 100%;
    background-color: var(--theme-color);
    border: 2px solid var(--theme-color);
    font-size: 36px;
    border-radius: 44px;
    color: #ffffff;
  }
  :deep(.van-button__text){
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .imsIcon{
    // width: 32px;
    // height: 32px;
    // color: #ffffff;
    // background-color: #ffffff;
  :deep(path){
    fill:#ffffff;
  }
  }
  .editText{
    margin-left: 10px;
    font-weight: 500;
  }
}
</style>
