<template>
  <div class="con">
    <van-sticky>
      <van-nav-bar title="反馈与建议" left-text="" left-arrow @click-left="onClickLeft" />
    </van-sticky>
    <!-- <van-nav-bar title="反馈与建议" left-text="" left-arrow @click-left="onClickLeft" /> -->
    <div class="form">
      <van-form
        @failed="onFailed"
        input-align="right"
        @submit="onSubmit"
        error-message-align="right"
        label-width='100'
        class='asda'
      >
        <van-field name='feedbackType' label='选择反馈类型' class='oip' required :rules="[{ required: true, message: '请选择反馈类型' }]">
          <!-- required -->
          <template #input>
            <van-checkbox-group v-model='formData.feedbackType' :max='1'  direction="horizontal">
              <van-checkbox  v-for="(item,index) in feedTypeList" :key='index' :name="item.value" @click='()=>getCli(item.value)'>
                {{item.name}}
              </van-checkbox>
            </van-checkbox-group>
          </template>
        </van-field>
        <van-field name='detailText' 
          class='oip'
          required
          label='详细意见' 
          v-model="formData.detailText" 
          type='textarea'
          placeholder="请输入详细意见" 
          rows="3"
          maxlength="150"
          show-word-limit
          :rules="[{ required: true, message: '请填写意见' }]"
          />
          <!-- required -->
          <van-field
          v-model="formData.detailPhoto"
          readonly
          name="detailPhoto"
          label="图片"
          input-align="left"
          error-message-align="left"
          >
          <template #input>
            <compress-uploader v-model="fileList" max-count="1" :after-read="afterRead" />
          </template>
        </van-field>
        <div class='connect'>联系方式(至少填写一项)</div>
        <van-field
          label="手机号"
          v-model="formData.phone"
          name="phone"
          placeholder="请输入手机号"
        />
        <van-field
          label="qq/微信"
          v-model="formData.qqWechat"
          name="qqWechat"
          placeholder="请输入qq/微信"
        />
        <van-field
          label="邮箱"
          v-model="formData.email"
          name="email"
          placeholder="请输入邮箱"
        />
        <div class='warnTips' v-if='tipShow'><p class='ioi'>以上三种联系方式中至少填写一项</p></div>
      <div style="margin: 16px">
        <van-button round block type="primary" native-type="submit" @click='showTips'> 提交 </van-button>
      </div>  
      </van-form>
    </div>

  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from "vue";
import Api from "@/api/uploadfile";
import ApiSer from "@/api/appService";
import FileHandle from "@/utils/file-handle";
import { Toast } from "vant";
import { getSchoolId } from "@/utils";
// import {RadioGroup,Radio} from 'vant';

const router = useRouter();
let fileList = ref<File[] | any>([]);
const tipShow = ref(false);
let fileHandle = new FileHandle(["detailPhoto"]);
const formData = <any>ref({
  email: "",
  detailPhoto: "",
  detailText: "",
  feedbackType: "01",
  phone: "",
  qqWechat: "",
  schoolId: ""
});
const asdo = ref("01");
const feedTypeList = ref([
  {
    value: "01",
    name: "账号相关"
  },
  {
    value: "02",
    name: "组织相关"
  },
  {
    value: "03",
    name: "捐赠相关"
  },
  {
    value: "04",
    name: "侵权相关"
  },
  {
    value: "05",
    name: "其他功能建议"
  }
]);
const afterRead: any = async (file: any) => {
  let formData1 = new FormData();

  formData1.append("file", file.file);
  // formData.append('flag', 'Y');//加密上传
  file.status = "uploading";
  file.message = "上传中...";
  await Api.uploadFile(formData1)
    .then(res => {
      if (res.code == 200) {
        file.status = "";
        file.message = "";
        console.log(res.data);
        nextTick(() => {
          if (
            res.data.tokenUrl &&
            res.data.tokenUrl == "" &&
            res.data.tokenUrl == undefined &&
            res.data.tokenUrl == null
          ) {
            formData.value.detailPhoto = res.data.tokenUrl as string;
          } else {
            formData.value.detailPhoto = res.data.uploadUrl as string;
          }
        });

        Toast.success("上传成功");
      } else {
        file.status = "failed";
        file.message = "上传失败";
        Toast.fail(res.msg);
      }
    })
    .catch(err => {
      file.status = "failed";
      file.message = "上传失败";
      Toast.fail(`上传失败：${err}`);
    });
};
const getCli = (val: any) => {
  console.log(val);
  formData.value.feedbackType = val;
  console.log(formData.value);
};
const onClickLeft = () => {
  // router.push({ path: '/tab/organization' });
  router.go(-1);
};
const showTips = async () => {
  if (formData.value.email || formData.value.phone || formData.value.qqWechat) {
    tipShow.value = false;
  } else {
    tipShow.value = true;
  }
};
const onSubmit = async () => {
  //tipShow
  formData.value.schoolId = getSchoolId() as string;
  const { data, code, msg } = await ApiSer.feedbackAndSuggestions(
    formData.value
  );
  if(code == 200){
    Toast.success(msg);
     router.go(-1);
  }
};
const onFailed = (errorInfo: any) => {
  console.log("failed", errorInfo);
};
watch(
  formData.value,
  (newVal:any, oldVal:any) => {
    // [formData.value.email,formData.value.qqWechat,formData.value.phone]
    console.log(newVal);
    if (newVal.email || newVal.phone || newVal.qqWechat) {
      tipShow.value = false;
    } else {
      // tipShow.value = true;
    }
  },
  { deep: true, immediate: true }
);
onMounted(() => {});
</script>
<style lang='less' scoped>
.con {
  width: 100%;
  height: 100%;
  .asda {
    .oip {
      // display:block;
      flex-direction: column;
      .van-checkbox-group {
      }
    }
  }
  .connect {
    padding: 0px 34px;
  }
  .connect::before {
    content: "*";
    color: red;
    margin-right: 3px;
  }
}
/deep/.van-checkbox--horizontal {
  margin-bottom: 15px;
}
.warnTips {
  width: 100%;
  height: 100%;
  text-align: center;
  .ioi {
    color: #ee0a24;
    font-size: 24px;
  }
}
</style>