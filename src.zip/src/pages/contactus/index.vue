<template>
  <van-sticky>
    <van-nav-bar :title="title" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="gray-bg1 contact-cont">
    <van-search show-action v-model="userName" placeholder="请输入搜索关键词">
      <template #action>
        <div @click="goSearchPage" class="iasd">搜索</div>
      </template>
    </van-search>
    <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="getListData" :immediate-check="false">
      <div v-for="(item, index) in destArr" :key="index">
        <div class="contact-man-title">
          <img src="@/assets/img/contact-icon.png" width="30" height="18" alt="" />
          <span>{{ item.deptName }}</span>
          <img src="@/assets/img/contact-icon.png" width="30" height="18" class="rotate-img" alt="" />
        </div>
        <div class="contact-man-list" v-for="(sub, sidx) in item.data" :key="sidx">
          <div class="contact-man">
            <div class="contact-man-left">
              <span class="name">{{ sub.userName }}</span>
              <div class="left-list" v-if='sub.position'>
                <img src="@/assets/img/zhiwei-icon@2x.png" width="12" height="12" alt="" />
                <span>职位：<span class="left-list-text">{{ sub.position }}</span></span>
              </div>
              <div class="left-list" v-if='sub[connect] && !isLiaoShiDa()'>
                <img src="@/assets/img/contact-phone@2x.png" width="12" height="12" alt="" />
                <span>联系电话：<span class="left-list-text">{{ sub[connect] }}</span></span>
              </div>
              <div class="left-list" v-if='sub.email'>
                <img src="@/assets/img/contact-email@2x.png" width="12" height="12" alt="" />
                <span>{{ schoolCode == SchoolCode.ShanDa ? '办公邮箱' : 'E-mail' }}：<span class="left-list-text">{{ sub.email }}</span></span>
              </div>
              <div class="left-list" v-if='sub.officeAddress'>
                <img src="@/assets/img/contact-addr@2x.png" width="12" height="12" alt="" />
                <div style="display: flex">{{ addressName }}：<span class="left-list-text">{{ sub.officeAddress }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </van-list>
    <div style='width: 1px; height: 50px;' />
  </div>
</template>
<script lang="ts" setup>
import { contactUs } from "@/api/servive/index";
import { schoolConfig, config } from "@/hooks/schoolConfig";
import { Toast } from "vant";
import { isLiaoShiDa } from '@/utils/customizedType';
import { getSchoolCode } from "@/utils";
import { ConcatUsMode, ConcatUsDataFromUserManageSchoolList, SchoolCode } from "@/constants";

interface IDest {
  deptLevel: string
  deptName: string
  data: Array<any>
}

let contactData = ref<any>([]);
let map: Record<string, number> = {};
let destArr = ref<IDest[]>([]);

const loading = ref(false);
const finished = ref(false);
const title = ref("");
const addressName = ref("");
const connect = ref("");
let schoolCode = getSchoolCode()!
const currentPage = ref(0);
const userName = ref("");
const goSearchPage = async () => {
  initSearch()
  getListData()
};

/**
 * 重置搜索
 */
const initSearch = () => {
  currentPage.value = 0;
  finished.value = false;
  map = {}
  destArr.value = []
  contactData.value = []
}

const getListData = async () => {
  let concatUs = ConcatUsDataFromUserManageSchoolList.includes(schoolCode) ? ConcatUsMode.UserManage : ConcatUsMode.SchoolContactManage
  let res = await contactUs({ 
    userName: userName.value, 
    concatUs,
    pageSize: 15,
    pageNum: ++currentPage.value
  });
  if (res.code == 200) {
    let { list, pageNum, pages } = res.data
    if ( concatUs == ConcatUsMode.UserManage ) {
      contactData.value = [...contactData.value, ...list]
      list.forEach((item: any) => {
        let { deptLevel, deptName } = item
        if (typeof map[deptLevel] == 'undefined') {
          destArr.value.push({
            deptLevel: deptLevel,
            deptName: deptName,
            data: [item]
          });
          map[deptLevel] = destArr.value.length - 1;
          return
        }
        destArr.value[map[deptLevel]].data.push(item)
      })
    } else {
      let newListData = list.map((item: any) => {
        return {
          deptName: item.deptName,
          deptLevel:item.sorting,
          data: item.officeList
        }
      })
      destArr.value = [...destArr.value, ...newListData]
    }
    loading.value = false;
    finished.value = pageNum >= pages
    currentPage.value = pageNum
  } else {
    Toast.fail(res.msg);
  }
};

onBeforeMount(() => {
  let a = (schoolConfig("contactus") as unknown) as config;
  title.value = a.title as string;
  connect.value = a.connect as string;
  addressName.value = a.addressName as string;
  getListData()
});
const onClickLeft = () => history.back();
</script>
<style lang="less" scoped>
.gray-bg1 {
  background: #f5f5f5;
  height: 99vh;
  overflow: auto;
}

.isdi {
  position: absolute;
  top: 160px;
  left: 30px;
  width: 690px;
  height: 80px;
  border-radius: 40px;
  --van-search-background-color: rgba(0, 0, 0, 0.5);
  --van-search-content-background-color: none;
  --van-search-action-padding: 5px;
  --van-search-action-text-color: rgba(255, 255, 255, 0.8);
  --van-search-left-icon-color: #fff;
  --van-field-input-text-color: #fff;
  --van-active-color: none;

  .iasd {
    background: rgba(255, 255, 255, 0.1);
    padding: 0 30px;
    border-radius: 40px;
  }
}

.contact-cont {
  padding: 24px 30px;

  .contact-man-title {
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 36px;
    font-weight: 600;
    line-height: 88px;

    span {
      padding: 0 40px;
    }

    .rotate-img {
      transform: rotateZ(180deg);
    }
  }

  .contact-man-list {
    background: #fff;

    border-radius: 16px;
    margin-bottom: 50px;

    .man-list-top {
      background: #fbfbfb;
      display: flex;
      align-items: center;
      font-size: 28px;
      color: #666;
      line-height: 55px;
      padding: 10px 30px;

      .dian {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-right: 30px;
        background: linear-gradient(270deg,
            #eaeaea 0%,
            #aaa9a9 100%,
            #ffffff 100%);
      }
    }

    .contact-man {
      display: flex;
      justify-content: space-between;
      padding-bottom: 20px;
      border-bottom: 1px solid #dfdfdf;
      padding: 24px 30px;

      &:last-child {
        border-bottom: 0;
      }

      .contact-man-left {
        flex: 8;

        .name {
          font-size: 32px;
          font-weight: 600;
        }

        .left-list {
          font-size: 24px;
          color: #666;
          padding-top: 20px;
          display: flex;

          img {
            margin-right: 20px;
          }

          .left-list-text {
            color: #333;
            max-width: 78%;
          }
        }
      }
    }
  }
}
</style>