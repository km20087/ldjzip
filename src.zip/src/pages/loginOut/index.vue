<template>
  <div class="form">
    <van-nav-bar title="退出登录" left-text="" left-arrow @click-left="onClickLeft" />
    <div class="formList">
      <div class="typeName">当前账号</div>
      <div class="content"
        >{{ user.mobile }}<van-icon name="arrow" class="maLe" color="#999999"
      /></div>
    </div>
    <div class="button">
      <van-button type="primary" round @click="loginOut">退出登录</van-button>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import { ref, reactive } from 'vue';
  import ApiUser from '@/api/user';
  import { Dialog } from 'vant';
  import { Toast } from 'vant';
  import { useMenuStore } from "@/store";
  import { goLoginPage } from '@/utils/login';
  import { clearUserStorage } from '@/utils';

  const menuStore = useMenuStore();

  const router = useRouter();
  const $route = useRoute();
  const user = ref({ mobile: '' });
  const onClickLeft = () => {
    router.back();
  };
  const loginOut = () => {
    Dialog.confirm({
      title: '警告',
      message: '确定退出吗',
      confirmButtonText: '确定退出',
    })
      .then(async () => {
        const { data, msg, code } = await ApiUser.loginLogout({});
        Toast({ message: msg });
        clearUserStorage()
        menuStore.resetMenu()
      })
      .catch(() => {})
      .finally(()=>{
         goLoginPage(false);
      });
  };
  onMounted(() => {
    let mobile = $route.query.mobile;
    user.value.mobile = mobile as string;
  });
</script>

<style lang="less" scoped>
  .form {
    width: 100%;
    height: 100%;
    .formList {
      margin: 0 30px;
      // width: 100%;
      height: 100px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #dfdfdf;
    }
    .typeName {
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #333333;
    }
    .content {
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #333333;
    }
    .maLe {
      margin-left: 25px;
    }
    .button {
      width: 92%;
      margin: 0 auto;
      margin-top: 80px;
      height: 88px;
      .van-button--round {
        width: 100%;
      }
      .van-button__text {
        font-size: 36px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
      }
    }
  }
</style>
