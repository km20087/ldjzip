<template>
  <div class="news-footer">
    <!-- <van-image round width="18" height="18" :src="manHead" /> -->
    <span class="van-ellipsis">{{ name }}</span>
    <span class="van-ellipsis">{{ date }}</span>
    <span class="van-ellipsis">阅读次数：{{ readNum }}</span>
  </div>
</template>
<script lang="ts" setup>
import { url } from 'inspector';

defineProps({
  name: String,
  date: String,
  readNum: String,
  manHead: String,
});
</script>
<style lang="less" scoped>
.news-footer {
  display: flex;
  align-items: center;
  font-size: 20px;
  span {
    padding: 8px 15px;
    color: #333;
  }
}
</style>