<template>
  <div class="news-list">
    <div class="news-title van-multi-ellipsis--l2">
      {{ title }}
    </div>
    <div class="news-content van-ellipsis">{{ content }}</div>
    <div class="news-img">
      <fix-image
        width="690"
        height="280"
        fit="cover"
        position="center"
        :isOriginal="true"
        :src="newsPic ? newsPic : ''"
        :class="typeHandle(String(contentUrl))?'pdfSize':'imsw'"
      />
    </div>
    <news-foot v-bind="$attrs" />
  </div>
</template>
<script lang="ts" setup>
  import newsFoot from './newsFoot.vue';

  defineProps({
    title: String,
    content: String,
    newsPic: String,
    contentUrl:String,
  });

  const typeHandle = (val:string) =>{
    if(!!val){
      let type = val.split('.')[1]
      if(type === "pdf"){
        return true
      }else{
        return false
      }            
    }else{
      return false
    }

  }
</script>
<style lang="less" scoped>
  .news-list {
    background: #fff;
    padding: 30px;
    margin-bottom: 30px;
    .news-title {
      font-size: 32px;
      font-weight: 600;
      line-height: 40px;
      color: #333;
      font-family: PingFangSC-Medium, PingFang SC;
      text-align: center;
    }
    .news-content {
      font-size: 28px;
      color: #666666;
      line-height: 56px;
    }
    .news-img {
      margin: 20px 0;
      border-radius: 16px;
      text-align: center;
      overflow: hidden;
      .imsw {
        width: 690px;
        // height: 280px;
        height: 414px;
      }
      .pdfSize{
        width: 500px;
        height: 680px;
      }
    }
  }
</style>
