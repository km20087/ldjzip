<template>
  <van-sticky>
    <van-nav-bar :title="configTitle" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="gray">
    <!-- <van-pull-refresh v-model="refreshing" @refresh="onRefresh"> -->
    <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" v-model:error="error"
      error-text="请求失败，点击重新加载" @load="onLoad">
      <news-list v-for="item in testList" :key="item['niId']" :title="item['newsTitle']" :news-pic="item['coverImage']"
        :name="item['showEditor'] || item['authorDeptName']" :contentUrl="item['contentUrl']" :date="item['showTime'] || item['updateTime']" :read-num="item['clickCount']"
        @click="jumpDetail(item['niId'])" />
    </van-list>
    <!-- </van-pull-refresh> -->
  </div>
    <!-- <div v-else>
      <div class="imsaw1">
        <img :src="noneData" alt="" class="ims" />
        <p class="p1">暂无数据~</p>
      </div>
    </div>       -->
</template>
<script lang="ts" setup>
import { clickNum, getSchoolNews, getNewsDetail,  school, detail } from "@/api/home";
import { Toast } from "vant";
import { schoolConfig } from "@/hooks/schoolConfig";
import newsList from "./components/newsList.vue";
import { tranNumber } from "@/utils/money-show";
import noneData from '@/assets/img/noneData.png';
const onClickLeft = () => history.back();
const $router = useRouter();
const $route = useRoute();
const dparams = reactive<detail>({
  niId: ""
});
const news_type = ref($route.query.type ? $route.query.type : "focus_school");
let detailData = <any>reactive({});
const jumpDetail = async (val: any) => {
  dparams.niId = val;
  clickNum(dparams);
  await getData({ niId: val });
  if (detailData.isUrl == 1) {
    window.location.href = detailData.contentUrl;
  } else {
    $router.push({ name: "newsDetail", query: detailData });
  }
};
const configTitle = ref("");
const getData = async (id: detail) => {
  const { code, data, msg } = await getNewsDetail(id);
  if (code == 200) {
    detailData = { ...data };
  } else {
    // Toast.fail(msg);
  }
};
const loginInfo = reactive<school>({
  newsType: "focus_school",
  isReturnContent: '0',
  pageNum: 1,
  pageSize: 4
});
interface titleConfig {
  title: string;
}
const error = ref(false);
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const testList = ref([]);
const initList = async () => {
  let typeTitle = news_type.value as string

  let a = (schoolConfig("news", typeTitle) as unknown) as titleConfig;
  configTitle.value = a.title as string;
  loginInfo.newsType = (news_type as unknown) as string;
   console.log('testList-news',loginInfo.newsType)
  const { code, data, msg } = await getSchoolNews(loginInfo);
 console.log('testList-news',data)
  if (code == 200) {
    testList.value = testList.value.concat(data.list);
    testList.value.map((item: any) => {
      item.clickCount = tranNumber(item.clickCount, 2);
    });
    loginInfo.pageNum++;
    loading.value = false;
    if (testList.value.length >= data.total) {
      finished.value = true;
    }
  } else {
    Toast.fail(msg);
    finished.value = true;
  }
  refreshing.value = false;
};

const onLoad = () => {
  initList().catch(() => {
    error.value = true;
  });
};

const onRefresh = () => {
  // 清空列表数据
  finished.value = false;

  // 重新加载数据
  // 将 loading 设置为 true，表示处于加载状态
  loading.value = true;
  loginInfo.pageNum = 1;
  testList.value = [];
  onLoad();
};
</script>
<style lang="less" scoped>
.gray{
  background: #f5f5f5;
  height: 100%;
  overflow-y: auto;
}
.news-list {
  background: #fff;
  padding: 30px;
  margin-bottom: 30px;

  .news-title {
    font-size: 32px;
    font-weight: 600;
    line-height: 40px;
    color: #333;
    font-family: PingFangSC-Medium, PingFang SC;
  }

  .news-content {
    font-size: 28px;
    color: #666666;
    line-height: 56px;
  }

  .news-img {
    margin: 20px 0;
    border-radius: 16px;
    overflow: hidden;
  }

  .news-footer {
    display: flex;
    align-items: center;

    span {
      padding: 8px 15px;
      color: #333;
    }
  }
}
.imsaw1 {
  width: 100%;
  height: 100%;
  margin-top: 60px;
  text-align: center;
  margin-top: 200px;
  .ims {
    width: 400px;
    height: 270px;
  }
  .p1 {
    font-size: 28px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #999999;
  }
  .but {
    margin-top: 40px;
  }
}
</style>
