<template>
  <van-nav-bar title="选择相册" left-text="" left-arrow @click-left="onClickLeft" />
  <div class="picCard-list">
    <van-list
      v-model:loading="loading"
      :finished="finished"
      finished-text="没有更多了"
      v-model:error="error"
      error-text="请求失败，点击重新加载"
      @load="onLoad"
    >
    <picturesCard
      v-for="(item, index) in albumList"
      :key="index"
      :src="item.coverImage"
      :name="item.albumName"
      :number="item.photosCount"
      @sureTrans="sureTrans(item)"
    />
    </van-list>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from "vue";
import picturesCard from "@/components/picCom/picturesCard.vue";
import Api from "@/api/orgPhoto";
import { albumParam, saveData, locationP } from "@/store";
import { Toast } from "vant";
const setAlbumParam = albumParam();
const locationSetting = locationP();
const setSaveData = saveData();
const router = useRouter();
// const props = defineProps({
//   groupsId: { type: String, default: '' },
// });
interface albumP {
  address: string;
  albumId: string;
  albumName: string;
  coverImage: string;
  clickCount: string;
  albumType: string;
  permissionScope: string;
  photosCount: string;
}

const error = ref(false);
const loading = ref(false);
const finished = ref(false);
const isLastPageb = ref(false);
const refreshing = ref(false);
const onClickLeft = () => {
  setSaveData.saveF = "0";
  locationSetting.name = "";
  setSaveData.picList = [];
  router.back();
};
const albumList = ref([] as Array<albumP>);
const listP = ref({
  pageNum: 0,
  pageSize: 6
});
const initAlbum = async () => {
  let type = setAlbumParam.type
  let groupsId = type == '1' ? setAlbumParam.groupsId :  ''
  let albumType = type == '1' ? '1' : '0'
  const { data, code, msg } = await Api.listAlbum({
    groupsId,
    albumType,
    pageNum: listP.value.pageNum,
    pageSize: listP.value.pageSize
  });
  if (listP.value.pageNum == 1) {
    albumList.value = [];
  }
  if (code == 200) {
    isLastPageb.value = data.isLastPage;
    loading.value = false;
    albumList.value = albumList.value.concat(data.list);
    // albumList.value = data.list;
  } else {
    Toast({
      message: msg,
      icon: "none"
    });
  }
  if (isLastPageb.value) {
    loading.value = false;
    finished.value = true;
  }
};
const sureTrans = async (value: albumP) => {
  if (setSaveData.saveF == "1") {
    setAlbumParam.albumId = value.albumId;
    setAlbumParam.permissionScope = value.permissionScope;
    setAlbumParam.albumName = value.albumName;
    router.back()
  } else {
    let photoList = setAlbumParam.photoList;
    const { data, msg, code } = await Api.transferPhotos({
      toAlbumId: value.albumId,
      fromAlbumId: setAlbumParam.albumId,
      photoList
    });
    Toast({ message: msg });
    router.back()
  }
};
const onLoad = async () => {
  if (!isLastPageb.value && loading.value) {
    finished.value = false;
    listP.value.pageNum = (listP.value.pageNum as number) + 1;
    // await init();
    await initAlbum();
  } else {
    loading.value = false;
    finished.value = true;
  }
};
onMounted(() => {
  // console.log(props.groupsId);
  // initAlbum();
});
</script>
<style lang="less" scoped>
/deep/ .van-list {
  padding: 30px;
  display: flex;
  // align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
}
/deep/.van-list__finished-text {
  width: 100%;
}
.picCard-list {
  width: 100%;
}
</style>
