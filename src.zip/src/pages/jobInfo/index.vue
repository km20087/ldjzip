<template>
    <div>
        jobInfo
    </div>
</template>
