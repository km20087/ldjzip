<template>
  <div style="padding: 15px">
    <p style="margin: 0pt; orphans: 0; text-align: center; widows: 0">
      <br style="page-break-before: always; clear: both" /><span style="font-family: 宋体; font-size: 14pt">校友预约返校须知</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">各位校友：</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">   
        大家好！为了方便校友回母校办理档案相关业务、拜访恩师、参观游览校园风光，现开启校友预约返校功能。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">   
        请返校校友准确填写预约信息，预约申请通过后，凭带有通行标志的动态电子校园卡，向门卫出示后方可入校。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">    一、校园开放时间：</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">每日8:00至17:00。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span
        style="background-color: #ffffff; font-family: 宋体; font-size: 14pt; letter-spacing: 0.4pt">学校将根据校园实际情况、教育教学和重要活动需要，对入校政策及时间进行动态调整并发布通知，请留意系统公告。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">二、注意事项：</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">    </span><span
        style="font-family: 宋体; font-size: 14pt">（一）</span><span style="font-family: 宋体; font-size: 14pt">返校校友</span><span
        style="font-family: 宋体; font-size: 14pt">请遵守国家相关法律法规和校园管理规定，配合服从校内工作人员管理，注意人身和财产安全，远离施工现场等危险区域，在校停留期间请照看好老人和小孩。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">    </span><span
        style="font-family: 宋体; font-size: 14pt">（二）</span><span
        style="color: #ff0000; font-family: 宋体; font-size: 14pt; font-weight: bold">返校校友同行人员仅限本人亲朋，人数不超过3人。</span><span
        style="font-family: 宋体; font-size: 14pt">返校校友不得带领陌生人入校，不得有偿带领社会人员入校。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">（三）</span><span
        style="font-family: 宋体; font-size: 14pt">各教学、科研、办公、学生宿舍区等场所为非开放区域，谢绝参观。学校资源有限，校内服务设施（体育场、体育馆、图书馆等）暂不对外开放。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt; font-weight: normal">（</span><span
        style="font-family: 宋体; font-size: 14pt; font-weight: normal">四</span><span
        style="font-family: 宋体; font-size: 14pt; font-weight: normal">）因学校停车空间有限，为保障校园正常教育教学秩序和师生交通安全，不开放返校校友随行车辆的进校服务。</span><span
        style="font-family: 宋体; font-size: 14pt; font-weight: normal">驾驶车辆的校友请就近停车或选择步行、</span><span
        style="font-family: 宋体; font-size: 14pt; font-weight: normal">公共交通等方式返校。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">（五）请自觉遵守维护校园交通秩序，不在校内机动车道路上逗留、打闹，请勿携带宠物入校。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">（六）参观时请爱护校园环境、植被和公物。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">（七）学校为无烟校园，禁止在校园区域内吸烟。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">（八）</span><span
        style="font-family: 宋体; font-size: 14pt">返校校友及同行人员不得扰乱正常教学秩序，不得开展推销活动，不得占用校园场地，不得从事违法犯罪活动。一经发现，将视情况限制本人入校权限；情节严重的，将注销本人电子校园卡，终身不得进入校园。</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">祝各位校友返校愉快！</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">&#xa0;</span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt"><van-checkbox v-model="ischecked" shape="square" icon-size="15px"
          checked-color=""><span
            style="font-family: 宋体; font-size: 14pt">本人已阅读校友预约返校须知并承诺遵守以上规定</span></van-checkbox></span>
    </p>
    <p style="margin: 0pt; orphans: 0; text-align: justify; text-indent: 28pt; widows: 0">
      <span style="font-family: 宋体; font-size: 14pt">&#xa0;</span>
    </p>
    <div style="display: flex; justify-content: center">
      <van-button round color="var(--theme-color)" :disabled="isDisabled" @click="agreeFun">{{
        bttext
      }}</van-button>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { Toast } from 'vant';

const ischecked = ref(true);
const isDisabled = ref(true);
const seconds = ref(30);
const bttext = ref('');
const emit = defineEmits(['agreeFun']);

const agreeFun = () => {
  if (!ischecked.value) {
    return Toast('请勾选已阅读且同意');
  } else {
    emit('agreeFun');
    sessionStorage.setItem('backSchoolAgree', '1');
  }
};
onBeforeMount(() => {
  let space = ' '
  const timer = setInterval(() => {
    seconds.value--;
    bttext.value = `请仔细阅读不少于${seconds.value}s`;
    if (seconds.value == 0) {
      bttext.value = `${space}${space} 确 定 ${space}${space}`;
      isDisabled.value = false;
      clearInterval(timer);
    }
  }, 1000);
});
</script>
<style lang="less" scoped>
:deep(.van-button--round) {
  padding: 0 120px;
}
</style>