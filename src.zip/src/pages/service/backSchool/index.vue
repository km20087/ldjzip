<template>
  <van-sticky>
    <van-nav-bar title="预约返校" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <van-form
    class="form-wrap"
    @failed="onFailed"
    @submit="onSubmit"
    input-align="right"
    error-message-align="right"
  >
    <van-field
      v-if='visitorFlag || isShenYangYaoKeDaXueFlag'
      label="预约人"
      required
      v-model="actForm.visitorName"
      name="visitorName"
      placeholder="请输入预约人"
      maxlength="30"
      :readonly="isShenYangYaoKeDaXueFlag"
      :rules="[{ required: true, message: '请输入预约人' }]"
    />
    <van-field label="返校期队/年级" 
      v-model="actForm.schoolEndYear" 
      name="schoolEndYear" 
      is-link
       v-if='isShenYangYaoKeDaXueFlag'
      @click="startTimeFlag = isShenYangYaoKeDaXueFlag && true " 
      :disabled="!isShenYangYaoKeDaXueFlag"
    />    
    <van-field
      v-if='visitorFlag'
      label="预约人身份证号"
      required
      v-model="actForm.visitorIdNumber"
      name="returningReason"
      placeholder="请输入预约人身份证号"
      maxlength="30"
      :rules="[{ required: true, message: '请输入预约人身份证号' }]"
    />    
    <van-field
      label="返校原因"
      v-if='!isShenYangYaoKeDaXueFlag'
       :required="!isShenYangYaoKeDaXueFlag"
      v-model="actForm.returningReason"
      name="returningReason"
      placeholder="请输入返校原因"
      maxlength="30"
      :rules="[{ required: true, message: '请输入返校原因' }]"
    />

    <van-field
      v-model="actForm.returningStartTime"
      readonly
      required
      name="returningStartTime"
      label="开始时间"
      placeholder="点击选择日期"
      @click="show2cli()"
      :rules="stimeRules"
    />
    <van-popup v-model:show="showCalendar2" position="bottom" round>
      <van-datetime-picker
        v-model="currentDate"
        type="date"
        title="选择完整时间"
        :min-date="minDate"
        :max-date="maxDate"
        @confirm="onConfirm2"
        @cancel="showCalendar2 = false"
      />
    </van-popup>

    <van-field
      v-model="actForm.returningEndTime"
      readonly
      required
      name="returningEndTime"
      label="结束时间"
      placeholder="点击选择日期"
      @click="show3cli()"
      :rules="etimeRules"
    />
    <van-popup v-model:show="showCalendar3" position="bottom" round>
      <van-datetime-picker
        v-model="currentDate"
        type="date"
        title="选择完整时间"
        :min-date="minDate"
        :max-date="maxDate"
        @confirm="onConfirm3"
        @cancel="showCalendar3 = false"
      />
    </van-popup>

    <!-- 通过 validator 返回错误提示 -->
    <van-field
      label="联系方式"
      required
      v-model="actForm.contactInformation"
      name="contactInformation"
      placeholder="请输入方式"
      :rules="ExamContact"
    />

    <van-field
      v-model="actForm.collegeName"
      readonly
      name="collage"
      label="学院"
      is-link
      :rules="[{ required: true, message: '请选择学院' }]"
      placeholder="请选择学院"
      @click="showCollage = true"
      v-if="schoolLevel !== '1' && (schoolmateType == '0' || schoolmateType == '1' || isShenYangYaoKeDaXueFlag)"
    />
    <van-field
      v-model="actForm.majorName"
      is-link
      readonly
      v-if="isShenYangYaoKeDaXueFlag"
      name="majorName"
      label="专业"
      :placeholder="'请选择专业'"
      :rules="[{ required: true, message: '请输入专业' }]"
      @click="columnShow()"
    />    
    <van-popup v-model:show="showCollage" position="bottom" round>
      <van-picker
        :columns="collageList"
        :columns-field-names="{ text: 'deptName' }"
        @cancel="showCollage = false"
        @confirm="onConfirmColl"
      />
    </van-popup>
  <van-popup v-model:show="showPicker" position="bottom">
    <van-picker :columns="columns" class="wop"  @confirm="onConfirmPicker" @cancel="showPicker = false" >
    </van-picker>
  </van-popup>
    <!-- 通过 validator 返回错误提示 -->
    <!-- <van-field
      label="同行人数"
      required
      type="digit"
      v-model="actForm.numberOfAccompanyingPersons"
      name="numberOfAccompanyingPersons"
      placeholder="输入人数"
      @change="changeNum"
      :rules="[{ required: true, message: '请输入同行人数' }]"
    /> -->
    <van-field label="同行人数" required 
      v-model="actForm.numberOfAccompanyingPersons"
      v-if='!shandaFlag'
      name="numberOfAccompanyingPersons" >
      <template #input>
          <van-stepper v-model='actForm.numberOfAccompanyingPersons'
          @change="changeNum" 
          default-value="0"
          min="0"/>
      </template> 
    </van-field>
    <van-cell title="同行人信息" required v-if="partnerList.length > 0">
      <template #label>
        <div class="">
          <van-row
            gutter="1"
            class="partner-list"
            v-for="(item, index) in partnerList"
            :key="index"
          >
            <img
              src="@/assets/img/del_icon@2x.png"
              width="10"
              height="10"
              class="del-icon"
              alt=""
              @click="popOne(index)"
            />
            <van-col span="5"
              ><van-field
                input-align="center"
                error-message-align="center"
                v-model="item.name"
                type="text"
                placeholder="姓名"
                :rules="[{ required: true, message: '请输入' }]"
              ></van-field
            ></van-col>
            <van-col span="12"
              ><van-field
                input-align="center"
                error-message-align="center"
                v-model="item.idNumber"
                type="text"
                placeholder="身份证号"
                :rules="checkID"
              ></van-field
            ></van-col>
            <van-col span="7"
              ><van-field
                input-align="center"
                error-message-align="center"
                v-model="item.mobile"
                type="text"
                placeholder="手机号码"
                :rules="checkOhone"
              ></van-field
            ></van-col>
          </van-row>
        </div>
      </template>
    </van-cell>
    <van-field
      label="同行人数描述"
      v-model="actForm.description"
      name="description"
      v-if="partnerList.length > 0 && !isShenYangYaoKeDaXueFlag"
      placeholder="输入描述"
      maxlength="40"
    />

    <!-- <van-field
      v-model="actForm.showText"
      required
      :readonly="shandaFlag"
      name="interviewee"
      label="被访人"
      placeholder="请选择被访人"
      @click="showDiaByShowInterviewee"
      :rules="[{ required: true, message: '请选择被访人' }]"
    />
    <van-popup v-model:show="showInterviewee" position="bottom" round>
      <van-picker
        :columns="intervieweeList"
        :columns-field-names="{ text: 'showText' }"
        @cancel="showInterviewee = false"
        @confirm="onConfirmViewee"
      />
    </van-popup> -->

    <van-field
      v-if="!chengduFlag && !isShenYangYaoKeDaXueFlag"
      label="被访人姓名"
      v-model="actForm.campusUserName"
      :required="!isShenYangYaoKeDaXueFlag"
      name="campusUserName"
      :rules="[{ required: true, message: '请输入' }]"
      placeholder="输入被访人姓名"
      maxlength="40"
    />

    <!-- <van-field
      v-model="actForm.campusUserId"
      required
      readonly
       v-if='!shandaFlag'
      name="intervieweeId"
      label="被访人工号"
      placeholder="被访人工号"
      :rules="[{ required: true, message: '请输入被访人工号' }]"
    /> -->
    <van-field
      label="被访人邮箱"
      required
      v-if='shandaFlag'
      :readonly="shandaFlag"
      v-model="actForm.campusUserEmail"
      name="campusUserEmail"
      :rules="[{ required: true, message: '请输入' }]"
      placeholder="输入被访人邮箱"
    />
    <van-field
      label="车牌号"
      v-if='shandaFlag || chengduFlag || isShenYangYaoKeDaXueFlag'
      v-model="actForm.plateNumber"
      name="plateNumber"
      placeholder="输入车牌号"
      maxlength="40"
    />            
    <van-field
      label="到访单位"
      v-model="actForm.visitingUnit"
      name="returningPersonnel"
      maxlength="30"
      placeholder="输入到访单位"
      v-if="schoolLevel !== '1' && !isShanDa() && !isShenYangYaoKeDaXueFlag"
    />

    <van-field
      label="备注"
      v-model="actForm.remark"
      name="remark"
      autosize
      type="textarea"
      show-word-limit
      rows="5"
      maxlength="80"
      placeholder="请输入备注"
      v-if="!isShenYangYaoKeDaXueFlag"
    />
      <van-field
      v-else
        v-model="actForm.remark"
        rows="6"
        autosize
        label="返校活动安排"
        type="textarea"
        maxlength="100"
        placeholder="请输入返校活动安排"
        show-word-limit
      />      
    <div class="tips" v-if="isShenYangYaoKeDaXueFlag">
        <div class="part1">
            温馨提示:
        </div>
        <div class="part2 nowrap">
            <div>具体事宜请联系校友办公室晁璇，电话:15841418772。</div>
        </div>
    </div> 
    <div style="margin: 30px">
      <van-button :disabled='loading' round block type="primary" native-type="submit"> 提交 </van-button>
    </div>
  </van-form>
   
    <van-popup v-model:show="startTimeFlag" position="bottom">
    <van-picker :columns="timeList" title="请选择年份" show-toolbar :default-index="select" @confirm="yearConfirmStart"
      @cancel="startTimeFlag = false" />
  </van-popup> 
</template>
<script lang="ts" setup>
import { ref } from "vue";
import { Toast } from "vant";
import { useRouter,useRoute } from "vue-router";
import { backSchool, getappAuditList } from "@/api/servive";
import { fommatDate } from "@/utils/fommatDate";
import ApiDept from "@/api/common";
import { isChengDuYiXueYuan,isShanDa,isBaoTouZhiYeJiShu,isShenYangYaoKeDaXue } from '@/utils/customizedType';
import { getSchoolId, getUserStatus,getUserInfo } from "@/utils";
import {schoolShowConfig,zhongxueConfig} from "@/utils/schoolLevelShow"
import { formatDate, formatDateTime } from '@/utils/tool/time';
import { useMyInfo } from '@/pages/home/useMyInfo';
const { perInfo, initMy } = useMyInfo();
const $router = useRouter();
const $route = useRoute();
const onClickLeft = () => history.back();
const currentDate = ref(new Date());
const minDate = ref(new Date());
const maxDate = ref(new Date());
const visitorFlag = ref(false);
const loading = ref(false);
const steValue = ref(0);
const isWXEnv = ref(false);
const startTimeFlag = ref(false);
const select = ref('');
const timeList = <any>reactive([]);
const dateValue = ref('');
const isShenYangYaoKeDaXueFlag = isShenYangYaoKeDaXue()
let actForm = ref({
  collegeName: "",
  college: "",
  contactInformation: "",
  description: "",
  numberOfAccompanyingPersons: 0,
  remark: "",
  returningEndTime: "",
  visitingUnit: "",
  returningReason: "",
  returningStartTime: "",
  numberOfAccompanyingPersonList: [] as partner[],
  deptName: "",
  userName: "",
  showText: "",
  campusUserId: "",
  visitorName: "",
  visitorIdNumber: "",
  plateNumber: "",
  campusUserEmail: "",
  campusUserName: "",
  major:"",
  majorName:"",
  schoolEndYear:"",
});
interface partner {
  name: string;
  idNumber: string;
  mobile: string;
}

const schoolLevel = ref('')
const schoolmateType = <any>ref(null)
// const schoolConfig = <any>ref({})
const showPicker = ref(false)
const shandaFlag = ref(false);
const chengduFlag = ref(false)
const partnerList = ref<partner[]>([]);
const showCollage = ref(false);
const showCalendar2 = ref(false);
const showCalendar3 = ref(false);
const showInterviewee = ref(false);
const columns = ref<any[]>([])
let collageList = ref([]);
let intervieweeList = ref<any[]>([]);
//自定义校验
const stimeRules = <any>[
  { required: true, message: "开始时间不能为空" }
  // {
  //   validator: (value: any) => {
  //     if (new Date(value).getTime() < new Date().getTime()) {
  //       return false;
  //     }
  //   },
  //   message: "开始时间不能早于当前时间",
  //   trigger: ["onChange", "onBlur"]
  // }
];
const etimeRules = <any>[
  { required: true, message: "结束时间不能为空" },
  {
    validator: (value: any) => {
      if (
        new Date(value).getTime() <
        new Date(actForm.value.returningStartTime).getTime()
      ) {
        return false;
      }
    },
    message: "结束时间不能早于开始时间",
    trigger: ["onChange", "onBlur"]
  }
];
const ExamContact = <any>[
  { required: true, message: "请输入联系方式" },
  {
    validator: (value: any) => {
      const mobileReg = /^(([1][3,4,5,7,8,9]\d{9})|([0]\d{10,11})|(\d{7,8})|(\d{4}|\d{3})-(\d{7,8}))$/;
      const phoneReg = /^\d{3}-\d{8}|\d{4}-\d{7}$/;
      if (value.length === 11) {
        if (!mobileReg.test(value)) return false;
      } else if (value.length === 12) {
        if (!phoneReg.test(value)) return false;
      }
    },
    message: "请输入正确的手机号码或者固话号码（固话格式：区号-号码）",
    trigger: ["onBlur"]
  }
];
const checkID = <any>[
  { required: true, message: "请输入" },
  {
    validator: (value: any) => {
      const idReg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
      if (!idReg.test(value)) return false;
    },
    message: "格式有误",
    trigger: ["onBlur"]
  }
];
const checkOhone = <any>[
  { required: true, message: "请输入" },
  {
    validator: (value: any) => {
      const idReg = /^(([1][3,4,5,7,8,9]\d{9})|([0]\d{10,11})|(\d{7,8})|(\d{4}|\d{3})-(\d{7,8}))$/;
      if (!idReg.test(value)) return false;
    },
    message: "格式有误",
    trigger: ["onBlur"]
  }
];
const getViewList = async () => {
  const { code, data, msg } = await getappAuditList({
    roleCode: "SCHOOL_LEADER"
  });
  if (code == 200) {
    intervieweeList.value = data;
    intervieweeList.value.map(item => {
      return (item.showText = item.deptName + "-" + item.userName);
    });
  } else {
    Toast.fail(msg);
  }
  console.log(intervieweeList.value);
};
const showDiaByShowInterviewee = () => {
  if (!shandaFlag.value) {
    showInterviewee.value = true;
  }
};
const changeNum = () => {
  console.log(actForm.value.numberOfAccompanyingPersons);
  partnerList.value = [];
  if(isBaoTouZhiYeJiShu()){
    if( Number(actForm.value.numberOfAccompanyingPersons) > 3){
      for (let i = 0; i < 3; i++) {
        partnerList.value.push({ name: "", idNumber: "", mobile: "" });
      }  
    }else{
      for (let i = 0; i < Number(actForm.value.numberOfAccompanyingPersons); i++) {
        partnerList.value.push({ name: "", idNumber: "", mobile: "" });
      }        
    }
  }else{
    for (let i = 0; i < Number(actForm.value.numberOfAccompanyingPersons); i++) {
      partnerList.value.push({ name: "", idNumber: "", mobile: "" });
    }    
  }

};
const popOne = (idx: number) => {
  partnerList.value.splice(idx, 1);
  // actForm.value.numberOfAccompanyingPersons = String(partnerList.value.length);
  actForm.value.numberOfAccompanyingPersons = partnerList.value.length;
};
const onConfirmColl = (value: any) => {
  actForm.value.collegeName = value.deptName;
  actForm.value.college = value.deptId;
  initMajor(value.deptId)
  showCollage.value = false;
};

const initName = async ()=>{
  // let {data,code,msg} = await fetchBaseInfo({})
  // actForm.value.visitorName = data.nameDetail || data.name 
  // actForm.value.contactInformation = data.mobileDetail
  await initMy();
  let userInfo = JSON.parse(getUserInfo() as string)
  actForm.value.visitorName = userInfo.nameDetail || userInfo.name 
  actForm.value.contactInformation = userInfo.mobileDetail
}

const getYearData = () => {
  var nowTime = new Date(dateValue.value);
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  for (let i: number = 1900; i < 2035; i++) {
    timeList.push(i);
  }

  let years = formatDate(new Date(year, month, day));
  let Year = years.slice(0, 4);

  select.value = timeList.indexOf(Number(Year));
};
const getCurrentYear = () => {
  var nowTime = new Date();
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  let dateValue1 = '';
  dateValue1 = formatDate(new Date(year, month, day));
  dateValue.value = String(dateValue1.slice(0, 4));
  // this.signs(this.dateValue)
};

const yearConfirmStart = (value: string) => {
  actForm.value.schoolEndYear = value.toString();
  startTimeFlag.value = false;
};

const initMajor =async (id:string)=>{
      let schoolId = getSchoolId() as string;
      const { data, msg, code } = await ApiDept.deptList({
      schoolId: schoolId,
      parentId: id,
      allDept:1
    });
    if(code == 200){
      for (let i in data) {
        columns.value.push({ text: data[i].deptName, deptId: data[i].deptId });
      }
    }
}

const columnShow = () =>{
  if(!actForm.value.college){
    Toast('请选择学院')
    return
  }
  showPicker.value = true;
}

const onConfirmPicker = (val:any)=>{
    actForm.value.major = val.deptId;
    actForm.value.majorName = val.text;
    showPicker.value = false;
}

const onFailed = (errorInfo: any) => {
  console.log("failed", errorInfo);
};
const onConfirm2 = (date: any) => {
  actForm.value.returningStartTime = fommatDate(date, "yyyy-MM-dd");

  showCalendar2.value = false;
};
const show2cli = () => {
    dateRange()
    showCalendar2.value = true;
};
const show3cli = () => {
    dateRange()
    showCalendar3.value = true;
};

const dateRange = ()=>{
    let dateNow = new Date();
    const currentYear = new Date().getFullYear()
    minDate.value = dateNow;
    let nextYear = currentYear + 1
    let nextMonth = new Date().getMonth()
    // let nextDay = new Date().getDate()    
    let nextDay = new Date(new Date().setFullYear(nextYear)).getDate() 
    maxDate.value = new Date(nextYear,nextMonth,nextDay);
}
const onConfirm3 = (date: any) => {
  // let dateNow = new Date();
  // let year = date.getFullYear();
  // let month = date.getMonth()+1;
  // let day = new Date(year,month,0);
  // console.log(day)
  // return
  actForm.value.returningEndTime = fommatDate(date, "yyyy-MM-dd");
  showCalendar3.value = false;
};
const onConfirmViewee = (value: any) => {
  actForm.value.deptName = value.deptName;
  actForm.value.userName = value.userName;
  actForm.value.showText = value.showText;
  actForm.value.campusUserId = value.campusUserId;
  if (shandaFlag.value) {
    actForm.value.campusUserName = value.userName;
  }
  showInterviewee.value = false;
};
const onSubmit = async (val: FormData) => {
  if (!isWXEnv.value && shandaFlag.value) {
    Toast.fail("请在微信环境下提交预约返校申请");
    return;
  }
  if(isShenYangYaoKeDaXueFlag){
    actForm.value.returningReason = '返校'
    
  }
  actForm.value.numberOfAccompanyingPersonList = partnerList.value;
  // console.log(actForm.value)
  loading.value = true;
  const { code, data, msg } = await backSchool({
    ...actForm.value
  });
  if (code == 200) {
    // Toast.success("预约返校申请提交成功");
    if (shandaFlag.value) {
      Toast.success({
        mask: true,
        message: '提交成功',
        duration: 2000,
        forbidClick: true,
        onClose: () => {
          // $router.back()
          window.location.href = data.url; //home
        }
      });      
      window.location.href = data.url; //home
      // $router.push({path:"/reserveBackSchoolRecord"})
    } else {
      Toast.success({
        mask: true,
        message: '提交成功',
        duration: 2000,
        forbidClick: true,
        onClose: () => {
          $router.back()
        }
      });
    }
  } else {
    Toast.fail(msg);
    loading.value = false;
  }
};
onMounted(async () => {
  // let str = 'mozilla/5.0 (iphone; cpu iphone os 17_3_1 like mac os x) applewebkit/605.1.15 (khtml, like gecko) mobile/15e148 micromessenger/8.0.43(0x18002b2f) nettype/4g language/zh_cn'
  isWXEnv.value = navigator.userAgent.toLowerCase().includes("micromessenger");
  // getDateByNow()
  schoolLevel.value =  schoolShowConfig() as string
  schoolmateType.value = sessionStorage.getItem('schoolmateType')
  console.log('schoolmateType',schoolmateType.value)
  if (isShanDa()) {
    shandaFlag.value = true;
    actForm.value.showText = "陈仕达";
    actForm.value.campusUserName = '陈仕达'
    actForm.value.campusUserId = '4144010560'
    actForm.value.campusUserEmail = "chensd@stu.edu.cn";
    if (!isWXEnv.value) {
      Toast.fail("请在微信环境下提交预约返校申请");
    }
    if(!!$route.query?.returningStartTime && !!$route.query?.returningEndTime){
      actForm.value.returningStartTime = fommatDate(new Date(Number($route.query?.returningStartTime)), "yyyy-MM-dd");
      actForm.value.returningEndTime = fommatDate(new Date(Number($route.query?.returningEndTime)), "yyyy-MM-dd");
    }
  }
  if(isShenYangYaoKeDaXueFlag){
    initName()
    if(!!$route.query?.returningStartTime && !!$route.query?.returningEndTime){
      actForm.value.returningStartTime = fommatDate(new Date(Number($route.query?.returningStartTime)), "yyyy-MM-dd");
      actForm.value.returningEndTime = fommatDate(new Date(Number($route.query?.returningEndTime)), "yyyy-MM-dd");
    }
    getCurrentYear();
    getYearData();   
  }
  chengduFlag.value = isChengDuYiXueYuan()
  //visitorFlag
  let userStatus = getUserStatus()
  console.log('userStatus',userStatus)
  if (userStatus == "03" || userStatus == "04" || userStatus == "05") {
    visitorFlag.value = true;
  }
  getViewList();
  const { data, msg, code } = await ApiDept.deptList({
    schoolId: getSchoolId() as string
  });
  collageList.value = data.map((e: any) => {
    return { deptId: e.deptId, deptName: e.deptName };
  });
});
</script>
<style lang="less" scoped>
.upload-text {
  font-size: 28px;
  color: #004dff;
}
.partner-list {
  position: relative;
  margin-bottom: 20px;
  .del-icon {
    position: absolute;
    top: -8px;
    right: -8px;
    z-index: 99;
  }
  .van-cell {
    background: #fbfbfb;
    padding-left: 10px;
    padding-right: 10px;
  }
}
.van-field__control {
  font-size: 20px !important;
}
.form-wrap {
  --van-field-label-width: 6.9em;
}
.tips{
  width: 100%;
  margin-top: 60px;
  .part1{
    width: 100%;
    font-size: 28px;
    color: #333;
    font-weight: 600;
    margin-left: 40px;
  }
  .part2{
    margin-top: 40px;
    text-align: center;
  }
  .nowrap{
    word-break: break-all;
  }
}
</style>
