<template>
    <div class="con">
        <van-sticky>
            <van-nav-bar title="预约失败" left-arrow @click-left="onClickLeft" />
            <div class="result">
                <div class="logo">
                    <img :src="failed" alt="" class="ims" />
                </div>
                <div class="tips">
                    <p class="poo">预约失败</p>
                    <p class="oiis">预约返校申请提交失败</p>
                </div>                
            </div>                
        </van-sticky>
    </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from "vue";
import { useRouter, useRoute } from "vue-router";
// import checked from "@/assets/img/checked.png";
import failed from "@/assets/img/failed.png";
const $router = useRouter();
const onClickLeft = () =>{
     $router.push({ path: "/tab/index" });
}
</script>
<style lang="less" scoped>
.con {
  width: 100%;
  height: 100%;
  .result {
    width: 100%;
    height: 100%;
    margin: 0 auto;
  }
  .logo {
    margin-top: 200px;
    text-align: center;
    .ims {
      width: 120px;
      height: 120px;
    }
  }
  .tips {
    width: 100%;
    text-align: center;
    .poo {
      font-size: 36px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #333333;
    }
    .oiis {
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #666666;
    }
  }
  .osoo {
    width: 650px;
    height: 264px;
    background: #f8f8f8;
    border-radius: 16px;
    margin: 0 auto;
    padding: 0 50px;
    word-wrap: break-word;
    .was {
      widows: 100%;
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #333333;
    }
  }
  .info {
    width: 650px;
    height: 264px;
    background: #f8f8f8;
    border-radius: 16px;
    margin: 0 auto;
    padding: 0 50px;

    .ik {
      width: 100%;
      height: 88px;
      border-radius: 16px;
      display: flex;
      justify-content: space-between;
      align-content: center;
      word-wrap: break-word;
      .as {
        font-size: 28px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #666666;
      }
      .was {
        font-size: 28px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #333333;
      }
    }
  }
  .button {
    display: flex;
    // margin: 0 50px;
    margin-top: 80px;
    justify-content: center;
    align-items: center;
    .bu1 {
      width: 220px;
      height: 88px;
    }
    .can {
      font-size: 36px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 900;
      color: #333333;
      margin-right:21px;
    }
    .sure {
      font-size: 36px;
      color:#00548e;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 900;
      background:rgba(0,84,142,0.18);
       margin-right:21px;
      // color: #ffffff;
    }
    .hurry{
      font-size: 36px;
      background:#00548e;
      color:#ffffff;
      font-weight: 900;
    }
  }
}
</style>
