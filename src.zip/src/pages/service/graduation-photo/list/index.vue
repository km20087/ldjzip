<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="毕业照" />
    <fix-image :src="imgBanner" class="bg-img" />
    <div class="img-wrap row-wrap">
      <!-- <fix-image :src="imgSchoolLogoName" class="img-wrap_logo" /> -->
      <div class="titleXX">广州市象贤中学校友会</div>
    </div>
    <div class="introduce" v-html="introduceText"></div>
    <Search @search="handleSearch" />
    <van-empty v-if="listData.length == 0" description="暂无可投稿主题" />
    <van-list class="list-wrap" v-model:loading="loading" :finished="finished" @load="getListDataByYear">
      <div
        class="item-wrap"
        :class="{ open: item.isOpen }"
        v-for="(item, index) in listData"
        :key="item.id"
      >
        <div class="row space-between" @click="handleToggleItem(index, item)">
          <div class="title-wrap row van-ellipsis">
            <span class="van-ellipsis">{{ item.graduationYear }}校友班级照</span>
          </div>
          <div class="rt-wrap row">
            <i class="txt">{{ item.isOpen ? '收起' : '展开' }}</i>
            <van-icon class="icon icon-arrow" name="arrow" />
          </div>
        </div>
        <div class="item-detail-box">
          <div
            class="item-detail-wrap row space-between"
            v-for="(subItem, subIndex) in classList"
            :key="subIndex"
            @click="goPage(subItem)"
          >
            <div class="item-detail-title-wrap row">
              <img class="icon" :src="Icon" />
              <span class="txt van-ellipsis">{{ subItem.graduationClass }}</span>
            </div>
            <div class="rt-wrap row">
              <i class="txt">查看</i>
              <van-icon class="icon icon-eye" name="eye" />
            </div>
          </div>
        </div>
      </div>
    </van-list>
  </main>
</template>

<script setup lang="ts">
  import { ref, reactive } from 'vue'
  import { useRouter } from 'vue-router'
  import { fetchSubmissionTypeList } from '@/api/submission'
  import {graduationPhotoDetail,graduationYearPage,graduationClassPage} from "@/api/graduationPhoto"
  import { useGoBack } from '@/hooks/useGoBack'
  import { Toast } from 'vant'
  import { getSchoolCode } from '@/utils'
  import { SchoolCode } from '@/constants'
  import { useCacheImage } from '@/hooks/useCacheImage'
  import Search from '../components/search.vue'
  import Icon from '@/assets/img/graduation-photo-icon.png'

  const { img: imgBanner } = useCacheImage('SCHOOLMATE_CARD_BACKGROUND')
  const imgSchoolLogoName = computed(() => {
    const logoObj: Record<string, string> = {
      [SchoolCode.XiangXianZhongXue]: new URL(
        '@/assets/xiangxianzhongxue/logo-red.png',
        import.meta.url
      ).href,
    }
    return schoolCode && logoObj[schoolCode] ? logoObj[schoolCode] : ''
  })

  const { goBack } = useGoBack()
  let schoolCode = getSchoolCode()

  const introduceObj: Record<string, string> = {
    [SchoolCode.XiangXianZhongXue]: `此栏目是我们象贤中学各级校友的班级毕业照展示，照片里，师生并肩、笑容明朗，校服整齐、眼神明亮，每一帧都记录着同窗情谊、师恩难忘与少年意气。它不只是一张影像，更是一段时光的凭证、一份集体的纪念，是属于象贤学子的青春勋章，也是连接母校与未来的温暖印记。在此，我们也向各位校友征集班级照，如我们栏目还没有您所在班级照，可联系梁力莎老师，联系电话:<span style="color: #222">020-34877920</span>(上班时间);也可以在<span style="color: #222">[校友投稿]</span>专刊投稿，感谢您的提供。`,
  }
  const introduceText = schoolCode && introduceObj[schoolCode] ? introduceObj[schoolCode] : ''

  const searchText = ref('')

  const classLoading = ref(false)
  // const yearId = ref('')
  const router = useRouter()
  const page = reactive({
    pageNum: 0,
    pageSize: 5,
  })
  const listData = ref<graduationData[]>([])
  const classList = ref<graduationData[]>([])
  const loading = ref(false)
  const finished = ref(false)
  function handleSearch(text: string) {
    page.pageNum = 0
    searchText.value = text
    getListDataByYear()
  }

  async function getListDataByYear() {
    try {
      loading.value = true
      const { code, data, msg } = await graduationYearPage({
        graduationYear: searchText.value,
        pageNum: ++page.pageNum,
        pageSize: page.pageSize,
      })
      if (code == 200) {
        const { list, pages, pageNum } = data
        for(let i in list){
            list[i].isOpen = false
        }        
        finished.value = pageNum >= pages
        listData.value = pageNum == 1 ? list : [...listData.value, ...list]
      } else {
        Toast.fail(msg)
        finished.value = true
      }
    } catch (err) {
      console.log('getListDataByYear err', err)
    } finally {
      loading.value = false
    }
  }

async function getListDataByClass(graduationYear:string) {
    classLoading.value = true
    const { code, data, msg } = await graduationClassPage({
        graduationYear,
        pageSize:100,
        pageNum:1,
    })
    if(code == 200){
      classList.value = data.list
    }
    classLoading.value = false
}  

  function handleToggleItem(index:number, item:any) {
    listData.value[index].isOpen = !item.isOpen
    getListDataByClass(item.graduationYear)
  }

  function goPage({ id }: graduationData) {
    router.push({ path: '/graduation-photo-detail', query: { id } })
  }
</script>

<style lang="less" scoped>
  .wrap {
    // min-height: 100vh;
    // background: #f5f5f5;
    // padding: 32px;
    position: relative;
    z-index: 1;
    height: 100vh;
    overflow-y: auto;
  }
  .bg-img {
    width: 100%;
    height: 380px;
  }
  .row-wrap {
    display: flex;
    flex-direction: row;
  }
  .img-wrap {
    justify-content: center;
    // align-items: center;
    margin: 13px 0 0;
    .img-wrap_logo {
      width: 461px;
      height: 80px;
    }
    .titleXX{
      // margin-left: 40px;
      width: 461px;
      font-size: 36px;
      color: #c21e24;
      text-align: center;
      font-weight: 600;
    }
  }
  .introduce {
    margin: 20px 0 0;
    padding: 0 30px;
    font-size: 24px;
    color: #666;
  }
  .row {
    display: flex;
    flex-direction: row;
    align-items: center;
  }
  .space-between {
    justify-content: space-between;
  }
  .list-wrap {
    padding: 20px;
    transition: all 0.3s linear;
    .item-wrap {
      margin: 0 0 24px;
      height: 100px;
      will-change: height;
      background: #fff;
      border-radius: 16px;
      overflow: hidden;

      .item-detail-box {
        padding: 0 22px 27px;
        border-top: 1px solid #ededed;

        .item-detail-wrap {
          margin: 27px 0 0;
          background: linear-gradient(180deg, #f6fcf4 0%, rgba(249, 255, 247, 0) 100%);
          border: 3px solid #e6f0e2;
          border-radius: 20px;
          padding: 26px 18px;
          
          .item-detail-title-wrap {
            flex-direction: row;
            .icon {
              margin: 0 12px 0 0;
              width: 28px;
              height: 28px;
            }
            .txt {
              font-size: 28px;
              color: #333;
            }
          }
        }
      }

      .title-wrap {
        flex: 1;
        margin: 0 16px 0 0;
        padding: 34px 0;
        font-size: 32px;
        font-weight: 500;
        color: #222;
        &::before {
          flex: 0 0 auto;
          content: '';
          display: block;
          margin: 0 22px 0 0;
          width: 8px;
          height: 28px;
          background: linear-gradient(270deg, var(--theme-color-0-6) 0%, var(--theme-color) 100%);
          border-radius: 7px;
        }
      }
      .rt-wrap {
        flex: 0 0 auto;
        padding: 0 24px 0 0;
        .txt {
          font-style: normal;
          font-size: 28px;
          color: #999;
        }
        .icon {
          margin: 0 0 0 5px;
          font-size: 28px;
          color: #999;
          &.icon-eye {
            margin: 2px 0 0 10px;
          }
        }
      }
      &.open {
        height: auto;
        .icon-arrow {
          transform: rotate(-90deg);
        }
      }
    }
  }
</style>
