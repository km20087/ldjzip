<template>
  <div class="search-wrap">
    <div class="input-box row">
      <div class="input-wrap row">
        <van-icon class="icon" name="search"></van-icon>
        <input class="input" v-model="searchText" placeholder="请输入查询内容" />
      </div>
      <div class="btn row" @click="handleSearch">搜索</div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed, ref } from 'vue'

  const emit = defineEmits<{
    (e: 'search', value: string): void
  }>()

  const searchText = ref('')
  const handleSearch = () => {
    emit('search', searchText.value)
  }
</script>

<style lang="less" scoped>
  .search-wrap {
    padding: 32px 20px;
    background: #f5f5f5;
    .row {
      display: flex;
      flex-direction: row;
    }
    .input-box {
      justify-content: space-between;
      align-items: center;
      border-radius: 50px;
      background: #fff;
    }
    .input-wrap {
      flex: 1;
      padding: 26px 30px;
      align-items: center;
      .icon {
        flex: 0 0 auto;
        margin-right: 12px;
        font-size: 32px;
        color: #999;
      }
      .input {
        flex: 1;
        font-size: 28px;
        color: #666;
        border: none;
        &::placeholder {
          color: #999;
        }
      }
    }
    .btn {
      flex: 0 0 auto;
      width: 138px;
      height: 80px;
      background: linear-gradient(270deg, var(--theme-color-0-6) 0%, var(--theme-color) 100%);
      border-radius: 48px;
      font-size: 32px;
      color: #fff;
      justify-content: center;
      align-items: center;
    }
  }
</style>
