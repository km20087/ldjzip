<template>
  <div class="input-item">
    <div class="title-wrap" :class="{required}">
      <span>{{ title }}</span>
    </div>
    <slot></slot>
  </div>
</template>

<script setup lang="ts">
  withDefaults(
    defineProps<{
      title: string
      required: boolean
    }>(),
    {
      required: false,
    }
  )
</script>

<style lang="less" scoped>
  .input-item {
    margin: 0 0 24px;
    border-radius: 16px;
    background: #fff;
    .title-wrap {
      padding: 30px 0 6px;
      display: flex;
      flex-direction: row;
      align-items: center;
      font-size: 34px;
      font-weight: 600;
      color: #222;
      &::before {
        flex: 0 0 auto;
        content: '';
        display: block;
        margin: 0 22px 0 0;
        width: 8px;
        height: 36px;
        background: linear-gradient(270deg, var(--theme-color-0-6) 0%, var(--theme-color) 100%);
        border-radius: 7px;
      }
      &.required::after{
        content: '*';
        color: #f00;
        margin: 0 0 0 6px;
      }
    }
  }
</style>
