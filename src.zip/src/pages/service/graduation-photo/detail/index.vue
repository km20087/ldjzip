<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="毕业照" />
    <div class="haed-bar">
      <div class="head-title van-multi-ellipsis--l2">{{ detailData.graduationTitle }}</div>
      <div class="time">发布时间：{{ detailData.updateTime }}</div>
    </div>
    <div v-html="detailData.content" class="news-cont"></div>
    <van-image-preview v-model:show="showPreviewImage" :images="previewImage" :show-index="false" />
  </main>
</template>

<script setup lang="ts">
  import { ref, watchEffect } from 'vue'
  import { useRoute } from 'vue-router'
  import { fetchCulturalProductDetail } from '@/api/cultural-product'
  import { useGoBack } from '@/hooks/useGoBack'
  import { Base64 } from 'js-base64'
  import { useNewsPreviewImage } from '@/hooks/useNewsPreviewImage'
  import {graduationPhotoDetail} from "@/api/graduationPhoto"
  const { showPreviewImage, previewImage } = useNewsPreviewImage('.news-cont')

  const { goBack } = useGoBack()
  const route = useRoute()

  const detailData = ref<Partial<graduationData>>({})

  watchEffect(() => {
    let { id } = route.query
    if (!id) return
    getDetailData(id as string)
  })

  async function getDetailData(id: string) {
    try {
      const { code, data, msg } = await graduationPhotoDetail({ id })
      if (code == 200) {
        detailData.value = {
          ...data,
          // updateTime: data.updateTime ? data.updateTime.slice(0, 10) : '',
          content: data.content
            ? decodeURIComponent(
                Base64.decode(Base64.decode(Base64.decode(Base64.decode(data.content))))
              ).replace(/<img/gi, "<img style='width:100%;height:100%'")
            : '',
        }
      }
    } catch (err) {
      console.log('getDetailData err', err)
    }
  }

  const timeTranslate = (val:number)=>{
    let date1 = new Date(val)
    let year = date1.getFullYear()
    let month = date1.getMonth() + 1
    let day = date1.getDate()
    let hours = date1.getHours()
    let min = date1.getMinutes()
    return year + "-" + month + "-" + day + "-" + " " + hours + ":" + min
    // console.log(date1.toString(),year,month,day,hours)
  }

</script>

<style lang="less" scoped>
  .haed-bar {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 30px;
    .head-title {
      font-size: 36px;
      font-weight: 600;
      color: #333;
    }
    .time {
      margin: 20px 0 0;
      font-size: 24px;
      color: #999;
    }
  }
  .news-cont {
    padding: 0 30px;
  }
</style>
