<template>
    <van-nav-bar title="预约返校" left-text="" left-arrow @click-left="onClickLeft" />  
    <div class='con'>
        <div class='banner'>
            <fix-image :src="bannerData" :defaultSrc="alumniBanner" class="imgs" width="750" height="350" />
        </div>
        <div class='whiteCon'>
            <div class='white'>
                <div class='first'>
                    <div class='title'>
                        左右翻页查看下一条数据
                    </div>
                    <div class='qrCodeShow'>
                        <div class='left' @click="showNext('left')">
                            <img :src='leftPage' class='imsIcon'/>
                        </div>
                        <div class='qrcode'>
                            <img :src='currentInfo.qrCode' class='ims'/>
                            <div class="gray" v-if='currentInfo.expired'>
                                <img :src='warning' class='grayims'/>
                                <div class='out'>
                                    已过期
                                </div>
                            </div>                            
                        </div>

                        <div class='left' @click="showNext('right')">
                            <img :src='rightPage' class='imsIcon'/>
                        </div>
                    </div>
                    <div class='page'>
                        {{currentPage}}/{{pageNum}}
                    </div>

                </div>
                <div class='second'>
                    <div class='perInfo'>
                        <div class='label'>预约人</div>
                        <div class='show'>{{currentInfo.returningPersonnelName}}</div>
                    </div>
                    <div class='perInfo'>
                        <div class='label'>证件类型</div>
                        <div class='show'>身份证</div>
                    </div>
                    <div class='perInfo'>
                        <div class='label'>证件号码</div>
                        <div class='show'>{{currentInfo.cardNumber}}</div>
                    </div>
                    <div class='perInfo'>
                        <div class='label'>预约时间</div>
                        <div class='show'>{{currentInfo.returningStartTime}}至{{currentInfo.returningEndTime}}</div>
                    </div>
                    <div class='perInfo'>
                        <div class='label'>预约状态</div>
                        <div class='show' :class="currentInfo.expired?'useless':'useful'">{{currentInfo.expired?'已过期':'未过期'}}</div>
                    </div>
                    <div class='tipsA'>
                       温馨提示：凭此二维码进出校园，无需携带身份证件
                    </div>                                                                                
                </div>
            </div>
            <div class='button'>
              <!-- class='toe' -->
                <van-button round type='primary'  size='large' @click='onClickLeft'>
                    返 回
                </van-button>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
import { useRouter, useRoute } from "vue-router";
import Api, { returnSchoolList, returnSchoolDetail } from "@/api/servive";
import warning from "@/assets/appointment/warning.png";
import leftPage from "@/assets/appointment/leftPage.png";
import rightPage from "@/assets/appointment/rightPage.png";
import alumniBanner from "@/assets/img/alumniBanner.png";
import side from "@/assets/appointment/side.png";
import { getPictures } from "@/utils";

const pageNum = ref(0);
const currentPage = ref(1);
const router = useRouter();
const route = useRoute();
const returningSchoolId = ref("");
const dataList = ref([] as any);
const currentInfo = <any>ref({});
const bannerData = ref("");
const onClickLeft = () => {
  router.back();
};

const initBackUrl = async () => {
  getPictures("returnSchoolBanner").then(
    (result: ImageList) =>
      (bannerData.value = result.images.length
        ? result.images[0].fileAddress
        : "")
  );
};
const initDetail = async () => {
  const { data, code, msg } = await returnSchoolDetail({
    returningSchoolId: returningSchoolId.value
  });
  if (code == 200) {
    dataList.value = dataList.value.concat(data);
    pageNum.value = dataList.value.length;
    currentInfo.value = dataList.value[0] as any;
    console.log(currentInfo.value);
  }
};
const showNext = (val: string) => {
  if (val == "left") {
    if (currentPage.value > 1) {
      currentPage.value = currentPage.value - 1;
    }
  } else {
    if (currentPage.value < pageNum.value) {
      currentPage.value = currentPage.value + 1;
    }
  }
  currentInfo.value = dataList.value[currentPage.value - 1];
};
onMounted(async () => {
  // console.log(route.query.returningSchoolId)
  returningSchoolId.value = route.query.returningSchoolId as string;
  await initDetail();
  await initBackUrl();
  console.log(bannerData.value);
});
</script>
<style lang='less' scoped>
.con {
  width: 100%;
  height: 100%;
  .banner {
    width: 100%;
    height: 350px;
    .imgs {
      width: 100%;
      height: 350px;
      object-fit: cover;
    }
  }
  .whiteCon {
    width: 100%;
    height: 100%;
    background-color: #e7f6ff;
    .white {
      width: 84%;
      background-color: #ffffff;
      border-radius: 16px;
      position: relative;
      top: -30px;
      left: 50%;
      transform: translate(-50%, 0%);
      box-shadow: 0px 0px 8px 0px rgba(5, 112, 201, 0.08);
      .first {
        width: 100%;
        padding: 30px 25px;
        display: flex;
        flex-direction: column;
        align-items: center;
        border-bottom: 1px dashed #e6eaeb;

        .title {
          font-size: 24px;
          font-weight: 400;
          color: #666666;
          font-family: PingFang-SC-Medium, PingFang-SC;
          padding-bottom: 27px;
        }
        .qrCodeShow {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-bottom: 18px;
          .left {
            // width: 66px;
            // height: 66px;
            background-color: #f0f6fb;
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
          }
          .imsIcon {
            width: 44px;
            height: 44px;
          }
        }
        .page {
          font-size: 24px;
          font-weight: 400;
          color: #666666;
          font-family: PingFang-SC-Medium, PingFang-SC;
          // padding-bottom: 30px;
        }

        .qrcode {
          width: 330px;
          height: 330px;
          background: url("@/assets/appointment/side.png") no-repeat;
          background-position: center;
          background-size: cover;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          position: relative;
          .ims {
            width: 315px;
            height: 315px;
          }
        }
        .gray {
          width: 315px;
          height: 315px;
          background: rgba(0, 0, 0, 0.7);
          position: absolute;
          left: 7px;
          top: 7px;
          .grayims {
            position: absolute;
            width: 70px;
            height: 70px;
            left: 50%;
            top: 40%;
            transform: translate(-50%, -50%);
          }
          .out {
            position: absolute;
            left: 50%;
            top: 60%;
            transform: translate(-50%, -50%);
            font-size: 30px;
            font-family: PingFang-SC-Medium, PingFang-SC;
            font-weight: 500;
            color: #ffffff;
          }
        }
      }
      .second {
        width: 100%;
        padding: 30px 50px;
        .perInfo {
          width: 100%;
          display: flex;
          justify-content: space-between;
          padding-bottom: 24px;
          align-items: center;
          .label {
            font-size: 28px;
            font-weight: 400;
            color: #666666;
            font-family: PingFang-SC-Medium, PingFang-SC;
          }
          .show {
            font-size: 28px;
            font-weight: 400;
            color: #222222;
            font-family: PingFang-SC-Medium, PingFang-SC;
          }
          .useless {
            color: #f00923;
          }
          .useful {
            color: #17b205;
          }
        }
        .perInfo:last-child {
          padding-bottom: 0px;
        }
        .tipsA {
          width: 100%;
          // height: 57px;
          background: #fff2f2;
          padding: 7px 10px;
          box-sizing: border-box;
          // display: flex;
          // justify-content: center;
          // align-items: center;
          font-size: 22px !important;
          color: #ca0000;
        }
      }
    }
    .button {
      width: 100%;
      margin: 0 auto;
      padding: 0 60px;
      .toe {
        background-color: #1989fa;
        border: #1989fa;
      }
    }
  }
}
</style>
