<template>
    <van-nav-bar title="" left-text="" left-arrow @click-left="onClickLeft" />
    <div class='con'>
        <div class='title'>
            预约返校
        </div>
        <div class='choice'>
            <div class='item mar50' @click="jumpUrl('1')">
                <div class='part1'>
                    <img :src="createBackSchool" class='ims1' />
                    <span class='spFont'>新建预约返校</span>
                </div>
                <img :src="rightArraw" class='ims2' />
            </div>
            <div class='item' @click="jumpUrl('2')">
                <div class='part1'>
                    <img :src="backSchoolRecord" class='ims1' />
                    <span class='spFont'>预约记录</span>
                </div>

                <img :src="rightArraw" class='ims2' />
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
import createBackSchool from '@/assets/img/createBackSchool.png';
import backSchoolRecord from '@/assets/img/backSchoolRecord.png';
import rightArraw from '@/assets/img/rightArraw.png';
import { isLiaoShiDa } from '@/utils/customizedType';
import { useRouter, useRoute } from "vue-router";
const router = useRouter();
const jumpUrl = (val: string) => {
    let fun = isLiaoShiDa() ? router.push({ path: '/backSchool-ln' }) : router.push({ path: '/backSchool' })
    if (val == '1') {
        fun
    } else {
        router.push({ path: '/backSchoolList' });
    }
}
const onClickLeft = () => {
    router.back();
};
</script>

<style lang='less' scoped>
.mar50 {
    margin-bottom: 50px;
}

.con {
    width: 100%;
    height: 100%;
    padding: 0px 32px;
    padding-top: 79px;
}

.title {
    font-size: 40px;
    font-weight: 500;
    color: #000000;
    // line-height:36px;
    font-family: PingFang-SC-Medium, PingFang-SC;
}

.choice {
    margin-top: 49px;
    width: 100%;

    .item {
        width: 100%;
        height: 160px;
        background: #FFFFFF;
        box-shadow: 0px 2px 14px 0px rgba(0, 0, 0, 0.08);
        border-radius: 16px;
        display: flex;
        padding: 0px 44px 0px 32px;
        align-items: center;
        justify-content: space-between;

        .part1 {
            // width:100%;
            height: 100%;
            display: flex;
            align-items: center;
        }

        // justify-content:space-around;
        .spFont {
            margin-left: 44px;
            font-size: 36px;
            font-weight: 500;
            color: #3f547f;
            font-family: PingFang-SC-Medium, PingFang-SC;
        }

        .ims1 {
            width: 100px;
            height: 100px;
        }

        .ims2 {
            width: 44px;
            height: 44px;
        }
    }
}
</style>

