<template>
    <div class="cont">
        <nav-bar-2 left-arrow @click-left="goBack" title="校友信息审批" />
        <van-form input-align="right">
            <van-field readonly required name="area" label="姓名" />
            <van-field readonly required name="area" label="证件类型" />
            <van-field readonly required name="area" label="身份证号" />
            <van-field readonly required name="area" label="手机号" />
            <van-field readonly required name="area" label="省市" />
            <van-field readonly required name="area" label="单位名称" />
            <van-field readonly name="area" label="职务" />
            <van-field readonly required name="area" label="邮箱" />
        </van-form>

        <van-form input-align="right">
            <van-field readonly required name="area" label="入学年份" />
            <van-field readonly required name="area" label="毕业年份" />
            <van-field readonly required name="area" label="毕业时校名" />
            <van-field readonly required name="area" label="学院名称" />
            <van-field readonly required name="area" label="专业名称" />
            <van-field readonly name="area" label="班级" />
            <van-field readonly name="area" label="学号" />
            <van-field readonly required name="area" label="学历" />
            <van-field readonly name="area" label="毕业证件照">
                <template #input>
                    <fix-image src="" />
                </template>
            </van-field>
            <van-field readonly name="area" label="用户头像">
                <template #input>
                    <van-image :src='img'></van-image>
                </template>
            </van-field>
            <van-field readonly required name="area" label="校友会" />
        </van-form>

        <div class="down-check">
            <div class="title">请选择用户类型：</div>
            <div class="tips"><span style="color: #ff0000;">*注意：</span>通过审核自动成为校友身份，无需重复勾选！</div>
            <van-checkbox-group v-model="checkArr">
                <van-checkbox name="a">APP组织负责人</van-checkbox>
                <van-checkbox name="b">活动管理员</van-checkbox>
                <van-checkbox name="c">游客-常熟理工</van-checkbox>
                <van-checkbox name="d">校友-常熟理工学院</van-checkbox>
                <van-checkbox name="e">组织管理-常熟理工</van-checkbox>
                <van-checkbox name="f">学校管理员</van-checkbox>
            </van-checkbox-group>

        </div>

        <div class="btn-down">
            <van-row gutter="20" style="width: 100vw;">
                <van-col span="24" style="margin-bottom: 20px;">
                    <van-button round block color="#0570C9 ">通 过</van-button>
                </van-col>
                <van-col span="12">
                    <van-button round block color="#F59A23">转移校友会</van-button>
                </van-col>
                <van-col span="12">
                    <van-button round block color="#FA6262">拒 绝</van-button>
                </van-col>
            </van-row>
        </div>
    </div>
</template>
<script setup lang="ts">
import img from '@/assets/img/bacCard.png'
import { useGoBack } from '@/hooks/useGoBack';
const { goBack } = useGoBack();

const checkArr = ref<string[]>(['a', 'c'])
</script>
<style lang="less" scoped>
.cont {
    padding: 24px 30px;
    background-color: #f5f5f5;
    min-height: 100vh;

    .down-check {
        padding: 30px;
        background-color: #fff;
        border-radius: 16px;

        .title {
            font-size: 32px;
            color: #222222;
            font-weight: 500;
            margin-bottom: 24px;
        }

        .tips {
            font-size: 26px;
            color: #666666;
        }

        .van-checkbox {
            margin-top: 24px;
        }
    }

    .btn-down {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin: 80px 0;
    }
}

.van-form {
    border-radius: 16px;
    margin-bottom: 20px;
    overflow: hidden;
}
</style>