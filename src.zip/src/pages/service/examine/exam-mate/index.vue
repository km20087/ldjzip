<template>
    <div class="exam-list-cont">
        <nav-bar-2 left-arrow @click-left="goBack" title="校友信息审批" />
        <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
            <ExamList name="王德法" @on-jump="jumpfun()">
                <template #name-d>
                    <span class="classes">艺术学院雕塑1班</span>
                </template>
            </ExamList>
        </van-list>
    </div>
</template>
<script lang="ts" setup>
import ExamList from '../components/exam-list.vue';
import { getExamMateList } from '@/api/servive'
import { useGoBack } from '@/hooks/useGoBack';
const { goBack } = useGoBack();
const router = useRouter()

interface pageP {
    pageNum?: number
    pageSize?: number
}

const loading = ref(false);
const finished = ref(false);

const getList = async () => {
    const paramas: pageP = { pageNum: 1, pageSize: 10 }
    let { code, data, msg } = await getExamMateList(paramas)
}
const onLoad = () => {
    getList()
}
const jumpfun = () => {
    router.push({ path: 'mate-examine-detail' })

}
</script>
<style lang="less" scoped>
.exam-list-cont {
    padding: 24px 30px;
    background-color: #f5f5f5;
    min-height: 100vh;

    .classes {
        font-size: 24px;
        color: #666666;
    }
}
</style>