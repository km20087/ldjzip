<template>
    <div class="exam-list-cont">
        <nav-bar-2 left-arrow @click-left="goBack" title="预约返校审批" />
        <examList name="六六六" @onJump="jumpfun()">
            <template #name-r>
                <span class="classes">艺术学院雕塑1班</span>
            </template>
            <template #name-d>
                <div class="time">开始时间：2023-11-11 结束时间：2023-12-01</div>
            </template>
        </examList>
    </div>
</template>
<script lang="ts" setup>
import examList from '../components/exam-list.vue';
import { useGoBack } from '@/hooks/useGoBack';
const { goBack } = useGoBack();

const router = useRouter()
const jumpfun = () => {
    router.push({ path: '/return-examine-detail', query: {} })
}
</script>
<style lang="less" scoped>
.exam-list-cont {
    padding: 24px 30px;
    background-color: #f5f5f5;
    min-height: 100vh;

    .classes {
        font-size: 24px;
        color: #999;
    }

    .time {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 490px;
    }
}
</style>