<template>
    <div class="cont">
        <nav-bar-2 left-arrow @click-left="goBack" title="预约返校审批" />
        <van-form input-align="right">
            <van-field readonly required name="area" label="返校原因" />
            <van-field readonly required name="area" label="开始时间" />
            <van-field readonly required name="area" label="结束时间" />
            <van-field readonly required name="area" label="联系方式" />
            <van-field readonly name="area" label="学院" />
            <van-field readonly required name="area" label="同行人" />
            <van-field readonly name="area" label="同行人描述" />
            <van-field readonly required name="area" label="被访人" />
            <van-field readonly required name="area" label="被访人工号" />
            <van-field readonly name="area" label="到访单位" />
            <van-field readonly name="area" label="备注" />
        </van-form>
        <div class="btn-down">
            <van-button round block color="#FA6262" style="margin-right: 20px;">拒 绝</van-button>
            <van-button round block color="#0570C9">通 过</van-button>
        </div>
    </div>
</template>
<script setup lang="ts">
import { useGoBack } from '@/hooks/useGoBack';
const { goBack } = useGoBack();
</script>
<style lang="less" scoped>
.cont {
    padding: 24px 30px;
    background-color: #f5f5f5;
    min-height: 100vh;

    .btn-down {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin: 80px 0;
    }
}
</style>