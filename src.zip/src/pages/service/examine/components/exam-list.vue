<template>
    <div class="exam-list">
        <div class="list-l">
            <div class="name">{{ name }}
                <slot name="name-r" />
            </div>
            <!-- <div class="time">开始时间：2023-11-11 结束时间：2023-12-01</div> -->
            <slot name="name-d" />
        </div>
        <div class="list-r" @click="emits('on-jump')">审批</div>
    </div>
</template>
<script lang="ts" setup>
const emits = defineEmits(['on-jump']);
const props = withDefaults(defineProps<{
    name?: string
}>(), { name: '姓名' })
</script>
<style lang="less" scoped>
.flex {
    display: flex;
    align-items: center;
}



.exam-list {
    background: #FFFFFF;
    border-radius: 16px;
    padding: 32px;
    .flex();
    justify-content: space-between;

    .list-l {
        font-size: 24px;
        color: #666666;

        .time {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            max-width: 490px;
        }

        .name {
            font-size: 32px;
            color: #333333;
            font-weight: 500;
            margin-bottom: 20px;
            position: relative;

            .classes {
                font-size: 24px;
                color: #999;
            }

            &::before {
                content: '';
                height: 100%;
                width: 6px;
                background: url('@/assets/img/side-r@2x.png');
                background-repeat: no-repeat;
                background-size: 100% 100%;
                position: absolute;
                top: 0;
                left: -32px;
            }
        }
    }

    .list-r {
        background: #E1F2FF;
        border-radius: 30px;
        line-height: 60px;
        width: 126px;
        text-align: center;
        font-size: 30px;
        color: #0570C9;
        font-weight: 500;
    }
}
</style>