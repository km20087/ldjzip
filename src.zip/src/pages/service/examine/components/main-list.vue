<template>
    <div class="list" @click="jump">
        <div class="left">
            <van-image width="50" height="50" round :src="src" />
            <span class="label">{{ label }}</span>
        </div>
        <van-image width="22" height="22" :src="arrowIcon" />
    </div>
</template>
  
<script setup lang="ts">
import srcParams from '@/assets/img/examlist@2x.png'
import arrowIcon from '@/assets/img/arrow-r@2x.png'
const router = useRouter();
const props = withDefaults(
    defineProps<{
        src?: string;
        label?: string;
        path?: string;
    }>(),
    {
        src: srcParams,
        label: '校友信息审批',
        path: ''
    }
);
const jump = () => {
    router.push(props.path);
}
</script>
<style lang="less" scoped>
.flex {
    display: flex;
    align-items: center;
}

.list {
    margin-top: 50px;
    padding: 30px 32px;
    background: #FFFFFF;
    box-shadow: 0px 2px 14px 0px rgba(0, 0, 0, 0.08);
    border-radius: 16px;
    justify-content: space-between;
    .flex();

    .left {
        .flex();
    }

    .label {
        font-family: PingFangSC-Medium;
        font-size: 36px;
        color: #3F547F;
        letter-spacing: 0;
        line-height: 36px;
        font-weight: 500;
        padding-left: 35px;
    }
}
</style>