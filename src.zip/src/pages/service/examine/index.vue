<template>
    <div class="examlist-cont">
        <nav-bar-2 left-arrow @click-left="goBack" title="" />
        <div class="main">
            <div class="title">
                审核模块列表
            </div>
            <main-list v-for="item in list" :src="item.src" :label="item.label" :path="item.path" />
        </div>
    </div>
</template>
<script setup lang="ts">
import srcParams from '@/assets/img/examlist@2x.png'
import srcParams2 from '@/assets/img/examrecord@2x.png'
import mainList from './components/main-list.vue';
import { useGoBack } from '@/hooks/useGoBack';
const { goBack } = useGoBack();

interface par {
    src: string
    label: string
    path: string
}
const list = ref<Partial<par>[]>([{ src: srcParams, label: '校友信息审批', path: 'mate-examine' }, { src: srcParams2, label: '预约返校审批', path: 'return-examine' }])

</script>
<style lang="less" scoped>
.examlist-cont {
    min-height: 100vh;
    background: url("@/assets/img/examlist-bg.png");
    background-size: 100%;
    background-repeat: no-repeat;
    background-position: center center;

    .main {
        padding: 32px;

        .title {
            font-size: 40px;
            font-weight: 500;
            padding-top: 48px;
        }
    }
}
</style>