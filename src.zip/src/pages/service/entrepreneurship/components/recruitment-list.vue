<template>
  <div class="list-cont">
    <div class="left">
      <div class="title">{{ title }}</div>
      <div class="desc">
        <div class="company-name van-ellipsis">{{ desc }}</div>
        <span class="isMine" v-if="isSelf">本人发布</span>
      </div>
      <div>
        <span class="tag van-ellipsis">{{ tag }}</span>
      </div>
    </div>
    <div class="status">{{ statusTxt }}</div>
  </div>
</template>
<script setup lang="ts">
const statusTxt = ref('');

const prop = withDefaults(
  defineProps<{
    title?: string;
    desc?: string;
    tag?: string;
    status?: string;
    isSelf?: boolean;
  }>(),
  {
    title: '',
    desc: '',
    tag: '',
    status: '',
    isSelf: false,
  }
);
watch(
  () => prop.status,
  (val) => {
    if (val == '0') {
      statusTxt.value = '待审核';
    } else if (val == '1') {
      statusTxt.value = '审核通过';
    } else {
      statusTxt.value = '审核不通过';
    }
  }
);
</script>
<style lang="less" scoped>
.list-cont {
  background: #ffffff;
  border-radius: 16px;
  overflow: hidden;
  padding: 32px 24px;
  margin-bottom: 24px;
  position: relative;
  .title {
    font-size: 36px;
    color: #333333;
    font-weight: 500;
  }
  .desc {
    font-size: 26px;
    color: #666666;
    padding: 20px 0;
    display: flex;
    align-items: center;
    .company-name {
      // flex: 6;
      max-width: 320px;
      margin-right: 20px;
    }
    .isMine {
      // flex: 4;
      font-size: 24px;
      color: #ff8300;
      background: #fbe9d3;
      line-height: 36px;
      padding: 0 15px;
      border-radius: 5px;
    }
  }
  .tag {
    display: block;
    width: 100%;
    line-height: 40px;
  }
  .status {
    position: absolute;
    top: 0;
    right: 0;
  }
}
</style>