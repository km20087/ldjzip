<template>
  <main class="wrap detail-page">
    <nav-bar-2 left-arrow @click-left="goBack" title="创业创新详情" />
    <div class="detail-cont">
      <div class="postman">
        <div class="left">
          <div class="name">
            <div class="company-name">{{ detailData.recruitmentPosition }}</div>
            <span
              class="isMine"
              v-if="detailData.publisherFlag == '1' && detailData.auditStatus == '0'"
              >待审核</span
            >
            <span
              class="isMine audit1"
              v-if="detailData.publisherFlag == '1' && detailData.auditStatus == '1'"
              >审核通过</span
            >
            <div
              v-if="detailData.publisherFlag == '1' && detailData.auditStatus == '2'"
              style="display: flex; align-item: center"
            >
              <span class="isMine audit2">审核不通过</span
              ><van-icon color="#ff8300" size="18px" name="info" @click="showReason" />
            </div>
          </div>
          <div class="company-line">
            <van-image width="12px" height="12px" :src="compIcon"></van-image>
            <span>{{ detailData.projectName }}</span>
          </div>
        </div>
        <div class="right"></div>
      </div>
      <div class="detail-text">
        <div class="title">合作要求</div>
        <div class="text">{{ detailData.cooperationRequirements }}</div>
      </div>
      <div class="detail-text">
        <div class="title">联系方式</div>
        <div class="text">{{ detailData.contactDetails }}</div>
      </div>
    </div>
    <div class="detail-text2">
      <div class="title2">图片/视频({{ filesLen }})</div>
      <van-swipe
        :loop="false"
        :width="256"
        :height="179"
        :show-indicators="false"
        v-if="filesLen > 0"
      >
        <van-swipe-item v-for="(sitem, sindex) in detailData.photos" :key="sindex">
          <fix-image width="256" height="179" class="fixImg" :src="sitem"></fix-image>
        </van-swipe-item>
      </van-swipe>
    </div>
    <div class="operate-area" v-if="detailData.publisherFlag == '1'">
      <van-button color="var(--theme-color)" block round @click="onEdit">编辑</van-button>
      <van-button type="danger" block round plain @click="onDelete">删除</van-button>
    </div>
  </main>
</template>
  <script lang="ts" setup>
import { useGoBack } from '@/hooks/useGoBack';
import compIcon from '@/assets/icons/recruitment_comp@2x.png';
import { Dialog, Toast } from 'vant';
import servive from '@/api/servive';

const { goBack } = useGoBack();
const route = useRoute();
const router = useRouter();
let detailId = route.query;
let filesLen = ref(0);
let detailData = ref<any>({});

const getDetail = async () => {
  let { code, data, msg } = await servive.getEnterpriseDetail({ id: detailId });
  if (code == 200) {
    detailData.value = { ...data };
    for (let item in detailData.value) {
      if (item == 'photos') {
        if (!detailData.value[item]) {
          detailData.value[item] = [];
        } else {
          filesLen.value = detailData.value[item].length;
        }
      }
    }
    if (detailData.value['publisherFlag'] == '1' && detailData.value['rejectReason']) {
      Dialog({ title: '审核不通过', message: `拒绝原因：${detailData.value['rejectReason']}` });
    }
  } else {
    Toast.fail(msg);
  }
};
getDetail();
//弹出拒绝原因
const showReason = () => {
  if (detailData.value['rejectReason']) {
    Dialog({ title: '审核不通过', message: `拒绝原因：${detailData.value['rejectReason']}` });
  }
};
// const str =
//   '1、大恩大德啊违法违法；2、大伟大伟大额达哇额大鳄大伟大而发二大卫大卫；3、大二大卫大卫的安慰安慰发俄方阿德啊二大卫大卫发啊额达我的娃阿德阿文低洼埃尔多安挖的阿文。';
// let s = /^[1-9]([0-9]{0,2})[、].*/;
// let arr = str.split(s);
// console.log(arr, 'eee');
const onEdit = () => {
  router.push({
    name: 'createBusiness',
    query: { id: detailData.value.id, action: 'edit' },
  });
};
const onDelete = () => {
  Dialog.confirm({ title: '删除提示', message: '确认删除该条记录' })
    .then(async () => {
      let { code, msg, data } = await servive.deleteEnterprise({ id: detailId });
      if (code == 200) {
        Toast.success('删除成功！');
        router.push({ name: 'entrepreneurship' });
      } else {
        Toast.fail(msg);
      }
    })
    .catch((err) => {
      console.log(err);
    });
};
</script>
  <style lang="less" scoped>
.detail-page {
  padding-bottom: 138px;
}
.detail-cont {
  padding: 32px;
  .postman {
    padding-bottom: 40px;
    border-bottom: 1px solid #ededed;
    display: flex;
    justify-content: space-between;
    .left {
      flex: 8.5;
      .name {
        font-size: 40px;
        color: #333333;
        margin-bottom: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        .company-name {
          max-width: 320px;
          margin-right: 20px;
        }
        .isMine {
          font-size: 28px;
          line-height: 40px;
          padding: 0 20px;
          color: #3b98de;
          background: #d2e5f2;
          border-radius: 0 16px 0 16px;
          font-weight: 500px;
        }
        .audit1 {
          color: #0f9400;
          background: #ddefdb;
        }
        .audit2 {
          color: #df6472;
          background: #f8e5e7;
        }
      }
      .company-line {
        display: flex;
        align-items: center;
        font-size: 24px;
        color: #666666;
        margin: 10px 0;
        .van-image {
          margin-right: 10px;
        }
      }
    }
    .right {
      flex: 1.5;
      font-size: 36px;
      color: var(--theme-color);
      letter-spacing: 0;
      line-height: 36px;
      font-weight: 500;
      text-align: right;
    }
  }
  .detail-text {
    padding-top: 50px;
    .title {
      font-size: 36px;
      color: #333333;
      letter-spacing: 0;
      line-height: 36px;
      font-weight: 500;
      margin-bottom: 20px;
    }
    .text {
      font-size: 28px;
      line-height: 50px;
    }
  }
}
.detail-text2 {
  padding-top: 50px;
  padding-bottom: 40px;
  border-bottom: 1px solid #ebedf0;
  .title2 {
    font-size: 36px;
    color: #333333;
    letter-spacing: 0;
    line-height: 36px;
    font-weight: 500;
    margin-bottom: 30px;
    margin-left: 32px;
  }
}
.operate-area {
  display: flex;
  padding: 20px 32px;
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  border-top: 1px solid #f3f3f3;
  background: #fff;
  .van-button:first-of-type {
    margin-right: 20px;
  }
}
:deep(.van-swipe-item) {
  padding-left: 32px;
}
.fixImg {
  width: 100%;
  height: 100%;
  border-radius: 32px;
}
</style>