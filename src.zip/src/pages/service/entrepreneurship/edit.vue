<template>
  <div class="con">
    <nav-bar-2 left-arrow @click-left="goBack" title="创新创业" />
    <van-form @submit="onSubmit">
      <van-cell-group inset>
        <div class="label">创新创业项目名称</div>
        <van-field
          label=""
          v-model="query.projectName"
          :rules="[{ required: true, message: '请输入项目名称' }]"
          placeholder="请输入项目名称"
        >
        </van-field>
        <div class="label">招聘岗位</div>
        <van-field
          label=""
          v-model="query.recruitmentPosition"
          :rules="[{ required: true, message: '请输入招聘岗位' }]"
          placeholder="请输入招聘岗位"
        >
        </van-field>
        <div class="label">合作要求</div>
        <van-field
          label=""
          v-model="query.cooperationRequirements"
          type="textarea"
          :rules="[{ required: true, message: '请输入合作要求' }]"
          maxlength="500"
          rows="4"
          placeholder="请输入合作要求"
        >
        </van-field>
        <div class="label">职位联系方式</div>
        <van-field
          label=""
          v-model="query.contactDetails"
          :rules="[{ required: true, message: '请输入职位联系方式' }]"
          placeholder="请输入职位联系方式"
        >
        </van-field>
        <div class="label">图片</div>
        <van-field
          v-model="query.photo"
          readonly
          required
          name="photo"
          input-align="left"
          error-message-align="left"
        >
          <template #input>
            <compress-uploader
              v-model="photoList"
              max-count="9"
              :after-read="afterRead"
              :before-delete="beforeDelete"
            />
          </template>
        </van-field>
      </van-cell-group>
      <div style="margin: 16px">
        <van-button round block type="primary" native-type="submit"> 提交审核 </van-button>
      </div>
    </van-form>
  </div>
</template>
  <script lang="ts" setup>
import { useGoBack } from '@/hooks/useGoBack';
import { ref } from 'vue';
import ApiUpload from '@/api/uploadfile';
import api from '@/api/servive';
import { Toast } from 'vant';
import FileHandle from '@/utils/file-handle';
const { goBack } = useGoBack();
const router = useRouter();
const route = useRoute();
let detailId = ref<string>('');
let actionType = ref<'edit' | 'add'>('add');
const query = <any>ref({
  projectName: '',
  recruitmentPosition: '',
  cooperationRequirements: '',
  contactDetails: '',
  photos: [],
});
const photoList = ref([] as any[]);
const baseUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
const photosFile = new FileHandle(['photos']);
watch(
  () => route.query,
  (val: any) => {
    if (val.id) {
      detailId.value = val.id;
      getDetail();
    }
    if (val.action) {
      actionType.value = val.action;
    }
  },
  { immediate: true, deep: true }
);
//获取详情
async function getDetail() {
  let { code, data, msg } = await api.getEnterpriseDetail({ id: detailId.value });
  if (code == 200) {
    query.value = { ...query.value, ...data };
    photosFile.setOldFileUrls(query.value);
    query.value.photos.forEach((item: any) => {
      let url = baseUrl.value + item;
      photoList.value.push({ url });
    });
  } else {
    Toast.fail(msg);
  }
}
const beforeDelete = (_: any, { index }: { name: string; index: number }) => {
  query.value.photos.splice(index, 1);
  return true;
};
const afterRead = async (file: any) => {
  console.log('afterRead');
  let formData1 = new FormData();
  formData1.append('file', file.file);
  // formData.append('flag', 'Y');//加密上传
  file.status = 'uploading';
  file.message = '上传中...';
  await ApiUpload.uploadFile(formData1)
    .then((res) => {
      if (res.code == 200) {
        file.status = '';
        file.message = '';
        query.value.photos.push(res.data.uploadUrl);
        Toast.success('上传成功');
      } else {
        file.status = 'failed';
        file.message = '上传失败';
        Toast.fail(res.msg);
      }
    })
    .catch((err) => {
      file.status = 'failed';
      file.message = '上传失败';
      Toast.fail(`上传失败：${err}`);
    });
};
const onSubmit = async () => {
  if (actionType.value == 'edit') {
    query.value = { ...query.value, ...photosFile.compare(query.value) };
    let { code, data, msg } = await api.editEnterprise(query.value);
    if (code == 200) {
      Toast.success('编辑成功！');
      router.push({ name: 'entrepreneurship' });
    } else {
      Toast.fail(msg);
    }
  } else {
    let { code, data, msg } = await api.publishInnovationEnterpreneurship(query.value);
    if (code == 200) {
      Toast.success(msg);
      router.push({ name: 'entrepreneurship' });
    } else {
      Toast.fail(msg);
    }
  }
};
</script>
  <style lang="less" scoped>
.con {
  width: 100%;
  background: 100%;
  min-height: 100vh;
  //   van-field__body
  :deep(.van-cell) {
    padding: 0px;
  }
  :deep(.van-field__body) {
    padding: var(--van-cell-vertical-padding) var(--van-cell-horizontal-padding);
    border: 1px solid #dfdfdf;
    border-radius: 4px;
    width: 95%;
    margin-left: 15px;
    background-color: #ffffff;
    // border-bottom: 0px;
  }
  :deep(.van-field__error-message) {
    padding: var(--van-cell-vertical-padding);
  }
}
.label {
  font-size: 32px;
  font-weight: 900;
  color: #333333;
  padding: var(--van-cell-vertical-padding) var(--van-cell-horizontal-padding);
}
</style>