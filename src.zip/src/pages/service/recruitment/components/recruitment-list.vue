<template>
  <div class="list-cont">
    <div class="left">
      <div class="title">{{ title }}</div>
      <div class="desc">
        <div class="company-name van-ellipsis">{{ desc }}</div>
        <span class="isMine" v-if="isSelf">本人发布</span>
      </div>
      <div>
        <span class="tag" v-for="(item, index) in tag" :key="index">{{ item }}</span>
      </div>
    </div>
    <div class="right">{{ money }}</div>
  </div>
</template>
<script setup lang="ts">
const prop = withDefaults(
  defineProps<{
    title?: string;
    desc?: string;
    tag?: any;
    money?: string;
    isSelf?: boolean;
  }>(),
  {
    title: '',
    desc: '',
    tag: [],
    money: '',
    isSelf: false,
  }
);
</script>
<style lang="less" scoped>
.list-cont {
  background: #ffffff;
  border-radius: 16px;
  overflow: hidden;
  padding: 32px 24px;
  margin-bottom: 24px;
  display: flex;
  justify-content: space-between;
  .title {
    font-size: 36px;
    color: #333333;
    font-weight: 500;
  }
  .desc {
    font-size: 26px;
    color: #666666;
    padding: 20px 0;
    display: flex;
    align-items: center;
    .company-name {
      // flex: 6;
      max-width: 320px;
      margin-right: 20px;
    }
    .isMine {
      // flex: 4;
      font-size: 24px;
      color: #ff8300;
      background: #fbe9d3;
      line-height: 36px;
      padding: 0 15px;
      border-radius: 5px;
    }
  }
  .tag {
    display: inline-block;
    line-height: 40px;
    padding: 0 14px;
    background: #f5f5f5;
    border-radius: 8px;
    margin-right: 20px;
  }
  .right {
    font-size: 36px;
    font-weight: 500;
    color: var(--theme-color);
  }
}
</style>