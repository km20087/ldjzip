<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="企业招聘" />
    <div class="recruitment-cont">
      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list
          v-model:loading="loading"
          :finished="finished"
          finished-text="没有更多了"
          v-model:error="error"
          error-text="请求失败，点击重新加载"
          @load="onLoad"
        >
          <recruitmentList
            v-for="item in dataList"
            :key="item.id"
            :title="item.recruitmentPosition"
            :desc="item.enterpriseName"
            :tag="[item.educationRequirements, item.workingExperience, item.salary]"
            :money="item.salary"
            :is-self="item.publisherFlag == '1' ? true : false"
            @click="toDetail(item.id)"
          />
        </van-list>
      </van-pull-refresh>
      <div class="btn" v-if="schoolmateType == '3'">
        <van-button block round color="var(--theme-color)" @click="toRelease"
          >发布招聘信息</van-button
        >
      </div>
    </div>
  </main>
</template>
<script lang="ts" setup>
import { useGoBack } from '@/hooks/useGoBack';
import recruitmentList from './components/recruitment-list.vue';
import servive from '@/api/servive';
import { Toast } from 'vant';

const router = useRouter();
let page = ref({ pageNum: 1, pageSize: 10 });
const error = ref(false);
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const dataList = ref<any[]>([]);

let schoolmateType = computed(() => {
  return sessionStorage.getItem('schoolmateType');
});
const goBack = () => {
  router.push({ name: 'service' });
};
const onLoad = () => {
  getList().catch(() => {
    error.value = true;
  });
};
const onRefresh = () => {
  // 清空列表数据
  finished.value = false;

  // 重新加载数据
  // 将 loading 设置为 true，表示处于加载状态
  loading.value = true;
  page.value.pageNum = 1;
  dataList.value = [];
  onLoad();
};
const getList = async () => {
  let { data, code, msg } = await servive.getRecruitmentList({ ...page.value });
  if (code == 200) {
    dataList.value = dataList.value.concat(data.list);
    page.value.pageNum++;
    loading.value = false;
    if (dataList.value.length >= data.total) {
      finished.value = true;
    }
    refreshing.value = false;
  } else {
    Toast.fail(msg);
    finished.value = true;
  }
};
const toDetail = (id: string) => {
  router.push({ name: 'recruitment-detail', query: { id } });
};
const toRelease = () => {
  router.push({ name: 'recruitInpByEnterprise' });
};
</script>
<style lang="less" scoped>
.recruitment-cont {
  background: #f5f5f5;
  padding: 30px 30px 80px;
  min-height: 100vh;
  overflow-y: scroll;
  .btn {
    width: 690px;
    position: fixed;
    bottom: 20px;
  }
}
</style>