<template>
  <main class="wrap detail-page">
    <nav-bar-2 left-arrow @click-left="goBack" title="企业招聘详情" />
    <div class="detail-cont">
      <div class="postman">
        <div class="left">
          <div class="name">
            <div class="company-name">{{ detailData.recruitmentPosition }}</div>
            <span
              class="isMine"
              v-if="detailData.publisherFlag == '1' && detailData.auditStatus == '0'"
              >待审核</span
            >
            <span
              class="isMine audit1"
              v-if="detailData.publisherFlag == '1' && detailData.auditStatus == '1'"
              >审核通过</span
            >
            <div
              v-if="detailData.publisherFlag == '1' && detailData.auditStatus == '2'"
              style="display: flex; align-item: center"
            >
              <span class="isMine audit2">审核不通过</span
              ><van-icon color="#ff8300" size="18px" name="info" @click="showReason" />
            </div>
          </div>
          <div class="company-line">
            <van-image width="12px" height="12px" :src="compIcon"></van-image>
            <span>{{ detailData.enterpriseName }}</span>
          </div>
          <div class="company-line">
            <van-image width="12px" height="12px" :src="addrIcon"></van-image>
            <span>{{ detailData.companyAddress }}</span>
          </div>
        </div>
        <div class="right"> {{ detailData.salary }} </div>
      </div>
      <div class="detail-text">
        <div class="title">职位详情</div>
        <div class="text">{{ detailData.jobDuties }}</div>
      </div>
      <div class="detail-text">
        <div class="title">任职要求</div>
        <div class="text">{{ detailData.jobRequirements }}</div>
      </div>
      <div class="detail-text">
        <div class="title">工作地点</div>
        <div class="text">{{ detailData.workplace }}</div>
      </div>
      <div class="detail-text">
        <div class="title">薪酬范围</div>
        <div class="text">{{ detailData.salary }}</div>
      </div>
      <div class="detail-text">
        <div class="title">经验和学历要求</div>
        <div class="text"
          >{{ detailData.workingExperience }},{{ detailData.educationRequirements }}</div
        >
      </div>
      <div class="detail-text">
        <div class="title">联系方式</div>
        <div class="text">{{ detailData.contactDetails }}</div>
      </div>
    </div>
    <div class="detail-text2">
      <div class="title2">图片/视频({{ filesLen }})</div>
      <van-swipe
        :loop="false"
        :width="256"
        :height="179"
        :show-indicators="false"
        v-if="filesLen > 0"
      >
        <van-swipe-item v-for="(sitem, sindex) in detailData.photos" :key="sindex">
          <fix-image width="256" height="179" class="fixImg" :src="sitem"></fix-image>
        </van-swipe-item>
      </van-swipe>
    </div>
    <div class="operate-area" v-if="detailData.publisherFlag == '1'">
      <van-button color="var(--theme-color)" block round @click="onEdit">编辑</van-button>
      <van-button type="danger" block round plain @click="onDelete">删除</van-button>
    </div>
  </main>
</template>
  <script lang="ts" setup>
import { useGoBack } from '@/hooks/useGoBack';
import addrIcon from '@/assets/icons/recruitment_addr@2x.png';
import compIcon from '@/assets/icons/recruitment_comp@2x.png';
import servive from '@/api/servive';
import { Dialog, Toast } from 'vant';

const { goBack } = useGoBack();
const route = useRoute();
const router = useRouter();
let detailId = route.query;
let detailData = ref<any>({});
let filesLen = ref(0);

const getDetail = async () => {
  let { code, data, msg } = await servive.getRecruitmentDetail({ id: detailId });
  if (code == 200) {
    detailData.value = { ...data };
    for (let item in detailData.value) {
      if (item == 'photos') {
        if (!detailData.value[item]) {
          detailData.value[item] = [];
        } else {
          filesLen.value = detailData.value[item].length;
        }
      }
    }
    if (detailData.value['publisherFlag'] == '1' && detailData.value['rejectReason']) {
      Dialog({ title: '审核不通过', message: `拒绝原因：${detailData.value['rejectReason']}` });
    }
  } else {
    Toast.fail(msg);
  }
};
getDetail();
//弹出拒绝原因
const showReason = () => {
  if (detailData.value['rejectReason']) {
    Dialog({ title: '审核不通过', message: `拒绝原因：${detailData.value['rejectReason']}` });
  }
};
const onEdit = () => {
  router.push({
    name: 'recruitInpByEnterprise',
    query: { id: detailData.value.id, action: 'edit' },
  });
};
const onDelete = () => {
  Dialog.confirm({ title: '删除提示', message: '确认删除该条记录' })
    .then(async () => {
      let { code, msg, data } = await servive.deleteRecruitment({ id: detailId });
      if (code == 200) {
        Toast.success('删除成功！');
        router.push({ name: 'recruitment' });
      } else {
        Toast.fail(msg);
      }
    })
    .catch((err) => {
      console.log(err);
    });
};
</script>
  <style lang="less" scoped>
.detail-page {
  padding-bottom: 138px;
}
.detail-cont {
  padding: 32px;
  padding-bottom: 50px;
  .postman {
    padding-bottom: 40px;
    border-bottom: 1px solid #ededed;
    display: flex;
    justify-content: space-between;
    .left {
      flex: 8;
      .name {
        font-size: 40px;
        color: #333333;
        margin-bottom: 14px;
        font-weight: 500;
        display: flex;
        align-items: center;
        .company-name {
          max-width: 320px;
          margin-right: 20px;
        }
        .isMine {
          font-size: 28px;
          line-height: 40px;
          padding: 0 20px;
          color: #3b98de;
          background: #d2e5f2;
          border-radius: 0 16px 0 16px;
          font-weight: 500px;
        }
        .audit1 {
          color: #0f9400;
          background: #ddefdb;
        }
        .audit2 {
          color: #df6472;
          background: #f8e5e7;
          margin-right: 10px;
        }
      }
      .company-line {
        display: flex;
        align-items: center;
        font-size: 24px;
        color: #666666;
        margin: 10px 0;
        .van-image {
          margin-right: 10px;
        }
      }
    }
    .right {
      flex: 2;
      font-size: 36px;
      color: var(--theme-color);
      letter-spacing: 0;
      line-height: 36px;
      font-weight: 500;
      text-align: right;
    }
  }
  .detail-text {
    padding-top: 50px;
    .title {
      font-size: 36px;
      color: #333333;
      letter-spacing: 0;
      line-height: 36px;
      font-weight: 500;
      margin-bottom: 20px;
    }
    .text {
      font-size: 28px;
      line-height: 50px;
    }
  }
}
.detail-text2 {
  padding-top: 50px;
  padding-bottom: 40px;
  border-bottom: 1px solid #ebedf0;
  .title2 {
    font-size: 36px;
    color: #333333;
    letter-spacing: 0;
    line-height: 36px;
    font-weight: 500;
    margin-bottom: 30px;
    margin-left: 32px;
  }
}
.operate-area {
  display: flex;
  padding: 20px 32px;
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  border-top: 1px solid #f3f3f3;
  background: #fff;
  .van-button:first-of-type {
    margin-right: 20px;
  }
}
:deep(.van-swipe-item) {
  padding-left: 32px;
}
.fixImg {
  width: 100%;
  height: 100%;
  border-radius: 32px;
}
</style>