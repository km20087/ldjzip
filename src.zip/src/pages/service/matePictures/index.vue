<template>
  <van-nav-bar :title="title" left-text="" left-arrow @click-left="onClickLeft" />
  <div class="picCard-list">
    <van-list
      v-model:loading="loading"
      :finished="finished"
      finished-text="没有更多了"
      v-model:error="error"
      error-text="请求失败，点击重新加载"
      :offset="50"
      @load="onLoad"
    >
      <div class="list-cont">
        <addpicCard @jumpAddOrEditPhoto="jumpAdd" v-if="schoolAdmin" />
        <picturesCard
          v-for="(item, index) in albumList"
          :key="index"
          :src="item.coverImage || photoNone"
          :name="item.albumName"
          :thumbsUpCount="item.thumbsUpCount"
          :number="item.photosCount"
          @jumpAlubmList="jumpAluList(item)"
          @touchStart="touchStart($event, item)"
          @touchEnd="touchEnd"
        />
      </div>
    </van-list>
  </div>
  <div class="picNone" v-if="!schoolAdmin && albumList.length == 0">
    <img :src="photoNone" alt="" class="ims" />
    <div class="poa"> 暂无相册 </div>
  </div>
</template>


<script lang='ts'>
import { defineComponent } from 'vue';
export default defineComponent({
  beforeRouteEnter(to: any, from: any) {
    console.log('RouterWeb');
    console.log(from);
    if (from.path == '/tab/index') {
      sessionStorage.setItem('backUrl', '1');
    } else if (from.path == '/tab/service') {
      sessionStorage.setItem('backUrl', '2');
    }
  },
});
</script>

<script lang="ts" setup>
import { reactive, ref } from 'vue';
import photoNone from '@/assets/img/photoNone.png';
import picturesCard from '@/components/picCom/picturesCard.vue';
import addpicCard from '@/components/picCom/addpicCard.vue';
import { schoolConfig } from '@/hooks/schoolConfig';
import Api from '@/api/orgPhoto';
import { albumParam, rightCon } from '@/store';
import { Toast } from 'vant';
const setAlbumParam = albumParam();
const setServiceRight = rightCon();
const $router = useRouter();
interface albumP {
  address: string;
  albumId: string;
  albumName: string;
  coverImage: string;
  clickCount: string;
  albumType: string;
  permissionScope: string;
  photosCount: string;
  thumbsUpCount: string;
}
const title = ref('');
const error = ref(false);
const loading = ref(false);
const finished = ref(false);
const isLastPageb = ref(false);
const refreshing = ref(false);
const schoolAdmin = ref(false);
const timeOutEvent = <any>ref('');
const listP = ref({
  pageNum: 0,
  pageSize: 5,
});
const albumList = ref([] as Array<albumP>);
const initData = async () => {
  loading.value = true;
  const { data, code, msg } = await Api.listAlbum({
    groupsId: '',
    albumType: '1',
    pageNum: listP.value.pageNum,
    pageSize: listP.value.pageSize,
  });
  if (listP.value.pageNum == 1) {
    albumList.value = [];
  }
  if (code == 200) {
    isLastPageb.value = data.isLastPage;
    loading.value = false;
    albumList.value = albumList.value.concat(data.list);
    // albumList.value = data.list;
  } else {
    Toast({
      message: msg,
      icon: 'none',
    });
  }
  if (isLastPageb.value) {
    loading.value = false;
    finished.value = true;
  }
};
const initPer = async () => {
  const { data, code, msg } = await Api.isSchoolAdmin({});
  schoolAdmin.value = data;
  if (schoolAdmin.value) {
    setServiceRight.serviceR = '1';
    setServiceRight.orgR = '0';
  } else {
    setServiceRight.serviceR = '0';
    setServiceRight.orgR = '0';
  }
};
const jumpAdd = () => {
  setAlbumParam.type = '0';
  $router.push({
    path: '/orgAlubm',
    query: { type: 'add', groupsId: '', from: 'service' },
  });
};
const touchStart = (e: any, item: any) => {
  if (!schoolAdmin.value) {
    return;
  }
  timeOutEvent.value && clearTimeout(timeOutEvent.value);
  timeOutEvent.value = setTimeout(() => {
    // showSelect.value = true;
    // console.log(showSelect.value);
    // console.log('touchStart');
    $router.push({
      path: '/orgAlubm',
      query: {
        albumId: item.albumId,
        albumName: item.albumName,
        groupsId: item.groupsId,
        permissionScope: item.permissionScope,
        type: 'edit',
      },
    });
  }, 500);

  // e.preventDefault();
};
const onClickLeft = () => {
  let a = sessionStorage.getItem('backUrl');
  // $router.push({ path: a });
  // $router.go(-1);
  if (a == '1') {
    $router.push({ path: '/tab/index' });
  } else if (a == '2') {
    $router.push({ path: '/tab/service' });
  } else {
    $router.go(-1);
  }
};
const touchEnd = () => {
  if (!schoolAdmin.value) {
    return;
  }
  timeOutEvent.value && clearTimeout(timeOutEvent.value);
};
const jumpAluList = (value: albumP) => {
  setAlbumParam.permissionScope = value.permissionScope;
  $router.push({
    path: '/alubmList',
    query: {
      albumId: value.albumId,
      albumName: value.albumName,
      // type: 'servive',
    },
  });
};
interface titleConfig {
  title: string;
}
const onLoad = async () => {
  if (!isLastPageb.value && loading.value) {
    finished.value = false;
    listP.value.pageNum = (listP.value.pageNum as number) + 1;
    // await init();
    await initData();
  } else {
    loading.value = false;
    finished.value = true;
  }
};
onMounted(async () => {
  let a = schoolConfig('matePictures') as unknown as titleConfig;
  title.value = a.title as string;
  setAlbumParam.type = '0';
  await initPer();
  // await initData();
});
// onBeforeRouteLeave
// $router.beforeEnter(async (to, _from, next) => {
//   console.log("RouterWeb");
//   console.log(_from);
//   next();
// });
</script>

<style lang="less" scoped>
.picNone {
  // width: 100%;
  // height: 100%;
  text-align: center;
  // background: #f5f5f5;
  .poa {
    // font-size: 28px;
    padding: 42px;
    // font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 500;
    // color: #999999;
  }
  .ims {
    width: 300px;
    height: 300px;
  }
}
.list-cont {
  padding: 30px;
  display: flex;
  // align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
}
:deep(.van-list__finished-text) {
  width: 100%;
}
.picCard-list {
  width: 100%;
  overflow-y: scroll;
}
</style>
