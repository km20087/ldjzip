<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="文创产品" />
    <div class="haed-bar">
      <div class="head-title van-multi-ellipsis--l2">{{ detailData.title }}</div>
      <div class="time">发布时间：{{ detailData.updateTime }}</div>
    </div>
    <div v-html="detailData.detail" class="news-cont"></div>
    <van-image-preview v-model:show="showPreviewImage" :images="previewImage" :show-index="false" />
  </main>
</template>

<script setup lang="ts">
  import { ref, watchEffect } from 'vue'
  import { useRoute } from 'vue-router'
  import { fetchCulturalProductDetail } from '@/api/cultural-product'
  import { useGoBack } from '@/hooks/useGoBack'
  import { Base64 } from 'js-base64'
  import { useNewsPreviewImage } from '@/hooks/useNewsPreviewImage'

  const { showPreviewImage, previewImage } = useNewsPreviewImage('.news-cont')

  const { goBack } = useGoBack()
  const route = useRoute()

  const detailData = ref<Partial<CulturalProduct>>({})

  watchEffect(() => {
    let { id } = route.query
    if (!id) return
    getDetailData(id as string)
  })

  async function getDetailData(id: string) {
    try {
      const { code, data, msg } = await fetchCulturalProductDetail({ id })
      if (code == 200) {
        detailData.value = {
          ...data,
          updateTime: data.updateTime ? data.updateTime.slice(0, 10) : '',
          detail: data.detail
            ? decodeURIComponent(
                Base64.decode(Base64.decode(Base64.decode(Base64.decode(data.detail))))
              ).replace(/<img/gi, "<img style='width:100%;height:100%'")
            : '',
        }
      }
    } catch (err) {
      console.log('getDetailData err', err)
    }
  }
</script>

<style lang="less" scoped>
  .haed-bar {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 30px;
    .head-title {
      font-size: 36px;
      font-weight: 600;
      color: #333;
    }
    .time {
      margin: 20px 0 0;
      font-size: 24px;
      color: #999;
    }
  }
  .news-cont {
    padding: 0 30px;
  }
</style>
