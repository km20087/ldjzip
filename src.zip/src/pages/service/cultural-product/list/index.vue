<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="文创产品" />
    <img class="bg" :src="ImgBg" />
    <!-- <fix-image class="logo" :src="imgSchoolLogoName" /> -->
    <div class="titleXX">广州市象贤中学校友会</div>
    <div class="introduce">{{ introduceText }}</div>
    <div class="row-center">
      <img class="img-title" :src="ImgTitle" />
    </div>
    <van-empty v-if="listData.length == 0" description="暂无文创产品" />
    <van-list class="list-wrap" v-model:loading="loading" :finished="finished" @load="getListData">
      <div class="item-wrap" v-for="item in listData" :key="item.id" @click="goPage(item)">
        <FixImage class="cover" :src="item.coverUrl" />
        <div class="item-wrap_info">
          <span class="name">{{ item.title }}</span>
          <div class="btn" @click="goPage(item)">点击了解详情</div>
        </div>
      </div>
    </van-list>
  </main>
</template>

<script setup lang="ts">
  import { ref, reactive } from 'vue'
  import { useRouter } from 'vue-router'
  import { fetchCulturalProductList } from '@/api/cultural-product'
  import { useGoBack } from '@/hooks/useGoBack'
  import { Toast } from 'vant'
  import { getSchoolCode } from '@/utils'
  import { SchoolCode } from '@/constants'
  import ImgBg from '@/assets/img/wenchuang-bg.png'
  import ImgTitle from '@/assets/img/wenchuang-title.png'

  let schoolCode = getSchoolCode()
  const imgSchoolLogoName = computed(() => {
    const logoObj: Record<string, string> = {
      [SchoolCode.XiangXianZhongXue]: new URL(
        '@/assets/xiangxianzhongxue/logo-red.png',
        import.meta.url
      ).href,
    }
    return schoolCode && logoObj[schoolCode] ? logoObj[schoolCode] : ''
  })

  const { goBack } = useGoBack()
  const router = useRouter()

  const introduceObj: Record<string, string> = {
    [SchoolCode.XiangXianZhongXue]:
      '文创产品捐款将悉数用于章程规定的慈善公益及服务校友等项目。如需协助，可联系梁力莎老师，联系电话：020-34877920（上班时间）。',
  }
  const introduceText = schoolCode && introduceObj[schoolCode] ? introduceObj[schoolCode] : ''

  const page = reactive({
    pageNum: 0,
    pageSize: 10,
  })
  const listData = ref<CulturalProduct[]>([])
  const loading = ref(false)
  const finished = ref(false)

  async function getListData() {
    try {
      loading.value = true
      const { code, data, msg } = await fetchCulturalProductList({
        pageNum: ++page.pageNum,
        pageSize: page.pageSize,
      })
      if (code == 200) {
        const { list, pages, pageNum } = data
        finished.value = pageNum >= pages
        listData.value = pageNum == 1 ? list : [...listData.value, ...list]
      } else {
        Toast.fail(msg)
        finished.value = true
      }
    } catch (err) {
      console.log('getListData err', err)
    } finally {
      loading.value = false
    }
  }
  function goPage({ id }: CulturalProduct) {
    router.push({ path: '/cultural-product-detail', query: { id } })
  }
</script>

<style lang="less" scoped>
  .row-center {
    display: flex;
    flex-direction: row;
    justify-content: center;
  }
  .wrap {
    padding: 32px;
    position: relative;
    z-index: 1;
    height: 100vh;
    overflow-y: auto;
  }
  .bg {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    z-index: -1;
  }
  .logo {
    width: 519px;
  }
  .titleXX{
    margin-left: 40px;
    width: 519px;
    font-size: 40px;
    color: #c21e24;
    text-align: center;
    font-weight: 600;
  }
  .introduce {
    margin: 29px 0 0;
    font-size: 30px;
    color: #222;
  }
  .img-title {
    margin: 77px 0 60px;
    width: 381px;
    display: flex;
  }
  .list-wrap {
    .item-wrap {
      padding: 24px;
      margin: 0 0 24px;
      display: flex;
      flex-direction: row;
      background: #fff;
      box-shadow: 2px 4px 12px 0 rgba(152, 0, 0, 0.1);
      border-radius: 16px;
      border: 2px solid #ffDBD8;

      .cover {
        flex: 0 0 auto;
        margin: 0 24px 0 0;
        width: 160px;
        height: 160px;
      }
      .item-wrap_info {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        .name {
          font-size: 32px;
          font-weight: bold;
          color: #222;
        }
        .btn {
          padding: 22px 30px;
          align-self: flex-end;
          font-size: 26px;
          font-weight: 500;
          color: #fff;
          background: linear-gradient(270deg, var(--theme-color-0-6) 0%, var(--theme-color) 100%);
          border-radius: 35px;
        }
      }
    }
  }
</style>
