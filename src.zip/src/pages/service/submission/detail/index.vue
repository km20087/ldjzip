<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="我要投稿" />
    <header class="header">
      <img class="img-bg" :src="ImgTouGaoBg" />
      <fix-image class="img-logo" v-if="imgSchoolLogoName" :src="imgSchoolLogoName" />
    </header>
    <div class="title-wrap">
      <img class="title-wrap_bg" :src="ImgTouGaoTitleBg" />
      <span class="title-wrap_title van-multi-ellipsis--l2">
        {{ detailData.title }}
      </span>
      <i class="title-wrap_txt">欢迎投稿</i>
    </div>
    <div class="content-wrap">
      <fix-image class="content-wrap_bg" :src="imgLogo" />
      <span class="time">发布时间：{{ detailData.updateTime }}</span>
      <div v-html="detailData.content" class="news-cont"></div>
    </div>
    <div class="btn-fix"></div>
    <div class="fixed-btn-wrap">
      <div class="btn" @click="goPage">我要投稿</div>
    </div>
    <van-image-preview v-model:show="showPreviewImage" :images="previewImage" :show-index="false" />
  </main>
</template>

<script setup lang="ts">
  import { ref, watchEffect } from 'vue'
  import { useRoute, useRouter } from 'vue-router'
  import { fetchSubmissionTypeDetail } from '@/api/submission'
  import { useGoBack } from '@/hooks/useGoBack'
  import { Base64 } from 'js-base64'
  import { useNewsPreviewImage } from '@/hooks/useNewsPreviewImage'
  import ImgTouGaoBg from '@/assets/img/tougao-bg.png'
  import ImgTouGaoTitleBg from '@/assets/img/tougao-title-bg.png'
  import { getSchoolCode } from '@/utils'
  import { SchoolCode } from '@/constants'
  import { useCacheImage } from '@/hooks/useCacheImage'
  import { Toast } from 'vant'

  const { img: imgLogo } = useCacheImage('HOME_BOTTOM_ICON')

  let schoolCode = getSchoolCode()
  const imgSchoolLogoName = computed(() => {
    const logoObj: Record<string, string> = {
      [SchoolCode.XiangXianZhongXue]: new URL(
        '@/assets/xiangxianzhongxue/logo-white.png',
        import.meta.url
      ).href,
    }
    return schoolCode && logoObj[schoolCode] ? logoObj[schoolCode] : ''
  })

  const { showPreviewImage, previewImage } = useNewsPreviewImage('.news-cont')

  const { goBack } = useGoBack()
  const route = useRoute()
  const router = useRouter()

  const detailData = ref<Partial<SubmissionType>>({})

  watchEffect(() => {
    let { id } = route.query
    if (!id) return
    getDetailData(id as string)
  })

  async function getDetailData(id: string) {
    try {
      const { code, data, msg } = await fetchSubmissionTypeDetail({ id })
      if (code == 200) {
        detailData.value = {
          ...data,
          updateTime: data.updateTime ? data.updateTime.slice(0, 10) : '',
          content: data.content
            ? decodeURIComponent(
                Base64.decode(Base64.decode(Base64.decode(Base64.decode(data.content))))
              ).replace(/<img/gi, "<img style='width:100%;height:100%'")
            : '',
        }
      } else {
        Toast.fail(msg)
      }
    } catch (err) {
      console.log('getDetailData err', err)
    }
  }

  function goPage() {
    let { id, title } = detailData.value
    router.push({
      path: '/submission-submit',
      query: {
        id,
        title,
      },
    })
  }
</script>

<style lang="less" scoped>
  .header {
    position: relative;
    padding: 30px;
    z-index: 1;
    .img-bg {
      position: absolute;
      left: 0;
      top: 0;
      width: 750px;
      height: 270px;
      z-index: -1;
    }
    .img-logo {
      width: 466px;
      height: 81px;
    }
  }
  .title-wrap {
    margin-left: 30px;
    padding: 36px 40px;
    width: 690px;
    height: 260px;
    position: relative;
    color: #fff;
    z-index: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    .title-wrap_bg {
      position: absolute;
      left: 0;
      top: 0;
      width: 690px;
      height: 260px;
      z-index: -1;
    }
    .title-wrap_title {
      font-size: 52px;
      font-weight: 600;
    }
    .title-wrap_txt {
      font-size: 28px;
      font-style: normal;
      align-self: flex-start;
    }
  }
  .content-wrap {
    position: relative;
    padding: 30px;
    z-index: 1;
    .content-wrap_bg {
      position: absolute;
      left: 50%;
      top: 144px;
      transform: translateX(-50%);
      width: 600px;
      height: 600px;
      opacity: 0.08;
    }
    .time {
      margin: 0 0 90px;
      color: #999;
      font-size: 24px;
      text-align: right;
      display: block;
    }
  }
  
  .btn-fix {
    width: 1px;
    height: 125px;
  }
  .fixed-btn-wrap {
    background: #fff;
    position: fixed;
    bottom: 0;
    width: 100%;
    padding: 0 30px 30px;
    z-index: 5;
    .btn {
      padding: 28px 0;
      width: 100%;
      display: flex;
      justify-content: center;
      font-size: 34px;
      font-weight: 600;
      color: #fff;
      letter-spacing: 19px;
      background: linear-gradient(270deg, var(--theme-color-0-6) 0%, var(--theme-color) 100%);
      border-radius: 45px;
    }
  }
  
</style>
