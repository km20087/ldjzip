<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" :title="title" />
    <div class="input-wrap">
      <InputItem title="投稿的标题" :required="true">
        <van-field
          v-model="data.title"
          placeholder="请输入投稿的标题"
          rows="1"
          autosize
          type="textarea"
          show-word-limit
          maxlength="30"
        />
      </InputItem>
      <InputItem title="投稿的内容" :required="true">
        <van-field
          v-model="data.content"
          placeholder="请输入投稿的内容"
          rows="4"
          autosize
          type="textarea"
          show-word-limit
          maxlength="1000"
        />
      </InputItem>
      <InputItem title="文件上传" :required="false">
        <div class="uploader-wrap">
          <span class="tips">支持jpg、jpeg、png、pdf格式</span>
          <compress-uploader
            v-model="fileList"
            accept=".png,.jpg,.jpeg,.pdf"
            :after-read="afterRead"
            :max-count="1"
            @delete="handleDeleteFile"
          />
        </div>
      </InputItem>
      <div class="btn-wrap">
        <div class="btn" @click="handleSubmit">提交</div>
      </div>
    </div>
  </main>
</template>

<script setup lang="ts">
  import { ref, computed } from 'vue'
  import { useRoute, useRouter } from 'vue-router'
  import { saveSubmission } from '@/api/submission'
  import { useGoBack } from '@/hooks/useGoBack'
  import { Toast } from 'vant'
  import ApiUpload from '@/api/uploadfile'
  import InputItem from '../components/input-item.vue'

  const { goBack } = useGoBack()

  const route = useRoute()
  const router = useRouter()

  const title = computed(() => route.query.title || '我要投稿')

  const data = ref({
    title: '',
    content: '',
    stauts: '1',
  })
  const fileList = ref([])
  const attachUrlList = ref<{ url: string; name: string }[]>([])

  const handleDeleteFile = (_: any, { index }: any) => {
    attachUrlList.value.splice(index, 1)
  }
  const afterRead = async (file: any) => {
    let formData = new FormData()
    formData.append('file', file.file)
    formData.append('flag', 'Y')
    file.status = 'uploading'
    file.message = '上传中...'
    await ApiUpload.uploadFile(formData)
      .then((res) => {
        if (res.code == 200) {
          file.status = 'success'
          file.message = ''
          attachUrlList.value.push({ url: res.data.uploadUrl, name: file.file.name })
          Toast.success('上传成功')
        } else {
          file.status = 'failed'
          file.message = '上传失败'
          Toast.fail(res.msg)
        }
      })
      .catch((err) => {
        console.log('uploadFile err', err)
        file.status = 'failed'
        file.message = '上传失败'
        Toast.fail(`上传失败：${err}`)
      })
  }
  async function handleSubmit() {
    let loading = Toast.loading('提交中...')
    try {
      let attachUrl = ''
      let attachFileName = ''

      if (attachUrlList.value?.length) {
        attachUrl = attachUrlList.value.map((item) => item.url).join('!@!')
        attachFileName = attachUrlList.value.map((item) => item.name).join('!@!')
      }
      const result = await saveSubmission({
        ...data.value,
        magazineColumnId: route.query.id as string,
        attachUrl,
        attachFileName,
      })
      if (result.code == 200) {
        Toast.success({
          message: '提交成功',
          onClose: () => {
            router.go(-2)
          },
        })
        return
      }
      Toast.fail(result.msg)
    } catch (err) {
      loading.clear()
      console.log('handleSubmit err', err)
    }
  }
</script>

<style lang="less" scoped>
  .wrap {
    min-height: 100vh;
    background: #f5f5f5;
    --van-cell-vertical-padding: 24px;
    --van-cell-horizontal-padding: 24px;
  }
  .input-wrap {
    padding: 24px;
  }
  .uploader-wrap {
    padding: var(--van-cell-vertical-padding) var(--van-cell-horizontal-padding);
    .tips {
      margin: 0 0 24px;
      font-size: 26px;
      color: #666;
      display: block;
    }
  }
  .btn-wrap {
    padding: 80px 30px 30px;

    .btn {
      padding: 28px 0;
      width: 100%;
      display: flex;
      justify-content: center;
      font-size: 34px;
      font-weight: 600;
      color: #fff;
      letter-spacing: 19px;
      background: linear-gradient(270deg, var(--theme-color-0-6) 0%, var(--theme-color) 100%);
      border-radius: 45px;
    }
  }
</style>
