<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="投稿专栏" />
    <fix-image :src="imgBanner" class="bg-img" />
    <div class="img-wrap row-wrap">
      <!-- <fix-image :src="imgSchoolLogoName" class="img-wrap_logo" /> -->
      <div class="titleXX">广州市象贤中学校友会</div>
    </div>
    <div class="introduce">{{ introduceText }}</div>
    <Search @search="handleSearch" />
    <van-empty v-if="listData.length == 0" description="暂无可投稿主题" />
    <van-list class="list-wrap" v-model:loading="loading" :finished="finished" @load="getListData">
      <div class="item-wrap row" v-for="item in listData" :key="item.id" @click="goPage(item)">
        <div class="title-wrap row van-ellipsis">
          <span class="van-ellipsis">{{ item.title }}</span>
        </div>
        <div class="rt-wrap row">
          <i class="txt">展开</i>
          <van-icon class="icon" name="arrow"></van-icon>
        </div>
      </div>
    </van-list>
  </main>
</template>

<script setup lang="ts">
  import { ref, reactive } from 'vue'
  import { useRouter } from 'vue-router'
  import { fetchSubmissionTypeList } from '@/api/submission'
  import { useGoBack } from '@/hooks/useGoBack'
  import { Toast } from 'vant'
  import { getSchoolCode } from '@/utils'
  import { SchoolCode } from '@/constants'
  import { useCacheImage } from '@/hooks/useCacheImage'
  import Search from '../components/search.vue'

  const { img: imgBanner } = useCacheImage('SCHOOLMATE_CARD_BACKGROUND')
  const imgSchoolLogoName = computed(() => {
    const logoObj: Record<string, string> = {
      [SchoolCode.XiangXianZhongXue]: new URL(
        '@/assets/xiangxianzhongxue/logo-red.png',
        import.meta.url
      ).href,
    }
    return schoolCode && logoObj[schoolCode] ? logoObj[schoolCode] : ''
  })

  const { goBack } = useGoBack()
  let schoolCode = getSchoolCode()

  const introduceObj: Record<string, string> = {
    [SchoolCode.XiangXianZhongXue]:
      '时光流转，薪火相传，这里是我们象贤人投稿专栏，每一段文字，每一张照片，每一份心声，都承载着对母校的深情眷恋，记录着从象贤出发的逐梦历程。我们期待每一位校友踊跃投稿，分享你的校园时光、职场经历与人生收获，让珍贵记忆在此汇聚，让象贤精神永远传承。',
  }
  const introduceText = schoolCode && introduceObj[schoolCode] ? introduceObj[schoolCode] : ''

  const searchText = ref('')

  const router = useRouter()
  const page = reactive({
    pageNum: 0,
    pageSize: 10,
  })
  const listData = ref<SubmissionType[]>([])
  const loading = ref(false)
  const finished = ref(false)

  function handleSearch(text: string) {
    page.pageNum = 0
    searchText.value = text
    getListData()
  }

  async function getListData() {
    try {
      loading.value = true
      const { code, data, msg } = await fetchSubmissionTypeList({
        title: searchText.value,
        status: '1',
        pageNum: ++page.pageNum,
        pageSize: page.pageSize,
      })
      if (code == 200) {
        const { list, pages, pageNum } = data
        finished.value = pageNum >= pages
        listData.value = pageNum == 1 ? list : [...listData.value, ...list]
      } else {
        Toast.fail(msg)
        finished.value = true
      }
    } catch (err) {
      console.log('getListData err', err)
    } finally {
      loading.value = false
    }
  }
  function goPage({ id }: SubmissionType) {
    router.push({ path: '/submission-detail', query: { id } })
  }
</script>

<style lang="less" scoped>
  .wrap {
    height: 100vh;
    overflow-y: auto;
    background: #f5f5f5;
  }
  .bg-img {
    width: 100%;
    height: 380px;
  }
  .row-wrap {
    display: flex;
    flex-direction: row;
  }
  .img-wrap {
    justify-content: center;
    margin: 13px 0 0;
    .img-wrap_logo {
      width: 461px;
      height: 80px;
    }
    .titleXX{
      // margin-left: 40px;
      width: 461px;
      font-size: 36px;
      color: #c21e24;
      text-align: center;
      font-weight: 600;
    }    
  }
  .introduce {
    margin: 20px 0 0;
    padding: 0 30px;
    font-size: 24px;
    color: #666;
  }
  .row {
    display: flex;
    flex-direction: row;
    align-items: center;
  }
  .list-wrap {
    padding: 20px;
    .item-wrap {
      justify-content: space-between;
      margin: 0 0 24px;
      padding: 34px 0;
      background: #fff;
      border-radius: 16px;
      .title-wrap {
        flex: 1;
        margin: 0 16px 0 0;
        font-size: 32px;
        font-weight: 500;
        color: #222;
        &::before {
          flex: 0 0 auto;
          content: '';
          display: block;
          margin: 0 22px 0 0;
          width: 8px;
          height: 28px;
          background: linear-gradient(270deg, var(--theme-color-0-6) 0%, var(--theme-color) 100%);
          border-radius: 7px;
        }
      }
      .rt-wrap {
        flex: 0 0 auto;
        padding: 0 24px 0 0;
        .txt {
          font-style: normal;
          margin: 0 5px 0 0;
          font-size: 28px;
          color: #999;
        }
        .icon {
          font-size: 28px;
          color: #999;
        }
      }
    }
  }
</style>
