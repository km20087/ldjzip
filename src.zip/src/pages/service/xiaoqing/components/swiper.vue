<template>
  <div class="swiper-box">
    <swiper class="swiper-wrap" :modules="modules" :space-between="0" slides-per-view="auto" :autoplay="autoplay"
      :centered-slides="true" :loop="false">
      <swiper-slide class="swiper-wrap_item" v-for="(item, index) in list" :key="item">
        <a :href="item.jumpUrl ? item.jumpUrl : 'javascript:void(0);'">
          <fix-image class="img" :src="item.fileAddress" width="375" height="175" />
        </a>
      </swiper-slide>
    </swiper>
  </div>
</template>

<script lang="ts" setup>
import { Autoplay } from 'swiper';
import { Swiper, SwiperSlide } from 'swiper/vue';
import 'swiper/css';
const picUrl = import.meta.env.VITE_APP_PIC_BASE_URL;

const props = withDefaults(
  defineProps<{
    list: any[];
    interval: string;
  }>(),
  {
    list: () => [] as any[],
    interval: '2',
  }
);

const modules = [Autoplay];
const autoplay = computed(() => ({
  // delay: parseInt(props.interval) * 1000,
  delay: 2000,
  disableOnInteraction: false,
}));

const total = computed(() => props.list.length);
</script>

<style lang="less" scoped>
.swiper-box {
  overflow: hidden;
}

.swiper-wrap {
  height: 350px;
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  transition: all 0.5s ease;

  .swiper-wrap_item {
    flex: 0 0 750px;
    // border-radius: 10px;
    overflow: hidden;
    box-sizing: border-box;
  }

  .img {
    width: 750px;
    height: 350px;
  }

}
</style>
