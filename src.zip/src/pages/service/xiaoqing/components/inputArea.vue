<template>
    <van-popup v-model:show="isShowClone" :position="pos" :style="{ height: `${height}` }">
        <div class="pop-nav">
            <span @click="closePop">关闭</span>
            <span class="confirm-btn" @click="sendBarrage">发布</span>
        </div>
        <van-field v-model="barrageMsg" type="textarea" :rows="rows" autosize :maxlength="maxl" :placeholder="plac"
            show-word-limit>
        </van-field>
        <slot name="bottom-bar" />
    </van-popup>
</template>
<script setup lang="ts">
import { useVModel } from '@/hooks/useVModel'
import { PopupPosition, Toast } from 'vant'
const props = withDefaults(defineProps<{
    isShow?: boolean,
    pos?: PopupPosition,
    height?: string,
    maxl?: number,
    plac?: string,
    rows?: number,
}>(), {
    pos: 'bottom',
    height: '30%',
    maxl: 20,
    plac: '请输入内容...',
    rows: 3,
})
watch(
    () => props.isShow,
    (val) => {
        if (val) {
            barrageMsg.value = ''
            canClick.value = false
        }
    }
)
let barrageMsg = ref('');
let canClick = ref(false)
let $emit = defineEmits(['update:isShow', 'sendBarrage'])
const isShowClone = useVModel(props, 'isShow', $emit)
//关闭弹框
const closePop = () => {
    isShowClone.value = false
}
//发送弹幕
const sendBarrage = () => {
    if (!canClick.value) {//防止未及时关闭的重复点击
        $emit('sendBarrage', barrageMsg.value)
    } else {
        Toast('发送频繁，5秒后再操作吧！')
    }
    canClick.value = true
    setTimeout(() => {
        canClick.value = false
    }, 5000)

}
</script>
<style lang="less" scoped>
.pop-nav {
    padding: 5px 38px;
    border-bottom: 1px solid #DFDFDF;
    line-height: 88px;
    font-family: PingFangSC-Medium;
    font-size: 32px;
    color: #666666;
    display: flex;
    justify-content: space-between;

    .confirm-btn {
        color: #1E93EF;
    }
}
</style>