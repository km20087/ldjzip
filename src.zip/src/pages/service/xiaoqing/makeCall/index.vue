<template>
    <main class="wrap">
        <nav-bar-2 left-arrow @click-left="goBack" title="我为母校打CALL" />
        <div class="xiaoqing-cont" ref="makeCallBG">
            <div class="accout">
                <span>已有<span class="num">{{ count }}</span>人为母校打CALL</span>
            </div>
            <div class="barrage-main">
                <vue-danmaku class="danmaku" ref="danmakuRef" v-model:danmus="danmus" autoplay useSlot loop :speeds="30"
                    :channels="6">
                    <template v-slot:dm="{ index, danmu }">
                        <div class="barrage-list">
                            <div class="sub-list" :class="index == 0 && isME ? 'first' : ''">
                                <van-image width="19" height="19" style="margin-right: 10px;" :src="barrageIcon" />
                                <span>{{ danmu }}</span>
                            </div>
                        </div>
                    </template>
                </vue-danmaku>

            </div>
            <div class="call-btn">
                <div class="button" @click="showPop">
                    <van-image width="277" height="50" :src="themeBtn" />
                    <div class="text">为 母 校 送 祝 福</div>
                </div>
            </div>
        </div>
        <inputArea v-model:isShow="popShow" @sendBarrage="sendBarrage" />
    </main>
</template>
<script setup lang="ts">
import { useGoBack } from '@/hooks/useGoBack';
import { getPictures } from '@/utils';
import makeCall_BG from '@/assets/img/makeCall-bg.png'
import barrageIcon from '@/assets/img/barrage-icon@2x.png'
import themeBtn from '@/assets/img/theme-btn@2x.png'
import inputArea from '../components/inputArea.vue'
import servive from '@/api/servive';
import vueDanmaku from 'vue3-danmaku'
import { Toast } from 'vant';

const { goBack } = useGoBack();
const makeCallBG = ref();
const danmakuRef = ref();
let isME = ref(false);//是否自己发送
let popShow = ref(false);
let danmus = ref([]);
let count = ref('')

getPictures('SC_CHEER_FOR_SCHOOL_BACKGROUND').then(
    (result: ImageList) => {
        makeCallBG.value.style.backgroundImage = `url(${import.meta.env.VITE_APP_PIC_BASE_URL + result?.images?.[0]?.fileAddress})` || makeCall_BG
    }
);
//获取弹幕
const getList = async () => {
    let { code, data, msg } = await servive.getbarrage({});
    if (code == 200) {
        danmus.value = data.contentList
        count.value = data.count
    } else {
        Toast(msg);
    }

}
getList()
//显示弹框
const showPop = () => {
    popShow.value = true
}
//发送弹幕
const sendBarrage = async (e: any) => {
    let { code, data, msg } = await servive.sendbarrage({ content: e })
    if (code == 200) {
        isME.value = true
        danmus.value = []
        getList()
    } else {
        Toast(msg);
    }
    popShow.value = false
}
</script>
<style lang="less" scoped>
.xiaoqing-cont {
  width: 100vw;
  min-height: 100vh;
  background-position: center center;
  background-repeat: no-repeat;
  background-size: 100% 100%;

  .accout {
    text-align: center;
    width: 100%;
    padding: 80px 0;
    font-family: PingFang-SC-ExtraLight;
    font-size: 32px;
    color: #ff0000;

    .num {
      font-family: Arial-BoldMT;
      font-size: 60px;
      color: #ff0000;
      font-weight: 700;
    }
  }

  .barrage-main {
    height: 50vh;

    .danmaku {
      width: 100%;
      height: 100%;
    }

    .barrage-list {
      margin-bottom: 20px;
      display: flex;
      align-items: center;

      .sub-list {
        width: max-content;
        display: flex;
        align-items: center;
        padding: 10px 20px;
        background: #ffffff;
        border: 2px solid rgba(225, 182, 151, 1);
        border-radius: 50px;
        font-size: 26px;
        color: #333;
        margin-right: 30px;
      }

      .first {
        color: aqua;
      }
    }
  }

  .call-btn {
    width: 100%;
    position: fixed;
    left: 0;
    bottom: 50px;
    display: flex;
    justify-content: center;
    align-items: center;

    .button {
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;

      .text {
        position: absolute;
        font-family: PingFangSC-Medium;
        font-size: 36px;
        font-weight: 500;
        color: #ffffff;
        display: flex;
        justify-content: center;
        align-items: center;
      }
    }
  }
}
</style>