<template>
    <nav-bar-2 left-arrow @click-left="goBack" title="我要上晚会" />
    <main class="wrap" ref="wrapper">
        <Swiper :list="bannerData.images" :interval="bannerData.interval" v-if="bannerData.images?.length != 0" />
        <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
            <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" v-model:error="error"
                error-text="请求失败，点击重新加载" @load="onLoad">
                <div class="state-list" v-for="(item, index) in stateList" :key="index">
                    <Avatar class="user-head" :src="item.userProfilePicture" />
                    <div class="state-cont">
                        <span class="name">{{ item.username }}</span>
                        <div>{{ item.text }}</div>

                        <fix-image class="state-pic" :src="item.photo" @click="previewShowFun(item.photo)"></fix-image>

                    </div>
                </div>
            </van-list>
        </van-pull-refresh>
        <van-image-preview v-model:show="previewShow" :images="preimages">

        </van-image-preview>
        <div class="call-btn">
            <div class="button" @click="showPop">
                <van-image width="277" height="50" :src="themeBtn" />
                <div class="text">我 要 上 晚 会</div>
            </div>
        </div>
        <inputArea v-model:isShow="popShow" @sendBarrage="sendBarrage" height="50%" :maxl="100">
            <template v-slot:bottom-bar>
                <div class="upload-pic">
                    <compress-uploader v-model="fileList" max-count="1" :after-read="afterRead" />
                </div>
            </template>
        </inputArea>

    </main>
</template>
<script setup lang="ts">
import Swiper from '../components/swiper.vue';
import { useGoBack } from '@/hooks/useGoBack';
import { getPictures } from '@/utils';
import themeBtn from '@/assets/img/theme-btn@2x.png'
import inputArea from '../components/inputArea.vue'
import servive from '@/api/servive';
import Api from "@/api/uploadfile";
import { Toast } from 'vant';
import Avatar from '@/components/avatar/index.vue';

const { goBack } = useGoBack();
let bannerData = ref<Partial<ImageList>>({
    images: [],
    interval: '0',
});
let previewShow = ref(false)
let preimages = ref<string[]>([])
let fileList = ref<File[] | any>([])
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const error = ref(false);
const wrapper = ref()

interface state {
    username: string,
    text: string,
    photo: string,
    userProfilePicture: string
}
let stateList = ref<state[]>([]);
let popShow = ref(false);
let params = ref({ text: '', photo: '', })
let loginInfo = ref({
    pageNum: 1,
    pageSize: 10
})

getPictures('SC_ATTEND_PARTY_BANNER').then((result: ImageList) => (bannerData.value = result))
//显示弹框
const showPop = () => {
    popShow.value = true
}
const onLoad = () => {
    getList().catch(() => {
        error.value = true;
    });
};
const onRefresh = () => {
    // 清空列表数据
    finished.value = false;

    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    loading.value = true;
    loginInfo.value.pageNum = 1;
    stateList.value = [];
    onLoad();
};
//获取列表
const getList = async () => {
    let { code, data, msg } = await servive.getStateList(loginInfo.value)
    if (code == 200) {
        // stateList.value = data
        stateList.value = stateList.value.concat(data.list);
        loginInfo.value.pageNum++;
        loading.value = false;
        if (stateList.value.length >= data.total) {
            finished.value = true;
        }
        refreshing.value = false;
    } else {
        Toast(msg);
        finished.value = true;

    }
}
//发圈
const sendBarrage = async (e: any) => {
    params.value.text = e;
    let { code, data, msg } = await servive.sendStateList(params.value)
    if (code == 200) {
        wrapper.value.scrollTo({
            top: 0, behavior: 'smooth'
        })
        fileList.value = []
        onRefresh()
        refreshing.value = true;
    } else {
        Toast(msg);
    }
    popShow.value = false
}
//上传图片
const afterRead: any = async (file: any) => {
    let formData1 = new FormData();

    formData1.append("file", file.file);
    // formData.append('flag', 'Y');//加密上传
    file.status = "uploading";
    file.message = "上传中...";
    await Api.uploadFile(formData1)
        .then(res => {
            if (res.code == 200) {
                file.status = "";
                file.message = "";
                nextTick(() => {
                    if (
                        res.data.tokenUrl &&
                        res.data.tokenUrl == "" &&
                        res.data.tokenUrl == undefined &&
                        res.data.tokenUrl == null
                    ) {
                        params.value.photo = res.data.tokenUrl as string;
                    } else {
                        params.value.photo = res.data.uploadUrl as string;
                    }
                });

                Toast.success("上传成功");
            } else {
                file.status = "failed";
                file.message = "上传失败";
                Toast.fail(res.msg);
            }
        })
        .catch(err => {
            file.status = "failed";
            file.message = "上传失败";
            Toast.fail(`上传失败：${err}`);
        });
};
const previewShowFun = (e: string | any) => {
    preimages.value = []
    if (typeof e === 'string') {
        preimages.value.push(import.meta.env.VITE_APP_PIC_BASE_URL + e)

    }
    previewShow.value = true
}
// onMounted(() => {
//     let picsArr: any = document.getElementsByClassName('state-pic')
//     console.log(picsArr.length, 'picAee')
//     for (let i = 0; i < picsArr.length; i++) {
//         console.log(i, "iii")
//         if (picsArr[i].clientHeight >= picsArr[i].clientWidth) {
//             picsArr[i].height = '100px'
//         } else {
//             picsArr[i].width = '546px'
//         }
//     }
// })
</script>
<style lang="less" scoped>
.wrap {
    background: #f5f5f5;
    height: 100vh;
    overflow-y: scroll;

    .state-list {
        margin-top: 20px;
        display: flex;
        padding: 30px 40px;
        background: #fff;

        .user-head {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin-right: 30px;
        }

        .state-cont {
            display: flex;
            flex-direction: column;

            .name {
                font-size: 28px;
                color: #BA2C18;
                font-weight: 500;
                padding-bottom: 10px;
            }

            .state-pic {
                width: 546px;
                height: 546px;
                object-fit: contain;
                // width: 546px;
                // height: 200px;
                margin-top: 10px;
                border-radius: 16px;
            }
        }
    }

    .call-btn {
        width: 100%;
        position: fixed;
        left: 0;
        bottom: 50px;
        display: flex;
        justify-content: center;
        align-items: center;

        .button {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;

            .text {
                position: absolute;
                font-family: PingFangSC-Medium;
                font-size: 36px;
                font-weight: 500;
                color: #FFFFFF;
                display: flex;
                justify-content: center;
                align-items: center;
            }
        }
    }
}

.upload-pic {
    padding: 30px;
}

.van-list {
    padding-bottom: 160px !important;
}
</style>