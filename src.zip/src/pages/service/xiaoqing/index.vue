<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="" />
    <div class="xiaoqing-cont" ref="xiaoqingBG">
      <div class="xiaoqing-tit" :class="schoolCode == SchoolCode.PeiYingZhongXue?'xiaoqing-tit mar60':'xiaoqing-tit'">
        <fix-image class="tit-pic" v-if="schoolCode !== SchoolCode.PeiYingZhongXue" :src="themeTit"></fix-image>
      </div>
      <div class="ani" v-if="schoolCode == SchoolCode.PeiYingZhongXue">
        <p class="cheer">————热烈庆祝母校70周年华诞</p>
      </div>
      <div class="xiaoqing-func">
        <div
          class="func-entrance"
          v-for="(item, idx) in funcArr"
          :key="idx"
          @click="jumpPage(item.path)"
          v-show="item.hidden"
        >
          <van-image width="277" height="50" :src="item.img"></van-image>
          <div class="text">{{ item.name }}</div>
        </div>
      </div>
    </div>
  </main>
</template>
<script setup lang="ts">
import themeBtn from '@/assets/img/theme-btn@2x.png';
import themeBg from '@/assets/img/theme-bg.png';
import { useGoBack } from '@/hooks/useGoBack';
import { getPictures,getSchoolCode } from '@/utils';
import servive from '@/api/servive/index';
import { Toast } from 'vant';
import { SchoolCode } from '@/constants';
const { goBack } = useGoBack();
const xiaoqingBG = ref();
let themeTit = ref('');
const funcArr = ref([
  {
    sign: 'cheerForSchool',
    name: '我为母校打CALL',
    path: '/makeCall',
    img: themeBtn,
    hidden: false,
  },
  { sign: 'attendParty', name: '我 要 上 晚 会', path: '/partyShow', img: themeBtn, hidden: false },
  { sign: 'withRankingList', name: '祝 福 排 行 榜', path: '/chart', img: themeBtn, hidden: false },
  { sign: 'cloudLive', name: '云 直 播', path: '', img: themeBtn, hidden: false },
]);
const router = useRouter();
const schoolCode = getSchoolCode();
const jumpPage = (i: string) => {
  if (i == '') {
    Toast('敬请期待...');
  }
  router.push({ path: i });
};
const getFunList = async () => {
  let res = await servive.getfunction({});
  if (res.code == 200) {
    let { attendParty, cheerForSchool, withRankingList, cloudLive } = res.data;
    let openArr: any = { attendParty, cheerForSchool, withRankingList, cloudLive };
    for (let i in openArr) {
      for (let a of funcArr.value) {
        if (a.sign == i && openArr[i] == '1') {
          a.hidden = true;
        }
      }
    }
  }
};
onMounted(async () => {
  getFunList();
  getPictures('SC_HOME_BACKGROUND').then((result: ImageList) => {
    xiaoqingBG.value.style.backgroundImage =
      `url(${import.meta.env.VITE_APP_PIC_BASE_URL + result?.images?.[0]?.fileAddress})` || themeBg;
  });
  let img2 = await getPictures('SC_HOME_TITLE');
  themeTit.value = img2?.images?.[0]?.fileAddress;
});
</script>
<style lang="less" scoped>

.xiaoqing-cont {
  width: 100vw;
  min-height: 100vh;
  position: relative;
  background-position: center center;
  background-repeat: no-repeat;
  background-size: 100% 100%;
.xiaoqing-tit{
    width: 750px;
    height: 420px;
}
.mar60{
  margin-bottom:80px;
}
  .tit-pic {
    width: 750px;
    height: 420px;
  }
  .ani{
    position: absolute;
    top:377px;
    right:89px;
    .cheer{
      font-size: 28px;
      color:#ffffff;
    }
  }

  .xiaoqing-func {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px 0;

    .func-entrance {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 40px 0;

      .text {
        width: 100%;
        height: 100%;
        line-height: 100px;
        text-align: center;
        position: absolute;
        top: 0;
        left: 0;
        font-family: PingFang-SC-Medium;
        font-size: 32px;
        color: #ffffff;
        font-weight: 500;
      }
    }
  }
}
</style>