<template>
  <div class="map-address">
    <van-nav-bar title="校庆" left-text="" left-arrow @click-left="onClickLeft" />
    <!-- <div class="search">
      <van-search
        v-model="keyWords"
        show-action
        id="keyWords"
        placeholder="请输入地点"
        @search="getVal"
      >
        <template #action>
          <div @click="getVal">搜索</div>
        </template>
      </van-search>
    </div> -->
    <div id="container" class="mapSize"></div>
    <div class="address-list" v-if="address_list.length > 0">
      <ul>
        <li v-for="item in address_list" :key="item.id" @click="sureAddress(item)" class="tsad">
          <p class="name">{{ item.name }}</p>
          <p class="detail" v-if="item.district.length > 0">{{
            item.address.length > 0 ? item.district + item.address : item.district
          }}</p>
          <p v-else></p>
        </li>
      </ul>
    </div>
    <van-popup v-model:show="showFlag" position="bottom" :style="{ height: '45%' }">
      <div class="section">
        <div class="title">地点</div>
        <div><van-field v-model="content.name" placeholder="" /></div>
      </div>
      <div class="section">
        <div class="title">所属地区</div>
        <div><van-field v-model="content.district" placeholder="" /></div>
      </div>
      <div class="section">
        <div class="title">具体地址</div>
        <div><van-field v-model="content.address" placeholder="" /></div>
      </div>
      <van-row type="flex" justify="center">
        <van-col><van-button round type="primary" @click="jumpDetail()">确认</van-button></van-col>
        <!-- @click="jumpDetail()" -->
      </van-row>
      <van-row type="flex" justify="center">
        <van-col
          ><van-button round type="default" @click="showFlag = false">取消</van-button></van-col
        >
      </van-row>
    </van-popup>
  </div>
</template>

<script lang="ts" setup>
  import { ref, reactive, shallowRef } from 'vue';
  import AMapLoader from '@amap/amap-jsapi-loader';
  import { locationP } from '@/store';
  const locationSetting = locationP();
  const router = useRouter();
  let AMap: any = null;
  let map: any = null;
  const position: any = ref(null);
  const address_list = <any>ref([]);
  const keyWords = ref('');
  const showFlag = ref(false);
  // declare const window: any;
  const content = ref({
    address: '',
    district: '',
    name: '',
  });
  const onClickLeft = () => {
    locationSetting.name = '';
    router.back();
  };
  const initAMap = () => {
    // let that = this
    const win: any = window;
    win._AMapSecurityConfig = {
      securityJsCode: '461c0a8910d54d894acfa2e9c39f34b2',
    };
    let a = {};
    // a['123']
    AMapLoader.load({
      key: 'cb5cfb3a96c0317b53acbc3de59cec28', //申请好的Web端开发者Key，首次调用 load 时必填
      version: '2.0',
      plugins: [],
    })
      .then((Amap: any) => {
        AMap = Amap;
        // 其他功能同h5
        map = new AMap.Map('container', {
          // viewMode: "3D",
          // center: [114.514793, 38.042225], // 地图中心点坐标
          // city: '长沙',
          // center: [105.602725, 37.076636], //初始化地图中心点位置
          zoom: 5, // 地图缩放级别
        });
        getLocation();
      })
      .catch((e) => {
        console.log('高德地图加载错误', e);
      });
  };
  const getLocation = () => {
    AMap.plugin('AMap.Geolocation', function () {
      let geolocation = new AMap.Geolocation({
        enableHighAccuracy: true, //是否使用高精度定位，默认:true
        timeout: 10000, //超过10秒后停止定位，默认：无穷大
        maximumAge: 0, //定位结果缓存0毫秒，默认：0
        convert: true, //自动偏移坐标，偏移后的坐标为高德坐标，默认：true
        showButton: true, //显示定位按钮，默认：true
        buttonPosition: 'LB', //定位按钮停靠位置，默认：'LB'，左下角
        buttonOffset: new AMap.Pixel(10, 20), //定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
        showMarker: true, //定位成功后在定位到的位置显示点标记，默认：true
        showCircle: true, //定位成功后用圆圈表示定位精度范围，默认：true
        panToLocation: true, //定位成功后将定位到的位置作为地图中心点，默认：true
        zoomToAccuracy: true, //定位成功后调整地图视野范围使定位位置及精度范围视野内可见，默认：false
      });

      function onComplete(data: any) {
        // data是具体的定位信息
        // alert(JSON.stringify(data));
        position.value = data.position;
      }

      function onError(data: any) {
        // 定位出错
        console.log(data, 'onError');
      }

      map.addControl(geolocation); // 右下角 获取当前位置控件
      // that.map.on("click", showInfoClick);//手动地图选取点位
      // function showInfoClick(e) {
      //   console.log(e, " this. this. this.");
      // }
      // 获取详细地址api
      geolocation.getCurrentPosition(function (status: any, result: any) {
        if (status == 'complete') {
          onComplete(result);
          console.log(result);
        } else {
          onError(result);
        }
      });
    });
  };

  const circleMarker = () => {
    console.log('circleMarker');
    AMap.CircleMarker();
  };
  // const loadMap = ()=>{

  // }
  const jumpDetail = () => {
    locationSetting.name = content.value.name;
    router.back();
  };
  const getVal = () => {
    searchNear(keyWords.value);
  };
  const sureAddress = (val: any) => {
    console.log('sureAddress');
    console.log(val);
    if (val.name == '不显示地点') {
      router.back();
      locationSetting.name = val.name;
      return;
    }
    showFlag.value = true;
    content.value = { ...val };
    // return
    const placeSearch = new AMap.PlaceSearch({
      city: '', // 兴趣点城市，支持城市名、citycode、adcode
      citylimit: false, // 是否强制在设置的城市内搜索，默认false
      type: '商务住宅|公司企业|餐饮服务|科教文化服务|政府机构及社会团体', // 兴趣点类别，用‘|’分隔，默认：'餐饮服务|商务住宅|生活服务'
      // type: "公司企业", // 兴趣点类别，用‘|’分隔，默认：'餐饮服务|商务住宅|生活服务'
      pageSize: 30, // 每页条数，默认10，范围1-50
      // count: 30,
      pageIndex: 1, // 页码
      extensions: 'all', // 默认base，返回基本地址信息；all：返回详细信息
      map: map, // 地图实例，可选
      // panel: 'panel', // 结果列表的id容器，可选
      autoFitView: true, // 是否自动调整地图视野到marker点都处于可见范围
    });
    // let a = [val.location.lat, val.location.lng]
    let a = [val.location.lng, val.location.lat];
    placeSearch.searchNearBy('', a, 2000, function (status: any, result: any) {
      console.log(status);
      if (status == 'complete') {
        address_list.value = [];
        // address_list
        // showFlag.value = true;
      }
      console.log(result);
      // that.content = { ...result }
    });
  };
  const searchNear = (val: any) => {
    AMap.plugin(['AMap.AutoComplete', 'AMap.PlaceSearch'], function () {
      var autoOptions = {
        // 城市，默认全国
        // city: '石家庄',
        // 使用联想输入的input的id
        input: 'tipinput',
        // citylimit: true,
        // input: 'keywords',
        pageSize: '30', // 每页条数，默认10，范围1-50
        pageIndex: 1, // 页码
        // datatype: 'poi' //返回的数据类型
        autoFitView: true, // 是否自动调整地图视野到marker点都处于可见范围
      };
      var autocomplete = new AMap.AutoComplete(autoOptions);
      // var autocomplete = new AMap.PlaceSearch(autoOptions)
      // autocomplete.search(keywords, function(status, result) {
      //   // 搜索成功时，result即是对应的匹配数据
      //   console.log(result)
      // })
      autocomplete.search(val, function (status: any, result: any) {
        // 搜索成功时，result即是对应的匹配数据
        console.log(result);
        console.log('OKOKOKOKOKO');
        address_list.value = result.tips;
        let a = { name: '不显示地点', address: [], district: [] };
        address_list.value.unshift(a);
      });
      // const placeSearch = new AMap.PlaceSearch({
      //   // city: '石家庄', // 兴趣点城市，支持城市名、citycode、adcode
      //   citylimit: true, // 是否强制在设置的城市内搜索，默认false
      //   type: '商务住宅|公司企业|餐饮服务|科教文化服务|政府机构及社会团体', // 兴趣点类别，用‘|’分隔，默认：'餐饮服务|商务住宅|生活服务'
      //   // type: "公司企业", // 兴趣点类别，用‘|’分隔，默认：'餐饮服务|商务住宅|生活服务'
      //   pageSize: 30, // 每页条数，默认10，范围1-50
      //   pageIndex: 1, // 页码
      //   extensions: 'all', // 默认base，返回基本地址信息；all：返回详细信息
      //   map: map, // 地图实例，可选
      //   // panel: 'panel', // 结果列表的id容器，可选
      //   autoFitView: true, // 是否自动调整地图视野到marker点都处于可见范围
      // });
    });
  };
  onMounted(() => {
    initAMap();
  });
</script>

<style lang="less" scoped>
  .section {
    padding-top: 20px;
    &:first-child {
      margin-top: 10px;
    }
    .title {
      padding-left: 15px;
      color: #555555;
      font-size: 12px;
    }
    .cell-value {
      color: #c8c9cc;
      &.selected {
        color: #000;
      }
    }
  }
  .van-row {
    margin-top: 10px;
  }
  .van-col {
    /deep/ .van-button {
      width: 300px;
    }
  }
  .amap-container {
    width: 100%;
    // height: 100vh;
    height: 600px;
  }
  .map-address {
    height: inherit;
    .container {
      width: 100px;
      height: 398px;
    }
    .search {
      position: relative;
    }
    .address-list {
      position: absolute;
      top: 200px;
      width: 100%;
      // left: 35px;
      background-color: #fff;
      // height: 238px;
      // overflow: auto;
      overflow-y: scroll;
      .tsad {
        // text-align: center;
      }
      ul {
        li {
          padding: 6px;
          border-bottom: 1px solid #ddd;
          p:nth-of-type(1) {
            color: #333;
            font-size: 14px;
          }
          p:nth-of-type(2) {
            color: #666;
            font-size: 12px;
          }
        }
      }
    }
  }
</style>
