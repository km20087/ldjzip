<template>
  <van-nav-bar title="" left-text="" left-arrow @click-left="onClickLeft" />
  <div class='con'>
    <div class='title'>
      返校记录
    </div>
    <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
      <div class='itemList'>
        <div class='item' v-for="(item, index) in list" :key="index" @click='jumpDetail(item.returningSchoolId)'
          :class="item.expired ? 'usefulItem' : 'uselessItem'">
          <div class="one">
            <div class='leftOne'>
              <div class="title1" :class="item.expired ? 'useful' : 'useless'">返校申请</div>
              <img :src="useless" v-if="item.expired" class="ims" />
              <img :src="userful" v-else class="ims" />
            </div>
            <div class='rightOne'>
              <img :src="rightArraw" class="riA" />
            </div>
          </div>

          <div class='two'>
            <div class='leftTwo'>
              <div class="time">
                <div class="cnFont">入校时间</div>
                <div class='timeFont'>{{ item.returningStartTime }}</div>
              </div>
              <div class="time">
                <div class="cnFont">离校时间</div>
                <div class='timeFont'>{{ item.returningEndTime }}</div>
              </div>

            </div>
            <div class='rightTwo'>
              <div class='contain'>
                <!-- item.expired -->
                <img v-if="item.expired" :src="school_icon_org" class='ims2' />
                <img v-else :src="school_icon_blue" class='ims2' />
              </div>
              <div class='perShow'>
                <p> {{ item.numberOfAccompanyingPersons }}人</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </van-list>
  </div>
</template>
<script lang="ts" setup>
import { useRouter, useRoute } from "vue-router";
import rightArraw from "@/assets/appointment/rightArraw.png";
import useless from "@/assets/appointment/useless.png";
import userful from "@/assets/appointment/userful.png";
import school_icon_blue from "@/assets/appointment/school_icon_blue.png";
import school_icon_org from "@/assets/appointment/school_icon_org.png";
import Api, { returnSchoolList, returnSchoolDetail } from "@/api/servive";
import { isLiaoShiDa } from '@/utils/customizedType';

const router = useRouter();
const query = ref({
  pageNum: 1,
  pageSize: 10
});
const qrcodeUrl = ref("");
const loading = ref(false);
const finished = ref(false);
const isLastPageb = ref(false);
const list = ref([] as any);
const onClickLeft = () => {
  router.back();
};

const onLoad = async () => {
  query.value.pageNum = query.value.pageNum + 1;
  await initList();
};

const jumpDetail = (val: string) => {
  if (isLiaoShiDa()) {
    router.push({ path: "/backSchoolDetail-ln", query: { returningSchoolId: val } });
  } else {
    router.push({ path: "/backSchoolDetail", query: { returningSchoolId: val } });
  }
};

const initList = async () => {
  //returnSchoolList
  loading.value = true;
  const { data, code, msg } = await returnSchoolList(query.value);
  console.log(data);
  if (code == 200) {
    loading.value = false;
    isLastPageb.value = data.isLastPage;
    list.value = list.value.concat(data.list);
  } else {
    loading.value = false;
  }
  if (isLastPageb.value) {
    loading.value = false;
    finished.value = true;
  }
  //   await initQrcode();
};

const initQrcode = async () => {
  const { data, code, msg } = await returnSchoolDetail({
    returningSchoolId: list.value[0].returningSchoolId
  });
  qrcodeUrl.value = data[0].qrCode;
};

onMounted(async () => {
  console.log(Api);
  await initList();
  console.log("backSchool");
});
</script>

<style lang='less' scoped>
.con {
  width: 100%;
  //   height: 100%;
  padding: 0px 32px;
  padding-top: 39px;
}

.title {
  font-size: 40px;
  font-weight: 500;
  color: #000000;
  // line-height:36px;
  font-family: PingFang-SC-Medium, PingFang-SC;
  margin-bottom: 49px;
}

.itemList {
  width: 100%;

  //   height: 100%;
  //   height: 99vh;
  //   overflow: auto;
  .usefulItem {
    background: #f3f1fe;
  }

  .uselessItem {
    background: #eff7fb;
  }

  .item {
    width: 100%;
    // height: 192px;
    border-radius: 16px;
    margin-bottom: 18px;

    .one {
      width: 100%;
      height: 80px;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #e0daff;
      padding: 12px 24px 13px 24px;
    }

    .two {
      width: 100%;
      height: 111px;
      display: flex;
      justify-content: space-between;
      padding: 12px 24px 13px 24px;
      position: relative;

      .leftTwo {
        width: 80%;
        height: 100%;

        .time {
          //   height: 40px;
          width: 100%;
          height: 50%;
          display: flex;
          font-size: 0px;

          .cnFont {
            font-family: PingFang-SC-Medium, PingFang-SC;
            font-size: 24px;
            font-weight: 400;
            color: #666666;
          }

          .timeFont {
            padding-left: 20px;
            font-family: PingFang-SC-Medium, PingFang-SC;
            color: #222222;
            font-size: 24px;
          }
        }
      }

      .rightTwo {
        width: 20%;
        height: 100%;
        text-align: center;

        .perShow {
          color: #ff2a2a;
          font-size: 32px;
          font-weight: 500;
        }

        .contain {
          width: 185px;
          height: 192px;
          position: absolute;
          right: 0px;
          bottom: 0px;
        }

        .ims2 {
          width: 185px;
          height: 192px;
        }
      }
    }

    .leftOne {
      width: 100%;
      display: flex;
      align-items: center;

      .title1 {
        font-size: 36px;
        font-family: PingFang-SC-Medium, PingFang-SC;
        font-weight: 500;
      }

      .useful {
        color: #564486;
      }

      .useless {
        color: #0993d7;
      }

      .ims {
        padding-left: 20px;
        width: 143px;
        height: 42px;
      }
    }

    .rightOne {
      width: 100%;
      display: flex;
      align-items: center;
      flex-direction: row-reverse;

      .riA {
        width: 32px;
        height: 32px;
      }
    }
  }
}
</style>

