<template>
  <main class="wrap">
    <nav-bar-2 left-arrow @click-left="goBack" title="档案补办记录" />
    <van-empty v-if="listData.length == 0" description="暂无补办记录" />
    <van-list class="list-wrap" v-model:loading="loading" :finished="finished" @load="getListData">
      <div class="item-wrap" v-for="item in listData" :key="item.id">
        <div class="item-wrap_info">
          <div class="lf-wrap">
            <div class="line" />
            <div class="info">
              <span class="name">{{ item.archiveType }}</span>
              <span class="date">{{ item.createDt }}</span>
            </div>
          </div>
          <div class="status" :style="{
            background: stautsObj[item.status]?.bgColor,
            color: stautsObj[item.status]?.color,
          }">
            <span>{{ stautsObj[item.status]?.txt }}</span>
          </div>
        </div>
        <span class="item-wrap_reason gray" v-if="item.remark">备注：{{ item.remark }}</span>
        <span class="item-wrap_reason" v-if="item.reason">拒绝原因：{{ item.reason }}</span>
      </div>
    </van-list>
  </main>
</template>

<script lang="ts" setup>
import { ref, onBeforeMount, reactive } from 'vue';
import { list as fetchListData } from '@/api/archive/online';
import { useGoBack } from '@/hooks/useGoBack';
import { stautsObj } from './constant';

const { goBack } = useGoBack();

const listData = ref<ArchiveOnline[] | ArchiveRead[]>([]);
const page = reactive({
  pageNum: 0,
  pageSize: 10,
});

const loading = ref(false);
const finished = ref(false);

async function getListData() {
  try {
    loading.value = true;
    const result = await fetchListData({
      pageNum: ++page.pageNum,
      pageSize: page.pageSize,
    });
    if (result.code == 200) {
      const { list, pages, pageNum } = result.data;
      finished.value = pageNum >= pages;
      listData.value = pageNum == 1 ? list : [...listData.value, ...list];
    }
  } catch (err) {
    console.log('getListData err', err);
  } finally {
    loading.value = false;
  }
}

onBeforeMount(() => {
  getListData();
});
</script>

<style lang="less" scoped>
.wrap {
  min-height: 100vh;
  background: #f8f8f8;
}

.list-wrap {
  padding: 30px;

  .item-wrap {
    margin: 0 0 24px;
    padding: 32px 32px 32px 0;
    width: 100%;

    border-radius: 16px;
    background: #fff;

    .item-wrap_info {
      display: flex;
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
    }

    .item-wrap_reason {
      padding-left: 32px;
      display: inline-block;
      width: 100%;
      margin-top: 20px;
      &.gray{
        color: #999;
      }
    }

    .lf-wrap {
      display: flex;
      flex-direction: row;

      .line {
        margin-right: 25px;
        width: 6px;
        height: 32px;
        background: #0570c9;
        border-radius: 0px 5px 5px 0px;
      }

      .info {
        display: flex;
        flex-direction: column;

        .name {
          font-size: 32px;
          color: #333;
        }

        .date {
          margin: 20px 0 0;
          font-size: 24px;
          color: #666;
        }
      }
    }

    .status {
      padding: 7px 26px;
      font-size: 26px;
      border-radius: 25px;
    }
  }
}</style>
