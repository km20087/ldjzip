export const stautsObj: any = {
  0: {
    txt: '未办理',
    color: '#E1F2FF',
    bgColor: '#0570C9',
  },
  1: {
    txt: '办理中',
    color: '#FF8300',
    bgColor: '#FBE9D3',
  },
  2: {
    txt: '已办理',
    color: '#0F9400',
    bgColor: '#E4F2E2',
  },
  3: {
    txt: '已拒绝',
    color: '#df6472',
    bgColor: '#f9eaeb',
  },
};
