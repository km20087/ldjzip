import { ref } from 'vue';
import MyServe from '@/api/my';

export function useMyInfo() {
  const userInfo = ref<any>();
  // 获取个人信息
  async function getMyInfo() {
    try {
      const result = await MyServe.getDetailedInformation();
      if (result.code == 200) {
        userInfo.value = result.data;
      }
    } catch (err) {
      console.log('getMyInfo err', err);
    }
  }

  return {
    userInfo,
    getMyInfo,
  };
}
