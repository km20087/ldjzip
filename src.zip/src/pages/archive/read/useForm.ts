import { computed, Ref } from 'vue';
import { fetchGetConfig } from '@/api/archive/online';
import { BusinessType, SchoolingLengthOpt } from '../constant';

interface UseHookParams {
  data: Ref<any>;
}

export function useForm({ data }: UseHookParams) {
  const archiveTypeOpt = ref<selectOptions[]>([{ label: '1', value: '1' }]);
  const timeObj = ref<Record<string, string[]>>({});
  const customFieldName = { text: 'label', value: 'value' };

  const formConfig = computed(() => {
    const _DelegateInfo = [
      {
        label: '被委托人有效身份证件图片：',
        prop: '',
        type: 'upload',
        isUploadIdCard: true,
        mode: 'mode3',
        faceTxt: '身份证人面像',
        emblemTxt: '身份证国徽像',
        frontProp: 'principalCertificateFront',
        backProp: 'principalCertificateBack',
      },
      { label: '被委托人联系方式', prop: 'principalContact', type: 'text' },
      {
        label: '校友委托书',
        prop: '',
        type: 'upload',
        mode: 'mode3',
        isUploadOther: true,
        otherProp: 'alumniWarrant',
      },
    ];
    const delegateInfo = data.value.isDelegate == '0' ? [] : _DelegateInfo;
    const timeOpt = timeObj.value[data.value.archiveType];
    return [
      {
        title: '预约时间',
        config: [
          {
            label: '预约查阅文件类型',
            prop: 'archiveType',
            type: 'select',
            columns: archiveTypeOpt.value,
          },
          {
            label: '预约查询日期',
            prop: 'appointmentDate',
            type: 'date',
          },
          {
            label: '预约查询时间',
            prop: 'appointmentTimePeriod',
            type: 'select',
            columns: timeOpt,
          },
        ],
      },
      {
        title: '基础信息',
        config: [
          { label: '姓名', prop: 'stuName', type: 'text' },
          { label: '联系方式', prop: 'contact', type: 'text' },
        ],
      },
      {
        title: '学院信息',
        config: [
          { label: '学院', prop: 'collegeId', type: 'college' },
          { label: '专业', prop: 'majorId', type: 'major' },
          { label: '学制', prop: 'schoolingLength', type: 'select', columns: SchoolingLengthOpt },
        ],
      },
      {
        title: '证明材料',
        config: [
          {
            label:
              '身份证及相关证明材料上传：（提醒：若因干部档案审核工作而补档案，最好将干部档案缺差单在其他材料上传）',
            prop: '',
            type: 'upload',
            isUploadIdCard: true,
            mode: 'mode3',
            faceTxt: '身份证人面像',
            emblemTxt: '身份证国徽像',
            isUploadOther: true,
            frontProp: 'certificateFront',
            backProp: 'certificateBack',
            otherProp: 'otherMaterial',
          },
          { label: '是否委托查阅', prop: 'isDelegate', type: 'switch' },
          ...delegateInfo,
        ],
      },
    ];
  });

  async function getGetConfig() {
    const result = await fetchGetConfig({
      bizType: BusinessType.Read,
    });
    if (result.code == 200) {
      let { data } = result;
      archiveTypeOpt.value = data.reduce(
        (arr: string[], { archiveType, periods }: ArchiveGetConfig) => {
          arr.push(archiveType);
          timeObj.value[archiveType] = periods!;
          return arr;
        },
        []
      );
    }
  }

  return {
    formConfig,
    getGetConfig,
  };
}
