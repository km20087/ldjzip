<template>
  <div class="wrap">
    <Navbar title="档案服务" />
    <main class="main">
      <h1 class="title">档案查询及补办</h1>
      <div class="item" v-for="(item, index) in list" :key="index" @click="goPage(item.path)">
        <div class="lf">
          <img class="icon" :src="getImg(item.icon)" />
          <span class="txt">{{ item.title }}</span>
        </div>
        <img class="rt-icon" :src="getImg('archive/next.png')" />
      </div>
    </main>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed, onBeforeMount } from 'vue';
import { useRouter } from 'vue-router';
import { getImg } from '../utils';
import Navbar from '../components/nav-bar.vue';
import { SchoolCode } from '@/constants';
import { getSchoolCode } from '@/utils';
import { fetchGetConfig } from '@/api/archive/online';
import { BusinessType } from '../constant';

const schoolCode = getSchoolCode();
const router = useRouter();

const list = computed(() => {
  let defaultList = [
    { title: '在线补办档案', icon: 'archive/online.png', path: 'online' },
    { title: '查阅复印档案', icon: 'archive/read.png', path: 'read' },
    { title: '档案补办记录', icon: 'archive/record.png', path: 'record' },
  ]
  if (schoolCode == SchoolCode.ShanDa && readArchiveTypeList.value.length == 0) {
    defaultList.splice(1, 1)
  }
  return defaultList
});

const readArchiveTypeList = ref([])
async function getReadConfig() {
  const result = await fetchGetConfig({
    bizType: BusinessType.Read,
  });
  if (result.code == 200) {
    let { data } = result;
    readArchiveTypeList.value = data
  }
}

function goPage(path: string) {
  router.push({ path });
}

onBeforeMount(() => {
  if (schoolCode == SchoolCode.ShanDa) {
    getReadConfig()
  }
})

</script>

<style lang="less" scoped>
.wrap {
  width: 100vw;
  min-height: 100vh;
  background: #fafcfe;
}

.main {
  padding: 0 30px;
  box-sizing: border-box;
}

.title {
  margin: 0;
  padding: 80px 0 0;
  font-size: 40px;
  font-weight: 600;
  color: #000000;
}

.item {
  margin: 50px 0 0;
  padding: 30px 33px;
  background: #ffffff;
  border-radius: 16px;
  box-shadow: 0px 2px 14px 0px rgba(0, 0, 0, 0.08);
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;

  .lf {
    display: flex;
    flex-direction: row;
    align-items: center;

    .icon {
      width: 100px;
      height: 100px;
    }

    .txt {
      margin-left: 43px;
      font-size: 36px;
      font-weight: 600;
      color: #3f547f;
    }
  }

  .rt-icon {
    width: 44px;
    height: 44px;
  }
}
</style>
