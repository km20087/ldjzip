import { formatArray2Object } from '@/utils'
// 业务类型
export enum BusinessType {
  Online = '1',
  Read = '2',
}

export const BusinessTypeOpt = [
  { label: '在线补办档案', value: BusinessType.Online },
  { label: '查阅复印档案', value: BusinessType.Read },
]
export const BusinessTypeObj = formatArray2Object(BusinessTypeOpt)

// 领取方式
export const ReceiveTypeOpt = [
  { label: '邮寄', value: '1' },
  { label: '邮箱', value: '2' },
]
export const ReceiveTypeObj = formatArray2Object(ReceiveTypeOpt)

// 查阅时间段
export const TimeOpt = ['09:00-11:00', '14:00-16:00']

// 处理状态
export const StatusOpt = [
  { label: '未办理', value: '0' },
  { label: '办理中', value: '1' },
  { label: '已办理', value: '2' },
  { label: '已拒绝', value: '3' },
]
export const StatusObj = formatArray2Object(StatusOpt)

export const YesOrNoOpt = [
  { label: '否', value: '0' },
  { label: '是', value: '1' },
]

export const SchoolingLengthOpt = ['两年制', '三年制', '四年制', '五年制', '其他']
