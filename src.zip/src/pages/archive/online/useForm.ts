import { computed, Ref } from 'vue';
import { getYearOpt } from '../utils';
import { CardList, SchoolCode } from '@/constants';
import { fetchGetConfig } from '@/api/archive/online';
import { ReceiveTypeOpt, BusinessType, SchoolingLengthOpt } from '../constant';
import { getSchoolCode } from '@/utils';
interface UseHookParams {
  data: Ref<any>;
}

export function useForm({ data }: UseHookParams) {
  const YearOpt = getYearOpt();
  const archiveTypeOpt = ref<string[]>([]);
  const customFieldName = { text: 'label', value: 'value' };
  const schoolCode = getSchoolCode()

  const formConfig = computed(() => {
    let mailForm = [
      { label: '收件人姓名', prop: 'receiver', type: 'text' },
      { label: '收件人地址', prop: 'receiverAddress', type: 'area' },
      { label: '详细地址', prop: 'address', type: 'text' },
      { label: '联系电话', prop: 'contact', type: 'text' },
    ];
    let emailForm = [{ label: '邮箱地址', prop: 'email', type: 'text' }];
    const otherGetConfig =
      data.value.get == '1' ? mailForm : data.value.get == '2' ? emailForm : [];
    return [
      {
        title: '基础信息',
        config: [
          { label: '姓名', prop: 'stuName', type: 'text' },
          {
            label: '证件类型',
            prop: 'certificateType',
            type: 'select',
            columns: CardList,
            customFieldName: { text: 'text', value: 'cardId' },
          },
          { label: '证件号', prop: 'certificateNo', type: 'text' },
          {
            label: '补办档案类型',
            prop: 'archiveType',
            type: 'select',
            columns: archiveTypeOpt.value,
          },
          {
            label: '请点击上传您本人有效证件正反面：\n（证件请添加“材料仅供补办资料使用”水印）',
            prop: '',
            type: 'upload',
            isUploadIdCard: true,
            mode: 'mode2',
            frontProp: 'certificateFront',
            backProp: 'certificateBack',
          },
        ],
      },
      {
        title: '学历信息',
        config: [
          { label: '学院', prop: 'collegeId', type: 'college' },
          { label: '专业', prop: 'majorId', type: 'major' },
          { label: '学制', prop: 'schoolingLength', type: 'select', columns: SchoolingLengthOpt },
          { label: '入学年份', prop: 'enrollmentYear', type: 'select', columns: YearOpt },
          { label: '离校年份', prop: 'leavingYear', type: 'select', columns: YearOpt },
        ],
      },
      {
        title: '领取方式',
        config: [
          {
            label: '领取方式',
            prop: 'get',
            type: 'select',
            columns: ReceiveTypeOpt,
            customFieldName,
          },
          ...otherGetConfig,
        ],
      },
    ];
  });

  async function getGetConfig() {
    const result = await fetchGetConfig({
      bizType: BusinessType.Online,
    });
    if (result.code == 200) {
      let { data } = result;
      archiveTypeOpt.value = data.map(({ archiveType }: ArchiveGetConfig) => archiveType);
    }
  }

  return {
    formConfig,
    getGetConfig,
  };
}
