<template>
  <Navbar title="在线补办档案" />
  <section class="item-wrap" v-for="(item, index) in formConfig" :key="index">
    <Title :txt="item.title" />
    <div class="form-wrap">
      <template v-for="(form, i) in item.config" :key="i">
        <FormUpload v-if="/upload/.test(form.type)" v-model:data="data" v-bind="form" />
        <FormArea v-if="/area/.test(form.type)" v-model:data="data" v-bind="form" />
        <FormCollege
          v-else-if="/college/.test(form.type)"
          v-model:data="data"
          :label="form.label"
        />
        <FormMajor v-else-if="/major/.test(form.type)" v-model:data="data" :label="form.label" />
        <FormItem v-else v-model:data="data" v-bind="form" />
      </template>
    </div>
  </section>
  <van-dialog class="msgDialog" v-model:show="diaFlag" title="" :showCancelButton="false" :showConfirmButton="false">
      <div class="diaTitle">
        <p>请输入手机验证码</p>
      </div>
      <div class="con1">
        查阅复印档案，提交信息
      </div>
      <div class="con2">
        验证码送至您的手机{{userPhone}}
      </div>
      <div class="getCode">
        <div class="msg">
          <van-field v-model="inpMsgCode" placeholder="请输入短信验证码" />
          <span class="button">
            <span v-if="!downState" @click="getVerMsg">获取验证码</span>
            <van-count-down v-else time="60000" format="ss秒" class="timeDown" />
          </span>
        </div>        
    </div>

    <div class="bottom">
        <van-button class="cancel but1" @click="closeDialog">取 消</van-button>
        <van-button class="sure but1" @click="sendCheckMsg">确 定</van-button>

    </div>
  </van-dialog>
  <FormButton txt="提交" @click="submit" :disabled="isSubmitBtnDisabled" />
</template>

<script lang="ts" setup>
import Title from '../components/title.vue';
import FormItem from '../components/form-item.vue';
import FormUpload from '../components/form-upload.vue';
import FormButton from '../components/form-button.vue';
import FormCollege from '../components/form-college.vue';
import FormMajor from '../components/form-major.vue';
import FormArea from '../components/form-area.vue';
import { useMyInfo } from '../useMyInfo';
import { useGoBack } from '@/hooks/useGoBack';
import { useForm } from './useForm';
import { add } from '@/api/archive/online';
import { sendSmsPhone,checkSmsPhone } from '@/api/archive/read';
import { Toast } from 'vant';
import FileHandle from '@/utils/file-handle';
import Navbar from '../components/nav-bar.vue';
import { isLiaoShiDa } from '@/utils/customizedType';
import { getSchoolCode } from '@/utils';
import { SchoolCode } from '@/constants';
const schoolCode = getSchoolCode();
const fileHandle = new FileHandle(['certificateFront', 'certificateBack']);

const { goBack } = useGoBack();

const { userInfo, getMyInfo } = useMyInfo();

const data = ref<Partial<ArchiveOnline>>({});
const userPhone = ref('')
const isSubmitBtnDisabled = ref(false);
const diaFlag = ref(false)
const inpMsgCode = ref('')
const downState = ref(false)
const msgId = ref('')
watch(userInfo, () => {
  if (!userInfo.value) return;
  let {
    cardNumber,
    cardType,
    collegeId,
    collegeName,
    major,
    majorName,
    name,
    schoolStartYear,
    schoolEndYear,
    mobile,
    schoolId
  } = userInfo.value;
  userPhone.value = mobile
  data.value = {
    ...data.value,
    stuName: name,
    certificateType: cardType,
    certificateNo: cardNumber,
    collegeId,
    majorId: major,
    enrollmentYear: schoolStartYear,
    leavingYear: schoolEndYear,
    collegeName,
    majorName,
    schoolId
  };
});

const { formConfig, getGetConfig } = useForm({ data });
const sendCheckMsg = async () =>{
  if(!msgId.value){
    Toast.fail('请点击获取验证码')
    return
  }
  if(!inpMsgCode.value){
    Toast.fail('请输入验证码')
    return
  }    
  let res = await checkSmsPhone({mobile:userPhone.value as string,schoolId:data.value.schoolId as string,verCode:inpMsgCode.value,id:msgId.value})
  if(res.code == 200){
    Toast.success({
      message: res.msg,
    });
    submitApply()    
  }else{
    Toast.fail({
      message: res.msg,
    });    
  }
}

const closeDialog = () =>{
  diaFlag.value = false
  inpMsgCode.value = ''
  downState.value = false

}

const getVerMsg = async () =>{
  let res = await sendSmsPhone({mobile:userPhone.value as string,schoolId:data.value.schoolId as string,})
  if(res.code == 200){
    msgId.value = res.data as string
    Toast.success({
      message: res.msg,
    });
    downState.value = true
      setTimeout(() => {
        downState.value = false;
      }, 60000);
  }else{
    Toast.fail({
      message: res.msg,
    });
  }
}


const verifyForm = ()=>{
  console.log('formConfig',formConfig.value)
  let arr = formConfig.value
  let obj:any = {
      // ...(data.value as ArchiveRead),
      // ...fileHandle.compare(data.value),
      ...(data.value as ArchiveOnline),
      ...fileHandle.compare(data.value),
  }
  for(let i in arr){
    let item  = arr[i].config
    for(let a in item){
      if(item[a].type !=='upload' ){
        if(!obj[item[a].prop]){
          Toast.fail(`请输入${item[a].label}`)
          return false
        }
      }else{
        if((!obj['usefulUrls']) || (obj['usefulUrls'].length == 0)){
          Toast.fail('请上传证明材料')
          return false
        }
      }
    }
  }
  return true
}

function checkBeforeSubmit() {
  if (!data.value.get) {
    return '请选择领取方式';
  }
  if (isLiaoShiDa()) {
    if (!data.value.majorName) {
      return '请输入专业';
    }
  }
  return '';
}

const submitApply = async () =>{
    const { code, msg } = await add({
      ...(data.value as ArchiveOnline),
      ...fileHandle.compare(data.value),
    });
    if (code == 200) {
      Toast.success({ message: '提交成功' });
      setTimeout(() => goBack(), 800);
    } else {
      Toast.fail({ message: msg });
    }  
}

async function submit() {
  // console.log('submit',formConfig.value)
  let a = verifyForm()
  if(!a)return
  try {
    isSubmitBtnDisabled.value = true;
    let errorMessage = checkBeforeSubmit();
    if (errorMessage) {
      Toast({
        message: errorMessage,
        icon: 'none',
      });
      return;
    }

    if(schoolCode == SchoolCode.BaoTouZhiYeJiShu){
      diaFlag.value = true
      return
    }else{
      submitApply()
    }

  } catch (err) {
    console.log('submit err', err);
  } finally {
    isSubmitBtnDisabled.value = false;
  }
}

onBeforeMount(() => {
  getMyInfo();
  getGetConfig();
});
</script>

<style lang="less" scoped>
.form-wrap {
  padding: 0 30px;
}
.msgDialog{
  .van-dialog__confirm{
    background: #0570c9;
  }
}
.diaTitle{
  width: 100%;
  text-align: center;
  font-size: 36px;
  font-weight: 700;
}
.con1{
  color: #666666;
  font-size: 28px;
  margin-left: 40px;
  margin-top: 58px;
}

.con2{
  color: #666666;
  font-size: 32px;
  margin-top: 30px;
  margin-left: 40px;
}
.getCode{
  width: 100%;
  padding: 0 40px;
  box-sizing: border-box;
  margin-top: 30px;
  .msg{
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #E6E6E6;
    // margin-left: 40px;
    :deep(.van-cell){
      width: auto;
      padding-left: 0px;
    }
    .van-cell::after{
      display: none;
    }
    .button{
      border-radius: 30px;
      display: flex;
      height: 80px;
      min-width: 150px;
      align-items: center;
      justify-content: center;
      padding: 0px 20px;
      font-size: 28px;
      background: #f2f2f2;
      color: #0570c9;
    }    
  }
}
.bottom{
  width: 100%;
  padding: 40px 40px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  .but1{
    width: 280px;
    height: 80px;
    border-radius: 10px;
  }
  .sure{
    background: #0570c9;
    color: #ffffff;
  }
  .cancel{
    background: #f6f6f6;
    color: #666666;
    border:1px solid #BDBDBD;
  }
}
</style>
