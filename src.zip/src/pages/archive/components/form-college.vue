<template>
  <div class="form-item-wrap">
    <van-field
      class="custom-field"
      :label="label"
      v-model="dataClone.collegeName"
      placeholder="请选择"
      input-align="right"
      is-link
      readonly
      @click="showPicker = true"
    />
  </div>

  <van-popup v-model:show="showPicker" position="bottom">
    <van-picker
      :columns="list"
      :columns-field-names="customFieldName"
      @confirm="onConfirm"
      @cancel="showPicker = false"
    />
  </van-popup>
</template>

<script lang="ts" setup>
  import { ref, watch } from 'vue';
  import { useVModel } from '@/hooks/useVModel';
  import { useDept } from '@/hooks/useDept';
  const props = defineProps<{
    label: string;
    data: Record<string, any>;
  }>();

  const emits = defineEmits<{
    (e: 'update:data', data: Record<string, any>): void;
  }>();

  const dataClone = useVModel(props, 'data', emits);

  const { getDept } = useDept();

  const list = ref([]);
  const customFieldName = {
    text: 'deptName',
  };

  const showPicker = ref(false);

  const onConfirm = (value: any) => {
    dataClone.value.collegeName = value.deptName;
    dataClone.value.collegeId = value.deptId;
    showPicker.value = false;
  };

  onBeforeMount(async () => {
    list.value = await getDept();
  });
</script>

<style lang="less" scoped>
  .form-item-wrap {
    // padding: 34px 0 34px 26px;
    padding: 34px 0;
    border-bottom: 1px solid #dfdfdf;
    color: #666;
    display: flex;
    flex-direction: row;
    align-items: center;
    .custom-field {
      padding: 0;
      font-size: 28px;
      --van-field-label-color: #666;
      --van-field-label-width: 180px;
    }
  }
</style>
