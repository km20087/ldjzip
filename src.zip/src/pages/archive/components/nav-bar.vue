<template>
  <van-nav-bar class="nav" left-arrow @click-left="goBack" :title="title" @click-right="goNotePage">
    <template #right>
      <van-icon name="question-o" color="#979797" size="22" />
    </template>
  </van-nav-bar>
  <div class="fix-nav" />
</template>

<script lang="ts" setup>
  import { useRouter } from 'vue-router';
  import { useGoBack } from '@/hooks/useGoBack';

  defineProps<{
    title?: string;
  }>();

  const { goBack } = useGoBack();
  const router = useRouter();

  function goNotePage() {
    router.push('note');
  }
</script>

<style lang="less" scoped>
  .nav {
    width: 100vw;
    position: fixed;
    left: 0;
    top: 0;
  }
  .fix-nav {
    width: 1px;
    height: var(--van-nav-bar-height);
  }
</style>
