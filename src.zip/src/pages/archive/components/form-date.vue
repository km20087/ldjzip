<template>
  <div class="form-item-wrap">
    <van-field
      class="custom-field"
      :label="label"
      :modelValue="dataClone[prop]"
      placeholder="请选择"
      input-align="right"
      is-link
      readonly
      @click="showPicker = true"
    />
  </div>

  <van-popup v-model:show="showPicker" position="bottom">
    <van-datetime-picker
      v-model="date"
      type="date"
      title="请选择"
      :min-date="date"
      @confirm="onConfirm"
      @cancel="showPicker = false"
    />
  </van-popup>
</template>

<script lang="ts" setup>
  import { ref } from 'vue';
  import { useVModel } from '@/hooks/useVModel';
  import { fommatDate } from '@/utils/fommatDate';

  const props = defineProps<{
    label: string;
    prop: string;
    data: Record<string, string>;
  }>();

  const emits = defineEmits<{
    (e: 'update:data', data: Record<string, string>): void;
  }>();
  const date = new Date();
  const dataClone = useVModel(props, 'data', emits);

  const showPicker = ref(false);

  const onConfirm = (value: any) => {
    dataClone.value[props.prop] = fommatDate(value, 'yyyy-MM-dd');
    showPicker.value = false;
  };
</script>

<style lang="less" scoped>
  .form-item-wrap {
    // padding: 34px 0 34px 26px;
    padding: 34px 0;
    border-bottom: 1px solid #dfdfdf;
    color: #666;
    display: flex;
    flex-direction: row;
    align-items: center;
    .custom-field {
      padding: 0;
      font-size: 28px;
      --van-field-label-color: #666;
      --van-field-label-width: 235px;
    }
    :deep(.van-cell__right-icon) {
      top: 2px;
    }
  }
</style>
