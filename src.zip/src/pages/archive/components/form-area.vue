<template>
  <div class="form-item-wrap">
    <van-field
      class="custom-field"
      :label="label"
      :modelValue="data[prop]"
      placeholder="请选择"
      input-align="right"
      is-link
      @click="showPicker = true"
    />
  </div>
  <van-popup v-model:show="showPicker" position="bottom">
    <van-cascader
      v-model="cascaderValue"
      title="请选择"
      :options="options"
      :field-names="fieldName"
      @close="showPicker = false"
      @change="onChange"
      @finish="onFinish"
    />
  </van-popup>
</template>

<script lang="ts" setup>
  import { ref } from 'vue';
  import { useVModel } from '@/hooks/useVModel';
  import ApiDept from '@/api/common';

  interface ICascaderItem {
    value: string;
    selectedOptions: Area[];
  }
  const props = defineProps<{
    label: string;
    prop: string;
    data: Record<string, string>;
  }>();

  const emits = defineEmits<{
    (e: 'update:data', data: Record<string, string>): void;
  }>();

  const dataClone = useVModel(props, 'data', emits);

  const cascaderValue = ref('');
  const showPicker = ref(false);
  const options = ref([]);
  const areaP = reactive({
    parentNo: '',
    addrLevel: '1',
    addrName: '',
    pageSize: 100,
    pageNum: 1,
  });

  const fieldName = reactive({
    text: 'addrName',
    value: 'addrNo',
    children: 'children',
  });

  const onChange = async ({ value, selectedOptions }: ICascaderItem) => {
    let le = selectedOptions.length - 1;
    let ao = selectedOptions[le];
    if (ao.hasChild == '1') {
      areaP.parentNo = value;
      areaP.addrLevel = String(Number(ao.addrLevel) + 1);
      const { data, code, msg } = await ApiDept.areaList(areaP);
      selectedOptions.forEach((item: any) => {
        if (item.addrNo === value) {
          item.children = data.list;
        }
      });
    }
  };

  const onFinish = ({ value, selectedOptions }: ICascaderItem) => {
    let [{ hasChild }] = selectedOptions.slice(-1);
    // 当前选择的项是否有子孩， 若无则隐藏picker
    if (hasChild == '0') {
      showPicker.value = false;
    }
    dataClone.value[props.prop] = selectedOptions.reduce(
      (str, { addrName }) => ((str += addrName), str),
      ''
    );
  };

  const initArea = async () => {
    const { data, code, msg } = await ApiDept.areaList(areaP);
    if (code == 200) {
      if (areaP.addrLevel == '1') {
        options.value = data.list;
      }
    }
  };

  onBeforeMount(() => {
    initArea();
  });
</script>

<style lang="less" scoped>
  .form-item-wrap {
    // padding: 34px 0 34px 26px;
    padding: 34px 0;
    border-bottom: 1px solid #dfdfdf;
    color: #666;
    display: flex;
    flex-direction: row;
    align-items: center;
    .custom-field {
      padding: 0;
      font-size: 28px;
      --van-field-label-color: #666;
      --van-field-label-width: 235px;
    }
    :deep(.van-cell__right-icon) {
      top: 2px;
    }
  }
</style>
