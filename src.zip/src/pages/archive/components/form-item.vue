<template>
  <div class="form-item-wrap">
    <van-field
      v-if="/number|text/.test(type)"
      class="custom-field"
      :label="label"
      :type="(type as any)"
      v-model="dataClone[prop]"
      placeholder="请输入"
      input-align="right"
    />

    <van-field v-if="/switch/.test(type)" class="custom-field" :label="label" input-align="right">
      <template #input>
        <van-switch v-model="dataClone[prop]" :size="25" activeValue="1" inactiveValue="0" />
      </template>
    </van-field>

    <van-field
      v-if="/select/.test(type)"
      class="custom-field"
      :label="label"
      :modelValue="selectTxt"
      placeholder="请选择"
      input-align="right"
      is-link
      readonly
      @click="showPicker = true"
    />
  </div>

  <van-popup v-model:show="showPicker" position="bottom">
    <van-picker
      :columns="columns"
      :columns-field-names="customFieldName"
      @confirm="onConfirm"
      @cancel="showPicker = false"
    />
  </van-popup>
</template>

<script lang="ts" setup>
  import { ref } from 'vue';
  import { useVModel } from '@/hooks/useVModel';

  interface ICustomFiledName {
    text: string;
    value: string;
  }
  const props = withDefaults(
    defineProps<{
      label: string;
      prop: string;
      type?: string;
      data: Record<string, string>;
      columns?: any[];
      customFieldName?: ICustomFiledName;
    }>(),
    {
      type: 'text',
    }
  );

  const emits = defineEmits<{
    (e: 'update:data', data: Record<string, string>): void;
  }>();

  const dataClone = useVModel(props, 'data', emits);

  const selectTxt = computed(() => {
    if (!props.columns || !props.columns.length || !props.customFieldName)
      return dataClone.value[props.prop];
    let { text, value } = props.customFieldName;
    let idx = props.columns.findIndex((item) => item[value] == dataClone.value[props.prop]);
    return idx > -1 ? props.columns[idx][text] : dataClone.value[props.prop];
  });

  const showPicker = ref(false);

  const onConfirm = (chooseItem: any) => {
    let value = props.customFieldName ? chooseItem[props.customFieldName.value] : chooseItem;
    dataClone.value[props.prop] = value;
    showPicker.value = false;
  };
</script>

<style lang="less" scoped>
  .form-item-wrap {
    // padding: 34px 0 34px 26px;
    padding: 34px 0;
    border-bottom: 1px solid #dfdfdf;
    color: #666;
    display: flex;
    flex-direction: row;
    align-items: center;
    .custom-field {
      padding: 0;
      font-size: 28px;
      --van-field-label-color: #666;
      --van-field-label-width: 235px;
    }
    :deep(.van-cell__right-icon) {
      top: 2px;
    }
  }
</style>
