<template>
  <div class="btn-wrap">
    <van-button type="primary" round class="btn" :disabled="disabled">{{ txt }}</van-button>
  </div>
</template>

<script lang="ts" setup>
  defineProps<{
    txt: string;
    disabled: boolean;
  }>();
</script>

<style lang="less" scoped>
  .btn-wrap {
    padding: 50px 30px;
  }
  .btn {
    width: 100%;
    height: 88px;
    border-radius: 44px;

    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;

    font-size: 36px;
    letter-spacing: 2px;
  }
</style>
