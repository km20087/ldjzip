<template>
  <div class="title-wrap">
    <span class="txt">{{ txt }}</span>
  </div>
</template>

<script lang="ts" setup>
  const props = defineProps<{
    txt: string;
  }>();
</script>

<style lang="less" scoped>
  .title-wrap {
    padding: 40px 32px 20px;
    .txt {
      display: flex;
      flex-direction: row;
      align-items: center;
      font-size: 32px;
      font-weight: 500;
      color: #333333;
      &::before {
        margin-right: 19px;
        content: '';
        display: inline-block;
        width: 5px;
        height: 30px;
        background: var(--theme-color);
      }
    }
  }
</style>
