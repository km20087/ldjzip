<template>
  <div class="form-upload-wrap">
    <span class="title">{{ label }}</span>
    <div class="upload-wrap">
      <compress-uploader
        v-for="(item, index) in uploadConfig"
        :key="index"
        :class="`upload ${item.class}`"
        :after-read="(file:any) => afterRead(file, item.prop)"
      >
        <fix-image
          class="photo"
          v-if="data[item.prop]"
          :src="data[item.prop]"
          :width="item.class == 'mode2' ? 335 : 214"
          :height="item.class == 'mode2' ? 240 : 158"
        />
        <template v-else>
          <img class="img" :src="getImg(item.img)" />
          <i class="txt">{{ item.txt }}</i>
        </template>
      </compress-uploader>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import { computed } from 'vue';
  import { getImg } from '../utils';
  import ApiUpload from '@/api/uploadfile';
  import { useVModel } from '@/hooks/useVModel';

  const props = withDefaults(
    defineProps<{
      data: any;
      label?: string;
      isUploadIdCard?: boolean;
      faceTxt?: string;
      emblemTxt?: string;
      isUploadOther?: boolean;
      mode?: string; //这里是只有两种模式可选：'mode2' | 'mode3' 为了可以打包这里定义的类型为string
      frontProp?: string;
      backProp?: string;
      otherProp?: string;
    }>(),
    {
      isUploadIdCard: false,
      faceTxt: '证件正面',
      emblemTxt: '证件反面',
      isUploadOther: false,
      mode: 'mode3',
    }
  );
  const emits = defineEmits<{
    (e: 'update:data', data: any): void;
  }>();
  const dataClone = useVModel(props, 'data', emits);
  const uploadConfig = computed(() => {
    let result: any[] = [];
    if (props.isUploadIdCard) {
      let arr = [
        {
          class: `card ${props.mode}`,
          type: 'card_face',
          img: 'archive/card_face.png',
          txt: props.faceTxt,
          prop: props.frontProp,
        },
        {
          class: `card ${props.mode}`,
          type: 'card_emblem',
          img: 'archive/card_emblem.png',
          txt: props.emblemTxt,
          prop: props.backProp,
        },
      ];
      result.push(...arr);
    }

    if (props.isUploadOther) {
      let arr = [
        {
          class: `other ${props.mode}`,
          type: 'other',
          img: 'archive/plus@2x.png',
          txt: '点击上传',
          prop: props.otherProp,
        },
      ];
      result.push(...arr);
    }
    return result;
  });

  async function afterRead(file: any, prop: string) {
    try {
      let formData = new FormData();
      formData.append('file', file.file);
      formData.append('flag', 'Y');
      const result = await ApiUpload.uploadFile(formData);
      if (result.code == 200) {
        dataClone.value[prop] = result.data.tokenUrl;
      }
    } catch (err) {
      console.log('afterRead err', err);
    }
  }
</script>

<style lang="less" scoped>
  .form-upload-wrap {
    // padding: 0 0 32px 26px;
    padding: 0 0 32px;
  }
  .title {
    font-family: PingFangSC, PingFang SC;
    padding: 30px 0 20px;
    font-size: 28px;
    color: #666666;
    display: block;
    white-space: pre-wrap;
  }
  .upload-wrap {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    .upload {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      :deep(.van-uploader__input-wrapper) {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }
      &.card {
        background: #ffffff;
        border-radius: 4px;
        box-shadow: 0px 5px 20px 0px rgba(197, 202, 213, 0.25);
      }
      &.other {
        background: #f5f5f5;
        border-radius: 24px;
        .img {
          width: 44px;
          height: 44px;
        }
      }
      .txt {
        margin-top: 20px;
        font-size: 24px;
        color: #666666;
      }
      &.mode2 {
        flex: 1;
        height: 240px;
        margin-right: 20px;
        &:nth-of-type(2n) {
          margin-right: 0;
        }
        &.card {
          .img {
            width: 165px;
            height: 108px;
          }
        }
        .photo {
          width: 335px;
          height: 240px;
        }
      }
      &.mode3 {
        width: 214px;
        height: 158px;
        margin-right: 24px;
        &:nth-of-type(3n) {
          margin-right: 0;
        }
        &.card {
          .img {
            width: 108px;
            height: 70.7px;
          }
          .txt {
            margin-top: 13px;
          }
        }
        .photo {
          width: 214px;
          height: 158px;
        }
      }
    }
  }
</style>
