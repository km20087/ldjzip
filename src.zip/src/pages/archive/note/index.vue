<template>
  <nav-bar-2 left-arrow @click-left="goBack" title="操作说明" />
  <div v-html="detail" class="cont" />
</template>

<script lang="ts" setup>
  import { onBeforeMount, ref } from 'vue';
  import { useRoute } from 'vue-router';
  import { Toast } from 'vant';
  import { useSettingStore } from '@/store';
  import { getProtocolList, getProtocolDetail } from '@/api/news';
  import { useGoBack } from '@/hooks/useGoBack';
  import Api from '@/api/home';
  import { Base64 } from 'js-base64';

  const settingStore = useSettingStore();
  const { goBack } = useGoBack();

  const detail = ref('');

  async function getListData() {
    try {
      Toast.loading({ message: '加载中' });
      const result = await Api.getSchoolNews({
        newsType: 'archive',
        pageNum: 1,
        pageSize: 2,
      });
      if (result.code == 200) {
        console.log(result.data.list);
        const { list } = result.data;
        if (list && list.length) {
          getDetailData(list[0].niId);
        }
      }
    } catch (err) {
      console.log('err', err);
      Toast.clear();
    }
  }

  async function getDetailData(niId: string) {
    try {
      const result = await Api.getNewsDetail({ niId });
      if (result.code == 200) {
        detail.value = decodeURIComponent(
          Base64.decode(Base64.decode(Base64.decode(Base64.decode(result.data.content))))
        );
      }
    } catch (err) {
      console.log('err', err);
    } finally {
      Toast.clear();
    }
  }

  onBeforeMount(() => {
    getListData();
  });
</script>
<style lang="less" scoped>
  .cont {
    padding: 20px;
  }
</style>
