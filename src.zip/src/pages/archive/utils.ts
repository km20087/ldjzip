export function getImg(route: string) {
  return new URL(`../../assets/${route}`, import.meta.url).href;
}

export const getYearOpt = () => {
  let curYear = new Date().getFullYear();
  return Array.from({ length: 100 }, (_, i) => curYear - i);
};
