<template>
  <van-nav-bar :title="title" left-text="" left-arrow @click-left="onClickLeft" />
  <van-field
    v-model="query.albumName"
    label=""
    placeholder="填写相册名称"
    :class="query.albumName ? 'muan' : ''"
  />
  <van-field
    v-model="perName"
    is-link
    readonly
    name="picker"
    label="权限"
    placeholder="点击选择相册权限"
    @click="showPicker = true"
    input-align="right"
    v-if="isShowPermissionPicker"
  />
  <van-popup v-model:show="showPicker" position="bottom">
    <van-picker :columns="columns" @confirm="onConfirm" @cancel="showPicker = false" />
  </van-popup>
  <div class="but1">
    <van-button round type="danger" v-if="deShow" @click="deleteAlb" class="red">
      删除相册
    </van-button>
    <van-button round type="primary" @click="submit">完成</van-button>
  </div>
</template>

<script lang="ts" setup>
  import { reactive, ref } from 'vue';
  import Api from '@/api/orgPhoto';
  import { Toast } from 'vant';
  import { Dialog } from 'vant';
  import { albumParam } from '@/store';
  const router = useRouter();
  const $route = useRoute();
  const setAlbumParam = albumParam();
  const onClickLeft = () => {
    router.back();
  };
  const query = ref({
    albumName: '',
    permissionScope: '', //权限范围，0-全校可见，1-组织内可见
    albumType: '1', //0-校友相册，1-组织相册
    groupsId: '',
  });
  const isShowPermissionPicker = ref(false);
  const deShow = ref(false);

  const perName = ref('');
  const columns = reactive([
    { text: '全校可见', id: '0' },
    { text: '组织内可见', id: '1' },
  ]);
  const showPicker = ref(false);
  const title = ref('');
  // onBeforeMount(() => {
  //   console.log($route.query.type);
  // });
  const deleteAlb = async () => {
    Dialog.confirm({
      title: '警告',
      message: '确定删除吗',
      confirmButtonText: '确定删除',
    })
      .then(async () => {
        const { data, code, msg } = await Api.editAlbum({
          albumId: $route.query.albumId as string,
          status: '1',
        });
        Toast({ message: msg });
        if (code == 200) {
          router.back();
        }
      })
      .catch((err) => {
        // on cancel
        // Toast({ message: err.msg });
      });
  };
  const submit = async () => {
    if (deShow.value) {
      const { data, code, msg } = await Api.editAlbum({
        albumId: $route.query.albumId as string,
        albumName: query.value.albumName,
        permissionScope: query.value.permissionScope,
      });
      if (code == 200) {
        router.back();
      }
    } else {
      if (setAlbumParam.type == '0') {
        query.value.albumType = '0';
      }
      const { data, code, msg } = await Api.addAlbum(query.value);
      if (code == 200) {
        router.back();
      } else {
        Toast({ message: msg });
      }
    }
  };
  const onConfirm = (value: any) => {
    query.value.permissionScope = value.id;
    perName.value = value.text;
    showPicker.value = false;
  };

  onBeforeMount(() => {
    console.log($route.query.type);
    isShowPermissionPicker.value = setAlbumParam.type != '0';
    if ($route.query.type == 'add') {
      title.value = '新增相册';
      deShow.value = false;
    } else {
      title.value = '编辑相册';
      query.value.albumName = $route.query.albumName as string;
      query.value.permissionScope = $route.query.permissionScope as string;
      for (let i in columns) {
        if (columns[i].id == query.value.permissionScope) {
          perName.value = columns[i].text;
        }
      }
      deShow.value = true;
    }
    query.value.groupsId = $route.query.groupsId as string;
  });
</script>

<style lang="less" scoped>
  /deep/.van-field__control {
    font-size: 32px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #999999;
  }
  .muan {
    /deep/.van-field__control {
      font-size: 32px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #333333;
    }
  }
  /deep/ .van-cell__title {
    font-size: 32px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #333333;
  }
  /deep/.van-field__label::before {
    content: none;
  }
  .but1 {
    width: 100%;
    // margin:0 auto;
    text-align: center;
    margin-top: 80px;
    .van-button--round {
      width: 92%;
      height: 88px;
      border-radius: 44px;
    }
    .red {
      margin-bottom: 43px;
    }
  }
</style>
