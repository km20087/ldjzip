<template>
  <div class="con">
    <van-sticky>
      <van-nav-bar title="审核页面" left-arrow @click-left="onClickLeft" />
      <div class="result">
        <div class="logo" v-if="Flag">
          <img :src="checked" alt="" class="ims" />
        </div>
        <div class="logo" v-else>
          <img :src="failed" alt="" class="ims" />
        </div>
        <div class="tips" v-if="Flag">
          <p class="poo">审核中</p>
          <p class="oiis">您的申请信息已经提交，请耐心等待审核</p>
        </div>
        <div class="tips" v-else-if="userStatus == '05'">
          <p class="poo">审核失败</p>
          <p class="oiis">您申请的校友认证信息有误，原因如下：</p>
        </div>
        <div class="tips" v-else>
          <p class="poo">提交失败</p>
          <p class="oiis">您申请的校友认证信息有误 请重新认证校友</p>
        </div>
        <div class="info" v-if="Flag">
          <div class="ik"
            ><p class="as">姓名：</p><p class="was">{{ formData.name }}</p></div
          >
          <div class="ik" v-if="schoolLevel == '2'"
            ><p class="as">学号：</p><p class="was">{{ formData.studentIdNumber }}</p></div
          >
          <div class="ik" v-if="schoolLevel == '2'"
            ><p class="as">院系：</p><p class="was">{{ formData.collegeName }}</p></div
          >
          <!-- <div class="ik" v-else-if="schoolLevel == '1'"
            ><p class="as">{{schoolConfig.education}}</p><p class="was">{{ formData.education }}</p></div
          >           -->
        </div>
        <div class="osoo" v-else-if="userStatus == '05'">
          <p class="was">{{ reason }}</p>
        </div>
        <div class="button">
          <van-button round class="bu1 can" @click="returnIndex">返回</van-button>
          <van-button round type="primary" class="bu1 sure" @click="comeSuB" v-if="!isLiaoShiDa">重新提交</van-button>
          <van-button round type="primary" class="bu1 hurry" @click="urg" v-if='!isLiaoShiDa && urgeAuditFlag'>催促审核</van-button>
        </div>
      </div>
    </van-sticky>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref } from "vue";
import { useRouter, useRoute } from "vue-router";
import checked from "@/assets/img/checked.png";
import ApiMy from "@/api/my";
import { Toast } from 'vant';
import failed from "@/assets/img/failed.png";
import { SchoolCode } from '@/constants'
import { getSchoolCode, getUserStatus } from "@/utils";
  import {schoolShowConfig,zhongxueConfig} from "@/utils/schoolLevelShow"
let schoolCode = getSchoolCode()
const isLiaoShiDa = schoolCode == SchoolCode.LiaoShiDa

const name = ref("");
const yuanxi = ref("");
const studentIdNumber = ref("");
const $router = useRouter();
const route = useRoute();
const userStatus = ref("");
const urgeAuditFlag = ref(false);
const onClickLeft = () => {
  $router.push({path:"/tab/index"})
}
const formData = <any>reactive({
  name: "",
  studentIdNumber: "",
  collegeName: ""
});
const schoolLevel = ref('')
const schoolConfig = <any>ref({})
const reason = ref("");
const Flag = ref(false);
const comeSuB = () => {
  $router.push({ path: "/editPerInfo" });
};
const returnIndex = () => {
  $router.push({ name: "index" });
};
const initPer = async () => {
  const { data, code, msg } = await ApiMy.getAuditInformation({});
  Object.assign(formData, data);
  urgeAuditFlag.value = data.urgeAuditFlag
};
const urg =async ()=>{
  const {data,code,msg} = await ApiMy.urgeAudit({});
  Toast({message:msg});
  urgeAuditFlag.value = false
}
onMounted(() => {
  schoolLevel.value =  schoolShowConfig() as string
  schoolConfig.value =  zhongxueConfig()
  userStatus.value = getUserStatus() as string;
  Flag.value =
    userStatus.value == "04" ||
    userStatus.value == "06" ||
    userStatus.value == "00" ||
    userStatus.value == "03";
  if (userStatus.value == "05") {
    reason.value = sessionStorage.getItem("resson") as string;

    if(reason.value == null || reason.value == 'null'){
      reason.value = ""
    }
  }
  initPer();
});
</script>

<style lang="less" scoped>
.con {
  width: 100%;
  height: 100%;
  .result {
    width: 100%;
    height: 100%;
    margin: 0 auto;
  }
  .logo {
    margin-top: 200px;
    text-align: center;
    .ims {
      width: 120px;
      height: 120px;
    }
  }
  .tips {
    width: 100%;
    text-align: center;
    .poo {
      font-size: 36px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #333333;
    }
    .oiis {
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #666666;
    }
  }
  .osoo {
    width: 650px;
    height: 264px;
    background: #f8f8f8;
    border-radius: 16px;
    margin: 0 auto;
    padding: 0 50px;
    word-wrap: break-word;
    .was {
      widows: 100%;
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #333333;
    }
  }
  .info {
    width: 650px;
    height: 264px;
    background: #f8f8f8;
    border-radius: 16px;
    margin: 0 auto;
    padding: 0 50px;

    .ik {
      width: 100%;
      height: 60px;
      border-radius: 16px;
      display: flex;
      justify-content: space-between;
      // align-content: center;
      // word-wrap: break-word;
      flex-wrap: wrap;
      .as {
        font-size: 28px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #666666;
      }
      .was {
        font-size: 28px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #333333;
        flex:1;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3;
        overflow: hidden;
        word-break: break-all;        
      }
    }
  }
  .button {
    display: flex;
    // margin: 0 50px;
    margin-top: 80px;
    justify-content: center;
    align-items: center;
    .bu1 {
      width: 220px;
      height: 88px;
    }
    .can {
      font-size: 36px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 900;
      color: #333333;
      margin-right:21px;
    }
    .sure {
      font-size: 36px;
      color:var(--theme-color);
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 900;
      background:#fff;
       margin-right:21px;
      // color: #ffffff;
    }
    .hurry{
      font-size: 36px;
      background:var(--theme-color);
      color:#ffffff;
      font-weight: 900;
    }
  }
}
</style>
