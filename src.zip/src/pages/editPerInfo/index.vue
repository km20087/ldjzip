<template>
  <div class="con">
    <van-sticky>
      <van-nav-bar title="我的信息" left-arrow @click-left="onClickLeft" />
    </van-sticky>
    <div class="form">
      <van-form @failed="onFailed" input-align="right" @submit="onSubmit" error-message-align="right">
        <!-- <van-cell-group inset>
          <van-field
            label="姓名"
            required
            v-model="formData.name"
            name="pattern"
            placeholder=""
            :rules="[{ required: true, message: '请输入姓名' }]"
          />
          <van-field
            v-model="cardName"
            is-link
            readonly
            required
            name="area"
            label="证件类型"
            placeholder="点击选择证件类型"
            @click="showArea = true"
            :rules="cardRules"
          />
          <van-popup v-model:show="showArea" position="bottom">
            <van-picker :columns="CardList" @confirm="onConfirm" @cancel="showArea = false" />
          </van-popup>
          <van-field
            label="证件号"
            v-model="formData.cardNumber"
            name="validator"
            required
            :rules="[{ required: true, message: '请输入证件号' }]"
            placeholder="请输入证件号"
          />
          <van-field
            label="手机号"
            v-model="formData.mobile"
            name="validator"
            readonly
            placeholder="请输入手机号"
            :rules="[{ required: true, message: '请输入手机号' }]"
          />
          <van-field
            label="毕业时校名"
            v-model="formData.graduationSchoolName"
            name="validator"
            placeholder="请输入毕业时校名"
            required
            :rules="[{ required: true, message: '请输入毕业时校名' }]"
          />
          <van-field
            v-model="formData.schoolStartYear"
            is-link
            readonly
            required
            name="schoolStartYear"
            label="入学年份"
            placeholder="点击选择入学年份"
            @click="selectTimeFun('start')"
            :rules="timeStartRules"
          />
          <van-field
            v-model="formData.schoolEndYear"
            is-link
            readonly
            required
            name="schoolEndYear"
            label="毕业年份"
            placeholder="点击选择毕业年份"
            @click="selectTimeFun('end')"
            :rules="timeEndRules"
          />
          <van-popup v-model:show="startTimeFlag" position="bottom">
            <van-picker
              :columns="timeList"
              title="请选择年份"
              show-toolbar
              :default-index="select"
              @confirm="yearConfirmStart"
              @cancel="startTimeFlag = false"
            />
          </van-popup>
          <van-field
            v-model="formData.collegeName"
            is-link
            readonly
            name="coName"
            label="毕业院系"
            required
            placeholder="请选择"
            :rules="[{ required: true, message: '请输入毕业院系' }]"
            @click="columnShow('coName', '')"
          />
          <van-field
            v-model="formData.majorName"
            is-link
            readonly
            name="majorName"
            label="专业"
            required
            placeholder="请选择"
            :rules="[{ required: true, message: '请输入专业' }]"
            @click="columnShow('majorName', formData.collegeId)"
          />
          <van-field
            v-if="!claFlag"
            v-model="formData.classesName"
            is-link
            readonly
            name="classesName"
            label="班级"
            required
            placeholder="请选择"
            :rules="[{ required: true, message: '请输入班级' }]"
            @click="columnShow('classesName', formData.major)"
          />
          <van-field
            v-else
            label="班级"
            required
            v-model="formData.classesName"
            name="classesName"
            placeholder="请输入班级"
            :rules="[{ required: true, message: '请输入班级' }]"
          />
          <van-popup v-model:show="showPicker" position="bottom">
            <van-picker
              :columns="columns"
              @confirm="onConfirmPicker"
              @cancel="showPicker = false"
            />
          </van-popup>
          <van-field
            v-model="areaName"
            is-link
            readonly
            required
            name="area"
            label="省市"
            placeholder="点击选择省市"
            @click="showFlag = true"
            :rules="cardRules"
          />
          <van-popup v-model:show="showFlag" position="bottom">
            <van-cascader
              v-model="cascaderValue"
              title="请选择所在地区"
              :options="options"
              :field-names="fieldName"
              @close="showFlag = false"
              @change="onChange"
              @finish="onFinish"
            />
          </van-popup>
          <van-field
            label="学号"
            v-model="formData.studentIdNumber"
            name="validator"
            placeholder="请输入学号"
          />
          <van-field
            v-model="formData.bareheadedPhoto"
            readonly
            required
            name="bareheadedPhoto"
            label="免冠照片"
            input-align="left"
            error-message-align="left"
            :rules="[{ required: true, message: '请上传免冠照片' }]"
          >
            <template #input>
              <compress-uploader v-model="healthFileList" max-count="1" :after-read="afterRead" />
            </template>
          </van-field>
          <van-field
            label="工作单位"
            required
            v-model="formData.employer"
            name="validator"
            :rules="[{ required: true, message: '请输入工作单位' }]"
            placeholder="请输入工作单位"
          />
          <van-field
            label="职务"
            v-model="occupation.occupationName"
            name="validator"
            placeholder="请选择职务"
            readonly
            @click="goOccupationPage"
          />
        </van-cell-group> -->
        <van-cell-group inset :key="refreshFlag">
          <div class="woiasd" v-for="(item, index) in showList" :key="index">
            <van-field v-if="item.type == 'inp' && item.hasChild === ''" :label="item.cnName" :maxlength="item.maxlength"
              v-model="formData[item.enLabel]" name="pattern" :placeholder="placeholderEdit(item.enLabel,item.cnName)" :required="item.code == '3'" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" :disabled="item.enLabel == 'administrativeLevel' ? true : false" />
            <van-field v-else-if="item.type == 'inp' && item.hasChild === '1'" :label="item.cnName"
              v-model="formData[item.enLabel]" name="pattern" :placeholder="placeholderEdit(item.enLabel,item.cnName)" :required="item.code == '3'" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" />
            <van-field v-else-if="item.type == 'inp' && item.hasChild === '0'
              " :label="item.cnName" v-model="formData[item.enLabel]" name="pattern" :placeholder="placeholderEdit(item.enLabel,item.cnName)"
              :required="item.code == '3'" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" />
            <van-field v-else-if="item.type == 'inpSpecial' && item.enLabel === 'counselorName'
              " :label="item.cnName" v-model="formData[item.enLabel]" name="pattern" :placeholder="placeholderEdit(item.enLabel,item.cnName)"
              :required="item.code == '3'"
              :maxlength="5"
              :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" />              
              <!--  && parentIdFlag == item.parentId -->
            <van-field v-else-if="item.type == 'inpSpecial' &&
             majorNameType == 'input' && item.enLabel == 'majorName'" :label="item.cnName" v-model="formData[item.enLabel]" :name="item.enLabel" placeholder="请输入"
              :required="item.code == '3'" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" />  

              <van-field v-else-if="item.type == 'inpSpecial' && item.enLabel == 'collegeName'"
              v-model="formData[item.enLabel]" is-link readonly :name="item.enLabel" :label="item.cnName"
              :required="item.code == '3'" placeholder="请选择" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" @click="columnShow(item.enLabel,'')" />
                <van-field v-else-if="!handInpFalg &&  item.type == 'inpSpecial' && item.enLabel == 'majorName'"
              v-model="formData[item.enLabel]" is-link readonly :name="item.enLabel" :label="item.cnName"
              :required="item.code == '3'" placeholder="请选择" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" @click="columnShow(item.enLabel,formData.collegeId)" />   

            <van-field v-else-if="handInpFalg && item.enLabel == 'majorName'" v-model="formData['majorName']" label="专业" :placeholder="'请输入'+item.cnName"></van-field>
            
            <van-field v-else-if="item.enLabel == 'classesName' && !claFlag"
              v-model="formData[item.enLabel]" is-link readonly :name="item.enLabel" :label="item.cnName"
              :required="item.code == '3'" placeholder="请选择" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" @click="
  columnShow(
    item.enLabel,
    item.enLabel == 'majorName'
      ? formData.collegeId
      : item.enLabel == 'classesName'
        ? formData.major
        : ''
  )
  " />
            <van-field v-else-if="item.enLabel == 'classesName' && claFlag" :label="item.cnName"
              :required="item.code == '3'" v-model="formData[item.enLabel]" :name="item.enLabel" :placeholder="'请输入'+item.cnName" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" />
            <!--  -->
            <van-field v-else-if="item.type == 'special' && item.hasChild === ''" v-model="listParam[item.enLabel]"
              is-link readonly :name="item.enLabel" :label="item.cnName" :required="item.code == '3'" placeholder="请选择"
              :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" @click="showcol2(item.enLabel)" />
            <!-- question -->

            <van-field v-else-if="item.type == 'special' && item.hasChild == '1'" v-model="listParam[item.enLabel]"
              is-link readonly :name="item.enLabel" :label="item.cnName" :required="item.code == '3'" placeholder="请选择"
              :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" @click="showcol2(item.enLabel, item.enLabel)" />
            <van-field v-else-if="item.type == 'special' && item.hasChild == '0'
              " v-model="listParam[item.enLabel]" is-link readonly :name="item.enLabel" :label="item.cnName"
              :required="item.code == '3'" placeholder="请选择" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" @click="showcol2(item.enLabel)" />
              <!-- && parentIdFlag == item.parentId -->
            <van-field v-else-if="item.type == 'specialX' && item.enLabel == 'jobTitle' && (isLiaoShiDa()|| isChengDuYiXueYuan() ||isShenYangShiFan())" label="职务"
              v-model="formData[item.enLabel]" name="validator" placeholder="请输入职务" :required="item.code == '3'" />
            <van-field v-else-if="item.type == 'specialX' && item.enLabel == 'jobTitle' && !isLiaoShiDa() && !isShanDa()" :label="item.cnName"
              v-model="occupation.occupationName" name="validator" :required="item.code == '3'" :placeholder="'请选择'+item.cnName" readonly
              @click="goOccupationPage" />
              <!--  -->
            <van-field v-else-if="item.type == 'inpX' && isShanDa()" label="职务"
              v-model="occupationNameInp" name="validator" placeholder="请输入职务" />              
            <van-field v-else-if="item.type == 'specialX' && item.enLabel == 'areaName'" v-model="areaName" is-link
              readonly :required="item.code == '3'" name="area" :label="isGuangWenYi()?'所在省市':'省市'" :placeholder="isGuangWenYi()?'点击选择所在省市':'点击选择省市'" @click="changeShowFlag(item.enLabel)" :rules="[{ required: item.code == '3' ? true : false, message: `请选择${item.cnName}`}]" />

<van-field v-else-if="item.type == 'specialX' && (item.enLabel == 'studentSourceArea' || item.enLabel == 'workLifeLocation' )" v-model="formData[item.enLabel]" is-link
              readonly :required="item.code == '3'" name="area" :label="item.cnName" placeholder="点击选择地区" @click="changeShowFlag(item.enLabel)" :rules="[{ required: item.code == '3' ? true : false, message: `请选择${item.cnName}`}]" />
              <!-- "[
                { required: item.code == '3' ? true : false, message: `请上传${item.cnName}` },
              ]"     AreaRules-->

            <van-field v-else-if="item.type == 'specialX' && item.enLabel == 'residentArea'" v-model="residentArea"
              is-link readonly required name="residentArea" label="常住地区" placeholder="点击选择常住地区" @click="changeShowFlag(item.enLabel)"
              :rules="cardRules" />
            <van-field v-else-if="item.type == 'photo'" v-model="formData[item.enLabel]" readonly
              :required="item.code == '3'" :name="item.enLabel" :label="item.cnName" input-align="left"
              error-message-align="left" :rules="[
                { required: item.code == '3' ? true : false, message: `请上传${item.cnName}` },
              ]" @click="getType(item.enLabel)" class='upLoadPic'>
              <template #input>
                <compress-uploader v-if="item.enLabel == 'bareheadedPhoto'" v-model="healthFileList" max-count="1"
                  :after-read="afterRead" />
                  <!-- v-if="item.enLabel == 'bareheadedPhoto'" -->
                  <div class='uploadTips' v-if="item.enLabel == 'bareheadedPhoto'">
                  <div>图片规格仅限jpg,jpeg,png</div>
                  </div>                                         
                <compress-uploader v-if="item.enLabel == 'diplomaImage'" v-model="diplomaImageList" max-count="1"
                  :after-read="afterRead" />
                  <div class='uploadTips' v-if="item.enLabel == 'diplomaImage'">
                   <div>图片规格仅限jpg,jpeg,png</div>
                  </div>                     
                <compress-uploader v-if="item.enLabel == 'userProfilePicture'" v-model="userProfilePictureList"
                  max-count="1" :after-read="afterRead" @oversize="onOverSize"  />
                  <div v-if="item.enLabel == 'userProfilePicture'" class='uploadTips'>
                  <div class="weasdh">
                      <p  v-if="isGuangWenYi()">请上传证件照,用于制作校友卡,请勿上传身份证,</p>
                      <!-- <p  v-if="isGuangWenYi()">图片大小不能大于2MB,</p> -->
                      <p>图片规格仅限jpg,jpeg,png。</p>
                    </div>                    
                  </div>                  
                <compress-uploader v-if="item.enLabel == 'identificationDocumentImage'"
                  v-model="identificationDocumentImageList" max-count="1" :after-read="afterRead" />
                  <div class='uploadTips' v-if="item.enLabel == 'identificationDocumentImage'">
                   <div>图片规格仅限jpg,jpeg,png</div>
                  </div>                                      
              </template>
            </van-field>
            <!-- schoolEndYear  item.enLabel == 'schoolStartYear' ? 'start' : item.enLabel == 'schoolEndYear' ?'end':''-->
            <van-field v-else-if="item.type == 'select' && !!parentIdFlag && parentIdFlag == item.parentId"
              v-model="formData[item.enLabel]" is-link readonly :name="item.enLabel" :label="item.cnName"
              :required="item.code == '3'" placeholder="点击选择时间" @click="selectTimeFun(item.enLabel, item.code)" :rules="[
                {
                  required: item.code == '3' ? true : false,
                  validator:
                    item.enLabel == 'schoolStartYear'
                      ? (value) => timeStartRules(value, item.code)
                      : (value) => timeEndRules(value, item.code),
                },
              ]" />
            <van-field v-else-if="item.type == 'select' && !item.parentId" v-model="formData[item.enLabel]" is-link
              readonly :name="item.enLabel" :label="item.cnName" :required="item.code == '3'" placeholder="点击选择时间"
              @click="selectTimeFun(item.enLabel, item.code)" :rules="[
                {
                  required: item.code == '3' ? true : false,
                  validator:
                    item.enLabel == 'schoolStartYear'
                      ? (value) => timeStartRules(value, item.code)
                      : (value) => timeEndRules(value, item.code),
                },
              ]" />
            <van-field v-else-if="item.type == 'selectTime'" v-model="formData[item.enLabel]" is-link readonly
              :name="item.enLabel" :label="item.cnName" :required="item.code == '3'" placeholder="点击选择时间"
              @click="selectTimeBirFun()" :rules="[
                { required: item.code == '3' ? true : false, message: `请输入${item.cnName}` },
              ]" />
          </div>
          <van-popup v-model:show="showFlag"  @close="cancelPopup" :style="{height:'60%'}" position="bottom">
            <van-cascader v-model="cascaderValue" title="请选择所在地区" :options="options" :field-names="fieldName"
              @close="cancelOptionsDia" @change="onChange" @finish="onFinish" v-if="!areaInputFlag"/>
              <van-row  justify="center" align="center" v-else>
                <van-col :span="24" class='marginTop'>
                  <van-field label="国家:" input-align='center' @click="selectOutsideCountry" is-link v-model='outsideCountryName' readonly></van-field>
                </van-col>
                <van-col :span="24" class='marginTop'>
                  <van-field label="城市:" input-align='center' placeholder="请输入城市" v-model='outsideCityName'></van-field>
                </van-col>    
                <van-col :span="24" class='closeButton marginTop'>
                  <van-button round block type="primary" @click="closeOutsideCountry">
                    关闭
                  </van-button>
                </van-col>            
              </van-row>              
          </van-popup>
          <van-popup v-model:show="showPicker" position="bottom">
            <van-picker :columns="columns" @confirm="onConfirmPicker" ref="showAllTitle" class="wop" :class="{'ani-style':styleAn}" @change="showAllText" @cancel="showPicker = false" />
          </van-popup>
          <van-popup v-model:show="showBirthday" position="bottom">
            <van-datetime-picker v-model="britadayShow" type="date" title="选择年月日" :min-date="minDate"
              @confirm="onConfirmBirthdayPicker" @cancel="showBirthday = false" />
          </van-popup>
          <van-popup v-model:show="columnFlag2" position="bottom">
            <van-picker :columns="columns2" @confirm="onConfirmNationCountry" @cancel="columnFlag2 = false" />
          </van-popup>
          <van-popup v-model:show="startTimeFlag" position="bottom">
            <van-picker :columns="timeList" title="请选择年份" show-toolbar :default-index="select" @confirm="yearConfirmStart"
              @cancel="startTimeFlag = false" />
          </van-popup>
          <van-field v-if="showAluFlag" v-model="alumniName" is-link readonly name="area" label="校友会"
            placeholder="点击选择校友会" @click="showAlu = true" :required="showAluFlag" :rules="alumniRules" />
          <van-popup v-model:show="showAlu" position="bottom">
            <van-picker :columns="columnsAlu" :columns-field-names="fieldAlumniName" @confirm="onConfirmAlu"
              @cancel="showAlu = false" />
          </van-popup>

          <!--  -->
          <van-popup v-model:show="showNewSch" class="bottomPo" position="bottom" :style="{ height: '40%' }">
            <van-search class="fixtop" show-action v-model="inp" placeholder="请输入" @update:model-value="showChoice">
              <template #action>
                <div @click="sureChoice"> 确认 </div>
              </template>
            </van-search>
            <div class="itemShow">
              <div class="item" v-for="(item, index) in columns" :key="index" @click="sureItem(item)">
                {{ item.text }}
              </div>
            </div>
          </van-popup>
          <!--  -->
        </van-cell-group>

        <div class="butt1">
          <van-button round :disabled="loadingFlag" block type="primary" native-type="submit">
            提交
          </van-button>
        </div>
        <van-loading type="spinner" class="loadingioi" v-if="loadingFlag" color="#0094ff" size="28px"></van-loading>
      </van-form>
    </div>
  </div>
</template>

<script lang='ts'>
import { defineComponent } from 'vue';
export default defineComponent({
  beforeRouteEnter(to: any, from: any) {
    if (from.path == '/submited') {
      sessionStorage.setItem('subFlag', '1');
    }
  },
});
</script>

<script lang="ts" setup>
import { ref, reactive,getCurrentInstance } from 'vue';
import { Toast } from 'vant';
import { useRouter, useRoute } from 'vue-router';
import { formatDate, formatDateTime } from '@/utils/tool/time';
import ApiConfig from '@/api/config';
import Api from '@/api/user';
import ApiUpload from '@/api/uploadfile';
import ApiMy from '@/api/my';
import ApiDept from '@/api/common';
import FileHandle from '@/utils/file-handle';
import { useSettingStore, useUserStore } from '@/store';
import { useOccupation } from '@/hooks/useOccupation';
import { CardList,SchoolCode } from '@/constants';

// import listForm from "../infoConfig/data";
import listForm from '@/utils/dataList/infoConfig';
import nation from '@/utils/dataList/nation';
import country from '@/utils/dataList/country';
import datalist from '@/utils/dataList/datalist';
import baseInfo from '@/utils/dataList/baseInfo';
import jobInfo from '@/utils/dataList/jobInfo';
import company from '@/utils/dataList/company';
import stuInfo from '@/utils/dataList/stuInfo';
import { fommatDate } from '@/utils/fommatDate';
import { isLiaoShiDa,isShanDa,HeBeiShiFan,isShenYangYaoKeDaXue,speShowMajor,isBeiHuaHangTianGongYe,XiangXianZhongXue,isGuangWenYi,isChengDuYiXueYuan,isShenYangShiFan } from '@/utils/customizedType';
import { getRealFilePath, getSchoolCode, getSchoolId, getUserStatus, setUserStatus } from '@/utils'
import {schoolShowConfig} from "@/utils/schoolLevelShow"
import editEDu from "@/api/appEducationCorrection";
const userStore = useUserStore();
let fileHandle = new FileHandle(['bareheadedPhoto']);
let diplomaImageFile = new FileHandle(['diplomaImage']);
let userProfilePictureFile = new FileHandle(['userProfilePicture']);
let identificationDocumentImageFile = new FileHandle(['identificationDocumentImage']);
const schoolLevel = ref('')
const router = useRouter();
const route = useRoute();
const minDate = ref(new Date(1920, 0, 1));
const refreshFlag = ref(0);
const showArea = ref(false);
const startTimeFlag = ref(false);
const dateValue = ref('');
const timeList = <any>reactive([]);
const select = ref('');
const timeFlag = ref('');
const claFlag = ref(false);
const showAlu = ref(false);
const schoolList = <any>ref([]);
const education = ref('');
const showEdu = ref(false);
const columnsEdu = <any>ref([]);
const perList = <any>ref([]);
const showList = <any>ref([]);
const listInit = <any>ref([]);
const showAluFlag = ref(false);
const configList = <any>ref([]); //配置缓存数组
const alumniName = ref('');
const columnFlag2 = ref(false); //国籍或民族底部弹窗控制
const columns2 = <any>ref([]); //国籍或民族
const columnsAlu = <any>ref([]); //校友会
const healthFileList = <any>ref([]);
const diplomaImageList = <any>ref([]);
const loadingFlag = ref(false);
const userProfilePictureList = <any>ref([]);
const identificationDocumentImageList = <any>ref([]);
const typeName = ref('');
const cascaderValue = ref('');
const cardName = ref('');
const showPicker = ref(false);
const showFlag = ref(false);
const formData = <any>reactive({});
const listParam = <any>ref({});
const nameLabel = ref('');
const photoType = ref('');
const timeCode = ref('');
const parentNameFlag = ref('');
const parentIdFlag = ref('');
const editType = ref('');
const showAllTitle = ref()
const britadayShow = ref(new Date());
const showBirthday = ref(false);
const instance = getCurrentInstance()
const schoolCode = ref('');
const showAluPou = ref(false);
const shwoEditEdu = ref(false);
const showNewSch = ref(false);
const inp = ref('');
const inpId = ref('');
const fieldAlumniName = reactive({
  text: 'alumniAssociationName',
  value: 'alumniAssociationId',
});
const occupationNameInp = ref('')
const handInpFalg = ref(false)
const outsideCountry = <any>ref([])
const areaType = ref('')
const majorNameType = ref('select')

const areaInputFlag = ref(false)//地区下拉框输入
const outsideCityName = ref('')//国外城市名称
const outsideCountryName = ref('')//国外国家名称
const insideOrOutsideFlag = ref('0')//国内国外标志,inside:0,outside:1


const collegeAndMajorByHeBei = <any>ref({})
const collegeSureByHeBei = <any>ref({})
const collegeList = ref<{deptId: string, college: string}[]>([])
const registerFlag = ref('1')//0--未通过审核，1--通过审核
const styleAn = ref(false)
const gradeList = ref<Record<string, string>>({
  '本科':"本科",
  '硕士研究生':"硕士",
  '博士研究生':"博士",
  '专科':"专科"
})
const {
  occupation,
  initOccupation,
  goOccupationPage,
  pickOccupationToSubmit,
  getDataFromCache,
  getDataListCache,
} = useOccupation(formData, listParam.value);

const areaName = computed(() => {
    return getName(formData.provinceName) + getName(formData.cityName) + getName(formData.areaName)
    
});
const residentArea = computed(() => {
  return (
    getName(formData.provinceName) + getName(formData.cityName) + getName(formData.areaName) + ''
  );
});

const changeShowFlag = (val:string) =>{
  showFlag.value = true
  areaType.value = val
  initOptions()
}


const selectShow = async (val: any, type: string) => {
  //formData
  console.log(formData);
  typeName.value = type;
  inp.value = '';
  inpId.value = '';
  if (type == 'majorName' && formData.collegeId) {
    columns.value = [];
    await initClaOrMaj(formData.collegeId);
    showNewSch.value = true;
  } else if (type == 'classesName' && formData.major) {
    columns.value = [];
    await initClaOrMaj(formData.major);
    showNewSch.value = true;
  }
};
function getName(name: string | null) {
  return name || '';
}

const searchFiltering = (list: any, keywords: string) => {
  // let arr = JSON.parse(JSON.stringfy(list))
  let arr = [];
  // for(let a in keywords){}
  for (let i in list) {
    arr = list.filter((x: any) => {
      return x.text.indexOf(keywords) > -1;
    });
  }
  return arr;
};

const showChoice = () => {
  if (inp.value) {
    columns.value = searchFiltering(columns.value, inp.value);
  } else if (columns.value.length == 0 && inp.value == '') {
    if (typeName.value == 'majorName') {
      initClaOrMaj(formData.collegeId);
    } else {
      initClaOrMaj(formData.major);
    }
  }
  inpId.value = '';
};
const sureItem = (val: any) => {
  console.log(val);
  // console.log()
  inp.value = val.text;
  inpId.value = val.deptId;
};

const sureChoice = () => {
  if (typeName.value == 'majorName') {
    formData.majorName = inp.value;
    formData.major = inpId.value;
  } else if (typeName.value == 'classesName') {
    formData.classesName = inp.value;
    formData.classes = inpId.value;
  }
  console.log(formData);
  showNewSch.value = false;
};

const cardRules: any = [
  { required: true, message: '请选择省市' },
  {
    validator: (value?: any) => {
      console.log(value);
      if (!value) {
        return false;
      }
    },
    message: '请选择省市',
    trigger: ['onChange', 'onBlur'],
  },
];

const AreaRules: any = [
  { required: true, message: '请选择地区' },
  {
    validator: (value?: any) => {
      console.log('AreaRules',value);
      if (!value) {
        return false;
      }
    },
    message: '请选择地区',
    trigger: ['onChange', 'onBlur'],
  },
];

const alumniRules: any = [
  { required: true, message: '请选择校友会' },
  {
    validator: (value?: any) => {
      console.log(value);
      if (!value) {
        return false;
      }
    },
    message: '请选择校友会',
    trigger: ['onChange', 'onBlur'],
  },
];
const timeStartRules: any = (value: any, code: string) => {
  if (code == '3') {
    if (!value) {
      return '点击选择入学年份';
    } else if (
      Number(formData.schoolEndYear) > 1979 &&
      Number(formData.schoolEndYear) <= Number(value)
    ) {
      return '点击选择正确的入学年份';
    }
  } else {
    return '';
  }
};
const timeEndRules: any = (value: any, code: string) => {
  if (code == '3') {
    if (!value) {
      return '点击选择毕业年份';
    } else if (Number(value) <= Number(formData.schoolStartYear)) {
      return '点击选择正确的毕业年份';
    }
  } else {
    return '';
  }
};
const onOverSize = (file: File) => {
  if(isGuangWenYi()){
    // return Toast('文件大小不能超过2MB！')
  }else{
    return Toast('文件大小不能超过1MB！')
  }
  
}
const columns = <any>ref([]);
const options = <any>reactive([]);

const columnShowFlag = ref('');
const fieldName = reactive({
  text: 'addrName',
  value: 'addrNo',
  children: 'children',
});

const areaP = reactive({
  parentNo: '',
  addrLevel: '1',
  addrName: '',
  pageSize: 100,
  pageNum: 1,
});
const showcol2 = (name: string, parentName?: string) => {
  nameLabel.value = name;
  if (!!parentName) {
    parentNameFlag.value = parentName;
  }
  if (name == 'ethnic') {
    columns2.value = nation;
  } else if (name == 'nationality') {
    columns2.value = country;
  }else if(name == 'schoolmateType'){
    columns2.value = []
    let arr1:any = []
    for (let i in datalist) {
      if (datalist[i].type == "schoolmateType") {
        arr1 = datalist[i].list
      }
    }
    for(let a in configList.value){
      for(let b in arr1){
        if(configList.value[a].identityType == arr1[b].value){
          columns2.value.push(arr1[b])
        }
      }        
    }        
  } else {
    console.log('else');
    for (let i in datalist) {
      if (datalist[i].type == name) {
        columns2.value = datalist[i].list;
      }
    }
  }
  columnFlag2.value = true;
};
/***
 * name---enLabel
 * value--formData[item.enLabel]
 *
 */
const initFormData = (name: string, value: string) => {
  // console.log(name);
    for (let i in datalist) {
      if (datalist[i].type == name) {
        let param = datalist[i].list;
        for (let a in param) {
          if (param[a].value == value) {
            listParam.value[name] = param[a].text;
          }
        }
      }
    }  

  // if (name == "schoolmateType") {
  //   if (value == "0") {
  //     parentIdFlag.value = "1";
  //   } else {
  //     parentIdFlag.value = value;
  //   }
  // }
};
const onClickLeft = () => router.back();
const addTree = (selectedOptions: any, children: any, id: any) => {
  selectedOptions.forEach((item: any) => {
    if (item.addrNo === id) {
      item.children = children;
    }
  });
};
const onChange = async ({ value, selectedOptions, tabIndex }: any) => {
  console.log('onChange')
  // if(isShanDa()){
    if(selectedOptions[0].addrNo == '0' ){//国内
      let limitedNum = 0 
      if(areaType.value =='areaName'){
        limitedNum = 4
      }else{
        limitedNum = 3
      }
      console.log('limitedNum: ',limitedNum)
      if(selectedOptions.length < limitedNum){
        let le = selectedOptions.length - 1;
        let ao = selectedOptions[le];
        if (ao.hasChild == '1') {
          areaP.parentNo = String(value);
          areaP.addrLevel = String(Number(ao.addrLevel) + 1);
          const { data, code, msg } = await ApiDept.areaList(areaP);
          addTree(selectedOptions, data.list, value);
        } else {
          cancelOptionsDia()
        }       
      }else{
        cancelOptionsDia()
      }
    }else{//国外
      console.log('1221',selectedOptions)
      if(selectedOptions.length < 2){
        let le = selectedOptions.length - 1;
        let ao = selectedOptions[le];
        if (ao.hasChild == '1') {
            addTree(selectedOptions,outsideCountry.value,value)
        }else{
          cancelOptionsDia()
        }
      }else{
        console.log('1-1',areaType.value)
        if(areaType.value == 'workLifeLocation' && isGuangWenYi()){
          areaInputFlag.value = true
        }        
        cancelOptionsDia()
      }
    }
  // }
};
const getType = (type: string) => {
  photoType.value = type;
};
const cancelOptionsDia = () =>{
  if(!areaInputFlag.value){
    showFlag.value = false
    // initOptions()  
  }
}

const initOptions = ()=>{
  options.splice(options,options.length)
  initArea()
}
const getDefaultSchoolmate = (val: Array<any>) => {
  let arr = val;
  for (let i in arr) {
    if (arr[i].identityType == '0') {
      return arr[i];
    }
  }
};
//kfc
const getSchoolmateTypeByIdentity = (val: Array<any>) => {
  let arr = val;
  // let arr1 = [];
  let arr1 = {};
  for (let i in arr) {
    if (arr[i].identityType == formData.schoolmateType) {
      arr1 = arr[i];
    }
  }
  return arr1;
};
const initCountry = ()=>{
  let arr = <any>[]
  let CArr = <any>[]
    CArr = CArr.concat(country)
    for(let i in CArr){
      if(Number(i) > 0){
        arr.push({addrName:CArr[i].text,addrNo:CArr[i].value,hasChild:"0",parentNo:"1"})
      }
    }
    return arr
}


const initData = async () => {
  // console.log(route.query.editType); //修改个人信息类型，1-基本信息，2-学历信息，3-职务信息
  if (!route.query.editType) {
    listInit.value = listForm.listForm().list;
    // if (schoolCode.value == '4132010333') {
    //   // initEdu();
    //   showAluPou.value = true;
    // }
    if(speShowMajor()){
      registerFlag.value = '0'

    }
  } else if (route.query.editType == '1') {
    listInit.value = baseInfo();
  } else if (route.query.editType == '2') {
    listInit.value = stuInfo();
    // if (schoolCode.value == '4132010333') {
    //   // initEdu();
    //   showAluPou.value = true;
    // }
  } else if (route.query.editType == '3') {
    listInit.value = jobInfo();
    if (formData.schoolmateType == '3') {
      listInit.value = listInit.value.concat(company());
    }
  }
  editType.value = !!route.query.editType ? (route.query.editType as string) : '';
  const { data, code, msg } = await ApiConfig.infoConfigSchoolGet({enable:'1'});
  configList.value = data;
  if (code == 200) {
    schoolList.value = getSchoolmateTypeByIdentity(data);
    let objL = Object.getOwnPropertyNames(schoolList.value);
    if (objL.length == 0) {
      schoolList.value = getDefaultSchoolmate(data);
    }
    for (let i in listInit.value) {
      if (schoolList.value[listInit.value[i].enLabel] != '1' && schoolList.value[listInit.value[i].enLabel] != null && schoolList.value[listInit.value[i].enLabel] != undefined && schoolList.value[listInit.value[i].enLabel] != '') {
        showList.value.push({
          enLabel: listInit.value[i].enLabel,
          cnName: listInit.value[i].cnName,
          type: listInit.value[i].type,
          code: schoolList.value[listInit.value[i].enLabel],
          id: listInit.value[i].id ? listInit.value[i].id : '',
          hasChild: listInit.value[i].hasChild ? listInit.value[i].hasChild : '',
          maxlength:listInit.value[i].maxlength ? listInit.value[i].maxlength : 50,
          // parentName: listInit.value[i].parentName ? listInit.value[i].parentName : '',
          // parentId: listInit.value[i].parentId ? listInit.value[i].parentId : '',
        });
      }
    }
    console.log('showList.value',showList.value)
  } else {
    Toast({ message: msg });
  }
};

const showAreaFun = (val:string)=>{
    showFlag.value = true
    areaType.value = val
    // areaP.addrLevel = '1'
    // initArea()
}

const awd = ()=>{
  if(speShowMajor() && registerFlag.value === '0'){
      for(let i in collegeList.value){
        if(formData.collegeId == collegeList.value[i].deptId){
          formData.collegeName = collegeList.value[i].college
        }
      }   
  }  
}

const selectOutsideCountry = () =>{
  areaInputFlag.value = false
}
const closeOutsideCountry = ()=>{
  if(!!outsideCountryName.value && areaType.value == 'workLifeLocation' && isGuangWenYi()){
    formData[areaType.value] = outsideCountryName.value + outsideCityName.value
    outsideCityName.value = ''
    outsideCountryName.value = ''    
  }else{
    console.log('closeOutsideCountry--else')
  }
  areaInputFlag.value = false
  cancelOptionsDia()
}

const cancelPopup = ()=>{
  console.log('---cancelPopup---',areaType.value)
  if(areaType.value == 'workLifeLocation' && isGuangWenYi()){
    closeOutsideCountry()
  }else{
    cancelOptionsDia()
  }
}

const placeholderEdit = (enLabel:string,cnName:string)=>{
  if(isGuangWenYi()){
    if(enLabel == 'cardNumber'){//证件号码
      return '证件号码仅用于认证信息'
    }
    else if(enLabel == 'name'){//姓名
      return '请输入真实姓名'
    }
    else if(enLabel == 'mobile'){//联系方式
      return '请输入电话号码'
    }
    else{
      return '请输入'+cnName
    }
  }else{
    return '请输入'+cnName
  }
}

const onFinish = ({ value, selectedOptions, tabIndex }: any) => {
     let a = selectedOptions.length - 1;
    if(selectedOptions[0].addrNo == '0'){//国内
      if(areaType.value !='areaName'){
        if (selectedOptions[a].addrLevel == '1') {
          formData[areaType.value] = selectedOptions[a].addrName;
        } else if (selectedOptions[a].addrLevel >= '2') {
          formData[areaType.value] = formData[areaType.value] + selectedOptions[a].addrName;
        } 
      }else{
        if (selectedOptions[a].addrLevel == '1') {
          formData.provinceName = selectedOptions[a].addrName;
          formData.provinceId = selectedOptions[a].addrNo;
        } else if (selectedOptions[a].addrLevel == '2') {
          formData.cityName = selectedOptions[a].addrName;
          formData.cityId = selectedOptions[a].addrNo;
        } else if (selectedOptions[a].addrLevel == '3') {
          formData.areaName = selectedOptions[a].addrName;
          formData.areaId = selectedOptions[a].addrNo;
        }         
      }
    }else{//国外
      formData[areaType.value] = selectedOptions.map((option:any)=>{
        if(option.addrLevel !== '0'){
          return option.addrName
        }
      }).join('')      
      if(areaInputFlag.value){
        outsideCountryName.value = formData[areaType.value]
      }else{
        outsideCountryName.value = ''
      }         
    } 
};
//获取默认最新时间
const getCurrentYear = () => {
  var nowTime = new Date();
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  let dateValue1 = '';
  dateValue1 = formatDate(new Date(year, month, day));
  dateValue.value = String(dateValue1.slice(0, 4));
  // this.signs(this.dateValue)
};
const selectTimeFun = (flag: string, code: string) => {
  timeCode.value = code;
  timeFlag.value = flag;
  startTimeFlag.value = true;
};
const selectTimeBirFun = () => {
  showBirthday.value = true;
};
const yearConfirmStart = (value: string) => {
  formData[timeFlag.value] = value.toString();
  if(speShowMajor() && timeFlag.value == 'schoolStartYear'){
    formData.collegeName = ''
    formData.collegeId = ''
    formData.major = ''
    formData.majorName = ''    
    console.log('listParam',listParam.value)
  }
  startTimeFlag.value = false;
};
const getYearData = () => {
  var nowTime = new Date(dateValue.value);
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  for (let i: number = 1900; i < 2035; i++) {
    timeList.push(i);
  }

  let years = formatDate(new Date(year, month, day));
  let Year = years.slice(0, 4);

  select.value = timeList.indexOf(Number(Year));
};
const afterRead = async (file: any) => {
  let formData1 = new FormData();
  formData1.append('file', file.file);
  let isFlagY = ['userProfilePicture'].includes(photoType.value)
  formData1.append('flag', isFlagY ? 'Y' : '');//加密上传
  file.status = 'uploading';
  file.message = '上传中...';
  await ApiUpload.uploadFile(formData1)
    .then((res) => {
      if (res.code == 200) {
        file.status = '';
        file.message = '';
        formData[photoType.value] = isFlagY ? res.data.tokenUrl : res.data.uploadUrl;
        Toast.success('上传成功');
      } else {
        file.status = 'failed';
        file.message = '上传失败';
        Toast.fail(res.msg);
      }
    })
    .catch((err) => {
      file.status = 'failed';
      file.message = '上传失败';
      Toast.fail(`上传失败：${err}`);
    });
};
const onFailed = (errorInfo: any) => {
  console.log('failed', errorInfo);
};
const jump1 = () => {
  router.push({ path: 'second' });
  return;
};
const onSubmit = async () => {
  // console.log('formData---',formData)
  // return
  loadingFlag.value = true;
  let editType = '';
  if (route.query.editType) {
    editType = route.query.editType as string;
    formData.editType = editType;
  }
  pickOccupationToSubmit();
  let userStatus = getUserStatus();
  clearStuOrWorker(formData.schoolmateType);
  if(isShanDa()){
    subShanDaData()
  }
  if(isShanDa() || isLiaoShiDa() || isChengDuYiXueYuan() || isShenYangShiFan()){//职务:用户输入的话只传formData.jobTitle，用户列表选择的话就只传formData.occupationCode
    formData.occupationCode = ''
  }else{
    // formData.jobTitle = ''
    formData.jobTitle = formData.occupationCode
  }
  loadingFlag.value = false;

  if(speShowMajor()){
    if(!formData.collegeName){
      sessionStorage.removeItem('collegeAndMajorByHeBeiEdit')
    }
    let obj:any = {}
    if(!!sessionStorage.getItem('collegeAndMajorByHeBeiEdit')){
       obj = JSON.parse(sessionStorage.getItem('collegeAndMajorByHeBeiEdit') || "")
    }
    if(!!collegeAndMajorByHeBei.value?.newCollege){
      formData.collegeName = collegeAndMajorByHeBei.value.newCollege
      formData.collegeId = collegeAndMajorByHeBei.value.remark
    }else if(!!obj){
      formData.collegeName = obj?.newCollege
    }
    console.log(formData)
    console.log('collegeAndMajorByHeBei.value:',!!collegeAndMajorByHeBei?.value,collegeAndMajorByHeBei.value)
    // return
  } 

  console.log('onSubmit',formData)

  if (userStatus === '00' || '06') {
    if(isShanDa() && route.query.editType == '2'){

        formData.startYear = formData.schoolStartYear
        formData.endYear = formData.schoolEndYear
        formData.educationType = '1'
      // console.log('submit',
      // {        ...formData,
      //   ...fileHandle.compare(formData),
      //   ...diplomaImageFile.compare(formData),
      //   ...userProfilePictureFile.compare(formData),
      //   ...identificationDocumentImageFile.compare(formData),
      //   diplomaFile:formData.diplomaImage 
      //   })        
      const { code, msg } = await editEDu.applyAll({
        ...formData,
        ...fileHandle.compare(formData),
        ...diplomaImageFile.compare(formData),
        ...userProfilePictureFile.compare(formData),
       ...identificationDocumentImageFile.compare(formData),
        diplomaFile:formData.diplomaImage 
      });
      if (code == 200) {
        loadingFlag.value = false;
        Toast.success({ message: msg });
        // router.push({ path: '/login' });
        router.back();
        if(schoolCode.value != SchoolCode.ChengDeYiXueYuan){
          Toast({ message: '请等待审核' });
        }
        
      } else {
        loadingFlag.value = false;
        Toast.fail({ message: msg });
      }
    }else{
      const { code, msg } = await ApiMy.editAuditInformation({
        ...formData,
        ...fileHandle.compare(formData),
        ...diplomaImageFile.compare(formData),
        ...userProfilePictureFile.compare(formData),
        ...identificationDocumentImageFile.compare(formData),
      });
      if (code == 200) {
        loadingFlag.value = false;
        Toast.success({ message: msg });
        // router.push({ path: '/login' });
        router.back();
        if(schoolCode.value != SchoolCode.ChengDeYiXueYuan){
          Toast({ message: '请等待审核' });
        }
        
      } else {
        loadingFlag.value = false;
        Toast.fail({ message: msg });
      }
    }

  } else {
    const { code, msg, data } = await Api.completeSchoolmateInformation({
      ...formData,
      ...fileHandle.compare(formData),
      ...diplomaImageFile.compare(formData),
      ...userProfilePictureFile.compare(formData),
      ...identificationDocumentImageFile.compare(formData),
    });
    if (code == 200) {
      loadingFlag.value = false;
      Toast.success({ message: msg });
      setUserStatus(data.userStatus)
      router.push({ path: '/tab/index' });
      // router.back();
      Toast({ message: '请等待审核' });
    } else {
      loadingFlag.value = false;
      Toast.fail({ message: msg });
    }
  }
  const settingStore = useSettingStore();
  settingStore.check = true;
  userStore.isNeedInitOccupation = true;
};
const columnShow =async (val: string, id: string) => {
  console.log('columnShow',val,id)
  columnShowFlag.value = val;
  if(val == 'collegeName'){//isShanDa() && 
    handInpFalg.value = false
    claFlag.value = false;
  }
  if (!formData.collegeId && val == 'majorName') {
    Toast({ message: '请选择院系' });
    return;
  } else if (!isShanDa() && !XiangXianZhongXue() && schoolLevel.value !='1' && !formData.majorName && val == 'classesName') {
    Toast({ message: '请选择专业' });
    return;
  } else if (!XiangXianZhongXue() && !formData.collegeId && schoolLevel.value !='1' && val == 'classesName') {
    Toast({ message: '请选择院系' });//需要排除高中
    return;
  }
  if(speShowMajor()){
    if(val == 'collegeName'){
      if(!formData.education){
        Toast({ message: '请选择学历' });
      }
      if(!formData.schoolStartYear && !isBeiHuaHangTianGongYe()){
        Toast({ message: '请选择入学年份' });
      }else if(!formData.schoolEndYear && isBeiHuaHangTianGongYe()){
         Toast({ message: '请选择毕业年份' });
      }       
      // console.log('HeBeiShiFan===',listParam.value.education,formData.education,formData.schoolStartYear)
      initDept().then(() => {
        showPicker.value = true;
      });      
    }
    else if(val == 'majorName'){
       initClaOrMaj(id, true);
      //  showPicker.value = true;
    }
  }  
  else if (val === 'collegeName') {
    initDept().then(() => {
      showPicker.value = true;
      showAllText()
    });
  } else if (val ===  'majorName' && formData.collegeId) {
    await initClaOrMaj(id);
    showPicker.value = true;
  }else{
        console.log('else classes');
        initClaOrMaj(id, true);//id, false
      }    
  showPicker.value = true;//2025-07-04-edit    
};
const onConfirmPicker = (value: any) => {
  console.log('onConfirmPicker---oldCollegeName')
  if (columnShowFlag.value == 'collegeName') {
    formData.collegeId = value.deptId;
    formData.collegeName = value.text;
    if(speShowMajor()){
      formData.oldCollage = value.text;
      collegeSureByHeBei.value = value
    }
    formData.major = '';
    formData.majorName = '';
    formData.classes = '';
    formData.classesName = '';  
    initClaOrMaj(value.deptId);
  } else if (columnShowFlag.value == 'majorName') {
    if(!speShowMajor()&& value.deptId == 'shoudongshuru'){//isShanDa()--->!HeBeiShiFan()
      handInpFalg.value = true
      claFlag.value = true
    }else{
      handInpFalg.value = false
      claFlag.value = false
      formData.major = value.deptId;
      formData.majorName = value.text;
      formData.classes = '';
      formData.classesName = '';
      initClaOrMaj(value.deptId);   
      if(speShowMajor()){
        collegeAndMajorByHeBei.value = value
        sessionStorage.setItem('collegeAndMajorByHeBeiEdit', JSON.stringify(collegeAndMajorByHeBei.value));
        claFlag.value = true//2025-07-04-edit
        formData.major = value.majorId || '';
        formData.majorName = value.text;        
      }         
    }

  } else if (columnShowFlag.value == 'classesName') {
    if(value.deptId == 'shoudongshuru'){
      claFlag.value = true
    }else{
      formData.classes = value.deptId;
      formData.classesName = value.text;      
    }
  }
  showPicker.value = false;
};
const onConfirmBirthdayPicker = (val: any) => {
  formData.birthday = fommatDate(val, 'yyyy-MM-dd');
  showBirthday.value = false;
};
const initArea = async () => {
  areaP.addrLevel = '0'//国内和国外
  areaP.parentNo = ''
      let arr:any = []
      if(areaType.value=='areaName' || areaType.value=='residentArea'){
        arr = [
          {
            addrName:"国内",
            addrNo:"0",
            children:[],
            hasChild:"1",
            addrLevel:"0"
          },          
        ]
      }else{
        arr = [
          {
            addrName:"国内",
            addrNo:"0",
            children:[],
            hasChild:"1",
            addrLevel:"0"
          },
          {
            addrName:"国外",
            addrNo:"1",
            children:[],
            hasChild:"1",
            addrLevel:"0"        
          }          
        ]
      }
    for(let i in arr){
      options.push({...arr[i]})
    }  
    const { data, code, msg } = await ApiDept.areaList(areaP);
    if (code == 200) {
      let list = data.list;
      if (areaP.addrLevel == '1') {
        options.push(...data.list);
      }
    }    
};

const getOldCollegeByInit = ()=>{
  if(!collegeSureByHeBei.value.oldCollegeName){
    let arr = collegeList.value
    for(let i in arr){
      if(formData.collegeId == arr[i].deptId){
        return arr[i].college
      }
    }
  }else{
    return ''
  }
}

const initClaOrMaj = async (deptId: string,val?:boolean) => {
  let schoolId = getSchoolId() as string;
  if(speShowMajor()){
    console.log('initClaOrMaj---HeBeiShiFan',columnShowFlag.value)
    if(columnShowFlag.value == 'majorName'){
      let oldCollNameInit = getOldCollegeByInit()
      console.log('oldCollNameInit',oldCollNameInit,collegeSureByHeBei.value.oldCollegeName,'---',formData.collegeName)
      let collegeStr = ''
      const { data, msg, code } = await ApiDept.getMajor({
            grade:gradeList.value[listParam.value.education] || '',
            schoolYear:isBeiHuaHangTianGongYe()?formData.schoolEndYear:formData.schoolStartYear,
            college:collegeSureByHeBei.value.oldCollegeName || oldCollNameInit ||formData.oldCollage
        })
      columns.value = [];
      for (let i in data) {
        columns.value.push({ text: data[i].major, deptId: data[i].id,...data[i] });
      }        
    }
    claFlag.value = true;
  }
  if(!speShowMajor() && columnShowFlag.value !== 'collegeName'){//isShanDa()---!HeBeiShiFan()
    let allDept = 0
    if(isShenYangYaoKeDaXue() && columnShowFlag.value == 'majorName'){
      allDept = 1
    }    
    const { data, msg, code } = await ApiDept.deptList({
      schoolId: schoolId,
      parentId: deptId,
      allDept
    });
    columns.value = [];
    for (let i in data) {
      columns.value.push({ text: data[i].deptName, deptId: data[i].deptId });
    }    
    columns.value.push({
      text:"手动输入",
      deptId:"shoudongshuru"
    })
    console.log('handInpFalg.value',handInpFalg.value)
    if(handInpFalg.value){
      claFlag.value = true;
    }
    else{
      claFlag.value = false;
    }
  } 
  else if((speShowMajor() || XiangXianZhongXue())&& columnShowFlag.value == 'classesName'){
    const { data, msg, code } = await ApiDept.deptList({
      schoolId: schoolId,
      parentId: deptId,
    });
    columns.value = [];
    for (let i in data) {
      columns.value.push({ text: data[i].deptName, deptId: data[i].deptId });
    } 
      columns.value.push({
        text:"手动输入",
        deptId:"shoudongshuru"
      })
      if(handInpFalg.value){
        claFlag.value = true;
      }
      else{
        claFlag.value = false;
      }     
  }
    console.log('claFlag***:',columnShowFlag.value,columns.value.length)

};

const classShandaJudge = ()=>{
  if(isShanDa() && columnShowFlag.value == 'majorName' && columns.value.length >0){
    return true
  }else{
    return false
  }
}

const initDept = async () => {
  let schoolId = getSchoolId() as string;
  if(!speShowMajor()){
    const { data, msg, code } = await ApiDept.deptList({
      schoolId: schoolId,
    });
    columns.value = [];
    for (let i in data) {
      columns.value.push({ text: data[i].deptName, deptId: data[i].deptId });
    }   
    if(columns.value.length > 0){
        claFlag.value = false;
        majorNameType.value = 'select'
    }     
  }else{//河北师范获取学院数据
    if(isBeiHuaHangTianGongYe()){
      gradeList.value['中专'] = '中专'
    }  
    const { data, msg, code } = await ApiDept.getCollage({
      grade:gradeList.value[listParam.value.education] || '',
      schoolYear:isBeiHuaHangTianGongYe()?formData.schoolEndYear:formData.schoolStartYear
    });
    columns.value = [];
    let arr:Array<any> = []
    for(let i in data){
      arr.push(data[i])
      let tes1 = ''
      if(registerFlag.value == '1'){
          tes1 = data[i].newCollege
      }else{
          tes1 = data[i].college
      }
       collegeList.value.push({text:tes1,deptId:data[i]['remark'],oldCollegeName:data[i]['oldCollegeName'],...data[i]})
    }
    awd()
    let brr = []
    brr = unique(arr)
    for(let i in brr){
      columns.value.push(brr[i])
    }
  }
};

const unique = (arr:Array<any>) => {
  let newArr:any = []
    newArr = JSON.parse(JSON.stringify(arr))
   for(let i = 0;i<newArr.length;i++){
     if(registerFlag.value == '1'){
      newArr[i]['text'] = newArr[i].newCollege       
     }else{
       newArr[i]['text'] = newArr[i].college
     }
     newArr[i]['deptId'] = newArr[i].remark
     newArr[i]['oldCollegeName'] = newArr[i].college
     for(let j = Number(i+1);j<newArr.length;j++){
       if(newArr[i].college === newArr[j].college){
         newArr.splice(j,1)
         j--
       }
     }
   } 
   return newArr
}

const showAllText = () =>{
  // console.log('showAllText',a)

  let index = showAllTitle.value.getColumnIndex(0) as number
  // console.log('showAllText',document.querySelectorAll('.van-picker-column__item')[index])
  // let selectedItems:any = document.querySelectorAll('.van-picker-column__item--selected')
  let selectedItems:any = document.querySelectorAll('.van-picker-column__item')
  console.log('selectedItems',selectedItems)
    selectedItems.forEach((item:any,ix:Number) => {
    if(index == ix){
      let child:any = item.querySelector('.van-ellipsis')
      console.log(child.scrollWidth,item?.offsetWidth)
      if (child.scrollWidth > item?.offsetWidth) { // 判断child文字宽度
        styleAn.value = true
      } else {
        styleAn.value = false
      }
      instance?.proxy?.$forceUpdate()
    }

    // console.log('item-showAll',item.style)
  })
}

const initPer = async () => {
  //route.query.editType
  if (!!route.query.editType) {
    const { data, code, msg } = await ApiMy.getDetailedInformation({}); //通过审核
    Object.assign(formData, data); 
  } else {
    const { data, code, msg } = await ApiMy.getAuditInformation({}); //刚注册完，但还没通过审核
    Object.assign(formData, data);
  } 
  for (let i in formData) {
    if (!!formData[i] && i != 'nationality'  && i != 'ethnic') {
      initFormData(String(i), formData[i]);
    } else if (i == 'nationality') {
      nationalityInit();
    }else if (i == 'ethnic') {
      ethnicInit();
    }
  }
  if(speShowMajor()){
    formData.oldCollage = formData.collegeName
  }    
  // 初始化职务信息
  initOccupation();
};
const nationalityInit = () => {
  for (let i in country) {
    if (formData['nationality'] == country[i].value) {
      listParam.value['nationality'] = country[i].text;
    }
  }
};
const ethnicInit = () => {
  listParam.value['ethnic'] = formData['ethnic'];
};
const onConfirmAlu = (value: any, index: any) => {
  console.log(value);
  alumniName.value = value.alumniAssociationName;
  formData.alumniAssociationId = value.alumniAssociationId;
  showAlu.value = false;
  // console.log(index)
};
const changeConfig = () => {
  refreshFlag.value++;
  schoolList.value = [];
  showList.value = [];
  schoolList.value = getSchoolmateTypeByIdentity(configList.value);
  if (schoolList.value.length == 0) {
    schoolList.value = getDefaultSchoolmate(configList.value);
  }
  for (let i in listInit.value) {
    if (schoolList.value[listInit.value[i].enLabel] != '1' && schoolList.value[listInit.value[i].enLabel] != null && schoolList.value[listInit.value[i].enLabel] != undefined && schoolList.value[listInit.value[i].enLabel] != '') {
      showList.value.push({
        enLabel: listInit.value[i].enLabel,
        cnName: listInit.value[i].cnName,
        type: listInit.value[i].type,
        code: schoolList.value[listInit.value[i].enLabel],
        id: listInit.value[i].id ? listInit.value[i].id : '',
        hasChild: listInit.value[i].hasChild ? listInit.value[i].hasChild : '',
        parentName: listInit.value[i].parentName ? listInit.value[i].parentName : '',
        parentId: listInit.value[i].parentId ? listInit.value[i].parentId : '',
      });
    }
  }
};
const onConfirmNationCountry = (value: any) => {
  listParam.value[nameLabel.value] = value.text || value;  
  formData[nameLabel.value] = value.value || value;
  columnFlag2.value = false;
  //kfc
  if (nameLabel.value == 'schoolmateType') {
    parentIdFlag.value = String(value.value);
    changeConfig();
  }
  // return;
  if (formData[parentNameFlag.value] == '0') {
    parentIdFlag.value = '1';
  } else {
    // parentIdFlag.value = formData[parentNameFlag.value];
  }
    if(nameLabel.value == 'education' && speShowMajor()){
      formData.collegeName = ''
      formData.collegeId = ''
      formData.major = ''
      formData.majorName = ''    
      console.log('listParam',listParam.value)
    }  
};

const clearStuOrWorker = (val: string) => {
  if (!val) {
    return;
  }
  if (val == '0' || val == '1') {
    formData.jobDepartment = '';
    formData.jobNumber = '';
    formData.positionType = '';
    formData.colleagueName = '';
    formData.jobDuration = '';
  } else {
    formData.collegeName = '';
    formData.majorName = '';
    formData.classesName = '';

    formData.studentIdNumber = '';
    formData.education = '';
    formData.academicDegree = '';
    formData.classmateName = '';
    formData.schoolDuties = '';
  }
};

const initSchoolExp = async (deptId: string) => {
  let schoolId = getSchoolId() as string;
  const { data, msg, code } = await ApiDept.deptList({
    schoolId: schoolId,
    parentId: deptId,
  });
  return data;
};

function handleDataAfterGetPerInfo() {
    // initDept();
  for (let i in CardList) {
    if (CardList[i].cardId == formData.cardType) {
      cardName.value = CardList[i].text;
    }
  }
  if (formData.bareheadedPhoto) {
    healthFileList.value.push({ url: getRealFilePath(formData.bareheadedPhoto) });
  }
  if (formData.diplomaImage) {
    diplomaImageList.value.push({ url: getRealFilePath(formData.diplomaImage) });
  }
  if (formData.userProfilePicture) {
    userProfilePictureList.value.push({ url: getRealFilePath(formData.userProfilePicture) });
  }
  if (formData.identificationDocumentImage) {
    identificationDocumentImageList.value.push({ url: getRealFilePath(formData.identificationDocumentImage) });
  }
  initDept();
  if (formData.major) {
    let list: any = initSchoolExp(formData.major);
    if (list.length > 0) {
      claFlag.value = false;
    } else {
      claFlag.value = true;
    }
  }
  //加一个学校类型判断--大学、中学，中学的话就把claFlag = true（手输班级），
  if (formData.schoolmateType == 0 || formData.schoolmateType == 1) {
    parentIdFlag.value = '1';
  } else {
    parentIdFlag.value = '2';
  }
  console.log('handleDataAfterGetPerInfo--parentIdFlag.value',parentIdFlag.value,formData.schoolmateType)
  let subFlag = sessionStorage.getItem('subFlag');
  if (subFlag && getSchoolCode() == '4132010333') {
    initAlumni();
    showAluFlag.value = true;
  }
  if(isShanDa()){
    initShandaData()
  }
  initEduData();
  columnShowFlag.value = 'collegeName'
  initClaOrMaj(formData.collegeId)
    console.log('***formData***',formData)
}

const initShandaData = ()=>{
  //旧数据是返回code的，新需求是直接输入和返回都是职务名称，所以要对数据做判断，
  let reg = /^[0-9]+$/;
  if(reg.test(formData.jobTitle)){
    console.log('initShandaData---if')
    occupationNameInp.value = formData.occupationName
  }else{
    console.log('initShandaData---else')
    occupationNameInp.value = formData.jobTitle
  }
}

const subShanDaData = () =>{
  formData.jobTitle = occupationNameInp.value
}


const initEduData = () => {
  if (formData.education) {
    for (let a in columnsEdu.value) {
      if (formData.education == columnsEdu.value[a].value) {
        education.value = columnsEdu.value[a].text;
      }
    }
  }
};
const initAlumni = async () => {
  const { data, code, msg } = await Api.listAll({});
  Object.assign(columnsAlu.value, data);
  if (formData.alumniAssociationId) {
    for (let i in columnsAlu.value) {
      if (columnsAlu.value[i].alumniAssociationId == formData.alumniAssociationId) {
        alumniName.value = columnsAlu.value[i].alumniAssociationName;
      }
    }
  }
};
onMounted(async () => { 
  outsideCountry.value = initCountry()
  sessionStorage.removeItem('data1');
  schoolLevel.value =  schoolShowConfig() as string
  // 是否是从职务选择页返回的
  schoolCode.value = getSchoolCode() as string;
  if (schoolCode.value == '4132010333') {
    formData.schoolmateType = '0';
  }
  if (userStore.isNeedInitOccupation || isShanDa()) {
    console.log('stag--if')
    await initPer().then(() => {
      handleDataAfterGetPerInfo();
    });
  }
  else {
    Object.assign(formData, getDataFromCache());
    console.log('stag--else',formData)
    Object.assign(listParam.value, getDataListCache());
    handleDataAfterGetPerInfo();
  }
  await initData();
  // columnShowFlag.value = 'collegeName'//
  // initArea();
  getCurrentYear();
  getYearData();
});
</script>
<style lang="less" scoped>
.upLoadPic{
  position: relative;
  padding-bottom: 20px;
  height:250px;
  // margin-bottom: 10px;
}
.uploadTips{
  position:  absolute;
  width:550px;
  z-index:100;
  color: #ee0a24;
  top:100%;
  left:30%;
  transform: translate(-50%,-70%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-size: 14px;
  div{
    display:inline;
    // font-size: 14px;
    min-height:40px;
  }
  .weasdh{
    display: flex;
    justify-content: flex-start;
    align-items: flex-start;
    flex-wrap: wrap;
    font-size: 0px;
    height: 60px;
    margin-top:25px;
    p{
      margin:0px;
      padding:0px;
      font-size: 14px;
      height: 20px;
      line-height: 20px;
    }
  }  
}
:deep(.van-uploader__preview-image){
  width:140px;
  height:140px;
}
.marginTop{
  margin-top: 40px;
}
.closeButton{
  box-sizing: border-box;
  padding: 20px;  
}
.bottomPo {
  position: relative;
  width: 100%;
}

.fixtop {
  position: fixed;
  width: 100%;
}

.itemShow {
  margin-top: 120px;
  width: 98%;
  height: 100%;
  // text-emphasis: center;
  text-align: left;
  padding-left: 12.5%;

  // overflow-y: scroll;
  .item {
    width: 100%;
    height: 80px;
    line-height: 80px;
    font-size: 28px;
  }
}

.loadingioi {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.con {
  width: 100%;
  height: 100%;
  position: relative;
  overflow-y: scroll;

  .form {
    width: 100%;
    height: 100%;
    // padding-bottom: 30px;
  }

  /deep/ .van-form {
    // width: 100%;
    // height: 100%;
    // overflow-y: scroll;
  }
}

.butt1 {
  // position: fixed;
  // bottom: 5px;
  // left: 50%;
  // transform: translate(-50%, -50%);
  margin: 0px 30px;
  // margin-top:120px;
  height: 200px;
  text-align: center;

  /deep/ .van-butto {
    margin: 0 auto;
  }

  /deep/.van-button__content {
    // width: 300px;
  }
  :deep(.van-button--primary){
    margin-top:30px;
  }

  // margin-top: 10px;
  // margin: 10px 20px;
}

.up {
  margin: 15px 15px;

  // display: flex;
  // align-items: center;
  &-label {
    // font-size: 24px;
    color: #646566;
    padding: 0 15px;
  }

  &-border {
    margin: 0 15px;
    border-bottom: 1px solid #e7e7e7;
  }

  up-label::before {
    margin-right: 0.05333rem;
    color: red;
    content: '*';
  }
}

.upload {
  margin: 15px 15px 0;
  padding-bottom: 15px;
  border-bottom: 1px solid #e7e7e7;
  text-align: center;

  &-btn {
    width: 100px;
    height: 100px;
    background-color: #e7e7e7;
    border-radius: 5px;
  }

  &-tips {
    width: 95%;
    margin-top: 10px;
    color: #fe2f2f;
    font-size: 12px;
  }

  &-up {
    text-align: center;
    margin-top: 5px;

    .van-button--normal {
      font-size: 12px;
      height: 20px;
    }
  }
}
  .ani-style{

  :deep(.van-picker-column__item--selected) {
    // width: 100%;
  /* 重写选中后的效果 */
    .van-ellipsis {
      overflow: unset;
      white-space: nowrap;
      text-overflow: unset;
      display: block;
      // width: 100%;
      animation: move 12s linear infinite;
    }
    /* 增加scroll类 */

  }
  @keyframes move {
    0% { transform: translateX(10%); }
    100% { transform: translateX(-50%); }
  }

  }
</style>
