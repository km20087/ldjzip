<template>
  <div class="con">
    <van-nav-bar title="我的名片夹" left-text="" left-arrow @click-left="onClickLeft" />
    <myCard :perInfo="perInfo" :cardExchangeStatus="cardExchangeStatus" :showEdit="showEdit" :key="flag" v-if="!isSchoolFlag"></myCard>
    <ECard :per-info="perInfo" :showEdit="showEdit" :whiteFont="whiteFont" v-else/>
    <div :class="isSchoolFlag?'baseInfoList margin_Top':'baseInfoList'">
        <div class='intime' v-if="isSchoolFlag">
          <van-button class="intime_detail" :style="{backgroundColor:settingStore.themeColor}">
            <div class='timeText'>{{dateTime}}</div>
          </van-button>          
        </div>

      <div class='baseInfoItitle'>
        <Svgperinfo  class="baseInfoLogo"/>
        <span>基本信息</span>        
      </div>
      <div class='baseInfoItem'>
          <div class='ItemOne baseItem' @click="jumpEdit('base')">
            <div class='itemLeft'>
              <SvgbaseInfo class="itemLogo" />
              <span>基本信息</span> 
            </div>

            <div class='itemRight'>
               <SvgArrow class="itemArrow" />
            </div>
          </div>
          <div class='ItemTwo baseItem' @click="jumpEdit('job')"  v-if="schoolLevel == '2'">
            <div class='itemLeft'>
              <Svgwork class="itemLogo" />
              <span>职位信息</span> 
            </div>

            <div class='itemRight'>
              <SvgArrow class="itemArrow" />
            </div>
          </div>
          <div class='ItemThree baseItem'>
            <div class='itemLeft'>
              <SvgacceptCard class="itemLogo" />
              <span>允许接受陌生人名片</span> 
            </div>

            <div class='itemRight'>
              <van-switch v-model="perInfo.exchangeCardFlag" active-value="1" inactive-value="0"
                @update:model-value="onUpdateValue" size="24px" />
            </div>
          </div>
      </div>
    </div>
    <!-- 添加学校类型判断，大学就执行之前的，中学需要重新写一套新的学籍信息 -->
    <div class="education-list" v-if="isLiaoShiDa() || isShenYangShiFan() || isChengDuYiXueYuan()">
      <div class="xueji-xinxi">
        <Svgstudy class="xuejiLogo" />
        <span>学籍信息</span>
      </div>
      <div class="list-block" v-for="(item, index) in perInfo.educationInfoList" :key="index">
        <div class="up">
          <van-image :src="degreeLogo" class="degreeLogo" />
          <span>{{ eduName(item.education) }}</span>
        </div>
        <div class="down">
          <div class="msg">
            <span class="label">在校时间</span>
            <!-- <span>{{ item.classesName }}</span> -->
            <span>{{ item.schoolStartYear }}-{{ item.schoolEndYear }}</span>
          </div>          
          <div class="msg">
            <span class="label">院系：</span>
            <span>{{ item.collegeName }}</span>
          </div>
          <div class="msg">
            <span class="label">专业：</span>
            <span>{{ item.majorName }}</span>
          </div>
          <!-- <div class="msg">
            <span class="label">班级：</span>
            <span>{{ item.classesName }}</span>
          </div> -->
        </div>
      </div>
    </div>
    <div class="title" v-if="(perInfo.schoolmateType == '0' || perInfo.schoolmateType == '1') && !isLiaoShiDa() && !isShenYangShiFan()">
      <img :src="stuStatus" alt="" class="ims" />
      <span class="font">学籍信息</span>
    </div>
    <div class="info" v-if="(perInfo.schoolmateType == '0' || perInfo.schoolmateType == '1' || perInfo.schoolmateType == null) && !isLiaoShiDa() && !isShenYangShiFan()">
      <div class="listItem" v-if="schoolLevel == '2'">
        <div class="typeName">学历:</div>
        <div class="content">{{ changeA(perInfo.education) }}</div>
      </div>
      <div class="listItem" v-else-if="schoolLevel == '1'">
        <div class="typeName">{{schoolConfig.education}}:</div>
        <div class="content">{{ changeA(perInfo.education) }}</div>
      </div>      
      <div class="listItem mar40">
        <div class="typeName">在校时间:</div>
        <div class="content">{{ perInfo.schoolStartYear }}-{{ perInfo.schoolEndYear }}</div>
      </div>
      <div class="listItem mar40" v-if="schoolLevel == '1'">
        <div class="typeName">届别:</div>
        <div class="content">{{ perInfo.schoolEndYear }}</div>
      </div>      
      <div class="listItem mar40" v-if="schoolLevel == '1'">
        <div class="typeName">班级:</div>
        <div class="content">{{ perInfo.classesName }}</div>
      </div>        
      <div class="listItem mar40" v-if="schoolLevel == '2'">
        <div class="typeName">{{schoolCode == SchoolCode.BaoTouZhiYeJiShu?"系部:":"院系:"}}</div>
        <div class="content">{{ perInfo.collegeName }}</div>
      </div>
      <div class="listItem mar40" v-if="schoolLevel == '2'">
        <div class="typeName">专业:</div>
        <div class="content">{{ perInfo.majorName }}</div>
      </div>
    </div>
    <!--  && !isShenYangShiFan() -->
    <div class='bottomButton' v-if="submitFlag && schoolLevel == '2' && !isShanDa()">
        <van-button class="editButton" @click="editEducation">
          <SvgXueJiIcon  class='imsIcon' />
          <div class='editText'>修改学历信息</div>
        </van-button>
    </div>
  </div>
</template>
<script setup lang="ts">
import { reactive, ref } from 'vue';
import stuStatus from '@/assets/icons/stuStatus.png';
import myCard from '@/components/myCard/index.vue';
import { eduName,getPictures, getSchoolCode ,getPermission} from '@/utils';
import SvgacceptCard from '@/assets/icons/acceptCard.svg';
import SvgbaseInfo from '@/assets/icons/baseInfo.svg';
import Svgperinfo from '@/assets/icons/perinfo.svg';
import Svgstudy from '@/assets/icons/study.svg';
import Svgwork from '@/assets/icons/work.svg';

import Api, { mate, cardParam } from '@/api/schoolmate';
import SvgXueJiIcon from '@/assets/icons/xuejiIcon.svg';
import { Toast } from "vant";
// import rightArrow from '@/assets/mine/rightArrow.jpg';
import SvgArrow from '@/assets/icons/arrow.svg';
import { SchoolCode } from '@/constants';
import { useSettingStore } from '@/store';
import degreeLogo from '@/assets/mine/degreeLogo.png';
import { useLoadECard } from '@/pages/home/useLoadECard';
import { isLiaoShiDa,isShenYangShiFan,isChengDuYiXueYuan,isShanDa } from '@/utils/customizedType';
import {schoolShowConfig,zhongxueConfig} from "@/utils/schoolLevelShow"
// import ECard from '@/components/E-card/index.vue'
 const { ECard, isShowECard,whiteFont } = useLoadECard()
const router = useRouter();
const schoolCode = getSchoolCode();
const flag = ref(1);
const showEdit = ref(false);
// const isEcard = ref(false)
const perInfo = reactive<any>({
  name: '',
  schoolName: '',
  userProfilePicture: '',
  collegeName: '',
  schoolStartDate: '',
  classes: '',
  classesName: '',
  emailAddress: '',
  jobTitle: '', //职务
  detailedAddress: '',
  employer: '', //工作单位
  exchangeCardFlag: '1', // 0-不允许交换，1-允许交换
  majorName: '',
  wechat: '', //微信号
  mobile: '',
  academicDegree: '',
  schoolStartYear: '',
  schoolEndYear: '',
  education: '',
  officeAddress: '',
  schoolmateType: '', //3-企业，2-教职工，
  educationInfoList: [], //辽宁师范：学历数组
});

const dateTime = ref('')
const timeFlag = ref<any>()
const settingStore = useSettingStore();
const cardExchangeStatus = ref('');
const isSchoolFlag = ref(false)

const schoolLevel = ref('')
const schoolConfig = <any>ref({})

const eduList = ref([
  { text: '小学', value: '0' },
  { text: '初中', value: '1' },
  { text: '高中', value: '2' },
  { text: '专科', value: '3' },
  { text: '本科', value: '4' },
  { text: '硕士研究生', value: '5' },
  { text: '博士研究生', value: '6' },
]);

const submitFlag = ref(false)

const newMode = ref([
  '4121010165',//辽师
  // '4151013705',//成都医学院
  // '4121010166'//沈阳师范
])



const changeA = (val: string) => {
  for (let i in eduList.value) {
    if (eduList.value[i].value == val) {
      return eduList.value[i].text;
    }
  }
};
const editEducationFlag = ref(false)
const initPer = async () => {
  const { data, code, msg } = await Api.getDetailedInformation({});
  cardExchangeStatus.value = data.cardExchangeStatus == null ? '1' : data.cardExchangeStatus;
  if (code == 200) {
    if (data?.educationInfoList) {
      data.educationInfoList = data.educationInfoList.filter(
        (item: any) => Object.getOwnPropertyNames(item).length != 0
      );
    }
    Object.assign(perInfo, data);    
    perInfo.exchangeCardFlag =
      perInfo.exchangeCardFlag == null ? '1' : perInfo.exchangeCardFlag;
    flag.value++;
  }
};
const onUpdateValue = async (newValue: string) => {
  const { data, code, msg } = await Api.editExchangeCardFlag({ exchangeCardFlag: newValue });
  // Toast({ message: msg });
  if (code == 200) {
    // if (newValue == '1') {
    //   Toast({ message: '允许和陌生人交换名片' });
    // } else {
    //   Toast({ message: '禁止和陌生人交换名片' });
    // }
  } else {
    Toast({ message: '修改失败' });
  }
};

const showSpecialEcard =async () =>{
  if(isShenYangShiFan() || isChengDuYiXueYuan()){
    isSchoolFlag.value = true
  }
  if(isSchoolFlag.value){
    updateTime()
    timeFlag.value = setInterval(updateTime,100)     
  }  
}
const updateTime = () => {
  const now = new Date()
  const year = String(now.getFullYear())
  const month = addZeroShow(now.getMonth()+1)
  const day = addZeroShow(now.getDate())
  const hour = addZeroShow(now.getHours())
  const minute = addZeroShow(now.getMinutes())
  const second = addZeroShow(now.getSeconds())
  dateTime.value = `${year}-${month}-${day}  ${hour}:${minute}:${second}`
}

const addZeroShow = (val:number) =>{
  if(val < 10){
    return '0'+String(val)
  }else{
    return String(val)
  }
}

const jumpEdit = (type: string) => {
  if (type == 'base') {
    router.push({ path: '/editPerInfo', query: { editType: '1' } });
  } else if (type == 'job') {
    router.push({ path: '/editPerInfo', query: { editType: '3' } });
  } else if (type == 'stu') {
    router.push({ path: '/editPerInfo', query: { editType: '2' } });
  }
};
const editEducation = ()=>{
  router.push({path:"/showQualification"})
}
const onClickLeft = () => {
  router.back();
};
onBeforeUnmount(()=>{
  clearInterval(timeFlag.value)
  console.log('onBeforeUnmount',timeFlag.value)
})
onMounted(async () => {
  console.log('----test----')
  schoolLevel.value =  schoolShowConfig() as string
  schoolConfig.value =  zhongxueConfig()  
  submitFlag.value = getPermission('appAll')
  showEdit.value =   getPermission('editPerInfo')

    // if(newMode.value.includes(schoolCode!)){//学历修改按钮暂时是辽师专用
    //   editEducationFlag.value = true
    //   showEdit.value = false
    // }else{
    //   editEducationFlag.value = false
    //   showEdit.value = true
    // }

  await showSpecialEcard()  
  await initPer();

 
});
</script>
<style lang="less" scoped>
.mar40 {
  margin-top: 40px;
}

.con {
  width: 100%;
  height: 100%;
  background: #f9f9f9;
}

.education-list {
  // margin-top: 135px;
  padding: 59px 30px;

  .xueji-xinxi {
    display: flex;
    align-items: center;
    font-size: 36px;
    color: #222222;
    font-weight: 500;

    .xuejiLogo {
      width: 40px;
      height: 40px;
      margin-right: 10px;
    }
    span{
      margin-left:16px;
      color:#222222;
      margin-left:16px;
      font-size:36px;
      font-style:normal;
      font-weight:600;
    }
  }

  .list-block {
    margin-top: 26px;
    background: #ffffff;
    box-shadow: 1px 2px 20px 0px rgba(0, 0, 0, 0.04);
    border-radius: 16px;

    .up {
      // height: 70px;
      height:88px;
      display: flex;
      align-items: center;
      // background: url('@/assets/mine/xuewei-bg.png') no-repeat;
      background: url('@/assets/mine/mineBg.jpg') no-repeat;
      background-size: 100% 100%;
      padding: 0 30px;
      font-size: 32px;
      color: #dc7506;
      font-weight: 500;

      .degreeLogo {
        width: 40px;
        height: 40px;
        margin-right: 10px;
      }
    }

    .down {
      padding: 28px 40px;

      .msg {
        font-size: 28px;
        color: #666666;
        font-weight: 500;
        padding: 12px 0;
        display: flex;
        align-items: center;

        .label {
          display: inline;
          // min-width: 140px;
          margin-right: 30px;
        }
      }
    }
  }
}
.baseInfoList{
  margin-top: 135px;
  // padding: 59px 30px;
  padding:59px 30px 0 30px;
  box-sizing:border-box; 
  .intime{
    width: 100%;  
    padding: 0 29px 0 31px;
    box-sizing: border-box;
    padding-bottom: 30px;  
    .intime_detail{
      width: 100%;
      height: 88px;
      border-radius: 44px;      
      :deep(.van-button__text){
        display: flex;
        justify-content: center;
        align-items: center;
        
        color: #ffffff;
        font-size: 30px;
      }      
    }  
  } 
  .baseInfoItitle{
    display:flex;
    align-items:center;
    margin-bottom:22px;
    .baseInfoLogo{
      width:40px;
      height:40px;
      // fill: #000;
      //       :deep(path:last-child) {
      //         fill: var(--theme-color);
      //       }

      //       &.change-first {
      //         :deep(path:first-child) {
      //           fill: var(--theme-color);
      //         }

      //         :deep(path:last-child) {
      //           fill: #000;
      //         }
      //       }      
    }
    span{
      margin-left:16px;
      color:#222222;
      margin-left:16px;
      font-size:36px;
      font-style:normal;
      font-weight:600;

    }
  }  
  .baseInfoItem{
    box-shadow:1px 2 8px 0px rgba(0,0,0,0.06);
    border-radius:16px;
    background-color:#ffffff;
    .baseItem{
      height:88px;
      padding:0 28px;
      box-sizing:border-box;     
      display:flex;
      align-items:center;
      justify-content:space-between;
      .itemLeft{
        display:flex;
        align-items:center;
        .itemLogo{
          width:36px;
          height:36px;
          margin-right:20px;
          // fill: #000;
          //   :deep(path:last-child) {
          //     fill: var(--theme-color);
          //   }
          //   :deep(path:first-child) {
          //     // fill: var(--theme-color);
          //   }            
          //   &.change-first {
          //     :deep(path:first-child) {
          //       fill: var(--theme-color);
          //     }

          //     :deep(path:last-child) {
          //       fill: #000;
          //     }
          //   }            
        }
        span{
          color:#333333;
          font-family:PingFangSC PingFang SC;
          font-weight:400;
          font-size:28px;
          font-style:normal;
        }
      }
      .itemArrow{
        width:24px;
        height:24px;
        // background-color:tran
      }

    }
    .ItemOne{
      background: url('@/assets/mine/mineBg.jpg') no-repeat;
      background-size: 100% 100%;
    }

  }

}

.margin_Top{
  margin-top: 0px;
  padding-top:10px;
}

.title {
  width: 100%;
  height: 40px;
  padding-left: 30px;
  padding-right: 30px;
  margin-top: 100px;
  // line-height: 40px;
  display: flex;
  align-items: center;

  .ims {
    width: 40px;
    height: 40px;
  }

  .font {
    margin-left: 10px;
    font-size: 36px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    color: #222222;
  }
}

.info {
  margin: 0 auto;
  margin-top: 16px;
  margin-bottom: 30px;
  width: 92.5%;
  height: 372px;
  background: #fff;
  box-shadow: 1px 2px 20px 0px rgba(0, 0, 0, 0.04);
  border-radius: 8px;
  padding-top: 50px;
  padding-left: 40px;
  box-sizing: border-box;

  .listItem {
    width: 100%;
    height: 42px;
    display: flex;
    align-items: center;

    .typeName {
      width: 140px;
      height: 40px;
      line-height: 40px;
      font-size: 28px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #222222;
    }

    .content {
      margin-left: 40px;
      height: 40px;
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #222222;
      line-height: 40px;
    }
  }
}
.bottomButton{
  width: 100%;  
    padding: 0 29px 0 31px;
  box-sizing: border-box;
  padding-bottom: 70px;
}
.editButton{

  width: 100%;
  height: 88px;
  border-radius: 44px;
  :deep(.van-button__content) {
    width: 100%;
    color:  var(--theme-color);
    border: 2px solid  var(--theme-color);
    font-size: 36px;
    border-radius: 44px;
  }  

  :deep(.van-button__text){
    display: flex;
    justify-content: center;
    align-items: center;   
    // color: #B42D3B;
    //  color: #ffffff;
    font-size: 36px;
  }
  .editText{
    margin-left: 10px;
    font-weight: 500;
  }  
  .imsIcon{
    // fill: #000;
    :deep(path:last-child) {
      fill: var(--theme-color);
    }
    // width:32px;
    // height:32px;
  }
}
</style>
