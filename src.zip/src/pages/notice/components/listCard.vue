<template>
  <div class="list-card">
    <van-cell-group inset>
      <van-cell :title="title" title-class="van-ellipsis" @click="$emit('jumpDetail')">
        <template #label v-if="label">
          <div class="label-over" v-html="label"></div>
        </template>
        <template #right-icon v-if="hasRead">
          <span class="red-point"></span>
        </template>
      </van-cell>
      <van-cell :title="dateTime" value="查看详情" is-link @click="$emit('jumpDetail')" />
    </van-cell-group>
  </div>
</template>
<script lang="ts" setup>
const props = defineProps({
  label: String,
  title: String,
  dateTime: String,
  hasRead: Boolean,
});
</script>
<style lang="less" scoped>
.list-card {
  padding: 20px 0;
  .label-over {
    height: 146px;
    overflow: hidden;
    white-space: break-spaces;
    display: -webkit-box;
    overflow: hidden;
    text-overflow: ellipsis;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;
  }
  .red-point {
    width: 15px;
    height: 15px;
    background: red;
    border-radius: 50%;
  }
}
</style>