<template>
  <van-sticky>
    <van-nav-bar title="通知公告" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="notice-cont gray-bg">
    <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
      <van-list
        v-model:loading="loading"
        :finished="finished"
        finished-text="没有更多了"
        v-model:error="error"
        error-text="请求失败，点击重新加载"
        @load="onLoad"
      >
        <listCard
          v-for="item in testList"
          :key="item['id']"
          :title="item['title']"
          :label="item['content']"
          :date-time="item['createDate']"
          :has-read="item['readFlag'] == '0' ? true : false"
          @jump-detail="todetail(item['id'])"
        />
      </van-list>
    </van-pull-refresh>
  </div>
</template>
<script lang="ts" setup>
import { ref } from 'vue';
import listCard from './components/listCard.vue';
import { getNoticeList, getNoticeDetail } from '@/api/servive';
import { Toast } from 'vant';
import { Base64 } from 'js-base64';
const $router = useRouter();
let detailData = <any>reactive({});
const todetail = async (id: string) => {
  await getData({ id });
  if (detailData.isUrl == 1) {
    window.location.href = detailData.contentUrl;
  } else {
    $router.push({ name: 'noticeDetail', query: detailData });
  }
};
const getData = async (params: { [propName: string]: string }) => {
  const { code, data, msg } = await getNoticeDetail(params);
  if (code == 200) {
    detailData = { ...data };
  } else {
    Toast.fail(msg);
  }
};
const onClickLeft = () =>{
  $router.back()
};
const loginInfo = reactive<any>({
  pageNum: 1,
  pageSize: 10,
});
const testList = ref<any>([]);
const initList = async () => {
  const { code, data, msg } = await getNoticeList(loginInfo);
  if (code == 200) {
    let dom = document.createElement('div');
    data.list.forEach((item: any) => {
      if (!item.content) return
      const content = decodeURIComponent(
        Base64.decode(Base64.decode(Base64.decode(Base64.decode(item.content))))
      );
      dom.innerHTML = content;
      item.content = dom.innerText ? dom.innerText : content
    });
    testList.value = testList.value.concat([...data.list]);
    loginInfo.pageNum++;
    loading.value = false;
    finished.value = data.pageNum >= data.pages
  } else {
    Toast.fail(msg);
    finished.value = true;
  }
  refreshing.value = false;
};

const error = ref(false);
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const onLoad = () => {
  initList().catch(() => {
    error.value = true;
  });
};

const onRefresh = () => {
  // 清空列表数据
  finished.value = false;

  // 重新加载数据
  // 将 loading 设置为 true，表示处于加载状态
  loading.value = true;
  loginInfo.pageNum = 1;
  testList.value = [];
  onLoad();
};
</script>
<style lang="less" scoped>
.notice-cont {
}
</style>