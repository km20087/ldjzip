<template>
  <van-sticky>
    <van-nav-bar title="公告详情" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div>
    <div class="haed-bar">
      <div class="head-title">{{ detailData.title }}</div>
      <div class="author-bar">
        <van-image class="avatar" :src="authorPic" width="28" height="28" round v-if="schoolCode != SchoolCode.ShanDa"></van-image>
        <div class="dateTime">
          <div class="name">{{ schoolCode == SchoolCode.ShanDa ? detailData.showEditor : detailData.authorDeptName }}</div>
          <span class="time">{{  schoolCode == SchoolCode.ShanDa ? detailData.showTime : detailData.updateTime }}</span>
        </div>
      </div>
    </div>
  </div>
  <div v-if="isPdf">
    <Pdf :source="pdfUrl"/>
  </div>  
  <div v-else v-html="content" class="news-cont"></div>
  <van-image-preview v-model:show="showPreviewImage" :images="previewImage"  :show-index="false"/>
</template>
<script lang="ts" setup>
import { ref, nextTick } from "vue";
import { useRoute } from "vue-router";
import authorPic from "@/assets/img/news-avatar.png";
import { Base64 } from "js-base64";
import { SchoolCode } from '@/constants'
import { getSchoolCode } from '@/utils';
import { useNewsPreviewImage } from '@/hooks/useNewsPreviewImage'
import Pdf from '@/components/pdf/index.vue'

const { showPreviewImage, previewImage } = useNewsPreviewImage('.news-cont')
let detailData = ref<any>();
const content = ref<string>("");
const $router = useRouter();
const $route = useRoute();
const schoolCode = getSchoolCode()
const isPdf = ref(false)
const pdfUrl = ref('')
const DfsFileUrl = import.meta.env.VITE_APP_API_DFS_URL;
const BaseFileUrl = import.meta.env.VITE_APP_PIC_BASE_URL;
const onClickLeft = () => {
  $router.go(-1);
};
  const pdfState = ref({
    source:"",
    pageNum:1,
    scale:1,
    numPages:0,
  })
watch(
  () => $route.query,
  newVal => {
    if (newVal) {
      detailData.value = { ...newVal };
        console.log('contentUrl',detailData.value.contentUrl)
        // let isPdf = false
        !!detailData.value.contentUrl &&  (isPdf.value = detailData.value.contentUrl.includes('.pdf'))
        if(isPdf.value){
          pdfUrl.value = /\?token/.test(detailData.value.contentUrl) ? DfsFileUrl : BaseFileUrl + detailData.value.contentUrl
          pdfState.value.source = pdfUrl.value
          console.log(pdfUrl.value)
        }else{
          if (detailData.value.content) {
            let contentDetail = decodeURIComponent(
              Base64.decode(Base64.decode(Base64.decode(Base64.decode(detailData.value.content))))
            );
            content.value = contentDetail.replace(/<img/gi, "<img style='width:100%;height:100%'");
            nextTick(() => {
              document.body.scrollTo(0, 0)
            })
          }
        }
    }
  },
  { deep: true, immediate: true }
);
</script>
<style lang="less" scoped>
.haed-bar {
  padding: 30px;
  .head-title {
    font-size: 36px;
    font-weight: 600;
    line-height: 56px;
  }
  .author-bar {
    display: flex;
    align-items: center;
    margin: 20px 0;
    .avatar{
        margin: 0 24px 0 0;
      }
    .dateTime {
      .name {
        color: #000;
        font-size: 24px;
      }
      .time {
        color: #333;
        font-size: 24px;
      }
    }
  }
}
.news-cont {
  padding: 0 30px;
}
</style>
