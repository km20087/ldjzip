<template>
    <div class="list van-hairline--bottom" @click="toDetail">
        <div class="up">
            <div class="l">
                <fix-image :default-src="img1" :src="item?.eventPoster[0]" class="pic"></fix-image>
                <div class="status">
                    <div v-if="item?.auditStatus == '4'">申请驳回</div>
                    <div class="auditStatus-0" v-if="item?.auditStatus == '0'">未审核</div>
                    <div class="auditStatus-1" v-if="item?.auditStatus == '1'">审核通过</div>
                    <div class="auditStatus-3" v-if="item?.auditStatus == '2'">拒绝备案</div>
                    <div class="auditStatus-3" v-if="item?.auditStatus == '3'">草稿</div>
                </div>
            </div>
            <div class="r">
                <div class="tit van-multi-ellipsis--l2">{{ item.actName }}</div>
                <div class="msg">活动主题：{{ item.theme }}</div>
                <div class="msg">发起人：{{ item.applicant }}</div>
                <div class="msg">已报名：{{ item.currentNumberOfParticipants }}人</div>
                <div class="msg">活动时间：{{ item.startTime }}至{{ item.endTime }}</div>
                <div>
                    <div class="btn btn-publish" v-if="item?.auditStatus == '0'">点击审核</div>
                    <div class="btn btn-publish" v-else>查看详情</div>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
import img1 from "@/assets/img/birthday.jpg"
const router = useRouter()
const props = withDefaults(
    defineProps<{
        item: Partial<myCreateActList>
        isManage?: boolean
        actType?: string
    }>(),
    {
        item: () => ({}),
        isManage: false,
        actType: "resolve"
    }
)
const emits = defineEmits(['toDetail'])
const toDetail = () => {
    emits('toDetail')
}
</script>
<style lang="less" scoped>
.list {
    padding: 30px 0;
    margin: 0 30px;
    font-size: 24px;

    .up {
        display: flex;

        .l {
            position: relative;
            width: 140px;
            height: 180px;
            border-radius: 16px;
            margin-right: 20px;
            overflow: hidden;

            .pic {
                width: 100%;
                height: 100%;
            }

            .status {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                line-height: 46px;
                text-align: center;
                color: #fff;
                background: #FE6F5D;

                .auditStatus-0 {
                    background: #FF8300;
                }

                .auditStatus-1 {
                    background: #0F9400;
                }

                .auditStatus-3 {
                    background: #999999;
                }

            }
        }

        .r {
            position: relative;
            flex: 1; // max-width: 70%;

            .tit {
                font-size: 32px;
                font-weight: 500;
                color: #333;
                margin-bottom: 10px;
                max-width: 60%;
            }

            .msg {
                line-height: 36px;
                color: #666;
            }

            .btn {
                position: absolute;
                font-size: 28px;
                font-weight: 500;
                top: 0;
                right: 0;
                color: #fff;
                line-height: 60px;
                padding: 0 30px;
                background-color: #FC341B;
                border-radius: 30px;

                &-publish {
                    background: var(--theme-color);
                }
            }
        }
    }

    .down {
        padding: 20px 0 0;
        color: #ff0000;
    }
}
</style>