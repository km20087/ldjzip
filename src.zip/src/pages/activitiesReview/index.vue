<template>
    <van-sticky v-if="needTitle">
        <van-nav-bar title="活动审核" left-arrow @click-left="onClickLeft" />
    </van-sticky>
    <div :class="contClass ? contClass : 'review-cont'">
        <div class="tabs-cont">
            <Tabs @click="tabsClick" :data="tabsData" />
        </div>
        <div class="list-cont">
            <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
                <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
                    <ActList v-for="item in actList" :key="item.id" :item="item" :act-type="tabName"
                        @to-detail="toDetail(item.id, item.groupsId, tabName)" />
                </van-list>
            </van-pull-refresh>
        </div>
    </div>
</template>
<script lang="ts" setup>
import Tabs from "@/components/MyActivities/tabs.vue"
import ActList from "./components/list.vue"
import { getActivitiesAdminList } from "@/api/mine/index"
import { Toast } from "vant";

const props = withDefaults(
    defineProps<{
        needTitle?: boolean
        contClass?: string
        groupsId?: string
    }>(),
    {
        needTitle: true
    }
)
const tabsData = ref<Array<Partial<tabPros>>>([{ title: "未审核活动", name: "pending", member: 0, disabled: false }, { title: "已审核活动", name: "resolve", member: 0, disabled: false }])
const $router = useRouter();
const tabName = ref('pending')
const actList = ref<Array<myCreateActList>>([])
const listP = ref<pageParams>({ pageNum: 1, pageSize: 10 })
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);

const onClickLeft = () => $router.back();
const tabsClick = (name: string = '', title: string = '') => {
    tabName.value = name;
    initLoad();
}
const initLoad = () => {
    finished.value = false;
    loading.value = false;
    listP.value.pageNum = 1;
    actList.value = [];
    // onLoad()
}
let setDisabled = (b: boolean) => {
    tabsData.value.map(item => {
        item.disabled = b
    })
}
const getList = async (r: string) => {
    try {
        setDisabled(true)
        let params = { auditResult: r, ...listP.value, groupsId: props.groupsId || '' }
        let { code, data, msg } = await getActivitiesAdminList(params)
        if (code == 200) {
            actList.value = actList.value.concat(data.list);
            listP.value.pageNum++;
            loading.value = false;
            tabsData.value.map(item => {
                if (tabName.value == "resolve") {
                    if (item.name == tabName.value) item.title = `已审核活动(${data.total})`

                }
                if (tabName.value == "pending") {
                    if (item.name == tabName.value) item.title = `未审核活动(${data.total})`
                }
                return item
            })

            if (actList.value.length >= data.total) {
                finished.value = true;
            }
        } else {
            Toast.fail(msg);
            finished.value = true;
        }
        refreshing.value = false;
    } catch (error) {

    } finally {
        setDisabled(false)
    }

}
const onRefresh = () => {
    // 清空列表数据
    finished.value = false;

    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    loading.value = true;
    listP.value.pageNum = 1;
    actList.value = [];
    onLoad();
};
const onLoad = () => {
    let result = tabName.value == 'resolve' ? '1' : '0'
    getList(result)
}
const toDetail = (id: string, groupsId: string, tabName: string) => {
    $router.push({ path: 'activitiDetail', query: { id, groupsId, tabName } })
}
</script>
<style lang="less" scoped>
.bg-white() {
    background: #fff;
}

@padding-24: 24px;

.red {
    color: #ff0000
}

.review-cont {
    background: #f5f5f5;
    height: 100vh;
    overflow-y: scroll;
}

.tabs-cont {
    .bg-white();
    padding: @padding-24;
    margin-bottom: 20px;
}

.list-cont {
    .bg-white();
    min-height: 100vh;
    overflow-y: scroll;
    margin-top: 20px;

    .tips {
        margin: 24px 30px;
        padding: 24px 30px;
        border-radius: 6px;
        background: #f7f7f7;
        font-size: 24px;
        line-height: 38px;
        color: #666;
    }
}
</style>