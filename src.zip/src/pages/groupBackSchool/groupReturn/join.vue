<template>
    <van-sticky>
        <nav-bar title="报名" left-arrow @click-left="goBack" />
    </van-sticky>
    <van-form @submit="onSubmit" input-align="right" refs="form">
        <van-field v-model="queryForm.collegeName" name="collegeName" label="返校学院" placeholder="请输入返校学院" is-link readonly />
        <van-field v-model="queryForm.majorName" name="majorName" label="返校专业" placeholder="请输入返校专业" is-link readonly />
        <van-field v-model="queryForm.gradeName" name="gradeName" label="返校年级" placeholder="请输入返校年级" required :rules="[{ required: true, message: '请输入返校年级' }]" />
        <van-field v-model="queryForm.schoolmateName" name="schoolmateName" label="返校校友" placeholder="请输入返校校友" readonly />
        <van-field v-model="queryForm.mobile" required :rules="[{ required: true, message: '请输入联系电话' }]" name="mobile" label="联系电话" placeholder="请输入联系电话" />
        <!-- <fileCalendar v-model="queryForm.startTime" label="返校开始时间" label-width="7.1em" @on-confirm="" readonly>
        </fileCalendar>
        <fileCalendar v-model="queryForm.endTime" label="返校结束时间" label-width="7.1em" readonly>
        </fileCalendar> -->
        <van-field v-model="queryForm.plateNumber" name="plateNumber" label="车辆信息" placeholder="请输入车牌号" />
        <!-- <filedTextarea v-model:data="queryForm.scheduled" readonly />
        <filedTextarea title="其他需求" v-model:data="queryForm.otherDemand" readonly placeholder="请输入其他需求" /> -->
        <div class="tips">
            <span class="text">温馨提示：请保持车辆随行人员与申请随行人员一致，车辆免费入校时间与申请入校时间一致，请勿过久停留</span>
        </div>
        <div class="opr-area">
            <van-button color="#333" plain round style="border: 1px solid #dedede;" @click="onCancel">取 消</van-button>
            <van-button color="var(--theme-color)" round native-type="submit">提 交</van-button>
        </div>
    </van-form>
</template>
<script lang="ts" setup>
import fileCalendar from '@/components/file-calendar/index.vue'
import filedTextarea from '@/components/filed-textarea/index.vue'
import { joingroup } from '@/api/backSchoolMonth'
import { Dialog } from 'vant'
import ApiMy from '@/api/my';
import { useGoBack } from '@/hooks/useGoBack';
import { Toast } from 'vant'

const router = useRouter()
const queryForm = ref<any>({})
const { goBack } = useGoBack()

const initMy = async (): Promise<void> => {
    const { data, msg, code } = await ApiMy.baseInfo({});
    queryForm.value.schoolmateName = data.name
    queryForm.value.mobile = data.mobileDetail
    if (data?.educationInfoList) {
        data.educationInfoList = data.educationInfoList.filter(
            (item: any) => Object.getOwnPropertyNames(item).length != 0
        );
        queryForm.value.collegeName = data.educationInfoList[0].collegeName
        queryForm.value.collegeId = data.educationInfoList[0].collegeId
        queryForm.value.gradeName = data.educationInfoList[0].schoolStartYear
        queryForm.value.gradeId = data.educationInfoList[0].schoolStartYear
        queryForm.value.majorName = data.educationInfoList[0].majorName        
        queryForm.value.major = data.educationInfoList[0].major         
    }else{
        queryForm.value.collegeName = data.collegeName
        queryForm.value.collegeId = data.collegeId
        queryForm.value.majorName = data.majorName        
        queryForm.value.major = data.major  
        queryForm.value.gradeName = data.schoolStartYear
        queryForm.value.gradeId = data.schoolStartYear        
    }
}
initMy()
const onSubmit = () => {
    console.log('data: ',JSON.parse(<any>sessionStorage.getItem('groupBackSchoolDetail')))
    Dialog.alert({
        title: '温馨提示',
        message: '您的申请信息将提交学院管理员审核，审核结果将通过小程序进行通知，请留意查看。',
        confirmButtonText: '确认报名',
        confirmButtonColor: 'var(--theme-color)',
        showCancelButton: true,
        cancelButtonText: '取消'
    }).then(async () => {
        // on close
        try {
            //endDate
            const { code, msg, data } = await joingroup(queryForm.value)
            if (code == 200) {
                Toast.success(msg)
                goBack()
            } else {
                Toast.fail(msg)
            }
        } catch (error) {

        }
    });
}

const onCancel = () => {
    goBack()
}
onMounted(async () => {
    console.log('data: ',JSON.parse(<any>sessionStorage.getItem('groupBackSchoolDetail')))
    if (sessionStorage.getItem('groupBackSchoolDetail')) {
        let { id,startDate, endDate, scheduled, visitDate, remark, isVisitSchoolHistoryMuseum } = JSON.parse(<any>sessionStorage.getItem('groupBackSchoolDetail'))
        queryForm.value = { ...queryForm.value, returnActivityId: id, returnSchoolType: '0',startTime: startDate, endTime: endDate,visitTime: visitDate, otherDemand: remark, visitSchoolHistory: isVisitSchoolHistoryMuseum, initVisitSchoolHistory: isVisitSchoolHistoryMuseum  }
    }
})
</script>
<style lang="less" scoped>
:deep(.van-stepper__minus),
:deep(.van-stepper__plus) {
    color: var(--theme-color);
}

:deep(.van-stepper__minus--disabled),
:deep(.van-stepper__plus--disabled) {
    color: var(--van-stepper-button-disabled-icon-color);
    background-color: var(--van-stepper-button-disabled-color);
    cursor: not-allowed;
}

.opr-area {
    display: flex;
    justify-content: space-around;
    padding: 20px;

    .van-button {
        flex: 1;
        margin: 20px;
    }
}

.tips{
    display: flex;
    // justify-content: space-between;
    padding:20px 10px;
    box-sizing: border-box;
    // width: 100%;
    margin:0 20px;
    border-bottom: 2px solid var(--van-cell-border-color);    
    .text{
        color: #ee0a24;
    }
}
</style>