<template>
    <div class="con">
        <van-sticky>
            <nav-bar title="预约返校" left-arrow @click-left="goBack" />
        </van-sticky>            
        <dateSure @getBackSchoolDate="getBackSchoolDate">

        </dateSure>
        <div class="showTips">
            <div class="detailTips">
                <div class="title">
                    预约说明
                </div>
                <div class="con">
                    <div class="part1">
                        预约返校请仔细阅读以下说明:
                    </div>
                    <div class="part2">
                        <div>值年返校是指以班级或年级为单位，入学或毕业逢10周年、20周年、30周年、40周年等或其他满周年的集体返校活动。个人或三五人等小范围集体返校通过“返校预约”通道申请。</div>
                        <!-- <div>个人或三五人等小范围集体返校通过“返校预约”通道申请。</div> -->
                        <!-- <div>3.同一人同一天内只需提交一次申请，请勿重复申请;</div>
                        <div>4.如有疑问，欢迎来电咨询020-37247500</div> -->
                    </div>
                </div>
            </div>
        </div>
        <div class="buttonBottom">
            <!-- <van-button round  class="cancel" @click="goBack">
                取消
            </van-button> -->
            <!-- <van-button round  class="submit" @click="submitApply">
                预约记录
            </van-button>             -->
        </div>
    </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useGoBack } from '@/hooks/useGoBack';
import dateSure from "./components/dateSure.vue"
const { goBack } = useGoBack()
const router = useRouter();
const dateVal = ref(0)
const dateTime = ref('')

const getBackSchoolDate = (val:number) =>{
    dateVal.value = val
    console.log('dateVal',dateVal.value,val)
    // return
    router.push({name:"addGroupBackSchool",query:{date:dateVal.value,flag:"add"}})
    console.log('addGroupBackSchool',dateVal.value)
    
}   

const WeekDay = (val:number)=>{
    const CNum = ['日', '一', '二', '三', '四', '五', '六', '七', '八', '九']
    let str = '周'
    str = str + CNum[val]
    return str
}


</script>
<style lang="less" scoped>
.con{
    // width: 100%;
    position: relative;
    // background-color: #ffffff;
    font-family: PingFang-SC-Medium, PingFang-SC;
    .showTips{
        padding-top: 15px;
        box-sizing: border-box;
        width: 100%;
        background-color: #f6f6f6;
        .detailTips{
            background-color: #ffffff;
            box-sizing: border-box;
            width: 100%;
            padding: 40px 30px;
            .title{
                font-size: 36px;
                color:#222222;
            }
            .con{
                width: 100%;
                .part1{
                    margin-top: 40px;
                    color:#666666
                }
                .part2{
                    margin-top: 5px;
                    color:#222222;
                }
            }
        }


    }
    .buttonBottom{
        position: fixed;
        bottom: 100px;
        width: 100%;
        padding: 0 30px;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        .cancel{
            width: 330px;
            height: 80px;
            background: #f2f2f2;
            color: #D72415;
            font-size: 32px;
        }
        .submit{
            width: 330px;
            height: 80px;
            background: #D72415;
            color: #ffffff;
            font-size: 32px;            
        }
    }
}
</style>