<template>
    <div class="gray-bg">
        <van-sticky>
            <nav-bar title="团体信息" left-arrow @click-left="goBack" />
        </van-sticky>
        <div class="banner">
            <card :name="detailData.groupName" 
                :collega="detailData.collegeName" 
                :phone="detailData.contact"
                :member="detailData.registerCount" 
                :total="detailData.groupSize"
                :qrCode="detailData.qrCode"
                :creatorName="detailData.creatorName"
                :isShowCP="detailData.isHideContact == '0' ? true : false" />
        </div>
        <div class="main">
            <div class="group-msg">
                <div class="list">
                    <!-- <fix-image :default-src="iconduring" /> -->
                    <div class="text">
                        <span>活动时间：</span>
                        <span class="b">{{ detailData.startDate }}至{{ detailData.endDate }}</span>
                    </div>
                </div>
                <div class="list">
                    <!-- <fix-image :default-src="icondeadline" /> -->
                    <div class="text">
                        <span>报名截止时间：</span>
                        <span class="b">{{ detailData.registerDeadline }}</span>
                    </div>
                </div>
                <div class="list">
                    <div class="text">
                        <span>车辆信息：</span>
                        <span class="b">{{ detailData.plateNumber }}</span>
                    </div>
                </div>                
            </div>
            <div class="group-msg">
                <div class="btit">活动日程安排：</div>
                <div class="qmjnb">
                    {{ detailData.scheduled }}
                </div>
            </div>
            <div class="group-msg">
                <div class="invite">
                    <div class="member">
                        报名团员
                    </div>
                    <div class="but" @click="inviteAlumni" v-if="detailData.isCreator &&  detailData.disbanded == '0' && !uselessFlag && detailData.registered">
                        <van-button icon="plus">
                            邀请校友
                        </van-button>
                    </div>
                </div>
                <div class="alumniList">
                    <!-- {{ detailData.scheduled }} -->
                    <div class="list">
                        <van-swipe :loop="false" :width="60" :show-indicators="false" ref='indoSwipe'>
                            <van-swipe-item class="item"  v-for="(item,index) in alumniList" :key="index" @click="isManager(item)">
                                <fix-image :src="item.userProfilePicture" :default-src="DefaultAvatar"  class="ims" />
                                <div class="name">
                                    {{item.schoolmateName}}
                                </div>
                            </van-swipe-item>
                        </van-swipe>
                    </div>
                    <div class="right" @click="chagePage('next')">
                        <van-icon name="arrow" class="osp" size="30">

                        </van-icon>
                    </div>
                </div>
            </div>            
            <div class="opr-area" v-if="!detailData.isCreator && !detailData.registered && !uselessFlag && detailData.disbanded !='1' ">
                <van-button color="#333" plain round style="border: 1px solid #dedede;" @click="onCancel">取消</van-button>
                <van-button color="var(--theme-color)" round @click="toJoin">报 名</van-button>
            </div>
            <div class="opr-area" v-else-if="!detailData.isCreator && detailData.registered && detailData.disbanded !='1' ">
                <van-button color="#333" plain round style="border: 1px solid #dedede;" @click="onCancel">取消</van-button>
                <van-button color="var(--theme-color)" round @click="toExit('per')">退 出 团 队</van-button>                
            </div>
            <div class="opr-area" v-else-if="detailData.isCreator && detailData.registered && detailData.disbanded !='1' ">
                <van-button color="#333" plain round style="border: 1px solid #dedede;" @click="onCancel">取消</van-button>
                <van-button color="var(--theme-color)" round @click="toCancel">解 散 团 队</van-button>                
            </div>            
            <div class="opr-area" v-else-if="detailData.auditStatus == '2'">
                <van-button color="var(--theme-color)" round block size="large" icon="edit" @click="toEdit">编
                    辑</van-button>
            </div>
        </div>
        <van-dialog
            v-model:show="showdia" title="" class="dia" 
            :showConfirmButton="false"    
            :closeOnClickOverlay="true"     
        >
            <fix-image 
            :src="selectedUser.userProfilePicture" 
            :default-src="DefaultAvatar" 
            class="bg-wrap" />
            <div class="con">
                <p class="name">
                <span>{{ selectedUser.schoolmateName }}</span>
                <!-- <img v-if="selectedUser.isPrimaryLeader == '1'" :src="fuzeren" class="ims"/> -->
                </p>
                <!-- <div class="cosna" v-if="selectedUser.schoolName">
                <div class="ric"></div>
                <div class="daxue">{{ selectedUser.schoolName }}</div>
                </div> -->
                <div class="cosna">
                <div class="ric"></div>
                <div class="yuanxi"> {{ selectedUser.collegeName }}{{ selectedUser.classesName }}</div>
                </div>
                <!-- <div class="cosna">
                    <div class="ric"></div>
                    <div class="yuanxi">
                        {{
                        selectedUser.schoolStartYear
                            ? selectedUser.schoolStartYear.endsWith('级')
                            ? selectedUser.schoolStartYear
                            : selectedUser.schoolStartYear + '级'
                            : ''
                        }}
                </div>
                </div> -->
            </div>
            <div class="cosnaFla" v-if="detailData.isCreator">
              <div
                class="right maR5"
                @click="dialogByManager('manger')"
              >
               设置管理员
              </div>
              <div
                class="right tesR"
                @click="toExit('remove')"
              >
                移除该成员
              </div>
            </div>            
        </van-dialog>
    </div>
</template>
<script lang="ts" setup>
import card from './components/card.vue'
import iconlibrary from '@/assets/returnSchoolMonth/icon-library.png'
import icondeadline from '@/assets/returnSchoolMonth/icon-deadline.png'
import iconduring from '@/assets/returnSchoolMonth/icon-during.png'
import { getroupdetail,getRegisterDetailGWY,listSchoolmateGWY,cancelGroup, cancelBook,updateCreateBy } from '@/api/backSchoolMonth/index'
import { Dialog,Toast } from 'vant'
import DefaultAvatar from '@/assets/img/default-avatar.png';
import { useGoBack } from '@/hooks/useGoBack';
import {  getUserId } from '@/utils';
import {  getRegisterDetail ,getqrCode} from '@/api/backSchoolMonth'
const route = useRoute()
const router = useRouter()
const { goBack } = useGoBack()
const detailData = ref<Partial<ResultData>>({})
const indoSwipe = ref()
const alumniList = <any>ref([])
const showdia = ref(false)
const selectedUser = <any>ref({})
const uselessFlag = ref(false)
const typeName = ref('')
const callType = ref('')


const getDetail = async (id: any) => {
    callType.value = 'getDetail'
    const { code, msg, data } = await getroupdetail({ id })
    if (code == 200) {
        sessionStorage.removeItem('groupBackSchoolDetail')
        detailData.value = data
        timeCount(data.registerDeadline)
        sessionStorage.setItem('groupBackSchoolDetail', JSON.stringify(detailData.value))//保存起来，后面的报名或编辑的时候使用
        getMember(id)
    } else {
        Toast.fail(msg)
    }
}

const getPerByGroup = async (id: any)=>{
    //getqrCode getRegisterDetail
    callType.value = 'getPerByGroup'
    const {code, msg, data} = await getRegisterDetailGWY({id,returnActivityId:""})
    if (code == 200) {
        sessionStorage.removeItem('groupBackSchoolDetail')
        detailData.value = data
        timeCount(data.registerDeadline)
        // detailData.value.contact = data.mobile
        // detailData.value.startDate = data.startTime
        // detailData.value.endDate = data.endTime

        sessionStorage.setItem('groupBackSchoolDetail', JSON.stringify(detailData.value))//保存起来，后面的报名或编辑的时候使用
        getMember(data.returnActivityId)
    } else {
        Toast.fail(msg)
    }    
}

const getMember = async (id:string)=>{
    // alumniList
    let {code,data,msg} = await listSchoolmateGWY({returnActivityId:id})
    if(code == 200){
        alumniList.value = data
    }else {
        Toast.fail(msg)
    }
}

const isManager = async (val:any)=>{
    selectedUser.value = val
    console.log('selectedUser.value',selectedUser.value)
    let mineId = getUserId() as string
    let selectedUserId = selectedUser.value.userId
    if(mineId !== selectedUserId){
        showdia.value = true
    }

}

const timeCount = (val:string)=>{
    let deadLine = new Date(val).getTime()
    let now = new Date().getTime()
    if(now > deadLine){
        uselessFlag.value = true
    }else{
        uselessFlag.value = false
    }
}

const dialogByManager =async (type:string)=>{
    console.log('dialogByManager',{userId:selectedUser.value.userId,id:detailData.value.id as string})
    let param = {
        userId:"",
        id:""//活动ID
    }
    param.userId = selectedUser.value.userId
    console.log('*',route.query?.type)
    if(route.query?.type == 'perInfoByGroup'){
        param.id = detailData.value.returnActivityId as string
    }else{
         param.id = detailData.value.id as string
    }
    let res =  await updateCreateBy(param)
    if(res.code == 200){
        showdia.value = false
        // await getDetail(route.query.id)
        //  await getPerByGroup(route.query.id)
        router.push({path:"/index"})
    }else{
         Toast.fail(res.msg)
    }
}

const inviteAlumni = ()=>{
    if(typeName.value == 'perInfoByGroup'){
        router.push({path:"/schoolmate-search",query:{type:'invite',id:detailData.value.returnActivityId}})
    }else{
        router.push({path:"/schoolmate-search",query:{type:'invite',id:detailData.value.id}})

    }
    
}

const chagePage = (val:string) =>{
    if(val=='prev'){
        indoSwipe.value.prev()
    }else{
        indoSwipe.value.next()
    }
}


const onCancel = () => {
    goBack()
}
const toJoin = () => {
    router.push('groupBackSchoolDetailJoin')
}
const toExit = (type:string) =>{
    let msg = '您确定取消本次预约么'
    let param:any = {}   
    console.log( detailData.value)
    // return
    if(type == 'per'){
        let useId = getUserId()
        for(let i in alumniList.value){
            if(useId == alumniList.value[i].userId){
                  param.id = alumniList.value[i].id as string 
            }
        }
    }else{
        param.id = selectedUser.value.id as string 
         msg = '您确定要移除该成员'
         param.userId = selectedUser.value.userId as string
    }
    Dialog.alert({
        title: '温馨提示',
        message: msg,
        confirmButtonText: '确认',
        showCancelButton: true,
        cancelButtonText: '取消',
        confirmButtonColor: 'var(--theme-color)',
    }).then(async () => {
        // on close
        const { code, msg } = await cancelBook(param)
        if (code == 200 && type =='per') {
            router.push('groupBackSchool')
        }else{
            if(callType.value == 'getPerByGroup'){
                let disd = ''
                let useId = getUserId()
                for(let i in alumniList.value){
                    if(useId == alumniList.value[i].userId){
                        disd = alumniList.value[i].id as string 
                    }
                }                
                await getPerByGroup(disd)
            }else{
                await getDetail(route.query.id)
            }
            
        }
        Toast(msg)
    });
    showdia.value = false

}
const toCancel = () =>{
    let canId = ''
    // if(route.query.type =="joinGroup"){
    //     canId = detailData.value.id as string
    // }else{
    //     canId = detailData.value.returnActivityId as string
    // }
    if( callType.value == 'getDetail'){
        canId = detailData.value.id as string
    }else{
        canId = detailData.value.returnActivityId as string

    }
    // console.log('returnActivityId',canId)
    // return
    Dialog.alert({
        title: '温馨提示',
        message: '您确定解散该返校团体么？',
        confirmButtonText: '确认',
        showCancelButton: true,
        cancelButtonText: '取消',
        confirmButtonColor: 'var(--theme-color)',
    }).then(async () => {
        // on close
        const { code, msg, data } = await cancelGroup({ id:canId})
        if (code == 200) {
            router.push('groupBackSchool')
        }
        Toast(msg)
    });
}


const toEdit = () => {
    // detailData.startDate
    console.log('data',new Date(String(detailData.value.startDate)).getTime())
    let t = new Date(String(detailData.value.startDate)).getTime()
    router.push({ path: 'addGroupBackSchool', query: { flag: 'edit',date:t,id:route.query.id } })
}


onMounted(async ()=>{
    let type = route.query?.type
    console.log('****',type)
    if(type == 'perInfoByGroup'){
        console.log('1')
        typeName.value = type
        await getPerByGroup(route.query.id)
    }else{
        console.log('2')
        await getDetail(route.query.id)
    }
    

})
</script>
<style lang="less" scoped>
.banner {
    padding: 30px;
    background-color: #fff;
}

.main {
    padding: 30px;

    .group-msg {
        background: #FFFFFF;
        border-radius: 16px;
        padding: 32px;
        margin-bottom: 24px;

        .list {
            display: flex;
            align-items: center;

            img {
                width: 32px;
                height: 32px;
            }

            .text {
                margin-left: 20px;
                line-height: 56px;
                color: #666;

                .b {
                    color: #333;
                }

                &.colums {
                    margin-top: 10px;
                }

                &.sub {
                    padding-left: 32px;
                }
            }
        }

        .btit {
            font-size: 32px;
            font-weight: 500;
        }
        .invite{
            width: 100%;
            display: flex;
            align-items: center;
            justify-content:space-between;
            .member{
                font-size: 32px;
                font-weight: 500;
            }
            .but{
                width: 260px;
                height: 40px;
                text-align: center;
                .van-button--normal{
                    height: 40px;
                    line-height: 40px;
                    font-size: 20px;
                    background-color:rgba(245,108,108,0.8);
                    color:#FFFFFF;
                    font-weight: 700;
                    :deep(.van-button__icon){
                        font-size: 20px;
                    }
                }
                
            }
        }
        .alumniList{
            width: 100%;
            position: relative;
            height: 120px;
            display: flex;
            align-items: center;
            margin-top: 20px;
            .list{
                width: 90%;
                // flex:90;
                // height: 140px;
                :deep(.van-swipe){
                    height: 140px;
                }

                .item{
                    // width: 110px;
                    height: 140px;
                    // padding-right: 30px;
                    // background-color: #666;
                    
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    .ims{
                        margin-top: 5px;
                        width: 90px;
                        height: 90px;
                    }
                    .name{
                        margin-top: 5px;
                        font-size: 24px;
                        width: 120px;
                        white-space:nowrap;
                        overflow:hidden;
                        text-overflow: ellipsis;
                    }
                }
            }
            .right{
                // flex:10;
                 width: 10%;
                height: 120px;
                // line-height: 120px;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                .osp{
                    // transform: rotate(270deg);
                }
            }
        }

    }

    .opr-area {
        display: flex;
        justify-content: space-around;
        padding: 20px;
        margin-top: 60px;

        .van-button {
            flex: 1;
            margin: 20px;
        }
    }
}
:deep(.van-popup){
    width: 400px;
    height: 450px;
    // margin: 60px 30px 30px 0;
    // border-radius: 8px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: url("@/assets/schoolmate/card_1.png") no-repeat;
    .bg-wrap {
        // position: absolute;
        width: 130px;
        height: 150px;
        top: 0;
        text-align: center;
        // left: 0;
        // overflow: hidden;
        // z-index: -1;
    }
    .van-dialog__content{
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center; 
        //van-dialog__content
    }    
    .con {
      text-align: center;
      // height: 100%;
      padding: 0 20px;
      .name {
        // padding-top: 30px;
        margin:0px;
        font-size: 30px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #333333;
        // justify-content: center;
        // text-align: center;
        display: flex;
        justify-content: center;
        align-items: center;
        .ims {
          margin-left: 5px;
          width: 28px;
          height: 28px;
        }
      }
      .ric {
        margin-top: 13px;
        width: 8px;
        height: 8px;
        background: linear-gradient(270deg, #eaeaea 0%, #aaa9a9 100%, #ffffff 100%);
      }
      .iniDiv {
        display: block;
        height: 30px;
        font-size: 0px;
      }
      .cosna {
        width: 100%;
        // height: 30px;
        display: flex;
        margin-bottom: 10px; // word-break: break-all;
        // display: -webkit-box;
        // -webkit-line-clamp: 2;
        // -webkit-box-orient: vertical;
        // over-flow: hidden;
        // word-wrap: break-word;
        // flex-wrap: wrap;
      }
      .daxue {
        margin-left: 8px;
        font-size: 24px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #666666;
      }
      .yuanxi {
        width: 100%;
        // height: 30px;
        margin-left: 8px;
        font-size: 24px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #666666;
        text-align: left;
        // word-break: break-all;
        word-break: break-all;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }
    }      
    .cosnaFla {
        width: 100%;
        display: flex;
        padding: 0 6%;
        margin-top: 40px;
        // position: absolute;
        // bottom: 10px;
        justify-content: space-between;
        align-items: center;
        .right {
            width: 180px;
            font-size: 24px;
            padding: 0px 10px;
            box-sizing: border-box;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #999999;
            // margin-bottom: 20px;
        }
    }      
}
</style>