<template>
    <div class="card">
        <div class="left">
            <div class="left-name">{{ name }}</div>
            <div class="left-collega">学院：{{ collega }}</div>
            <div class="left-collega">发起人:{{ creatorName }}</div>
            <div class="left-phone" @click="copyText(phone)">
                <div class="wdad">联系方式：{{ phone }}</div>
                <!-- <img v-if="isShowCP" :src="ICON_COPY" class="copybtn"
                    @click="copyText(phone)" /> -->
                </div>    
        </div>
        <div class="center">
            <div class="center-label">已报名人数</div>
            <div class="center-num"><span>{{ member }}</span>/{{ total }}</div>
        </div>
        <!-- <div class="right" v-if="!!qrCode" @click="showQrcodeByClick">
            <img :src="qrCode" alt="" class="ims" />

        </div> -->
        <van-image-preview v-model:show="showQrcode" :images="imageList">
            <!-- :loop="false" :showIndex="false" -->

        </van-image-preview>
    </div>
</template>
<script lang="ts" setup>
import ICON_COPY from '@/assets/returnSchoolMonth/icon-copy.png'
import copyText from '@/hooks/useCopyText'
const props = withDefaults(
    defineProps<{
        name?: string;
        collega?: string
        phone?: string
        member?: number
        total?: number
        isShowCP?: boolean
        qrCode?:string
        creatorName?:string
    }>(),
    {
        name: '',
        collega: '',
        phone: '',
        member: 0,
        total: 0,
        isShowCP: false,
        qrCode:"",
        creatorName:""
    }
);
    const showQrcode = ref(false)
    const imageList = <any>ref([])
    const showQrcodeByClick = ()=>{
        console.log('showQrcodeByClick',props.qrCode)
        imageList.value = []
        imageList.value.push(props.qrCode)
        showQrcode.value = true
    }
</script>
<style lang="less" scoped>
.card {
    width: 100%;
    padding: 20px 32px;
    background: var(--theme-color);
    border-radius: 16px;
    font-family: PingFangHK-Medium;
    color: #fff;
    display: flex;
    align-items: center;
    font-weight: 500;

    .left {
        flex: 53;

        .left-name {
            font-size: 24px;
            // line-height: 72px;
            line-height: 36px;
        }

        .left-collega{
            font-size: 24px;
            line-height: 36px;
            display: flex;
            align-items: center;            
        }
        .left-phone {
            font-size: 24px;
            line-height: 36px;
            // line-height: 48px;
            display: flex;
            align-items: center;
            justify-content: flex-start;    
            .copybtn {
                width: 18px;
                height: 18px;
                margin-left: 10px;
            }
        }
    }

    .center {
        flex: 27;
        position: relative;
        // padding-left: 15px;
        // margin: 0 15px;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
        // &::before {
        //     content: '';
        //     width: 1px;
        //     height: 100%;
        //     background: linear-gradient(to bottom, transparent 0%, #fff 40%, #fff 50%, transparent 100%);
        //     position: absolute;
        //     left: 0px;
        // }

        .center-label {
            font-size: 24px;
            // line-height: 58px;
        }

        .center-num {
            font-size: 32px;

            span {
                font-size: 54px;
            }
        }
    }
    .right{
        flex: 20;
        .ims{
            width: 100%;
            height: 120px;
        }
    }
}
</style>