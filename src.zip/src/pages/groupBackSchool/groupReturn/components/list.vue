<template>
    <div class="sub-list">
        <div :class="isEnded =='2'?'up uper':'up'" >
            <div class="title hasTip">{{ data?.groupName }}</div>
            <div v-if="isEnded =='2'" :class="data?.status == '0'?'topRight wait':data?.status == '1'?'topRight pass':data?.status == '2'?'topRight noPass':'topRight useless'">
                {{tramslateStatus(String(data?.status))}}
            </div>
        </div>
        <div class="down">
            <p>活动时间：<span class="num">{{ data?.startDate }}~{{ data?.endDate }}</span></p>
            <p>截止时间：<span class="num">{{ data?.registerDeadline }}</span></p>
            <p>已报名人数：<span class="red">{{ data?.registerCount }}</span><span>/{{ data?.groupSize }}</span></p>
            <van-button color="var(--theme-color)"
                :style="{ backgroundColor: hex2Rgba(settingStore.themeColor, 0.14), border: 'none', }" block round plain
                size="small" @click="jumpFunc" v-if="isEnded =='0'">报 名</van-button>
            <van-button color="#666"  @click="jumpFunc" :style="{ backgroundColor: '#f5f5f5', border: 'none', }" block round plain size="small"
                v-else-if="isEnded =='1'">报名已结束</van-button>
            <van-button color="#666"  @click="jumpFunc" :style="{ backgroundColor: '#f5f5f5', border: 'none', }" block round plain size="small"
                v-else-if="isEnded =='2'">查看详情</van-button>                
        </div>
    </div>
</template>
<script lang="ts" setup>
import { hex2Rgba } from '@/utils/hex2rgba';
import { useSettingStore } from "@/store";
const settingStore = useSettingStore();
const emits = defineEmits(['jumpFunc'])
const props = withDefaults(defineProps<{ data?: Partial<ResultData>; isEnded?: string }>(), { isEnded: '' })
const jumpFunc = () => {
    emits('jumpFunc')
}

const tramslateStatus = (val:string)=>{
  let a = String(val)
  let obj:any = {
    '0':"审核中",
    '1':"审核通过",
    '2':"不通过",
    '3':"已失效"
  }
  for(let key in obj){
    if(key == val){
      return obj[key]
    }
  }
}

</script>
<style lang="less" scoped>
.sub-list {
    background: #FFFFFF;
    border: 1px solid #DFDFDF;
    box-shadow: 1px 2px 4px 0 rgba(0, 0, 0, 0.08);
    border-radius: 24px;
    margin-bottom: 20px;

    .uper{
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .up {
        font-family: PingFangSC-Medium;
        font-size: 32px;
        color: #333333;
        line-height: 72px;
        font-weight: 500;
        border-bottom: 1px solid #EDEDED;


        .hasTip {
            display: flex;
            align-items: center;
            justify-content: spa;
            padding: 0 10px;

            &:before {
                content: '';
                width: 10px;
                height: 10px;
                border-radius: 50%;
                background-color: #B42D3B;
                margin: 0 15px;
            }
        }
        .topRight{
            width: 140px;
            height: 40px;
            line-height: 40px;
            text-align: center;
            margin-right: 20px;
            // background-color: #f0f0f0;
            color:#ffffff;
            font-size: 26px;
            border-radius: 4px;
            font-weight: 700;
        }
        .wait{
            background-color: rgba(30,147,239,0.1);
            color:rgb(30,147,239);
            border: 1px solid rgb(30,147,239);
        }
        .pass{
            background-color: rgba(16,177,85,0.1);
            color:rgb(16,177,85);
            border: 1px solid rgb(16,177,85);
        }
        .noPass{
            background-color: rgba(215,36,21,0.1);
            color:rgb(215,36,21);
            border: 1px solid rgb(215,36,21);
        }
        .useless{
            background-color: rgba(102,102,102,0.1);
            color:rgba(102,102,102,1);
            border: 1px solid rgb(102,102,102);
        }        
    }

    .down {
        font-family: PingFangSC-Regular;
        font-size: 24px;
        color: #999999;
        line-height: 28px;
        padding: 0 24px 24px;

        .num {
            color: #333333;
        }

        .red {
            color: #B42D3B;
        }
    }
}
</style>