<template>
    <van-sticky>
        <nav-bar title="值年返校" left-arrow @click-left="goHome" />
    </van-sticky>
    <div class="gray-bg">
        <div class="banner">
            <FixImage :default-src="alumniBanner" :src="topBanner" class="banner-bg" />
        </div>
        <div class="list-cont">
            <stepJump v-for="(item, index) in list" :key="index" :url="getImg(item.icon as string)" :title="item.title"
                :icon="getImg('returnSchoolMonth/arrow-right.png')" :path="item.path" :query="item.query" />
        </div>

    </div>
</template>
<script lang="ts" setup>
import { getImg } from '@/utils/util';
import stepJump from '@/components/stepJump/index.vue'
import { useGoBack } from '@/hooks/useGoBack';
// import bannerBG from '@/assets/returnSchoolMonth/schoolBanner.png'
import alumniBanner from '@/assets/img/alumniBanner.png';
import {homeSwipePic} from '@/api/home';
import useCache from '@/hooks/useCache'
const router = useRouter()
const { goBack } = useGoBack()
const list = ref<Partial<listMsg>[]>([
    // { title: '创建团队', icon: 'returnSchoolMonth/group_return.png', path: 'addGroupBackSchoolDate', },
    { title: '创建团队', icon: 'returnSchoolMonth/group_return.png', path: 'recordGroupBackSchool',query:{type:"createGroup"}, },
    { title: '加入团队', icon: 'returnSchoolMonth/Review_progress.png', path: 'joinGroupBackSchool',},
    // { title: '我的团体', icon: 'returnSchoolMonth/Review_progress.png', path: 'recordGroupBackSchool',query:{type:"createGroup"} },
    // { title: '个人预约', icon: 'returnSchoolMonth/Review_progress.png', path: 'recordGroupBackSchool',query:{type:"record"} },
])

const topBanner = ref('')

const goHome = ()=>{
  router.push({path:"/index"})
}

// let bannerData = ref<Partial<ImageList>>({
//   images: [],
//   interval: '0',
// });
  useCache({
    key: 'BANNER',
    service: homeSwipePic,
    params: {
      imageType: 'BANNER'
    },
    callback: ({ code, data, msg }: any) => {
      if (code == 200) {
        // bannerData.value = data
        topBanner.value = data.images[0].fileAddress
        // console.log('bannerData',bannerData.value, topBanner.value)
      }
    }
  })
</script>
<style lang="less" scoped>
.banner-bg {
    width: 100vw;
    height: 350px;
}

.list-cont {
    padding: 0 33px;
}
</style>