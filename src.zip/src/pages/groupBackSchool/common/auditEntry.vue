<template>
    <van-sticky>
        <nav-bar title="我的预约" left-arrow @click-left="onClickLeft" />
    </van-sticky>
    <div class="">
        <ECard :per-info="perInfo" />
        <div class="entry-tit">快捷入口</div>
        <div class="list-cont">
            <stepJump v-for="(item, index) in list" :key="index" :url="getImg(item.icon as string)" :title="item.title"
                :path="item.path" :style="{ backgroundColor: hex2Rgba(settingStore.themeColor, 0.08) }"
                :query="item.query" />
        </div>
    </div>
</template>
<script setup lang="ts">
import ECard from '@/pages/home/component/ECard.vue';
import stepJump from '@/components/stepJump/index.vue'
import { useSettingStore } from "@/store";
import { hex2Rgba } from '@/utils/hex2rgba';
import { getImg } from '@/utils/util';
import ApiMy from '@/api/my';
const $router = useRouter();
const perInfo = ref<perInfo>({
    name: '',
    collegeName: '',
    schoolName: '',
    classes: '',
    userProfilePicture: '',
    classesName: '',
    mobile: '',
    educationInfoList: [],
});
const list = ref<Partial<listMsg>[]>([
    {
        title: '我的团体', icon: 'returnSchoolMonth/my_Group.svg', path: 'backSchoolAudit', query: { type: 'createGroup' }
    },
    {
        title: '报名入团', icon: 'returnSchoolMonth/join_group.svg', path: 'backSchoolAudit', query: { type: 'join' }
    },
    {
        title: '个人预约', icon: 'returnSchoolMonth/my_review.svg', path: 'backSchoolAudit', query: { type: 'personal' }
    }
])
const settingStore = useSettingStore();

const onClickLeft = () => $router.back();
const initMy = async () => {
    const { data, msg, code } = await ApiMy.baseInfo({});
    if (data?.educationInfoList) {
        data.educationInfoList = data.educationInfoList.filter(
            (item: any) => Object.getOwnPropertyNames(item).length != 0
        );
    }
    Object.assign(perInfo.value, data);
};
initMy()
</script>
<style lang="less" scoped>
.entry-tit {
    font-size: 38px;
    font-weight: 600;
    // line-height: 106px;
    padding: 34px 43px 0;
}

.list-cont {
    padding: 0 43px 43px;
}

:deep(.item) {

    .lf {
        .txt {
            color: var(--theme-color) !important;
        }
    }
}
</style>