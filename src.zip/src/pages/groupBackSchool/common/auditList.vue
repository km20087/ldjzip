<template>
    <van-sticky>
        <nav-bar :title="mYtitle" left-arrow @click-left="onClickLeft" />
    </van-sticky>
    <div class="back-cont gray-bg">
        <!-- <van-tabs v-model:active="activeName" color="var(--theme-color)" style="margin-bottom: 15px;" @click-tab="onLoad">
            <van-tab title="我的团体" name="createGroup"></van-tab>
            <van-tab title="报名入团" name="join"></van-tab>
            <van-tab title="个人预约" name="personal"></van-tab>
        </van-tabs> -->
        <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
            <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
                <backlist v-for="(item, index) in backList" :key="index" :item="item" :activeName="activeName"
                    @click="toDetail(item.id, activeName == 'record' ? item.returnActivityId : '', activeName == 'createGroup' ? item.auditStatus : item.status,item)" />
            </van-list>
        </van-pull-refresh>
        <div class="fix-btn--wrap"></div>
        <div class="btn-wrap">
             <van-button color="var(--theme-color)" class="wda" round @click="toCreate">创建团队</van-button>
        </div>
    </div>
</template>
<script lang="ts" setup>
import backlist from './components/backlist.vue';
import successIcon from '@/assets/appointment/successIcon.png';
import failedIcon from '@/assets/appointment/failedIcon.png';
import expireIcon from '@/assets/appointment/expireIcon.png';
import { getauditList, getroupdetail, listAuditRecord } from '@/api/backSchoolMonth/index';
import { Toast } from 'vant';
import { nameHasRouter } from '@/hooks/hasRouter';
import { formatDate, formatDateTime } from '@/utils/tool/time';

type actN = 'createGroup' | 'join' | 'record'
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const backList = ref([] as any[]);
const listP = {
    pageNum: 1,
    pageSize: 99,
};
const activeName = ref<actN>('createGroup')
const mYtitle = ref<string>('')

const $router = useRouter();
const $route = useRoute()

const onClickLeft = () => $router.back();
const onRefresh = () => {
    // 清空列表数据
    finished.value = false;

    // 重新加载数据
    // 将 loading 设置为 true，表示处于加载状态
    loading.value = true;
    listP.pageNum = 1;
    backList.value = [];
    onLoad();
};
const dateforAll = (s: string): string => {
    return s.replace(/-/g, '/')
}

const handleShowStatus = (item:any)=>{
    // '0':"审核中",
    // '1':"审核通过",
    // '2':"不通过",
    // '3':"已失效"
    let val = ''
    if( (item.ended == '1' || item.disbanded == '1')){
        val = '3'
    }else{
        val = item.auditStatus
    }
    return val
}

const onLoad = async () => {
    // let Api = activeName.value !== 'createGroup' ? activeName.value == 'join' ? listAuditRecord({ ...listP, returnSchoolType: '0' }) : listAuditRecord({ ...listP, returnSchoolType: '1' }) : getauditList(listP)
    let Api = activeName.value !== 'createGroup' ?listAuditRecord({ ...listP, returnSchoolType: '0' }) : getauditList(listP)
    // 异步更新数据
    backList.value = []
    let { code, data, msg } = await Api;
    if (code == 200) {
        if (activeName.value == 'createGroup') {
            backList.value = data.list.map((item: any) => {
                return { ...item,showStatus:handleShowStatus(item)  }
                // url: (item.ended == '1' || item.disbanded == '1') ? expireIcon : (item.auditStatus == 0 || item.auditStatus == 1) ? successIcon : failedIcon
            })

        } else {
            let date = dateforAll(formatDate(Date.now()))//因为ios的浏览器不支持含'-'格式
            let currentDate = new Date(date).getTime()
            backList.value = data.map((item: any) => {
                    return { ...item,groupSize: activeName.value == 'join' ? item.groupSize : String(Number(item.accompanyCount) + 1), url: new Date(dateforAll(item.endTime)).getTime() >= currentDate ? item.status == 0 || item.status == 1 ? successIcon : failedIcon : expireIcon   }
                    // return { id: item.id, status: item.status, returnActivityId: item.returnActivityId, startDate: item.startTime, endDate: item.endTime, groupSize: activeName.value == 'join' ? item.groupSize : String(Number(item.accompanyCount) + 1), url: new Date(dateforAll(item.endTime)).getTime() >= currentDate ? item.status == 0 || item.status == 1 ? successIcon : failedIcon : expireIcon }
                })
        }
        loading.value = true;
        finished.value = true;
        // backList.value = backList.value.concat(data);
        // listP.pageNum++;
        // loading.value = false;
        // if (backList.value.length >= data.total) {
        //     finished.value = true;
        // }
        console.log(' backList.value ', backList.value)
    } else {
        Toast.fail(msg);
    }
};
const toCreate = ()=>{
    $router.push({path:"/addGroupBackSchoolDate"})
}
const toDetail = async (id: string = '', gid?: string, std?: any,item?:any) => {
    // if (std == 2) return
    if (activeName.value == 'createGroup') {
        // await getDetail(id)
        nameHasRouter($router, 'groupBackSchoolDetail', '/groupBackSchoolDetail', { id, });
        // if(item.auditStatus == '1' && item.disbanded == '0' && item.disbanded == '0'){
        //     nameHasRouter($router, 'groupBackSchoolDetail', '/groupBackSchoolDetail', { id, type:"perInfoByGroup"});
        // }else{
        //     nameHasRouter($router, 'groupBackSchoolDetail', '/groupBackSchoolDetail', { id, });
        // }
        
    } else if (activeName.value == 'record') {//
        await getDetail(gid)
        nameHasRouter($router, 'detailGroupBackSchool', '/detailGroupBackSchool', { id:gid });
    } 
    // else {
    //     nameHasRouter($router, 'personalReturnStatus', '/personalReturnStatus', { id, returnActivityId: '' });
    // }
};
const getDetail = async (id: any): Promise<void> => {
    const { code, msg, data } = await getroupdetail({ id })
    if (code == 200) {
        sessionStorage.removeItem('groupBackSchoolDetail')
        sessionStorage.setItem('groupBackSchoolDetail', JSON.stringify(data))//保存起来，后面的报名或编辑的时候使用
    } else {
        Toast.fail(msg)
    }
}

watch(() => $route.query, (val: any) => {
    if (!val) return
    activeName.value = val.type
    mYtitle.value = val.type == 'createGroup' ? '我的团体' : val.type == 'join' ? '报名入团' : '个人预约'
}, { immediate: true, deep: true })
</script>
<style lang="less" scoped>
.back-cont {
    padding: 24px 30px;
    width: 100%;
    height: 100%;
}
.fixed-btn-wrap{
    width: 1px;
    height: 120px;
}
.btn-wrap{
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    padding: 20px 0;
    display: flex;
    justify-content: center;
    background: #fff;
    .wda{
        width: 85%;
        margin: 0 auto;
    }
}
</style>