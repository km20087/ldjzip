<template>
    <div class="gray-bg">
        <div class="banner">
            <FixImage :default-src="bannerBG" class="banner-bg" />
        </div>
        <div class="main">
            <div class="status get" v-if="!returnMsg.expired">审核通过</div>
            <div class="status lose" v-else>已 过 期</div>
            <div class="showTime">{{ currentTime }}</div>
            <div class="qrCode-cont">
                <!-- <img class="qrcode" :src="returnMsg.qrCode" />
                <div class="expired" v-if="returnMsg.expired">
                    <FixImage :default-src="expiredPic" class="pic" />
                    <span>已过期</span>
                </div> -->
                <ECard :per-info="perInfo" />
            </div>
            <div class="detail">
                <div class="one">
                    <span>返校学院</span>
                    <span class="b">{{ returnMsg.collegeName }}</span>
                </div>
                <div class="one">
                    <span>返校年级</span>
                    <span class="b">{{ returnMsg.gradeName }}</span>
                </div>
                <div class="one">
                    <span>姓&emsp;&emsp;名</span>
                    <span class="b">{{ returnMsg.schoolmateName }}</span>
                </div>
                <div class="one">
                    <span>返校时间</span>
                    <span class="b">{{ returnMsg.startTime }}至{{ returnMsg.endTime }}</span>
                </div>
                <div class="one">
                    <span>预约状态</span>
                    <span class="lose" v-if="returnMsg.expired">已过期</span>
                    <span class="get" v-else>已通过</span>
                </div>
                <!-- <van-notice-bar scrollable text="温馨提示：凭此二维码可进出校园，无需携带身份证件" /> -->
            </div>
        </div>
        <div class="btn">
            <van-button block round color="var(--theme-color)" @click="goBack">返 回</van-button>
        </div>

    </div>
</template>
<script lang="ts" setup>
import bannerBG from '@/assets/returnSchoolMonth/BANNER@2X.png'
import { getqrCode } from '@/api/backSchoolMonth/index'
import expiredPic from "@/assets/returnSchoolMonth/icon-expired.png"
import { useGoBack } from '@/hooks/useGoBack'
import { fommatDate } from '@/utils/fommatDate'
import ApiMy from '@/api/my';
import ECard from '../../home/component/ECard.vue'

const { goBack } = useGoBack()
const returnMsg = ref<any>({})
let currentTime = ref<string>('')
const perInfo = ref<perInfo>({
    name: '',
    collegeName: '',
    schoolName: '',
    classes: '',
    userProfilePicture: '',
    classesName: '',
    mobile: '',
    educationInfoList: [],
});
const route = useRoute()
onMounted(() => {
    setInterval(() => {
        currentTime.value = fommatDate(new Date(), '年月日时分秒')
    }, 1000);
})

const getQRcode = async () => {
    let { code, msg, data } = await getqrCode({ id: route.query.id, returnActivityId: route.query.returnActivityId })
    if (code == 200) {
        returnMsg.value = data
    }
}
getQRcode()

const initMy = async () => {
    const { data, msg, code } = await ApiMy.baseInfo({});
    if (data?.educationInfoList) {
        data.educationInfoList = data.educationInfoList.filter(
            (item: any) => Object.getOwnPropertyNames(item).length != 0
        );
    }
    Object.assign(perInfo.value, data);
};
initMy()
</script>
<style lang="less" scoped>
.banner-bg {
    width: 100vw;
    height: 209px;
}

.main {
    margin: 20px 24px 0;
    background: #FFFFFF;
    box-shadow: 0 0 8px 0 rgba(5, 112, 201, 0.08);
    border-radius: 15px;
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;

    .status {
        font-size: 36px;
        letter-spacing: 0;
        text-align: center;
        line-height: 24px;
        font-weight: 500;
        padding: 30px 0 34px;
    }

    .showTime {
        font-weight: 500;
        font-size: 36px;
        color: #3A62A4;
        padding: 5px 0 30px;
    }

    .qrCode-cont {
        // width: 350px;
        // height: 350px;
        // position: relative;
        width: 100%;

        :deep(.E-card) {
            padding: 0 25px;
            background: none;
            height: 452px;
        }

        .qrcode {
            width: 100%;
            height: 100%;
            align-items: center;
        }

        .expired {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, .7);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: #FFFFFF;
            font-size: 30px;
            line-height: 80px;
            font-weight: 500;

            .pic {
                width: 70px;
                height: 70px;
            }
        }
    }

    .detail {
        padding: 24px;
        width: 100%;
        margin-top: 34px;
        color: #666;
        border-top: 2px dashed #999;

        .one {
            display: flex;
            justify-content: space-between;
            line-height: 58px;

            .b {
                color: #222;
            }
        }
    }
}

.btn {
    margin: 40px 60px;
}

.get {
    color: #00CB2B;
}

.lose {
    color: #FF0000;
}
</style>