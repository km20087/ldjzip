<template>
  <div class="back-list">
    <div class="top" v-if="activeName=='createGroup'">
        <div class="topLeft">
          {{item.groupName}}
        </div>
        <!-- topRight -->
        <!-- disbanded -->
        <div :class="item.showStatus == '0'?'topRight wait':item.showStatus == '1'?'topRight pass':item.showStatus == '2'?'topRight noPass':'topRight useless'">
          {{tramslateStatus(item.showStatus)}}
        </div>
    </div>
    <div class="top" v-if="activeName=='record'">
        <div class="topLeft">
          {{item.groupName}}
        </div>
        <!-- topRight -->
        <!-- <div :class="item.status == '0'?'topRight wait':item.status == '1'?'topRight pass':item.status == '2'?'topRight noPass':'topRight useless'">
          {{tramslateStatus(item.status)}}
        </div> -->
        <img :src="item.url" alt="" class="topRight">
    </div>    
    <div class="center" v-if="activeName=='createGroup'">
      <div class="center_contet">
        <div class="tit">
          活动时间：
        </div>
        <div>
          {{item.startDate}}~{{item.endDate}}
        </div>
      </div>
      <div class="center_contet">
        <div class="tit">
          截止时间：
        </div>
        <div>
          {{item.registerDeadline}}
        </div>
      </div>
      <!-- <div class="center_contet">
        <div class="tit">
          已报名人数：
        </div>
        <div>
          {{item.registerCount}}
        </div>
      </div>       -->
    </div>    
    <div class="center" v-if="activeName=='record'">
      <div class="center_contet">
        <div class="tit">
          活动时间：
        </div>
        <div>
          {{item.startTime}}~{{item.endTime}}
        </div>
      </div>
      <div class="center_contet">
        <div class="tit">
          截止时间：
        </div>
        <div>
          {{item.registerDeadline}}
        </div>
      </div>
      <!-- <div class="center_contet">
        <div class="tit">
          已报名人数：
        </div>
        <div>
          {{item.registerCount}}
        </div>
      </div>       -->
    </div>
    <div class="button">
      <van-button  class="but1" :style="{'background':`linear-gradient(180deg,${hex2Rgba(settingStore.themeColor,1)} 0%,${hex2Rgba(settingStore.themeColor,0.7)} 100% )`}">
        <!-- {{item.showStatus =='1' || item.showStatus == '0'?'了解详情':'请重新提交'}} -->
        了解详情
      </van-button>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { hex2Rgba } from '@/utils/hex2rgba';
import { useSettingStore } from '@/store';
const settingStore = useSettingStore();
const props = withDefaults(
  defineProps<{
    item: any;
    activeName:string
  }>(),
  {}
);

const classState = (val:string)=>{
  let styleArr = ['topRight wait','topRight pass','topRight noPass','topRight useless']
  return styleArr[Number(val)]
}

const tramslateStatus = (val:string)=>{
  let a = String(val)
  let obj:any = {
    '0':"审核中",
    '1':"审核通过",
    '2':"不通过",
    '3':"已失效"
  }
  for(let key in obj){
    if(key == val){
      return obj[key]
    }
  }
}

</script>
<style lang="less" scoped>
.back-list {
  background: #ffffff;
  border-radius: 16px;
  padding: 20px 24px;
  margin-bottom: 24px;
  .top{
    display: flex;
    width: 100%;
    align-items: center;
    justify-content: space-between;
    height: 40px;
    box-sizing: border-box;
    padding-bottom: 15px;
    border-bottom: 1px solid #f0f0f0;
    .topLeft{
      font-size: 26px;
    }
    .topRight{
      width: 140px;
      height: 40px;
      line-height: 40px;
      text-align: center;
      // background-color: #f0f0f0;
      color:#ffffff;
      font-size: 26px;
      border-radius: 4px;
      font-weight: 700;
    }
    .wait{
      background-color: rgba(30,147,239,0.1);
      color:rgb(30,147,239);
      border: 1px solid rgb(30,147,239);
    }
    .pass{
      background-color: rgba(16,177,85,0.1);
      color:rgb(16,177,85);
      border: 1px solid rgb(16,177,85);
    }
    .noPass{
      background-color: rgba(215,36,21,0.1);
      color:rgb(215,36,21);
      border: 1px solid rgb(215,36,21);
    }
    .useless{
      background-color: rgba(102,102,102,0.1);
      color:rgba(102,102,102,1);
      border: 1px solid rgb(102,102,102);
    }
  }
  .center{
    width: 100%;
    margin-top:15px;
    .center_contet{
      display: flex;
      align-items: center;
      width: 100%;
      height: 40px;
      margin-top: 10px;
      .tit{
        font-size: 26px;
      }
      // align-items: center;
    }
  }  
  .button{
    width: 90%;
    margin: 0px auto;
    margin-top:20px;
    // .but1{
    //   background-color: linear-gradient();
    // }
    
    :deep(.van-button--normal){
      width: 100%;
      height: 60px;
      font-size: 26px;
      color:#ffffff;
      border-radius: 20px 20px 20px 20px;
    }
  }

}
</style>