<template>
  <div>
    <!-- v-if="logoList.length>0" -->
    <div class='logoList'>
        <div class='item' v-for="(item,index) in logoList" :key="index">
            <!-- <div class='logoState' v-if="tabState == '1'">
              <img v-if='item.pictureStatus == 0' :src="noChecked"  class="imsTips"/>
              <img v-if='item.pictureStatus == 1' :src="checkSuccessed" class="imsTips"/>
              <img v-if='item.pictureStatus == 2' :src="checkFailed" class="imsTips"/>
            </div> -->
            <fix-image :src="item.userProfilePicture" class="itemImg" @click="watchImg(item.userProfilePicture)" :isOriginal="true"/>
            <div class='userName'>
              <span class='name'>
                {{item.name}}
              </span>
              <img :src="female" class='lexIms' v-if="item.gender == '0'" />
              <img :src="male" class='lexIms' v-if="item.gender == '1'" />
            </div>
            <div class="button" v-if="tabStateCom == '0' && tabOnState == '1'">
              <van-button class="leftButton" @click="noPassOrPass(item,'1')">审核不通过</van-button>
              <van-button class="rightButton" @click="noPassOrPass(item,'0')">审核通过</van-button>
            </div>
            <!-- <div class="button" v-else-if="tabStateCom == '2'  && tabOnState == '1' ">
              <van-button class="leftButton">撤销审核</van-button>
              <van-button class="rightButton">提级处置</van-button>
            </div>             -->
            <div class="button" v-else-if="tabOnState == '0' ">
              <van-button class="leftButton" @click="noPassOrPass(item,'1')">审核不通过</van-button>
              <van-button class="rightButton" @click="noPassOrPass(item,'0')">审核通过</van-button>
            </div>           
            <div class="cancelButton" v-else>
              <van-button class="Cbutton" :icon="cancelIcon" @click="cancelAudited(item)">
                <!-- <template #left-icon>
                    <img :src="cancelIcon" />
                </template> -->
                撤销审核
              </van-button>
            </div>
        </div>
        <div class="refreshButton" v-if="tabOnState == '0'">
            <div class="button" @click="reInitData">
              <!-- 刷新 -->
              <van-icon name="replay" size="20"/>
            </div>
        </div>
    </div>
    <van-image-preview v-model:show="imgShow" :images="imageCheck" :showIndex="false">
    </van-image-preview> 
    <van-dialog v-model:show="dialogShow" title="警告" show-cancel-button @confirm='submitAudit' @cancel="closeDialog">
        <div class='diaTips' v-if="diaParam.auditResult=='1'">
          <span>是否不通过该用户头像？</span>
        </div>
        <div class='diaTips' v-if="diaParam.auditResult=='0'">
          <span>是否通过该用户头像？</span>
        </div>
        <div class='diaTips' v-if="diaParam.auditResult==''">
          <span>是否撤销审核</span>
        </div>        
        <van-field label="拒绝原因" v-model="rejectReason" autosize type="textarea" maxlength="100" show-word-limit v-if="diaParam.auditResult=='1'"></van-field>
    </van-dialog>
    </div>
</template>
<script lang="ts" setup>
import { ref, reactive,provide,inject } from "vue";
import checkFailed from "@/assets/mine/checkFailed.png";
import checkedPass from "@/assets/mine/checkedPass.png";
import cancelIcon from "@/assets/mine/cancelIcon.png";
import checkSuccessed from "@/assets/mine/checkSuccessed.png";
import female from "@/assets/mine/female.png";
import male from "@/assets/mine/male.png";
import noChecked from "@/assets/mine/noChecked.png";
import { encodeParam } from '@/utils/encrypt';
import { Dialog,Toast } from 'vant';
import Api from "@/api/schoolmateAudit/index"
const imgShow = ref(false);
const props =  defineProps({
  dataList:{
    type:Array,
    default:() => [] 
  },
  tabOn:{
    type:String,
    default:()=> '0' 
  },
  tabState:{
    type:String,
    default:()=> '0'    
  }
})

const emit = defineEmits(['onLoad','reInitDataList',"initArtHeadList","initAuditHeadList"])
const imageCheck = ref([] as Array<string>);
const tabStateCom = ref('')
// http://128.196.189.99:8088  123123
const defaultImg = ref("/group1/M00/00/85/gMS9Y2SvoQiAEIrFAAAxsTDisEI014.jpg");
const BaseFileUrl = import.meta.env.VITE_APP_PIC_BASE_URL;
const disabledButton = ref(false)
const logoList = ref<any>([])
const tabOnState = ref('')
const dialogShow = ref(false)
const diaParam = ref<any>({})
const rejectReason = ref('')
watch(
    () => props.dataList,
    (newVal:any)=>{
      logoList.value = newVal
    },
    { immediate: true, deep: true }
)
watch(
      () => props.tabState,
    (newVal:any)=>{
      tabStateCom.value = newVal
    },
    { immediate: true, deep: true }
)
watch(
      () => props.tabOn,
    (newVal:any)=>{
      tabOnState.value = newVal
    },
    { immediate: true, deep: true }
)
const watchImg = (img: string) => {
  // imageCheck.value.push()
    imageCheck.value = [];
    imageCheck.value.push(BaseFileUrl + img);
    imgShow.value = true;
    // console.log(imageCheck.value);
};

const noPassOrPass = async (val:any,type:string)=>{
  //auditResult 0--通过，1--拒绝
  diaParam.value.auditRecordId = val.auditRecordId
  diaParam.value.auditResult = type
  if(type == '1'){
    // message = '不通过'
  }else{
    // message = '通过'
  }
  dialogShow.value = true
}
const closeDialog = ()=>{
  rejectReason.value = ''
  dialogShow.value = true
}
const submitAudit =async ()=>{
  // auditResult

  // console.log({rejectReason:rejectReason.value,auditRecordId:diaParam.value.auditRecordId,auditResult:diaParam.value.auditResult})
  if(diaParam.value.auditResult == '1'){//审核不通过
    if(!rejectReason.value){
      Toast.fail('请输入拒绝原因')
      return
    }
    console.log('审核不通过',rejectReason.value,diaParam.value)
    try{
      let {code,data,msg} =  await Api.auditPicture({rejectReason:rejectReason.value,auditRecordId:diaParam.value.auditRecordId,auditResult:diaParam.value.auditResult})
      Toast.success(msg)
      if(code == 200){
        reInitData()
      }
    }catch(err){
      console.log(err)
    }
  }else if(diaParam.value.auditResult == '0'){//审核通过
    try{
      let {code,data,msg} =  await Api.auditPicture({auditRecordId:diaParam.value.auditRecordId,auditResult:diaParam.value.auditResult})
      Toast.success(msg)
      if(code == 200){
        reInitData()
        
      }
    }catch(err){
      console.log(err)
    }
  }
  else{//撤销审核
  // console.log(diaParam.value.auditRecordId)
    try{
      let {code,data,msg} =  await Api.revokeAuditPicture({auditRecordId:diaParam.value.auditRecordId})
      Toast.success(msg)
      if(code == 200){
        reInitData()
      }else{
        console.log(diaParam.value.auditRecordId)
      }
    }catch(err){
      console.log(err)
    }
  }
}
const reInitData = ()=>{
  console.log('reInitData')
  // return
  emit('reInitDataList')
  if(tabOnState.value == '0'){
    emit('initAuditHeadList')
  }else{
    emit('initArtHeadList')
  }
}
const cancelAudited = async (val:any)=>{
  diaParam.value.auditResult = ""
  diaParam.value.auditRecordId = val.auditRecordId
  dialogShow.value = true
}
onMounted(()=>{

})
</script>
<style lang='less' scoped>
.logoList {
  width: 100%;
  // height: 65vh;
  // max-height: 70vh;
  // height: 100%;
  // overflow-y: scroll;
  padding: 0 24px;
  box-sizing: border-box;
  padding-bottom: 24px;
  background-color: #f5f5f5;
  display: flex;
  // min-height: 100vh;
  justify-content: space-between;
  // align-items: flex-start;
  align-content: start;
  flex-wrap: wrap;
  position: relative;
  .item {
    width: 339px;
    // height: 288px;
    margin-top: 24px;
    border-radius: 24px;
    background-color: #ffffff;
    position: relative;
    display: flex;
    box-sizing: border-box;
    padding-bottom: 24px;
    justify-content: flex-start;
    align-items: center;
    flex-direction: column;
    .itemImg {
      //   position: absolute;
      //   top: 68px;
      //   left: 100px;
      margin-top: 68px;
      width: 140px;
      height: 140px;
      border-radius: 8px;
    }
    .logoState {
      position: absolute;
      left: 0px;
      top: 0px;
      .imsTips {
        height: 54px;
        width: auto;
      }
    }
    .userName {
      display: flex;
      margin-top: 20px;
      align-items: center;
      justify-content: center;
      margin-bottom: 24px;
      width: 100%;
      .lexIms {
        margin-left: 10px;
        width: 28px;
        height: 28px;
      }
    }
    .button {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 60px;
      color: #ffffff;
      .leftButton {
        // f45608
        width: 148px;
        height: 60px;
        background-color: #f45608;
        // background: url("@/assets/mine/cancelChecked.png") no-repea
        border-radius: 35px 0 0 35px;
        color: #ffffff;
        font-size: 17px;
        padding: 0px;
        // background-size: 100% 100%;
      }
      .rightButton {
        // b42d3b
        width: 148px;
        height: 60px;
        background-color: #b42d3b;
        border-radius: 0 35px 35px 0;
        color: #ffffff;
        font-size: 17px;
        padding: 0px;
        // background: url("@/assets/mine/checkedPass.png") no-repeat;
        // background-size: 100% 100%;
      }
    }
    .cancelButton {
      width: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 60px;
      color: #ffffff;
      // background:
      .Cbutton {
        width: 300px;
        height: 60px;
        background-color: #b42d3b;
        border-radius: 35px 35px 35px 35px;
        color: #ffffff;
        font-size: 17px;
        padding: 0px;
      }
      :deep(.van-icon__image) {
        width: 24px;
        height: 24px;
      }
    }
  }
  .refreshButton {
    position: fixed;
    bottom: 60px;
    right: 40px;
    .button {
      width: 60px;
      height: 60px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      background-color: #f5f5f5;
      // :deep(.van-icon) {
      //   width: 50px;
      //   height: 50px;
      // }
    }
  }
}
.diaTips {
  width: 100%;
  display: flex;
  justify-content: center;
  margin: 10px 0;
  font-size: 30px;
}
:deep(.van-dialog__header) {
  padding-top: 30px;
  margin-bottom: 20px;
}
</style>
