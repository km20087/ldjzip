<template>
    <div class="con">
    <van-sticky>
        <nav-bar :title="tit" left-arrow @click-left="onClickLeft" :key="tit" />
    </van-sticky>
    <div class='main'>
        <div class="tab">
            <van-button :disabled="vanDisabled" :class="tabOn=='0'?'defaultTab leftTab selected':'defaultTab leftTab'" @click="sureTab('0')">
              头像巡查
            </van-button>
            <van-button :disabled="vanDisabled" :class="tabOn=='1'?'defaultTab rightTab selected':'defaultTab rightTab'" @click="sureTab('1')">
              人工审查
            </van-button>            
            <!-- selected class="defaultTab leftTab" -->
            <!-- class="defaultTab rightTab" -->
        </div>
        <!-- <div class="stateTab" v-if="tabOn == '0'">
            <div class="left">
                <van-field  label="" placeholder="姓名"  v-model="inp">
                    <template #right-icon>
                        <van-icon name="search" />
                    </template>
                </van-field>
            </div>
            <div class="right">
                <div class='rightTitle'>
                    头像状态
                </div>
                <van-field  label="" label-width="80px" placeholder="请选择" input-align="center" v-model="stateSelect"/>
            </div>
        </div> -->
        <div class="artCheck" v-if="tabOn == '1'">
            <van-tabs v-model:active="tabState" class="tabList" title-active-color="#000000" title-inactive-color="#666666" @click="onClickTab">
              <van-tab title="未审核" name="0" :disabled="tabDisabled">
                
              </van-tab>
              <van-tab title="审核通过" name="1" :disabled="tabDisabled">
                
              </van-tab>
              <van-tab title="审核不通过" name="2" :disabled="tabDisabled">
                
              </van-tab>
            </van-tabs>
            <!-- <van-field label="" placeholder="姓名" class='artInp' v-model="inp">
              <template #right-icon>
                <van-icon name="search" />
              </template>
            </van-field> -->
            <form action='/'>
              <van-search v-model="inp" placeholder="姓名" @search="searchName">
              <template #left-icon>
                <van-icon name="" />
              </template>                
              <template #right-icon>
                <van-icon name="search" />
              </template>
              </van-search>
            </form>
        </div>
        <!-- <van-pull-refresh v-model="refreshing" @refresh="onfreshed">
          <van-list v-model:loading="loading" :finished="finished" @load="onLoad" finished-text="没有更多了">
            <logoList :dataList="dataList" :tabOn="tabOn" :tabState="tabState" @onLoad="onLoad" @reInitDataList="reInitDataList" :key="key"></logoList>
          </van-list>          
        </van-pull-refresh> -->
        <div class="dataListTab"> 
          <van-list v-model:loading="loading" :finished="finished" @load="onLoad" finished-text="没有更多了" :offset="30">
            <logoList :dataList="dataList" :tabOn="tabOn" :tabState="tabState" @initAuditHeadList="initAuditHeadList" @initArtHeadList="initArtHeadList" @onLoad="onLoad" @reInitDataList="reInitDataList" :key="key"></logoList>
          </van-list>               
        </div>
    </div>
    </div>
</template>
<script lang="ts" setup>
import { ref, reactive,provide,inject } from "vue";
import { useRouter, useRoute } from "vue-router";
import logoList from "./logoList.vue"
import checkFailed from "@/assets/mine/checkFailed.png";
import checkSuccessed from "@/assets/mine/checkSuccessed.png";
import female from "@/assets/mine/female.png";
import male from "@/assets/mine/male.png";
import noChecked from "@/assets/mine/noChecked.png";
import defautHeader from "@/assets/mine/default-head@2x.png";
import Api from "@/api/schoolmateAudit/index"

const router = useRouter(); //editQualification
const tit = ref("头像审查");
const inp = ref("");
const tabState = ref('0')
const stateSelect = ref("");
const tabOn = ref("0")
const dataList = ref([] as any)
const imgShow = ref(false);
const imageCheck = ref([] as Array<string>);
const loading = ref(false)
const finished = ref(true)
const refreshing = ref(false)
const pictureStatus = ref('')
const pageNum = ref(1)
const pageSize = ref(10)
const isLastPage = ref(false)
const key = ref(0)
const vanDisabled = ref(false)
const tabDisabled= ref(false)
const defaultImg = ref(
  "/group1/M00/00/85/gMS9Y2SvoQiAEIrFAAAxsTDisEI014.jpg"
);


const sureTab =async (val:string)=>{
  if(tabOn.value != val){
    dataList.value = []
  }
  tabOn.value = val;

  finished.value = false
  // loading.value = true
  dataList.value = []
  isLastPage.value = false
  console.log('finished',finished.value)
  reInitDataList()
  if(val=='0'){
    reInitDataList()
    await initAuditHeadList()
  }else{
    reInitDataList()
    await initArtHeadList()
  }

}

const onClickTab =async (val:any) =>{
  pageNum.value = 1
  isLastPage.value = false
  if(pictureStatus.value !== val){
    tabDisabled.value = true
    // dataList.value = []
    reInitDataList()
    // finished.value = false
    await initArtHeadList()
    tabDisabled.value = false
  }
  console.log(finished.value)
}

const searchName = ()=>{
  // if(!inp.value){
  //   return
  // }
  reInitDataList()
  initArtHeadList()

}

const onClickLeft = () => {
  router.back();
};

const onfreshed = ()=>{
  finished.value = false
  loading.value = true
  // dataList.value = []
  // console.log('onfreshed')
  onLoad()
}

const onLoad = async ()=>{
  console.log('onload')
  finished.value = false
  console.log(isLastPage.value,"isLastPage.value",loading.value,"loading.value")
  if(tabOn.value == '0'){
    console.log('巡查')
    await initAuditHeadList()
    finished.value = true
    refreshing.value = false;
  }
  else{
    // pageNum++
    console.log('人工')
    //tabState  0--未审核,1--审核通过,2--审核不通过
    if( !isLastPage.value && loading.value){
      console.log('人工翻页')
      pageNum.value++
      await initArtHeadList()     
      
    }else{
      finished.value = true
      refreshing.value = false;          
    }
  }
  
}

const initAuditHeadList = async ()=>{
    loading.value = true
    vanDisabled.value = true
    key.value++
  try{
    dataList.value = []
    const result = await Api.randomListAiAudit({})
    // console.log(result)
    if(result.code == 200){
      // dataList.value = result.data

      let list = result.data
      for(let i in list){
        dataList.value.push(list[i])
      }                       
      loading.value = false
      finished.value = true      
    }
    vanDisabled.value = false
  }catch(err){
    console.log(err,'err')
    loading.value = false
    finished.value = true
    vanDisabled.value = false
  }
}

const initArtHeadList = async ()=>{
    loading.value = true
    vanDisabled.value = true
    key.value++
  // 
  let pn = pageNum.value
  let ps = pageSize.value
  pictureStatus.value = tabState.value
  try{
    //  pageAllPictureRecord    pageAuditPictureSchoolmate
    const result = await Api.pageAllPictureRecord({pictureStatus:pictureStatus.value,pageNum:pn,pageSize:ps,name:inp.value})
    if(result.code == 200){
      isLastPage.value = result.data.isLastPage       
      dataList.value = dataList.value.concat(result.data.list)             
      loading.value = false
      if(isLastPage.value){
        loading.value = false;
        finished.value = true;
      }      
    }
    vanDisabled.value = false
  }catch(err){
    console.log(err,'err')
    loading.value = false
    finished.value = true
    vanDisabled.value = false
  }
  console.log('finished',finished.value)
}

const reInitDataList = ()=>{
  console.log('reInitDataList')
  finished.value = false
  loading.value = false
  dataList.value = []
  pageNum.value = 1;
  pageSize.value = 10;

}

onMounted(()=>{
  onLoad()
})
</script>
<style lang="less" scoped>
.con {
  widows: 100%;
  height: 100vh;
  overflow-y: scroll;
}
.main {
  width: 100%;
  // min-height: 60vh;
  // padding: 0 24px;
  box-sizing: border-box;
  font-family: PingFangSC, PingFang SC;
  // min-height: 100vh;
  padding-top: 10px;
  // background-color: #f5f5f5;
  .tab {
    width: 100%;
    // margin-top: 10px;
    display: flex;
    justify-content: center;
    align-items: center;
    .defaultTab {
      width: 351px;
      height: 80px;
      border: 2px solid #b42d3b;
      color: #b42d3b;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #ffffff;
    }
    .leftTab {
      border-radius: 16px 0px 0px 16px;
    }
    .rightTab {
      border-radius: 0px 16px 16px 0px;
    }
    .selected {
      color: #ffffff;
      background-color: #b42d3b;
    }
  }
  .stateTab {
    width: 100%;
    height: 90px;
    display: flex;
    margin-top: 10px;
    background-color: #ffffff;
    align-items: center;
    padding: 13px 23px;
    box-sizing: border-box;
    // justify-content:
    :deep(.van-cell) {
      padding: 0 12px;
      box-sizing: border-box;
      height: 64px;
      line-height: 64px;
      border-radius: 8px;
    }
    .left {
      :deep(.van-cell) {
        //   padding: 0px;
        width: 290px;
        background-color: rgba(0, 0, 0, 0.04);
      }
      :deep(.van-field__left-icon) {
        margin-left: 10px;
      }
    }
    .right {
      display: flex;
      align-items: center;
      background-color: #ffffff;
      .rightTitle {
        color: #222222;
        width: 180px;
        height: 90px;
        line-height: 90px;
        font-size: 28px;
        text-align: right;
        box-sizing: border-box;
        padding-right: 10px;
      }
      :deep(.van-cell) {
        //   padding: 0px;
        // width: 240px;
        // width: 120px;
        flex: 1;
        background-color: rgba(0, 0, 0, 0.04);
      }
    }
  }
  .artCheck {
    width: 100%;
    // margin-top: 10px;
    // height: 90px;
    background-color: #ffffff;

    .tabList {
      height: 90px;
      border-bottom: 1px solid #dfdfdf;
      :deep(.van-tab--active) {
        // font-weight: 500;
        font-weight: bold;
      }
    }
    // .artInp {
    //   padding: 0px;
    //   background-color: #ffffff;
    //   // height: 70px;
    //   padding: 15px 24px;
    //   height: 100px;
    //   box-sizing: border-box;

    //   :deep(.van-field__value) {
    //     // padding: 5px 24px;
    //     // height: 70px;
    //     // box-sizing: border-box;
    //     background: rgba(0, 0, 0, 0.04);
    //   }
    //   :deep(.van-field__body) {
    //     padding: 0px 23px 0 20px;
    //     height: 70px;
    //     border-radius: 8px;
    //     box-sizing: border-box;
    //   }
    // }
  }
  .logoList {
    width: 100%;
    padding: 0 24px;
    box-sizing: border-box;
    padding-bottom: 24px;
    background-color: #f5f5f5;
    display: flex;
    // min-height: 100vh;
    justify-content: space-between;
    // align-items: flex-start;
    align-content: flex-start;
    flex-wrap: wrap;
    .item {
      width: 339px;
      height: 288px;
      margin-top: 24px;
      background-color: #ffffff;
      position: relative;
      .itemImg {
        position: absolute;
        top: 68px;
        left: 100px;
        width: 140px;
        height: 140px;
        border-radius: 8px;
      }
    }
  }
}
.dataListTab {
  max-height: 100%;
  // overflow-y: scroll;
}
</style>