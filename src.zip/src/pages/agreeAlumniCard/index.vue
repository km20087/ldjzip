<template>
  <div class="con" :class="cardExchangeStatus == '0' ? 'wido' : ''">
    <van-nav-bar title="名片夹" left-text="" left-arrow @click-left="onClickLeft" />
    <myCard :perInfo="perInfo" :showEdit="showEdit" :cardExchangeStatus="cardExchangeStatus" :key="flag"></myCard>
    <div class="education-list" v-if="isLiaoShiDa() && perInfo?.educationInfoList?.length > 0">
      <div class="xueji-xinxi">
        <van-image :src="xuejiLogo" class="xuejiLogo" />
        <span>学历信息</span>
      </div>
      <div class="list-block" v-for="(item, index) in perInfo.educationInfoList" :key="index">
        <div class="up">
          <van-image :src="degreeLogo" class="degreeLogo" />
          <span>{{ item.education }}</span>
        </div>
        <div class="down">
          <div class="msg">
            <span class="label">院系：</span>
            <span>{{ item.collegeName }}</span>
          </div>
          <div class="msg">
            <span class="label">专业：</span>
            <span>{{ item.majorName }}</span>
          </div>
          <div class="msg">
            <span class="label">班级：</span>
            <span>{{ item.classesName }}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="title" v-if="!isLiaoShiDa()">
      <img :src="stuStatus" alt="" class="ims" />
      <span class="font">学历信息</span>
    </div>
    <div class="info" v-if="!isLiaoShiDa()">
      <div class="listItem mar40" v-if="schoolLevel == '2'">
        <div class="typeName">学历:</div>
        <div class="content">{{ changeA(perInfo.education) }}</div>
      </div>
      <div class="listItem mar40" v-else-if="schoolLevel == '1'">
        <div class="typeName">{{schoolConfig.education}}:</div>
        <div class="content">{{ changeA(perInfo.education) }}</div>
      </div>        
      <div class="listItem mar40">
        <div class="typeName">在校时间:</div>
        <div class="content">{{ perInfo.schoolStartYear }}-{{ perInfo.schoolEndYear }}</div>
      </div>
      <div class="listItem mar40" v-if="schoolLevel == '2'">
        <div class="typeName">{{schoolCode == SchoolCode.BaoTouZhiYeJiShu?"系部:":"院系:"}}</div>
        <div class="content">{{ perInfo.collegeName == 'none' ? '' : perInfo.collegeName }}</div>
      </div>
      <div class="listItem mar40" v-else-if="schoolLevel == '1'">
        <div class="typeName">届别:</div>
        <div class="content">{{ perInfo.schoolEndYear }}</div>
      </div>         
      <div class="listItem mar40" v-if="schoolLevel == '2'">
        <div class="typeName">专业:</div>
        <div class="content">{{ perInfo.majorName == 'none' ? '' : perInfo.majorName }}</div>
      </div>
      <div class="listItem mar40" v-else-if="schoolLevel == '1'">
        <div class="typeName">班级:</div>
        <div class="content">{{ perInfo.classesName }}</div>
      </div>           
    </div>
    <div class="title2" v-if="cardExchangeStatus == '1'">
      <!-- <img :src="stuStatus" alt="" class="ims" /> -->
      <span class="font">其他信息</span>
    </div>
    <div class="info1" v-if="cardExchangeStatus == '1'">
      <div v-for="(item, index) in showDataList" :key="index" :class="picList.includes(item.enLabel)
        ? 'mar160 listItem'
        : item.value != 'none'
          ? 'listItem mar40'
          : ''
        ">
        <div class="typeName" v-if="item.value != 'none'">{{ item.cnName }}:</div>
        <div class="content" v-if="!picList.includes(item.enLabel) && item.value != 'none'">{{
          initDataShow(item.enLabel, item.value, item.type)
        }}</div>
        <div class="content" v-else-if="picList.includes(item.enLabel)">
          <fix-image class="imgLogo" :src="item.value" width="130" height="130" alt="图片" />
        </div>
      </div>
    </div>
    <div v-else>
      <div class="imsaw" v-if="exchangeCardFlag == '1'">
        <!-- <img :src="nodata" alt="" class="ims" /> -->
        <p class="p1">对方很害羞隐藏了信息</p>
        <p class="p1">快来和TA交换信息试试吧～</p>
        <van-button round type="primary" class="but" @click="exchangeCard">交换名片</van-button>
      </div>
      <div class="imsaw" v-else>
        <!-- <img :src="nodata" alt="" class="ims" /> -->
        <p class="p1">对方拒绝与陌生人交换名片</p>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { reactive, ref } from 'vue';
import nodata from '@/assets/img/nodata.png';
import { useOccupation } from '@/hooks/useOccupation';
import stuStatus from '@/assets/icons/stuStatus.png';
import myCard from '@/components/myCard/index.vue';
import Api, { mate, cardParam } from '@/api/schoolmate';
import ApiConfig from '@/api/config';
import { Toast, Dialog } from 'vant';
// import listForm from "../infoConfig/data";
import listForm from '@/utils/dataList/infoConfig';
import nation from '@/utils/dataList/nation';
import country from '@/utils/dataList/country';
import datalist from '@/utils/dataList/datalist';
import xuejiLogo from '@/assets/mine/xuejiLogo.png';
import degreeLogo from '@/assets/mine/degreeLogo.png';
import { isLiaoShiDa,isShanDa } from '@/utils/customizedType';
import { SchoolCode } from '@/constants';
import { getSchoolCode } from '@/utils';
import {schoolShowConfig,zhongxueConfig} from "@/utils/schoolLevelShow"
const schoolCode = getSchoolCode();
const router = useRouter();
const route = useRoute();
const flag = ref(1);
const showEdit = ref(false);
const cardExchangeStatus = ref('');
const exchangeCardFlag = ref('');
const formData = <any>reactive({});
const loasd = ref([
  'mobile',
  'wechat',
  'emailAddress',
  'employer',
  'detailedAddress',
  'name',
  'userProfilePicture',
  'academicDegree',
  'schoolStartYear',
  'schoolEndYear',
  'collegeName',
  'majorName',
  'education',
]);
const noShowList = ref([
  'cardType',
  'cardNumber',
  'classmateName',
  'colleagueName',
  'identificationDocumentImage',
  'diplomaImage',
]);
const picList = ref([
  'bareheadedPhoto',
  'diplomaImage',
  'userProfilePicture',
  'identificationDocumentImage',
]);

const schoolLevel = ref('')
const schoolConfig = <any>ref({})

const eduList = ref([
  { text: '小学', value: '0' },
  { text: '初中', value: '1' },
  { text: '高中', value: '2' },
  { text: '专科', value: '3' },
  { text: '本科', value: '4' },
  { text: '硕士研究生', value: '5' },
  { text: '博士研究生', value: '6' },
]);
const listInit = <any>ref([]);
const showList = <any>ref([]);
const showDataList = <any>ref([]);
const occupationName = ref('');
const perInfo = <any>ref({});
const showAllList = ref([] as any);
const groupsAdminShowAllInfoFlag = ref('');
const paramList = ref([] as string[]);
const { occupation } = useOccupation(formData);
const changeA = (val: string) => {
  for (let i in eduList.value) {
    if (eduList.value[i].value == val) {
      return eduList.value[i].text;
    }
  }
};

const initDataShow = (enLabel: string, value: string, type: string) => {
  if (
    type == 'inp' ||
    type == 'specialX' ||
    type == 'selectTime' ||
    enLabel == 'ethnic' ||
    enLabel == 'jobDuration' ||
    type == 'inpSpecial'
  ) {
    if (enLabel != 'jobTitle') {
      //辽宁师范职务直接返回中文名
      return value;
    } else {
      // return isLiaoShiDa() ? value : occupationName.value;
      if(isLiaoShiDa() || isShanDa()){
        return value
      }else{
        return occupationName.value
      }
    }
  } else if (type == 'select') {
    return value;
  } else if (enLabel != 'nationality') {
    for (let i in datalist) {
      if (datalist[i].type == enLabel) {
        let list = datalist[i].list;
        for (let a in list) {
          if (list[a].value == value) {
            return list[a].text;
          }
        }
      }
    }
  } else if (enLabel == 'nationality') {
    for (let i in country) {
      if (country[i].value == value) {
        return country[i].text;
      }
    }
  }
};
const initPerConfig = async () => {
  listInit.value = listForm.listForm().list;
  console.log('agreeAlumniCard',listInit.value)
  let a = route.query.userId as string;
  const { data, code, msg } = await ApiConfig.infoConfigPerGet({ userId: a });
  if (code == 200) {
    showAllList.value = data;
    for (let i in data) {
      if (data[i] == '3') {
        paramList.value.push(i); //获得所有需要展示的字段
        if (!loasd.value.includes(i)) {
          showList.value.push({ enLabel: i, cnName: '', value: '', type: '' });
        }
      }
    }
    //辽宁师范学历数组
    if (isLiaoShiDa()) {
      paramList.value.push('educationInfoList');
    }
    let laoso = ['name', 'userProfilePicture'];
    for (let i in laoso) {
      if (!paramList.value.includes(laoso[i])) {
        paramList.value.push(laoso[i]);
      }
    }

    initPer();
  }
};
const exchangeCard = async () => {
  if (schoolCode == SchoolCode.ShanDa) {
    Dialog.confirm({
      title: '提 示',
      message: '网络交友行为与平台无关，谨防上当，避免产生钱财交易',
      showCancelButton: false,
      confirmButtonText: '我已知晓',
    }).then(async () => {
      let a = route.query.userId as string;
      const { data, code, msg } = await Api.exchangeSchoolmateCard({
        userId: a,
        exchangeResult: '1',
      });
      Toast({ message: msg });
    });
  } else {
    let a = route.query.userId as string;
    const { data, code, msg } = await Api.exchangeSchoolmateCard({
      userId: a,
      exchangeResult: '1',
    });
    Toast({ message: msg });
  }
};
const initSchoolmateType = (val: string, obj: any) => {
  if (val == '0' || val == '1' || val == null) {
    obj['jobDepartment'] = 'none';
    obj['jobNumber'] = 'none';
    obj['positionType'] = 'none';
    obj['colleagueName'] = 'none';
    obj['jobDuration'] = 'none';
  } else {
    obj['collegeName'] = 'none';
    obj['majorName'] = 'none';
    obj['classesName'] = 'none';
    obj['studentIdNumber'] = 'none';
    obj['education'] = 'none';
    obj['academicDegree'] = 'none';
    obj['classmateName'] = 'none';
    obj['schoolDuties'] = 'none';
  }
};
const initPer = async () => {
  let a = route.query.userId as string;
  let b = route.query.groupsId as string;
  // { userId: a }   memberGroupsId
  const { data, code, msg } = await Api.getDetailedInformation({
    userId: a,
    memberGroupsId: b,
  });
  console.log(data, 'dada');

  occupationName.value = data.occupationName;
  cardExchangeStatus.value = data.cardExchangeStatus || '';
  exchangeCardFlag.value = data.exchangeCardFlag == null ? '1' : data.exchangeCardFlag;
  if (data.groupsAdminShowAllInfoFlag != null) {
    groupsAdminShowAllInfoFlag.value = data.groupsAdminShowAllInfoFlag;
    groupsAdminShowAllInfoFlag.value == '1' ? (cardExchangeStatus.value = '1') : null;
  }
  if (code == 200) {
    if (groupsAdminShowAllInfoFlag.value !== '1') {
      console.log(perInfo.value, 'perInfo.value');

      for (let i in paramList.value) {
        perInfo.value[paramList.value[i]] = data[paramList.value[i]]; //根据字段获取需要展示的信息
      }
      initSchoolmateType(perInfo.value.schoolmateType, perInfo.value);
      for (let i in showList.value) {
        showList.value[i].value = perInfo.value[showList.value[i].enLabel];
      }
      for (let a in listInit.value) {
        for (let i in showList.value) {
          if (
            showList.value[i].enLabel == listInit.value[a].enLabel &&
            !noShowList.value.includes(showList.value[i].enLabel)
          ) {
            showDataList.value.push({
              value: showList.value[i].value,
              cnName: listInit.value[a].cnName,
              type: listInit.value[a].type,
              enLabel: listInit.value[a].enLabel,
            });
          }
        }
      }
      flag.value++;
      // formData.occupationCode = perInfo.value.jobTitle;
    } else {
      perInfo.value = data;
      initSchoolmateType(perInfo.value.schoolmateType, perInfo.value);
      // for (let i in showList.value) {
      //   showList.value[i].value = perInfo.value[showList.value[i].enLabel];
      // }
      let asl: any = [];
      for (let i in showAllList.value) {
        asl.push({ enLabel: i, cnName: '', value: '', type: '' });
      }
      for (let i in asl) {
        asl[i].value = perInfo.value[asl[i].enLabel];
      }
      for (let a in listInit.value) {
        for (let i in asl) {
          if (
            asl[i].enLabel == listInit.value[a].enLabel &&
            !noShowList.value.includes(asl[i].enLabel)
          ) {
            showDataList.value.push({
              value: asl[i].value,
              cnName: listInit.value[a].cnName,
              type: listInit.value[a].type,
              enLabel: listInit.value[a].enLabel,
            });
          }
        }
      }
      flag.value++;
    }
  }

  formData.occupationCode = perInfo.value.jobTitle;
  console.log('showDataList',showDataList.value)
};
const onClickLeft = () => {
  router.back();
};

onMounted(() => {
  initPerConfig();
  schoolLevel.value =  schoolShowConfig() as string
  schoolConfig.value =  zhongxueConfig()    
});
</script>
<style lang="less" scoped>
.wido {
  height: 100% !important;
  padding-bottom: 0px !important;
}

.mar40 {
  margin-bottom: 40px;
}

.mar160 {
  margin-bottom: 160px;
}

.con {
  width: 100%;
  // height: 100%;
  padding-bottom: 20px;
  background: #f9f9f9;

  .education-list {
    margin-top: 135px;
    padding: 59px 30px;

    .xueji-xinxi {
      display: flex;
      align-items: center;
      font-size: 36px;
      color: #222222;
      font-weight: 500;

      .xuejiLogo {
        width: 40px;
        height: 40px;
        margin-right: 10px;
      }
    }

    .list-block {
      margin-top: 26px;
      background: #ffffff;
      box-shadow: 1px 2px 20px 0px rgba(0, 0, 0, 0.04);
      border-radius: 16px;

      .up {
        height: 70px;
        display: flex;
        align-items: center;
        background: url('@/assets/mine/xuewei-bg.png') no-repeat;
        background-size: 100% 100%;
        padding: 0 30px;
        font-size: 32px;
        color: #dc7506;
        font-weight: 500;

        .degreeLogo {
          width: 40px;
          height: 40px;
          margin-right: 10px;
        }
      }

      .down {
        padding: 28px 40px;

        .msg {
          font-size: 28px;
          color: #666666;
          font-weight: 500;
          padding: 12px 0;
          display: flex;
          align-items: center;

          .label {
            display: inline;
            // min-width: 140px;
            margin-right: 30px;
          }
        }
      }
    }
  }
}

.title {
  width: 100%;
  height: 40px;
  padding-left: 30px;
  padding-right: 30px;
  margin-top: 180px;
  // line-height: 40px;
  display: flex;
  align-items: center;

  .ims {
    width: 40px;
    height: 40px;
  }

  .font {
    margin-left: 10px;
    font-size: 36px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    color: #222222;
  }
}

.title2 {
  width: 100%;
  height: 40px;
  padding-left: 30px;
  padding-right: 30px;
  margin-top: 40px;
  // line-height: 40px;
  display: flex;
  align-items: center;

  .ims {
    width: 40px;
    height: 40px;
  }

  .font {
    margin-left: 10px;
    font-size: 36px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    color: #222222;
  }
}

.info {
  margin: 0 auto;
  margin-top: 16px;
  width: 92.5%;
  height: 372px;
  background: #fff;
  box-shadow: 1px 2px 20px 0px rgba(0, 0, 0, 0.04);
  border-radius: 8px;
  padding-top: 50px;
  padding-left: 40px;
  box-sizing: border-box;

  .listItem {
    width: 100%;
    height: 42px;
    display: flex;
    align-items: center;

    .typeName {
      width: 180px;
      height: 40px;
      line-height: 40px;
      font-size: 28px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #222222;
    }

    .content {
      margin-left: 40px;
      height: 40px;
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #222222;
      line-height: 40px;
    }
  }
}

.info1 {
  margin: 0 auto;
  margin-top: 16px;
  // margin-bottom: 20px;
  width: 92.5%;
  padding-bottom: 20px;
  // height: 372px;
  overflow-y: scroll;
  background: #fff;
  box-shadow: 1px 2px 20px 0px rgba(0, 0, 0, 0.04);
  border-radius: 8px;
  padding-top: 50px;
  padding-left: 40px;
  box-sizing: border-box;

  .listItem {
    width: 100%;
    height: 42px;
    display: flex;
    align-items: center;

    .typeName {
      width: 200px;
      height: 40px;
      line-height: 40px;
      font-size: 28px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #222222;
    }

    .content {
      margin-left: 40px;
      height: 40px;
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #222222;
      line-height: 40px;
    }
  }
}

.imsaw {
  margin-top: 30px;
  width: 100%;
  height: 100%;
  text-align: center;

  .ims {
    width: 219px;
    height: 219px;
  }

  .p1 {
    margin: 0;
    font-size: 28px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #666666;
  }

  .but {
    margin-top: 40px;
  }
}

.imgLogo {
  width: 130px;
  height: 130px;
  border-radius: 50%;
  object-fit: cover;
  background: #fff;
}
</style>
