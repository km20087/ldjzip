<template>
  <div>
    <van-nav-bar title="活动详情" left-text="" left-arrow @click-left="onClickLeft" />
    <div class="fontsd">
      <p>{{ titeas }}</p>
    </div>
    <div class="asdi">
      <div v-html="hsad" class="helm"></div>
    </div>
  </div>
</template>
<script lang="ts" setup>
  import Api, { school } from '@/api/home';
  import { reactive, ref } from 'vue';
  import { useRouter } from 'vue-router';
  const router = useRouter();
  const sdasd = ref('');

  const testList = ref([]);
  const index = ref(0);
  const username = ref('');
  const password = ref('');
  const titeas = <any>ref('');
  const hsad = <any>ref('');
  const onSubmit = (val: any) => {};
  const initList = async () => {
    // const { status, data, msg } = await Api.getSchoolNews(loginInfo);
    // testList.value = data.list;
  };
  const onClickLeft = () => {
    history.back();
  };
  initList();
  onMounted(() => {
    // 获取当前路由实例参数
    hsad.value = router.currentRoute.value.query.index;
    titeas.value = router.currentRoute.value.query.tit;
  });
</script>

<style lang="less" scoped>
  .fontsd {
    width: 100%;
    text-align: center;
    margin: 0 auto;
    font-weight: 500;
    font-size: 36px;
  }
  .asdi {
    width: 100%;
    height: 80vh;
    padding: 0 20px;
    overflow-y: scroll;
    .helm {
      width: 100%;
      // height: 100%;
      margin-bottom: 100px;
      height: 100vh;
      // overflow-y: scroll;
      p {
        line-height: 24px;
      }
    }
  }
</style>
