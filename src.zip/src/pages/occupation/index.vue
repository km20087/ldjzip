<template>
  <van-collapse
    ref="firstCollapseRef"
    class="collapse-wrap"
    v-model="activeName"
    accordion
    @change="change"
  >
    <template v-for="(item, index) in collapseList" :key="item.code">
      <van-cell
        v-if="item.hasChildren == '0'"
        :title="item.occupationName"
        :class="{ choose: item.code == occupation.code }"
        @click="onChoose(item)"
      />
      <van-collapse-item v-else :title="item.occupationName" :name="index">
        <span
          class="tag"
          :class="{ choose: subItem.code == occupation.code }"
          v-for="subItem in item.children"
          @click="onChoose(subItem)"
        >
          {{ subItem.occupationName }}
        </span>
      </van-collapse-item>
    </template>
  </van-collapse>
</template>

<script setup lang="ts">
  import { getOccupationInfo } from '@/api/my/occupation';
  import { Toast } from 'vant';
  import { ref } from 'vue';
  import { useRouter } from 'vue-router';
  import { useUserStore } from '@/store';
  import { storeToRefs } from 'pinia';
  const router = useRouter();
  const userStore = useUserStore();
  const { occupation } = storeToRefs(userStore);

  const activeName = ref();

  const collapseList = ref<Occupation[]>([]);

  function onChoose(item: Occupation) {
    occupation.value = item;
    userStore.isNeedInitOccupation = false;
    router.back();
  }

  async function getData(code: string): Promise<Occupation[]> {
    let data = [];
    try {
      const result = await getOccupationInfo({ code });
      if (result.code == 200) {
        data = result.data;
      }
    } finally {
      return data;
    }
  }

  async function getChildrenData(code: string, index: number) {
    const data = await getData(code);
    collapseList.value[index].children = data;
  }

  async function change(index: number | string) {
    if (index === '') return;
    let { code, children = [] } = collapseList.value[index as number];
    if (children.length) return;
    const toast = Toast.loading({ message: '加载中' });
    await getChildrenData(code, index as number);
    toast.clear();
  }

  function findIndex(code: string, data: Occupation[]) {
    return data.findIndex((item) => item.code == code);
  }

  onMounted(async () => {
    const toast = Toast.loading({ message: '加载中' });
    let firsetLevelData = await getData('0');
    collapseList.value = firsetLevelData;
    let { parentCode, code } = occupation.value;
    if (code == '') return;
    if (parentCode == '0') {
      activeName.value = findIndex(code, firsetLevelData);
    } else {
      let firstLevelIndex = findIndex(parentCode, firsetLevelData);
      await getChildrenData(parentCode, firstLevelIndex);
      activeName.value = firstLevelIndex;
    }
    toast.clear();
  });
</script>

<style lang="less" scoped>
  .collapse-wrap {
    --van-collapse-item-content-padding: 16px 16px 0;
  }
  .tag {
    padding: 8px 16px;
    margin: 0 16px 16px 0;
    border-radius: 50px;
    background-color: #f1f1f1;
    display: inline-block;
  }
  .choose {
    color: #fff;
    background-color: var(--van-button-primary-background-color);
  }
</style>
