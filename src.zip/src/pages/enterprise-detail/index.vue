<template>
    <div class='content'>
		<van-nav-bar :title="title" left-text="" left-arrow @click-left="onClickLeft" />  
		<!-- <div class="gap"></div>		       -->
        <div class='enterprise_detail'>
           <enterprisetitle :logo="enterpriseInfo.logo" :enterpriseName="enterpriseInfo.enterpriseName" :positionCount="enterpriseInfo.positionCount" :views="enterpriseInfo.views" />         
        </div>
		<van-tabs :active="act" shrink @click-tab="onClickTab">
			<van-tab title="企业简介" name="0">
			</van-tab>
			<van-tab title="招聘信息" name="1">

			</van-tab>								
		</van-tabs>
			<!-- <div class='des' v-html="innerHtml" v-if="act == '0'"> -->
				
			<!-- </div> -->
			<img :src="enterpriseInfo.content" alt=""  v-if="act == '0'" class="ims1">
			<div class="jobInfo" v-else-if="act == '1'">
				<van-list v-model:loading="loading" :finished="finished" :immediate-check="true" :finished-text="finsText" @load="onLoad" :offset='400'>
				<van-cell v-for="(item, index) in jobList" :key="index" @click='jumpJobDetail(item)'>
					<div class='jobItem'>
						<div class='jobtitle'>
							{{item.positionName}}
						</div>
						<div class='jobdetail'>
							<div class='creatTime'>
								{{changeTime(item.createTime)}}
							</div>
							<div class='salaryTypeClass' v-if="item.salaryType == '0'">
								面议
							</div>
							<div class='salaryTypeClass' v-if="item.salaryType == '1'">
								{{item.salaryMin}} - {{item.salaryMax}}
							</div>							
						</div>
					</div>
				</van-cell>
				</van-list>
							
			</div>			
    </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import jobIcon from '@/assets/img/jobIcon.png';
import Api from "@/api/enterprise"
import { Base64 } from 'js-base64';
import enterprisetitle from './enterprisetitle.vue'
const router = useRouter();
const route = useRoute();
const title = ref('校友企业');
const innerHtml = ref('')

// const showDefault = ref(false)
const enterpriseInfo = <any>ref({})

const act = ref('0')

const jobList = <any>ref([])
const loading = ref(false);
const finished = ref(false);
const isLastPageb = ref(false);
const total = ref(0);
const finsText = ref('没有更多了');
const pages = ref(0);

const pageJob = ref({
	pageNum:1,
	pageSize:10
})

const showDefault = (item:any) =>{
	let img = new Image()
	img.src = item.logo 
	img.onerror = ()=>{
        console.log('error1')
		// item.showDefault = true
	}	
}

const jumpJobDetail = (item:any) =>{
	// router
	console.log(item)
	//enterpriseInfo
	sessionStorage.setItem('enterpriseInfo',JSON.stringify(enterpriseInfo.value))
	sessionStorage.setItem('jobDetail',JSON.stringify(item))
	router.push({path:"/enterprise-job"})

}

const onClickTab = (val:any) =>{
	act.value = val.name
}


const initData =async ()=>{
    let id = route.query.id || ''
    console.log(id)
    try{
        let {msg,code,data} = await Api.detailEnterprise({id})
        let content1 = ''
        if(code == 200){
            if(!!data.content){
                let contentDetail = decodeURIComponent(
                    Base64.decode(Base64.decode(Base64.decode(Base64.decode(data.content))))
                )
                content1 = contentDetail.replace(/<img/gi, "<img style='width:100%;height:100%'")
            }
          innerHtml.value = content1
          console.log('content1',content1)
          enterpriseInfo.value = data
		enterpriseInfo.value.positionCount = !enterpriseInfo.value.positionCount?0:enterpriseInfo.value.positionCount
		enterpriseInfo.value.views = !enterpriseInfo.value.views?0:enterpriseInfo.value.views
        }
    }catch(err){
        console.log(err)
    }
}

const changeTime = (val:any)=>{
	let time = new Date(val)
	console.log(time)
	let year = time.getFullYear()
	let month = addZeroShow(time.getMonth()+1)
	let day = addZeroShow(time.getDate())
	return `${year}-${month}-${day}`
}

const addZeroShow = (val:number) =>{
  if(val < 10){
    return '0'+String(val)
  }else{
    return String(val)
  }
}

const initJob = async ()=>{
	loading.value = true;	
	try{
		let {msg,code,data} = await Api.pagePosition({schoolmateEnterpriseId:route.query.id || '',...pageJob.value})
		if(code == 200){
				pages.value = data.pages;
				total.value = data.total;
				isLastPageb.value = data.isLastPage;
			if (pages.value == 1) {
				jobList.value.length = 0;
			}	
			jobList.value = jobList.value.concat(data.list)	
			loading.value = false;
		}else{
			finsText.value = msg;
			loading.value = false;
			finished.value = true;			
		}
	}catch(err){
		console.log(err)
	}
	if (isLastPageb.value) {
		finished.value = true;
		loading.value = false;
	}		
}	

const onLoad = ()=>{
	console.log('bottom---')
  if (!isLastPageb.value) {
	pageJob.value.pageNum++;
	finished.value = false;
	initJob();
  } else {
    loading.value = false;
    finished.value = true;
  }	
}

const onClickLeft = () => {
    router.go(-1);
};

const addViews = async () =>{
	let id = route.query.id || ''
	await Api.addEnterpriseViews({id})
}

onMounted(async ()=>{
     initData()
	 initJob()
	 addViews()
})
</script>

<style lang='less' scoped>
.content{
	width: 100%;
	// height: 99%;
	// overflow: hidden;
	// background-color: #f5f5f5;
	.gap {
		margin-top: 30px;
		width: 100%;
		height: 20px;
		background-color: #f5f5f5;
	}	
    .enterprise_detail{
		padding-top: 20px;
		width:100%;
		background-color: #ffffff;

	}
		.jobInfo{
			width: 100%;
			// 
			height: 75%;
			overflow-y: auto;
			// overflow-y: scroll;	

			.jobItem{
				background-color: #ffffff;
				margin-bottom:20px;
				width:100%;
				padding: 10px 20px;
				box-sizing: border-box;
				
				.jobtitle{
					font-size:36px;
					font-weight:600;
					display:flex;
					justify-content: flex-start;
					align-items: center;
				}
				.jobdetail{
					margin-top:20px;
					width:100%;
					display: flex;
					align-items: center;
					justify-content: space-between;
					.creatTime{
						font-size: 28px;
					}
					.salaryTypeClass{
						color:#40A9FF;
						font-size: 36px;
					}
				}
			}

			
		}	
}
.ims1{
	width: 100vw;
	height: auto;
	// margin-bottom: 20px;
}
</style>

