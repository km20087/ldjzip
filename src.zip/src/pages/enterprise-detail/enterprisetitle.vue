<template>
    <div class='item'>
        <fix-image :defaultSrc="enterpriseLogo" :src="logo" class="logoIms"></fix-image>
    	<div class='right'>
    		<div class='name'>
    			{{enterpriseName}}
    		</div>
    		<div class='other'>
    			<div class='jobClass'>
    				<div class='icon'>
    					<img :src="jobIcon" class='ims' />
    				</div>
    				<div class='jobNumber'>招聘岗位:{{positionCount || 0}}</div>
    			</div>
    			<div class='pageView'>
    				浏览量:{{views || 0}}
    			</div>
    		</div>
    	</div>
    </div>        
</template>
<script lang="ts" setup name="enterprise-detail">
import enterpriseLogo from '@/assets/img/enterpriseLogo.png';
import jobIcon from '@/assets/img/jobIcon.png';
const props = withDefaults(
  defineProps<{
      logo:string,
      enterpriseName:string
      positionCount:number
      views:number
  }>(),
  {
    // enterpriseInfo:null
    logo:"",
    enterpriseName:"",
    positionCount:0,
    views:0,

  }
)
</script>
<style lang='less' scoped>
        .item{
			width: 100%;
			padding: 5px 20px;
			box-sizing: border-box;
			display: flex;
			align-items: center;
			justify-content: flex-start;
			.svg-icon{
				width:150px;
				height: 150px;
				margin-right:20px;
			}
			.logoIms{
				width:150px;
				height: 150px;
				border-radius:20px;
				margin-right:20px;
			}
			.right{
				display: flex;
				flex-direction: column;
				justify-content: flex-start;
				.other{
					display: flex;
					justify-content: flex-start;
					align-items: center;	
					font-size: 30px;
					.jobClass{
						display: flex;
						justify-content: flex-start;
						align-items: center;
						margin-right: 10px;
						.icon{
							display: flex;
							justify-content: flex-start;
							align-items: center;
							margin-right: 15px;
							.ims{
								width: 36px;
								height: 36px;
								margin-right: 5px;
							
							}							
						}	
					}				
				}
			}
		}
</style>