<template>
	<div class='content'>
		<van-nav-bar :title="title" left-text="" left-arrow @click-left="onClickLeft" />
		<div class='searchPart'>
			<van-search show-action v-model="keyword" class="isdi" placeholder="请输入搜索关键词"  >
				<template #action>
				<div @click="searchEnterprise" class="iasd">搜索</div>
				</template>
			</van-search>
		</div>
		<div class="gap"></div>
		<div class='vanList'>
    		<van-list v-model:loading="loading" :finished="finished" :immediate-check="true" :finished-text="finsText" @load="onLoad" :offset='400'>		
				<van-cell v-for="(item, index) in enterpriseList" :key="index">
					<div class='item' @click='jumpDetail(item)'>
						<fix-image :defaultSrc="enterpriseLogo"  :src="item.logo" class="logoIms"></fix-image>
						<!-- <EnterpriseLogoSvg class="svg-icon" v-else /> -->
						<div class='right'>
							<div class='name'>
								{{item.enterpriseName}}
							</div>
							<div class='other'>
								<div class='jobClass'>
									<div class='icon'>
										<img :src="jobIcon" class='ims' />
									</div>
									<div class='jobNumber'>招聘岗位:{{item.positionCount || 0}}</div>
								</div>
								<div class='pageView'>
									浏览量:{{item.views || 0}}
								</div>
							</div>
						</div>
					</div>
					
				</van-cell>		
			</van-list>		
		</div>
	</div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import enterpriseLogo from '@/assets/img/enterpriseLogo.png';
import jobIcon from '@/assets/img/jobIcon.png';
import Api from "@/api/enterprise"
const title = ref('校友企业');
const enterpriseName = ref('')
const loading = ref(false);
const finished = ref(false);
const isLastPageb = ref(false);
const total = ref(0);
const pages = ref(0);
const finsText = ref('没有更多了');
const keyword = ref('')
const router = useRouter();
const searchparam = ref({
//   groupsId: '',
	enterpriseName:"",
	pageNum: 1,
	pageSize: 10,
});

const enterpriseList = <any>ref([])

const addViews = async (item:any) =>{
	let id = item.id || ''
	await Api.addEnterpriseViews({id})
}

const jumpDetail = (item:any)=>{
	// console.log(item)
	if(item.contentUrl){
		addViews(item)
		window.location.href = item.contentUrl
	}else{
		router.push({path:"/enterprise-detail",query:{id:item.id}})		
	}
}

const initData =async ()=>{
	//pageEnterprise
  loading.value = true;
  const { data, code, msg } = await Api.pageEnterprise(searchparam.value);
  if (code == 200) {
    pages.value = data.pages;
    total.value = data.total;
    isLastPageb.value = data.isLastPage;
	enterpriseList.value = data.pageNum == 1 ? data.list : [...enterpriseList.value, ...data.list];
	console.log('isLastPageb.value:',isLastPageb.value)
	loading.value = false;
  } else {
    finsText.value = msg;
    loading.value = false;
    finished.value = true;
  }
    if (isLastPageb.value) {
      finished.value = true;
      loading.value = false;
	}  
  console.log('enterpriseList.value',enterpriseList.value)
  console.log('loading:',loading.value,'finished:',finished.value)
}

const showDefault = (item:any) =>{
	let img = new Image()
	img.src = item.logo 
	img.onerror = ()=>{
		// item.showDefault = true
	}	
}


const onLoad = () =>{
	console.log('bottom---')
  if (!isLastPageb.value) {
	searchparam.value.pageNum++;
	finished.value = false;
	initData();
  } else {
    loading.value = false;
    finished.value = true;
  }	
}

const onClickLeft = () => {
	router.go(-1);
};

const searchEnterprise = ()=>{
	searchparam.value.enterpriseName = keyword.value
	searchparam.value.pageNum = 1
	enterpriseList.value = []
	initData()
}
onMounted(() => {
  initData();
});

</script>
<style lang="less" scoped>
.content{
	width:100%;
	position: relative;
    height: 99%;
	overflow: hidden;
	.gap {
		margin-top: 30px;
		width: 100%;
		height: 20px;
		background-color: #f5f5f5;
	}
	.searchPart{
		margin-top: 20px;
		width: 100%;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		.isdi {
		//   position: absolute;
		//   top: 160px;
		//   left: 30px;
		width: 690px;
		height: 80px;
		border-radius: 40px;
		--van-search-background-color: rgba(236, 236, 236, 1);
		--van-search-content-background-color: none;
		--van-search-action-padding: 5px;
		// --van-search-action-text-color: rgba(255, 255, 255, 0.8);
		--van-search-action-text-color:#424243;
		--van-search-left-icon-color: #fff;
		--van-field-input-text-color: #fff;
		--van-active-color: none;

		.iasd {
			background: rgba(255, 255, 255, 0.1);
			padding: 0 30px;
			color:#424243;
			border-radius: 40px;
		}
		:deep(.van-icon-search){
			color:#424243;
		}
		:deep(.van-field__control){
			color:#424243;
		}
		}			
	}
	.vanList{
		width: 100%;
		height: 80%;
		// height: 80vh;
		position: relative;
		margin-top: 15px;
		// overflow-y: scroll;	
		overflow-y: auto;
		.item{
			width: 100%;
			padding: 5px 20px;
			box-sizing: border-box;
			display: flex;
			align-items: center;
			justify-content: flex-start;
			.svg-icon{
				width:150px;
				height: 150px;
				margin-right:20px;
			}
			.logoIms{
				width:150px;
				height: 150px;
				border-radius:20px;
				margin-right:20px;
			}
			.right{
				display: flex;
				flex-direction: column;
				justify-content: flex-start;
				.other{
					display: flex;
					justify-content: flex-start;
					align-items: center;	
					font-size: 30px;
					.jobClass{
						display: flex;
						justify-content: flex-start;
						align-items: center;
						margin-right: 10px;
						.icon{
							display: flex;
							justify-content: flex-start;
							align-items: center;
							margin-right: 15px;
							.ims{
								width: 36px;
								height: 36px;
								margin-right: 5px;
							
							}							
						}	
					}				
				}
				.name{
					font-weight:700;
					white-space:nowrap;
					overflow-x:hidden;
					text-overflow:ellipsis;
					width:500px;
				}
			}
		}
	}

}



</style>