<template>
  <div class="content" :class="isUseSkin2 ? cssHome.contentHome : ''">
    <div class="header-img-wrap" v-if="skin2Config.headerImgWrapFlag">
      <img :class="cssHome.headerImgBgHome" :src="getRealFilePath(bannerData.images?.length ? bannerData.images[0]?.fileAddress : '')" />
      <!-- <img :class="cssHome.headerImgBgLogo"  :src="getRealFilePath(schoolNameImg)" /> -->
    </div>
    <template v-else>
      <nav-bar :title="`${settingStore.schoolName}校友`" left-text="" @click-left="onClickLeft" />
      <header class="header">
        <div class="header-info-wrap">
          <fix-image class="logo" :src="schoolNameImg" />
          <img class="welcome" v-if="schoolCode !== SchoolCode.PeiYingZhongXue" :src="getImg('home/welcome.png')" />
          <img  class="welcome" v-else :src="getImg('home/welcome2.png')" />
        </div>
        <Swiper :list="bannerData.images" :interval="bannerData.interval" />
      </header>
    </template>

    <div class="icon-box" :class="isUseSkin2 ? cssHome.iconBoxHome : ''">
      <div class="icon-wrap">
        <div :class="cenLogoList.length>4?'icon-wrap_item overFour':'icon-wrap_item'" v-for="item in cenLogoList" :key="item.label" @click="jumpNew(item)">
          <img class="icon" v-if="item.imgPath" :src="getImg(item.imgPath)" />
          <component class="icon" v-else :is="item.img" />
          <span class="txt">{{ item.label }}</span>
          <div class="loadingGif" v-if="timeEndFlag && item.label == '校友码'">
            <!-- <img :src="loadingGif"  class='loadingSize'/> -->
            <van-loading type="spinner" color="#111111" class="loadingSize" />
          </div>
        </div>
      </div>
    </div>

    <!-- 通知公告 -->
    <aside :class="cssHome.noticeWrap" v-if="isUseSkin2">
      <img class="notice-icon" :src="getSkin2Img('tongzhigonggao.png')" />
      <div class="notice-line"></div>
      <!-- <span 
        class="notice-txt van-ellipsis"
        v-show="noticeList.length"
        @click="jumpDetail(noticeList.length && noticeList[0].niId)" 
      >
        {{ noticeList.length ? noticeList[0].newsTitle : '' }}
      </span> -->
      <span
        class="notice-txt van-ellipsis"
        v-show="noticeList.length"
        @click="jumpDetail(noticeList.length && noticeList[0].niId)"       
      >
        <van-notice-bar :text=" noticeList.length ? noticeList[0].newsTitle : ''" color="#222222" background="transparent">
        </van-notice-bar>
      </span>      
      <img class="notice-bg" :src="getSkin2Img('tongzhigonggao-bg.png')" />
    </aside>
    <aside class="news-box news-full-screen bottom-border" v-if="skin2Config.schoolHistoryShowFlag">
      <div class="title-wrap">
        <div class="title-wrap_lf">
          <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
          <span class="txt">辉煌校史</span>
        </div>
        <div class="more" @click="toMorePage(`history_${skin2NewsTypeSuffix}`,schoolHistoryShow.length)">
          更多
          <SvgRightArrow/>
        </div>
      </div>
      <div class="news-wrap_swiper" v-if="schoolHistoryShow.length">
        <SwiperNews :list="schoolHistoryShow" @clickItem="jumpDetail"/>
        <img class="swiper-bg" :src="getSkin2Img('schoolhistory.png')" v-if="!XiangxianFlag"/>
      </div>
    </aside>
    <!-- <aside class="news-box news-full-screen bottom-border padd50" v-if="skin2Config.lastesDonateFlag">
      <img :src="zuixinjuanzeng" class="lastesDonateCss" alt="">
    </aside> -->
    <!-- 最新捐赠 -->
    <div class="lastDonate" v-if="skin2Config.lastesDonateFlag">
       <!-- <img :src="zuixinjuanzeng" class="lastesDonateCss" alt=""> -->
       <div class="titleDonate">
          <div class="left">
            <img :src="goldenleave" alt="" class="goldenleave">
            <!-- <div>最新捐赠</div> -->
            <img :src="zxjz" alt="" class="zxjz">
          </div>
          <div class="right"  @click="toWait">
            <div class="more">更多</div>
            <div class="triangle"></div>
          </div>
       </div>
       <van-swipe :loop="false" :width="300" :show-indicators="false">
          <van-swipe-item  class="donateItem" v-for="(item,index) in donatePer"  :key="index">
            <!-- <Avatar class="imgLogo" :src="item.userProfilePicture" /> -->
            <div class="itemContent"  @click="toWait">
              <Avatar class="Logo" :src="item.userProfilePicture" />
              <div class="name">
                {{item.name}}
              </div>
              <div class="cash">
                <img :src="jinbi" alt="" class="jinbi">
                <div class="name mar10">捐赠</div>
                <div class="jine">{{item.donateCash}}</div>
              </div>
              <div class="tiem">
                {{item.time}}
              </div>
            </div>
          </van-swipe-item>
       </van-swipe>
    </div>
    <aside class="news-box news-full-screen bottom-border" v-if="skin2Config.schoolDonateFlag">
        <div class="title-wrap">
          <div class="title-wrap_lf">
            <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
            <span class="txt">爱心捐赠</span>
          </div>
          <div class="more" @click="toWait">
            更多
            <SvgRightArrow />
          </div>
        </div>
      <div class="donateLove">
        <div class="itemCSSBy1">
          <div class="leftByitemCSS1">
            <img :src="xuexiaojijin" alt="" class="imsDonate"  @click="toWait">
          </div>
          <div class="rightByitemCSS1">
            <div class="rightTop">
              <img :src="xiangmujuanzeng" alt="" class="imsDonate"  @click="toWait">
            </div>
            <div class="rightTop dis2">
              <img :src="yuanshijijin" alt="" class="imsDonate"  @click="toWait">
              <img :src="qiyejuanzeng" alt="" class="imsDonate"  @click="toWait">
            </div>
          </div>
        </div>
         <div class="itemCSSBy2">
              <img :src="zhuanjiajijin" alt="" class="imsDonate mar12"  @click="toWait">
              <img :src="juanzengdishui" alt="" class="imsDonate"  @click="toWait">
        </div>       
      </div>
    </aside>      
    <aside class="news-box news-full-screen bottom-border" v-if="skin2Config.activeListFlagFlag">
      <div class="title-wrap">
        <div class="title-wrap_lf">
          <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
          <span class="txt">校友活动</span>
        </div>
        <div class="more" @click="goActiveListPage">
          更多
          <SvgRightArrow />
        </div>
      </div>
      <div class="active-wrap" v-if="activeList.length" :style="{'background-image': `url(${getSkin2Img('xiaoyouhuodong-bg.png')})`}">
        <div class="active-wrap_item" v-for="(item, index) in activeList" :key="index" @click="goJoinActivePage(item)">
          <fix-image class="img" :src="item['oriEventPoster']" width="211" height="160" :defaultSrc="nodata2" :isOriginal="true"/>
          <span class='act-tag' v-if="item.status == '2'">报名中</span>
          <span class='act-tag ing' v-else-if="item.status == '1'">进行中</span>
          <span class='act-tag waiting' v-else-if="item.status == '3'">未开始</span>
          <span class='act-tag end' v-else>已结束</span>
          <section class="active-content">
            <span class="active-title van-ellipsis">{{ item.theme }}</span>
            <span class="active-txt van-ellipsis">主办方：{{ item.organizer }}</span>
            <span class="active-txt van-ellipsis">报名截止时间：{{ item.registrationDeadline ? item.registrationDeadline.substring(0, 10) : '' }}</span>
            <div class="date-wrap">
                <img class="date-icon" :src="getImg('home/time.png')" />
                {{ item['startTime'] ? item.startTime.substring(0, 10): ''}}
                {{ item['endTime'] ? '至 ' + item.endTime.substring(0, 10): ''}}
              </div>
          </section>
        </div>
        <img class="active-bg" v-if="schoolCode == SchoolCode.PeiYingZhongXue" :src="getSkin2Img('active-bg.png')" />
      </div>
    </aside>  
    <aside class="news-box news-full-screen bottom-border" v-if="skin2Config.lastNewsFlag">
      <div class="title-wrap">
        <div class="title-wrap_lf">
          <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
          <span v-if="schoolCode == SchoolCode.XiangXianZhongXue" class="txt">新闻动态</span>
          <span v-else class="txt">最新动态</span>
        </div>
        <div class="more" @click="toMorePage(`latest_news_${skin2NewsTypeSuffix}`,latestNewsList.length)">
          更多
          <SvgRightArrow />
        </div>
      </div>
      <div class="news-wrap row" v-if="latestNewsList.length">
        <div class="news-wrap_item none-background" v-for="(item, index) in latestNewsList" :key="index" @click="jumpDetail(item['niId'])">
          <fix-image class="img" :src="item['coverImage']" width="486" height="284" :defaultSrc="nodata2" :isOriginal="true"/>
          <section class="new-content padding-left-0 padding-right-0">
            <span class="new-title van-ellipsis">{{ item['newsTitle'] }}</span>
            <div class="info-wrap van-ellipsis">
              <div class="date-wrap">
                <img class="date-icon" :src="getImg('home/time.png')" />
                {{ item['updateTime'] ? item.updateTime.substring(0, 10): ''}}
              </div>
            </div>
          </section>
        </div>
        <img class="zuixindongtai-bg" :src="getSkin2Img('zuixindongtai-bg.png')" v-if="!XiangxianFlag"/>
      </div>
    </aside>
    <aside class="news-box news-full-screen bottom-border" v-if="skin2Config.schoolMateShowFlag">
      <!-- 级社风采 -->
      <div class="title-wrap">
        <div class="title-wrap_lf">
          <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
          <span class="txt">{{nameConfig('schoolmate_show')}}</span>
        </div>
        <div class="more" @click="toMorePage(`schoolmate_show_${skin2NewsTypeSuffix}`,schoolMateShow.length)">
          更多
          <SvgRightArrow/>
        </div>
      </div>
      <div class="news-wrap_swiper" v-if="schoolMateShow.length">
        <SwiperNews :list="schoolMateShow" @clickItem="jumpDetail"/>
        <img class="swiper-bg" :src="getSkin2Img('xiaoyoufengcai-bg.png')" v-if="!XiangxianFlag && schoolCode !== SchoolCode.PeiYingZhongXue"/>
        <img class="swiper-bg" :src="getSkin2Img('schoolhistory.png')" v-else-if="schoolCode == SchoolCode.PeiYingZhongXue" />
      </div>
    </aside>
    <aside class="news-box news-full-screen bottom-border" v-if="skin2Config.schoolMateWorkFlag">
      <div class="title-wrap">
        <div class="title-wrap_lf">
          <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
          <span class="txt">培英风采</span>
        </div>
        <div class="more" @click="toMorePage(`schoolmate_work_${skin2NewsTypeSuffix}`,schoolMateWork.length)">
          更多
          <SvgRightArrow/>
        </div>
      </div>
      <div class="news-wrap_swiper" v-if="schoolMateWork.length">
        <SwiperNews :list="schoolMateWork" @clickItem="jumpDetail"/>
        <img class="swiper-bg" :src="getSkin2Img('schoolMateShow.png')" />
      </div>
    </aside>    
    <aside class="news-box news-full-screen bottom-border" v-if="skin2Config.enterpriseFlag">
      <div class="title-wrap">
        <div class="title-wrap_lf">
          <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
          <span class="txt">校友企业</span>
        </div>
        <div class="more" @click="jumpEnterpriseList">
          更多
          <SvgRightArrow />
        </div>
      </div>
      <div class="news-wrap" :class="cssHome.enterpriseListCss" v-if="enterpriseList.length">
        <!-- 校友企业 -->
        <div class="news-wrap_item none-background" v-for="(item, index) in enterpriseList" :key="index" @click="jumpDetailEnterprise(item)">
          <div class="enterpriseCss">
            <fix-image class="img" :src="item['logo']" width="486" height="284" :defaultSrc="nodata2" :isOriginal="true"/>
          </div>
          <section class="new-content padding-left-0 padding-right-0">
            <span class="new-title van-ellipsis">{{ item['enterpriseName'] }}</span>
              <!-- <span class="new-title van-ellipsis">{{ item['logo'] }}</span> -->
            <div class="info-wrap van-ellipsis">
              <!-- <div class="date-wrap">
                <img class="date-icon" :src="getImg('home/time.png')" />
                {{ item['updateTime'] ? item.updateTime.substring(0, 10): ''}}
              </div> -->
            </div>
          </section>
        </div>
        <img class="zuixindongtai-bg" :src="getSkin2Img('zuixindongtai-bg.png')" v-if="cssHome.enterpriseListBg == '1'"/>
      </div>
    </aside>

<!-- 下面是没有第二套皮肤UI和汕大 -->

    <div class="news-box" v-if="!isUseSkin2">
        <div class="title-wrap" v-if="schoolCode !== SchoolCode.ChengDeYiXueYuan">
          <div class="title-wrap_lf">
            <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
            <span class="txt">{{ titleSchool }}</span>
          </div>
          <div class="more" @click="toMorePage('focus_school',testList.length)" :style="{ color: settingStore.themeColor }">更多</div>
        </div>
        <div class="news-wrap"  v-if="schoolCode !== SchoolCode.ChengDeYiXueYuan">
          <div class="news-wrap_item" v-for="(item, index) in testList" :key="index" @click="jumpDetail(item['niId'])">
            <fix-image class="img" :src="item['coverImage']" width="330" height="186" :defaultSrc="nodata2" :isOriginal="true"/>
            <section class="new-content">
              <span class="new-title van-ellipsis">{{ item['newsTitle'] }}</span>
              <div class="info-wrap van-ellipsis">
                <span class="auth van-hairline--right">{{ item['showEditor'] || item['authorDeptName'] }}</span>
                <span class="num"></span><span class="oasd">{{ item['clickCount'] }}</span>
              </div>
            </section>
          </div>
        </div>
        <div v-if="schoolCode == SchoolCode.ChengDeYiXueYuan" >
          <div v-for="(itm,index) in newsArr" :key="index">
            <div class="title-wrap" >
              <div class="title-wrap_lf">
                <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
                <span class="txt">{{ itm.name }}</span>
              </div>
              <div class="more" @click="toMorePage(itm.type,itm.list.length)" :style="{ color: settingStore.themeColor }">更多</div>
            </div>        
            <div class="active-wrap"  >
              <div class="active-wrap_item" v-for="(item, index) in itm.list" :key="index" @click="jumpDetail(item['niId'])">
                <fix-image class="img" :src="item['coverImage']" width="211" height="160" :defaultSrc="nodata2" :isOriginal="true"/>
                <section class="active-content ChengDeNews">
                  <span class="active-title van-ellipsis">{{ item.newsTitle }}</span>
                  <span class="active-txt van-ellipsis mar10">发布人：{{ item.author }}</span>
                  <span class="active-txt van-ellipsis mar10">发布时间：{{ item.updateTime ? item.updateTime.substring(0, 10) : '' }}</span>
                </section>
              </div>
            </div>  
          </div>
        </div>
    </div>
    <div class="news-box" v-if="shandaFlag">
      <div class="title-wrap">
        <div class="title-wrap_lf">
          <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
          <span class="txt">校友工作</span>
        </div>
        <div class="more" @click="toMorePage('schoolmate_work',schoolMateWork.length)" :style="{ color: settingStore.themeColor }">更多</div>
      </div>
      <div class="news-wrap">
        <div class="news-wrap_item" v-for="(item, index) in schoolMateWork" :key="index"
          @click="jumpDetail(item['niId'])">
          <fix-image class="img" :src="item['coverImage']" width="330" height="186" :defaultSrc="nodata2" :isOriginal="true"/>
          <section class="new-content">
            <span class="new-title van-ellipsis">{{ item['newsTitle'] }}</span>
            <div class="info-wrap van-ellipsis">
              <span class="auth van-hairline--right">{{ item['showEditor'] || item['authorDeptName'] }}</span>
              <span class="num"></span><span class="oasd">{{ item['clickCount'] }}</span>
            </div>
          </section>
        </div>
      </div>
    </div>
    <div class="news-box" v-if="shandaFlag">
      <div class="title-wrap">
        <div class="title-wrap_lf">
          <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
          <span class="txt">校友风采</span>
        </div>
        <div class="more" @click="toMorePage('schoolmate_show',schoolMateShow.length)" :style="{ color: settingStore.themeColor }">更多</div>
      </div>
      <div class="news-wrap">
        <div class="news-wrap_item" v-for="(item, index) in schoolMateShow" :key="index"
          @click="jumpDetail(item['niId'])">
          <fix-image class="img" :src="item['coverImage']" width="330" height="186" :defaultSrc="nodata2" :isOriginal="true"/>
          <section class="new-content">
            <span class="new-title van-ellipsis">{{ item['newsTitle'] }}</span>
            <div class="info-wrap van-ellipsis">
              <span class="auth van-hairline--right">{{ item['showEditor'] || item['authorDeptName'] }}</span>
              <span class="num"></span><span class="oasd">{{ item['clickCount'] }}</span>
            </div>
          </section>
        </div>
      </div>
    </div>
    <div class="news-box" v-if="shandaFlag">
      <div class="title-wrap">
        <div class="title-wrap_lf">
          <SvgIconTitle class="icon" :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" />
          <span class="txt">桑浦文苑</span>
        </div>
        <div class="more" @click="toMorePage('countryside_beauty',countryBeauty.length)" :style="{ color: settingStore.themeColor }">更多</div>
      </div>
      <div class="news-wrap">
        <div class="news-wrap_item" v-for="(item, index) in countryBeauty" :key="index" @click="jumpDetail(item['niId'])">
          <fix-image class="img" :src="item['coverImage']" width="330" height="186" :defaultSrc="nodata2" :isOriginal="true" />
          <section class="new-content">
            <span class="new-title van-ellipsis">{{ item['newsTitle'] }}</span>
            <div class="info-wrap van-ellipsis">
              <span class="auth van-hairline--right">{{ item['showEditor'] || item['authorDeptName'] }}</span>
              <span class="num"></span><span class="oasd">{{ item['clickCount'] }}</span>
            </div>
          </section>
        </div>
      </div>
    </div>
    <van-dialog v-model:show="showDialogBir" @closed="nexHoliday" title="" :showConfirmButton="false" :closeOnClickOverlay="true"
      class="diaimsShanda">
      <div class="imgBack">
        <fix-image :src="birthdayImg" alt="" class="imgSize" />
      </div>
      <div   class="birPos">
        <div v-html="birthdayHtml" class="htmlText">
        </div>
      </div>
    </van-dialog>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref,watch } from 'vue';
import { useRouter } from 'vue-router';
import { clickNum, getSchoolNews, getNewsDetail, homeSwipePic, school, detail } from '@/api/home';
import ApiUser from '@/api/user';
import nodata2 from '@/assets/img/nodata2.png';
import { Toast } from 'vant';
import { getSecret } from '@/api/servive';
import {holidayBlessings} from "@/api/holiday"
import { schoolConfig } from '@/hooks/schoolConfig';
import Swiper from './component/swiper.vue';
import SwiperNews from './component/swiper-news.vue';
import { useSettingStore } from '@/store';
import loadingGif from '@/assets/home/loadingGif.gif';
import birthday from '@/assets/img/birthday.jpg';
import SvgRightArrow from '@/assets/img/right-arrow.svg'
import SvgIconTitle from '@/assets/home/icon_title.svg';
import { hex2Rgba } from '@/utils/hex2rgba';
import { Dialog } from 'vant';
import { SchoolCode ,NoSkinConfig} from '@/constants'
import useCache from '@/hooks/useCache'
import { useGoIdentifyPage } from '@/pages/home/useGoIdentifyPage'
import { useIndexCenterMenu } from './useIndexCenterMenu'
import { getSchoolCode, getImg, getUserStatus,isHasButton } from '@/utils'
import { useActive } from './useActive'
import { useNews } from './useNews'
import { getRealFilePath } from '@/utils'
import { usePendingOpenDialog } from "@/pages/home/usePendingOpenDialog";
import { useGoMateCardSDPage } from "@/pages/home/useGoMateCardSDPage";
import ApiEnterprise from "@/api/enterprise"
import { useSkin2 } from './useSkin2'
import { nameHasRouter,nameHasRouterByFn } from '@/hooks/hasRouter';

import Avatar from '@/components/avatar/index.vue';
import juanzengdishui from '@/assets/shenyangyaoke/juanzengdishui.png'
import qiyejuanzeng from '@/assets/shenyangyaoke/qiyejuanzeng.png'
import xiangmujuanzeng from '@/assets/shenyangyaoke/xiangmujuanzeng.png'
import xuexiaojijin from '@/assets/shenyangyaoke/xuexiaojijin.png'
import yuanshijijin from '@/assets/shenyangyaoke/yuanshijijin.png'
import zhuanjiajijin from '@/assets/shenyangyaoke/zhuanjiajijin.png'
import zuixinjuanzeng from '@/assets/shenyangyaoke/zuixinjuanzeng.png'

import goldenleave from '@/assets/shenyangyaoke/goldenleave.png'
import jinbi from '@/assets/shenyangyaoke/jinbi.png'
import zxjz from '@/assets/shenyangyaoke/zxjz.png'

const { showPendingOpenDialog } = usePendingOpenDialog()
const { handleGoMateCardSDPage } = useGoMateCardSDPage()
const schoolCode = getSchoolCode()
const { isUseSkin2, getSkin2Img, skin2NewsTypeSuffix,cssHome,skin2Config } = useSkin2()

const { goIdentifyPage ,getIdentifyPath} = useGoIdentifyPage()
const { activeList, getActiveList, goJoinActivePage, goActiveListPage, } = useActive()
/**通知公告 */
const noticeList = ref<NewsData[]>([])
const latestNewsList = ref<NewsData[]>([])
const XiangxianFlag = ref(false)
const { initList, initListAndCache } = useNews()

const enterpriseList = <any>ref([])

const settingStore = useSettingStore();
const router = useRouter();
const isAuthorized = getUserStatus() == '00' || getUserStatus() == '06' || settingStore.isManagerMode
const showDialogBir = ref(false);
const holidayNum = ref(0)
const { cenLogoList } = useIndexCenterMenu()
const fesFlag = ref('1')//1--use,2--baned


const donatePer = ref<any[]>([])
const fakeDonateList =ref<any[]>([
  {
    name:"test1",
    userProfilePicture:"",
    donateCash:"1万元",
    time:"2026-06-01"
  },
  {
    name:"test2",
    userProfilePicture:"",
    donateCash:"2万元",
    time:"2026-06-01"
  },
  {
    name:"test3",
    userProfilePicture:"",
    donateCash:"3万元",
    time:"2026-06-01"
  },
  {
    name:"test4",
    userProfilePicture:"",
    donateCash:"4万元",
    time:"2026-06-01"
  },
])

const testList = ref<NewsData[]>([]);
const schoolMateWork = ref<NewsData[]>([]);
const countryBeauty = ref<any>([]);
const schoolMateShow = ref<NewsData[]>([]);
const schoolHistoryShow = ref<NewsData[]>([]);
const shandaFlag = ref(false);
const timeOutF = ref();
const birthdayTips = ref('')
const birthdayHtml = ref('')
const birthdayImg = ref('')
const timeEndFlag = ref(false);
let bannerData = ref<Partial<ImageList>>({
  images: [],
  interval: '0',
});

const newsArr = <any>ref([])

const fesData = <any>ref([])
// const fesHtml = <any>ref([])

let schoolNameImg = ref<string>('');

const dparams = reactive<detail>({
  niId: '',
});
let detailData = <any>reactive({});
const onClickLeft = () => {
  router.back();
};
const titleSchool = ref('');

const jumpRes = ()=>{
  let userStatus = getUserStatus()
  if(userStatus == '03'){
    router.push({path:'/submited'})
    
  }else{
    goIdentifyPage().then((res)=>{
      if(res)router.push({path:getIdentifyPath()})
    })  
  }

}

const jumpNew = async (item: any) => {
  let val = item.jump
  console.log('jumpNew',val)  
  /**是否满足可使用权限 */
  let userStatus = getUserStatus()
  // let isAuthorized = userStatus == '00' || userStatus == '06' || settingStore.isManagerMode
  let schoolCode = getSchoolCode() as any;
  if ([SchoolCode.GuangWenYi, SchoolCode.WuLuMuQiZhiYeDaXue].includes(schoolCode)) {
    if ( userStatus == '04' && val == 'second') {
      router.push({name: val})
      return
    }
    if (['backSchool-ln'].includes(val)) {
      showPendingOpenDialog()
      return
    }
  }
  if (val == 'mateCard') {
    console.log('val',val)
    // if (shandaFlag.value || [SchoolCode.GuangWenYi,SchoolCode.WuLuMuQiZhiYeDaXue,SchoolCode.BaoTouZhiYeJiShu,SchoolCode.PeiYingZhongXue].includes(schoolCode)) {
    //   isAuthorized ?  handleGoMateCardSDPage() : jumpRes()
    //   return;
    // }
    if(schoolCode == SchoolCode.ShenYangShiFan){
      //myPerInfoCard
      //  router.push({ path: '/myPerInfoCard' })
      if(isAuthorized){
        // router.push({ path: '/mateCard' })
         router.push({ path: '/myPerInfoCard' })
         return
      }else{
        jumpRes()
      }
    }
    if( schoolCode == SchoolCode.ChengDuYiXueYuan){
      // router.push({ path: '/mateCard' })
      if(isAuthorized){
        router.push({ path: '/mateCard' })
      }else{
        jumpRes()
      }
      
    }
    if (userStatus == '00' || userStatus == '06' || settingStore.isManagerMode) {
      router.push({ path: '/mateCardAP' })
      // return
      // window.location.href =
      //   'https://webapp.xiaofubao.com/card/home_cslg.shtml?platform=CSLG_EDU&schoolCode=10333&authAppid=45810333';
    } else {
      jumpRes()
    }
  } else if (val == 'donate') {

    if (userStatus == '00' || userStatus == '06') {
      if (shandaFlag.value) {
        Toast({ message: '该功能暂时没开放' });
      } else {
        // let { data } = await getSecret({});
        // window.location.href = import.meta.env.VITE_APP_DONATE_URL + '?' + data;
        window.location.href = '../juanzeng/index.html#id=dp6j74&p=首页&sc=1&c=1'
        return
      }
    } 
  } else if (val == 'backSchool') {
    if (schoolCode === SchoolCode.ChangShu || schoolCode === SchoolCode.ShenYangShiFan) {
      showPendingOpenDialog()
    } else {
      isAuthorized ? router.push({ path: '/' + val }) : jumpRes()
    }
  }else if(val == 'reserveBackSchoolDate'){
     isAuthorized ? router.push({ path: '/' + val }) : jumpRes()
  } else if (val == 'activeList') {
    if (schoolCode === SchoolCode.LiaoShiDa) {
      window.location.href = 'https://mp.weixin.qq.com/mp/homepage?__biz=MzAwNTUwNDY1OQ==&hid=2&sn=d496646f1b461936c6dc43c5509d449b&scene=1&devicetype=iOS18.1.1&version=18003531&lang=zh_CN&nettype=3G+&ascene=7&session_us=gh_a555bb03e8c8&fontScale=100'
    }else if(schoolCode === SchoolCode.ShanDa){
      if (isAuthorized) {
        router.push({ path: '/' + val });
      } else {
        jumpRes()
      }
    }else {
      router.push({ path: '/' + val });
    }
  }else if(val == 'matePictures'){
    if(schoolCode === SchoolCode.ShanDa){
      router.push({ path: '/' + val });
    }else{
      if (isAuthorized) {
        router.push({ path: '/' + val });
      } else {
        jumpRes()
      }
    }
  }else if(val == 'serviceNews' && schoolCode === SchoolCode.ShanDa){
    router.push({ path: '/' + val,query:{type:'schoolmate_journal'} });
  }
  else if(val == 'type'){
    router.push({ name: val });
  }
  else if(val == 'news'){
    if(!!item?.params){
      router.push({ name: val,query:{type:item.params} });
    }else{
       router.push({ name: val });
    }
  }else if(val == 'groupBackSchool' && schoolCode === SchoolCode.PeiYingZhongXue){
      showPendingOpenDialog()
      return
  }
  else {
    if (isAuthorized) {
      console.log('44444')
      router.push({ path: '/' + val });
    } else {
      console.log('55555',val,item.path,)
      // jumpRes()
      nameHasRouterByFn(router,val,'/'+val,jumpRes)
    }
  }
};

const nameConfig = (val:string) =>{
  if(val === 'schoolmate_show'){
    if(schoolCode == SchoolCode.PeiYingZhongXue){
      return '级社风采'
    }
    else if(schoolCode == SchoolCode.ShenYangYaoKeDaXue){
      return '期队风采'
    }else{
      return '校友风采'
    }
  }
}

const jumpEnterpriseList = () =>{
  if(enterpriseList.value.length > 0){
    router.push({ path: '/schoolmate-enterprise', });
  }else{
    Toast({ message: '十分抱歉，暂无相关数据' });
  }
}

const toMorePage = (type: string,len:number) => {
  if(len > 0){
    router.push({ path: '/news', query: { type } });
  }else{
    Toast({ message: '十分抱歉，暂无相关数据' });
  }
  
};

const toWait = ()=>{
  Toast({ message: '该功能暂时没开放' });
  return
}

const jumpDetail = async (val: any) => {
  dparams.niId = val;
  clickNum(dparams);
  await getData({ niId: val });
  if (detailData.isUrl == 1) {
    window.location.href = detailData.contentUrl;
  } else {
    router.push({ name: 'newsDetail', query: detailData });
  }
};

const jumpDetailEnterprise = (item:any)=>{
	// console.log(item)
	if(item.contentUrl){
		window.location.href = item.contentUrl
	}else{
	  router.push({path:"/enterprise-detail",query:{id:item.id}})    
  }

}

const getData = async (id: detail) => {
  const { code, data, msg } = await getNewsDetail(id);
  if (code == 200) {
    detailData = { ...data };
  } else {
    Toast.fail(msg);
  }
};

const initShanda = async () => {
  shandaFlag.value = true;
  initListAndCache({
    newsType: 'focus_school',
    successCallback(data){
      testList.value = data
    }
  })
  initListAndCache({
    newsType: 'countryside_beauty',
    successCallback(data){
      countryBeauty.value = data
    }
  })
  initListAndCache({
    newsType: 'schoolmate_work',
    successCallback(data){
      schoolMateWork.value = data
    }
  })
  initListAndCache({
    newsType: 'schoolmate_show',
    successCallback(data){
      schoolMateShow.value = data
    }
  })
};

async function initSkin2Data() {
  initListAndCache({
    newsType: 'notice',
    pageSize: 1,
    successCallback(data){
      noticeList.value = data
    }
  })
  if(schoolCode ==SchoolCode.XiangXianZhongXue){
    if(isAuthorized){
      isHasButton('ACTIVITIES_PAGE') && getActiveList({status:""})
    }
  }else{
    isHasButton('ACTIVITIES_PAGE') && getActiveList({status:""})
  }
  

  initListAndCache({
    newsType: `latest_news_${skin2NewsTypeSuffix}`,
    pageSize: 4,
    successCallback(data){
      latestNewsList.value = data
    }
  })

  initListAndCache({
    newsType: `schoolmate_show_${skin2NewsTypeSuffix}`,
    pageSize: 4,
    successCallback(data){
      schoolMateShow.value = data
    }
  })
  if(schoolCode == SchoolCode.PeiYingZhongXue){
    initListAndCache({//培英风采
      newsType: `schoolmate_work_${skin2NewsTypeSuffix}`,
      successCallback(data){
        schoolMateWork.value = data
      }
    })    
  }
  initListAndCache({
    newsType: `history_${skin2NewsTypeSuffix}`,
    pageSize: 4,
    successCallback(data){
      schoolHistoryShow.value = data
    }
  })
  isHasButton('AppSchoolmateEnterprise_Page') && initEnterprise()
}
 
const initEnterprise =async () =>{
  let params = {
    enterpriseName:"",
    pageNum: 1,
    pageSize: 4,    
  }
  const { data, code, msg } = await ApiEnterprise.pageEnterprise(params);
  if(code == 200){
    enterpriseList.value = data.list
  }
}

const initDCWJ = async (ima: any) => {
  // let b = await dcwjUrl();
  // let { data } = await ApiUser.uentry(b as string);
  for (let i in ima.images) {
    if (ima.images[i].imageName == '调查问卷') {
      // ima.images[i].jumpUrl = data.data.url;
      const { data, code, msg } = await getSchoolNews({
        newsType: 'question',
        pageNum: 1,
        pageSize: 2,
      });
      let a = data.list[0].contentUrl.split('?channelCode=');
      dcwjUrlInit(a[1], i);
    }
  }
  // console.log(ima)
};
interface titleConfig {
  title: string;
}



const dcwjUrlInit = async (val: string, i: any) => {
  let { data } = await ApiUser.uentry(val);
  // jumpUrl = data.data.url;
  bannerData.value.images![i].jumpUrl = data.data.url;
  // console.log(bannerData.value)
  // window.location.href = data.data.url
};
const setLoadingTime = () => {
  let time = new Date().getTime();
  let stTime = 0;
  let userStatus = getUserStatus();
  if (sessionStorage.getItem('setTime')) {
    console.log('setTime-if');
    stTime = JSON.parse(sessionStorage.getItem('setTime') as string);
    let difference = time - stTime;
    console.log(time); //1,7001,15942011
    if (difference > 0) {
      if (difference > 120000) {
        //超时
        console.log('超时');
        timeEndFlag.value = false;
      } else if (difference > 0 && userStatus == '00') {
        if (difference < 60000) {
          difference = 120000;
        }
        console.log('setLoadingTime---initTimeOut');
        timeEndFlag.value = true;
        timeOutF.value = setTimeout(() => {
          console.log('setLoadingTime----setTimeout');
          console.log(Date.now());
          timeEndFlag.value = false;
          sessionStorage.removeItem('setTime');
          clearTimeout(timeOutF.value);
        }, difference);
      }
    } else {
      if (timeOutF.value) {
        clearTimeout(timeOutF.value);
      }
      sessionStorage.removeItem('setTime');
      timeEndFlag.value = false;
    }
  }
};

  function decode(content: string) {
    let temp = content
    for (let i = 0; i < 4; i++) {
      temp = window.atob(temp)
    }
    return decodeURIComponent(temp)
  }

const showBirthday = async () => {
    await getBirHoliday()
};

const getBirHoliday =async ()=>{
  console.log('a1')
  let birFlag = sessionStorage.getItem('birthdayReminder');
  let {code,data,msg} = await holidayBlessings({})
  if(code == 200){
     for(let i in data){
      if(data[i].imageType == '1'){
        let content = data[i].content
        !!content && (birthdayHtml.value = decode(data[i].content))
        birthdayImg.value = data[i].fileAddress
      }else{
        fesData.value.push(data[i])
      }   
     }
    if (birFlag == '1' ) {
          showDialogBir.value = true;
          sessionStorage.setItem('birthdayReminder', 'pass');
    }else{
          if(!!sessionStorage.getItem('fesFlag')){
            fesFlag.value = sessionStorage.getItem('fesFlag') as string
          }  
          if(fesFlag.value === '1'){
             getFesHoliday()
          }
    }        
  }
}


const getFesHoliday = async ()=>{
  if(fesData.value.length > 0 && holidayNum.value != fesData.value.length){
    let content = fesData.value[holidayNum.value].content
    !!content && (birthdayHtml.value = decode(fesData.value[holidayNum.value].content))
    birthdayImg.value = fesData.value[holidayNum.value].fileAddress    
    holidayNum.value++
    showDialogBir.value = true
  }else{
    showDialogBir.value = false
    fesFlag.value = "2"
    sessionStorage.setItem('fesFlag',  fesFlag.value);
  }
}

const nexHoliday = async ()=>{
  getFesHoliday()
}

onMounted(async () => {
  // timeEndFlag.value = true;
  XiangxianFlag.value = schoolCode == SchoolCode.XiangXianZhongXue
  //包头和象贤中学
  if(XiangxianFlag.value || schoolCode == SchoolCode.BaoTouZhiYeJiShu){
    useCache({
      key: 'ECARD_BACKGROUND',
      service: homeSwipePic,
      params: {
        imageType: 'ECARD_BACKGROUND'
      },
      callback: ({code, data, msg}: any) => {
      
      }
    })   
  }
  if(isAuthorized && schoolCode ==SchoolCode.ShanDa){
    showBirthday();
  }
  
  console.log('!!!isUseSkin2!!!',isUseSkin2)
  if (schoolCode == SchoolCode.ShanDa ||schoolCode == SchoolCode.HeBeiShiFan) {
    initShanda();
  } else if (isUseSkin2) {
    initSkin2Data()
  } else {
    console.log("NoSkinConfig--NEWS!!",!!NoSkinConfig[String(schoolCode)])
    let schoolNOSkin = !!NoSkinConfig[String(schoolCode)]
    if(schoolNOSkin){
      // newsArr.value
      let configArr = NoSkinConfig[String(schoolCode)]
      for(let i in configArr){
          initListAndCache({
            newsType: configArr[i].type,
            pageSize: 4,
            successCallback(data){
              // newsArr.value = data
              configArr[i]['list'] = data
            }
          })
      }
       newsArr.value = configArr
       console.log('!!newsArr',newsArr.value)
    }else{
      initListAndCache({
        newsType: 'focus_school',
        pageSize: 4,
        successCallback(data){
          testList.value = data
        }
      })
    }

  }

  let homeConfig = schoolConfig('home') as unknown as titleConfig;
  titleSchool.value = homeConfig.title as string;

  useCache({
    key: 'BANNER',
    service: homeSwipePic,
    params: {
      imageType: 'BANNER'
    },
    callback: ({ code, data, msg }: any) => {
      if (code == 200) {
        bannerData.value = data
        initDCWJ(bannerData.value)
      }
    }
  })
  useCache({
    key: 'HOME_HEADER_ICON',
    service: homeSwipePic,
    params: {
      imageType: 'HOME_HEADER_ICON'
    },
    callback: ({ code, data, msg }: any) => {
      if (code == 200) {
        schoolNameImg.value = data?.images?.[0]?.fileAddress
      }
    }
  })

});

</script>
<style lang="less" scoped>
  .hide{
    display: none !important
    ;
  }
.padding-left-0{
  padding-left: 0!important;
}
.padding-right-0{
  padding-right: 0!important;
}
.padding-bottom-0{
  padding-bottom: 0!important;
}
.header-img-wrap {
  position: relative;

  .header-img-bg{
    width: 750px;
    height: 550px;
  }
  .header-img-Xiangxian{
    width: 750px;
    height: 894px;    
  }
  .header-img-logo{
    width: 496px;
    height: 60px;
    position: absolute;
    top: 150px;
    left: 50%;
    transform: translateX(-50%);
  }
  .header-img-logo-Xiangxian{
    display: none;
  }
}

/deep/.diaims {
  // height: 827px;
  width:516px;
  // width: 100%;
  // height: auto;
  background: url('@/assets/img/birthday.jpg') no-repeat;
  background-size: 100% auto;

  // position: relative;
  .birPos {
    position: absolute;
    top: 25%;
    left: 10%;
    width: 80%;

    .hello {
      font-size: 28px;
      font-family: PingFangSC, PingFang SC;
      font-weight: 900;
      color: #653020;
      line-height: 28px;
      margin-bottom: 20px;
    }

    .birCon {
      font-size: 28px;
      color: #653020;
      font-family: PingFangSC, PingFang SC;
      line-height: 49px;
    }
  }
}

/deep/.diaimsShanda {
  // height: 827px;
  width:516px;
  height: auto;
  background: transparent;

  // min-height: 400px;
  .birPos {
    position: absolute;
    top: 0%;
    left: 0%;
    width: 100%;
    height: 100%;
    .htmlText{
    box-sizing: border-box;
    padding: 0 40px;      
    width: 100%;
    // height: 100%;
    text-align: center;
      font-family: PingFangSC, PingFang SC;
       font-size: 28px;
      p{
        margin: 0px;
      }
    }
  }
  .imgBack{
    // position: absolute;
    // left: 0px;
    // top:0px;
    // min-height: 800px;
    // z-index:2004;
    // float:left;
    // margin:0 auto;
    // width:100%;
    // height: 100%;
    .imgSize{
      width: 100%;
      height: 100%;
    }
  }  
  .van-dialog__content{
    height: 100%;
  }
}


.content {
  font-size: 0px;
  width: 100%;
  min-height: 100%;
  background-color: rgba(0, 0, 0, 0.04);
  &.white{
    background: #fff;
  }
}

.header {
  height: 440px;
  background: linear-gradient(180deg, var(--theme-color) 0%, rgba(255, 255, 255, 0) 100%);

  .header-info-wrap {
    display: flex;
    flex-direction: rwo;
    justify-content: space-between;
    align-items: center;
  }

  .logo {
    width: 314px;
    height: 70px;
    margin: 17px 50px 17px;
    object-fit: contain;
  }

  .welcome {
    width: 247px;
    height: 94px;
  }
}

.icon-box{
  padding: 30px 35px 0;
  .icon-wrap {
    padding: 32px 0;
    box-sizing: border-box;
    background: #fff;
    display: flex;
    flex-direction: row;
    border-radius: 12px;
    justify-content: space-around;
    flex-wrap: wrap;
    .icon-wrap_item {
      position: relative;
      flex: 0 0 25%;
      display: flex;
      flex-direction: column;
      align-items: center;

      .loadingGif {
        width: 170px;
        height: 110px;
        position: absolute;

        .loadingSize {
          width: 100%;
          height: 100%;
          position: relative;

          /deep/.van-loading__spinner {
            // margin: 0 auto;
            // left: 30%;
            // top: 18%;
            position: absolute;
            left: 30%;
            top: 15%;
            // transform: translate(-50%, -50%);
          }
        }

        // background: rgba(0,0,0,0.7);
        cursor: not-allowed;
        background: #fff;
        opacity: 0.5;
      }

      .icon {
        width: 64px;
        height: 64px;
        fill: #000;

        :deep(path:last-child) {
          fill: var(--theme-color);
        }

        &.change-first {
          :deep(path:first-child) {
            fill: var(--theme-color);
          }

          :deep(path:last-child) {
            fill: #000;
          }
        }
      }

      .txt {
        margin-top: 10px;
        font-size: 28px;
        color: #666;
      }

      &.disabled {
        .txt {
          color: #c7c7c7;
        }
      }
    }
    .overFour{
      flex: 0 0 30%;
      margin-top:10px;
    }
  }
  &.row {
    padding-top: 8px;
    .icon-wrap{
      width: 100%;
      flex-wrap: nowrap;
      // justify-content: flex-start;
      justify-content: space-around;
      overflow-x: auto;
      // &::before{
      //   content: '';
      //   display: block;
      //   width: 35px;
      //   height: 35px;
      //   flex: 0 0 auto;
      // }
      .icon-wrap_item {
        flex: 0 0 auto;
        width: 150px;
        .icon{
          width: 80px;
          height: 80px;
        }
      }
    }
  }
  &.flex3By2Line{
    padding-top: 8px;
    box-sizing: border-box;
    .icon-wrap{
      width: 100%;
      flex-wrap: wrap;
      justify-content: flex-start;
      // justify-content: space-around;
      // overflow-x: auto;
      // &::before{
      //   content: '';
      //   display: block;
      //   width: 35px;
      //   height: 35px;
      //   flex: 0 0 auto;
      // }
      .icon-wrap_item {
        flex: 0 0 auto;
        // width: 250px;
        width: 30vw;
        margin-top:10px;
        .icon{
          width: 80px;
          height: 80px;
        }
      }
    }    
  }
}


.notice-wrap{
  margin: 10px 0 0 30px;
  width: 690px;
  height: 100px;
  padding: 0 20px;
  box-sizing: border-box;
  box-shadow: 1px 2px 24px 0px rgba(0,0,0,0.1);
  border-radius: 16px;
  display: flex;
  flex-direction: row;
  align-items: center;
  position: relative;
  z-index: 1;
  .notice-icon{
    width: 64px;
    height: 63px;
  }
  .notice-line{
    margin: 0 20px;
    width: 1px;
    height: 32px;
    border: 2px solid var(--theme-color-0-6);
  }
  .notice-txt{
    flex:1;
    font-size: 28px;
    color: #222222;
  }
  .notice-bg{
    width: 204px;
    height: 100px;
    position: absolute;
    top: 0;
    right: 0;
    z-index: -1;
  }
}

.news-box {
  padding: 30px 30px 0;
    &.bottom-border{
    border-bottom: 20px solid #F5F6F6;;
  }

  .title-wrap {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;

    .title-wrap_lf {
      display: flex;
      flex-direction: row;
      align-items: center;

      .icon {
        width: 40px;
        height: 40px;

        :deep(path:first-child) {
          fill: var(--sub-color);
        }
      }

      .txt {
        margin-left: 12px;
        font-size: 36px;
        font-weight: 500;
        color: #222222;
      }
    }

    .more {
      display: flex;
      flex-direction: row;
      align-items: center;
      font-size: 24px;
      color: #999;
      .icon{
        width: 24px;
        height: 24px;
      }
    }
  }

  .news-wrap {
    margin-top: 27px;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    z-index: 1;
    position: relative;

    .news-wrap_item {
      flex: 0 0 330px;
      margin-bottom: 20px;
      display: flex;
      flex-direction: column;
      border-radius: 12px;
      background: #fff;
      overflow: hidden;
      &.none-background{
        background: none;
      }

      &:nth-child(2n-1) {
        margin-right: 30px;
      }

      .img {
        width: 330px;
        // height: 186px;
        height: 198px;
      }

      .new-content {
        padding: 20px;
        font-size: 28px;
        color: #333;

        .new-title {
          display: block;
          width: 330px;
        }

        .info-wrap {
          margin-top: 19px;
          font-size: 24px;
          color: #999;

          .auth {
            padding-right: 20px;
            --van-border-color: #999;
          }

          .num {
            padding-left: 20px;
          }
        }
      }
    }

    &.row {
      flex-wrap: nowrap;
      overflow-x: auto;
      .news-wrap_item {
        flex: 0 0 486px;
        margin-right: 24px;
        &:nth-child(2n-1) {
          margin-right: 24px;
        }
        .info-wrap{
          margin-top: 10px;
        }
        .img{
          width: 486px;
          // height: 284px;
          height: 291.6px;
        }
        .date-wrap{
          display: flex;
          flex-direction: row;
          align-items: center;
          font-size: 24px;
          color: #999999;
          .date-icon{
            width: 24px;
            height: 24px;
            margin-right: 6px;
          }
        }
      }
    }
    &.rowBySmall{
      flex-wrap: nowrap;
      overflow-x: auto;
      .news-wrap_item {
        flex: 0 0 120px;
        margin-right: 24px;
        &:nth-child(2n-1) {
          margin-right: 24px;
        }
        .info-wrap{
          margin-top: 10px;
        }
        .new-title{
          font-size: 20px;
          color:#222222;
          white-space:nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          width: 120px;
          
        }
        .enterpriseCss{
          width: 120px;
          height: 70px;
          background-color: #fff;
          box-shadow: 0px 0 16px 0px rgba(0,0,0,0.16);
          border-radius: 6px;
          display: flex;
          justify-content: center;
          align-items: center;
        }
        .img{
          width: 58px;
          // height: 284px;
          height: 58px;
        }
        .date-wrap{
          display: flex;
          flex-direction: row;
          align-items: center;
          font-size: 24px;
          color: #999999;
          .date-icon{
            width: 24px;
            height: 24px;
            margin-right: 6px;
          }
        }
      }      
    }


  }
  .zuixindongtai-bg {
    position: absolute;
    bottom: 0;
    left: 0;
    z-index: -1;
    width: 750px;
    height: 434px;
  }
  .active-wrap{
    margin: 32px 0 0;
    padding: 0 30px;
    position: relative;
    z-index: 1;
    background-repeat: no-repeat;
    background-position: 100% 100%;
    background-size: 100% 100%;
    background-attachment: border-box;
    .active-wrap_item{
      padding-bottom: 30px;
      display: flex;
      flex-direction: row;
      position: relative;
      .img{
        width: 211px;
        height: 160px;
        border-radius: 8px;       
      }
        .act-tag {
          display: inline-block;
          position: absolute;
          top: 0;
          left: 0;
          width: 211px;
          line-height: 46px;
          font-size: 24px;
          color: #fff;
          text-align: center;
          background: #fe6f5d8f;
        }   
        .ing {
          background: #21ca0e97;
        }
        .end {
          background: #888b948d;
          color: #fff;
        }
        .waiting {
          background: #e6a23c;
          // color: #fff;
        }             
      .active-content{
        margin-left: 30px;
        display: flex;
        flex-direction: column;
        justify-content: space-around;
        .active-title{
          font-size: 28px;
          color: #222222;
          width:400px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        .active-txt{
          font-size: 24px;
          color: #979797;
          width:400px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;          
        }
        .date-wrap{
          display: flex;
          flex-direction: row;
          align-items: center;
          font-size: 24px;
          color: #999999;
          .date-icon{
            width: 24px;
            height: 24px;
            margin-right: 6px;
          }
        }
      }
      .ChengDeNews{
        justify-content: flex-start;
        .mar10{
          margin-top: 10px;
        }
      }
    }
    .active-bg{
      position: absolute;
      width: 750px;
      height: 145px;
      bottom: 0px;
    }
  }
  &.news-full-screen {
    padding-left: 0;
    padding-right: 0;
    .title-wrap{
      padding: 0 30px;
    }
    .news-wrap {
      padding: 0 30px;
    }
  }
  .news-wrap_swiper{
    position: relative;
    margin: 32px 0 0;
    height: 340px;
    z-index: 1;
    
    .swiper-bg{
      position: absolute;
      bottom: 0;
      left: 0;
      width: 750px;
      height: 307px;
      z-index: -1;
    }
  }
}
.lastDonate{
  width: 100vw;
  height: 187px;
  margin-top: 50px;
  position: relative;
  background: url("@/assets/shenyangyaoke/zuixinjuanzeng.png") no-repeat;
  background-size:100% 100%;
  padding-top:24px;
  box-sizing: border-box;
  .titleDonate{
    width: 100%;
    height: 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    padding: 0 24px;
    box-sizing: border-box;
    .left{
      display: flex;
      align-items: center;
      .goldenleave{
        width: 40px;
        height: 40px;
        margin-right: 13px;
      }
      .zxjz{
        width: 150px;
        height: 32px;
      }
    }
    .right{
      display: flex;
      align-items: center;
      .more{
        font-size: 24px;
        color:#ffffff;
        margin-right: 5px;
        font-weight: 500;
      }
      .triangle{
        width: 0;
        height: 0;
        border-left:14px solid white;
        border-top: 14px solid transparent;
        border-bottom: 14px solid transparent;
      }      
    }
  }
  .donateItem{
    display: flex;
    justify-content: center;
    align-items:center ;
    min-width: 531px;
    .itemContent{
      width: 531px;
      height: 72px;
      margin: 0 20px;
      background:rgba(255,255,255,0.75);
      border-radius: 40px;
      border:1px solid #ffffff;
      display: flex;
      align-items: center;
      padding: 0 6px;
      box-sizing: border-box;
      .jinbi{
        width: 36px;
        height: 36px;
      }
      .Logo{
        width: 60px;
        height: 60px;
        margin-right: 14px;
      }
      .name{
        font-size: 26px;
        color:#222222;
        font-weight: 500;
        margin-right: 20px;
      }

      .cash{
        display: flex;
        align-items: center;
        margin-right: 10px;
        .jinbi{
          width: 36px;
          height: 36px;
          margin-right: 10px;
        }
        .mar10{
          margin-right: 10px;
        }
        .jine{
          color:#ff0500;
          font-size: 26px;
        }
      }
      .tiem{
        color:#999999;
        font-size: 26px;
      }
    }
  }
}
.donateLove{
  width: 100%;
  padding: 0 30px;
  box-sizing: border-box;
  margin-top: 30px;
  // display: flex;
  // flex-direction: column;
  .itemCSSBy1{
    width: 100%;
    display: flex;
    align-items: center;
    margin-bottom: 12px;
    .leftByitemCSS1{
      width: 240px;
      height: 305px;
      margin-right: 12px;
    }
    .rightByitemCSS1{
      height: 306px;
      flex:1;
      display: flex;
      flex-direction: column;
      align-items: center;
      .rightTop{
        width: 100%;
        height: 147px;
      }
      .dis2{
        margin-top: 12px;
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
    }
  }
  .itemCSSBy2{
    margin-bottom: 12px;
    width: 100%;
    height: 147px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .mar12{
    margin-right: 12px;
  }
  .imsDonate2{
    // width: 339px;
    height: 146px;
  }
  .imsDonate{
    width: 100%;
    height: 100%;
  }
}
.lastesDonateCss{
  // margin: 0 30px;
  position: absolute;
  left: 50%;
  top:50%;
  transform: translate(-50%,-50%);
  // width: 100%;
  height: 187px;
}
.padd50{
  padding-top:55px;
}
.donateItem{
  width: 100%;
  display: flex;
}
</style>
