<template>
  <div class="content">
    <nav-bar title="校友" left-text="" />
    <div class="banner">
      <fix-image :src="bannerData" :defaultSrc="alumniBanner" class="imgs" width="750" height="350" />
      <van-search show-action class="isdi" placeholder="请输入搜索关键词" readonly @click="goSearchPage">
        <template #action>
          <div @click="goSearchPage" class="iasd">搜索</div>
        </template>
      </van-search>
      <van-tabs v-model:active="active" class="cenTab" @click-tab="changeTabs" v-if="!isGuangWenYi()">
        <van-tab title="全部"></van-tab>
        <van-tab title="推荐" ></van-tab>
        <van-tab title="同级"></van-tab>
        <van-tab title="同城"></van-tab>
        <!-- <van-tab title="同行业" v-if="isGuangWenYi()"></van-tab> -->
      </van-tabs>
      <van-tabs v-model:active="active" class="cenTab" @click-tab="changeTabs" v-if="isGuangWenYi()">
        <van-tab title="全部"></van-tab>
        <van-tab title="同城"></van-tab>
        <van-tab title="同级"></van-tab>
        <van-tab title="同专业"></van-tab>
        <van-tab title="同行业"></van-tab>  
      </van-tabs>      
      <!-- <van-tabs v-model:active="active" class="cenTab" @click-tab="changeTabs" v-if="isChangshu()">
        <van-tab title="全部"></van-tab>
        <van-tab title="同院"></van-tab>     
        <van-tab title="同班"></van-tab>
        <van-tab title="同城"></van-tab>   
      </van-tabs> -->
    </div>
    <div class="alumniList">
      <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad" :offset="100">
        <SchoolMateList :list="dataList" @jump="jumpAlu">
          <template #default="{ item }">
            <div class="schoolmate-icon-wrap city-wrap" v-if="active == 1 && !isGuangWenYi()">
              <img class="icon-recommend" :src="getImg('img/icon-recommend.png')" />
            </div>
            <div class="schoolmate-icon-wrap city-wrap" v-if="active == 3 && !isGuangWenYi()">
              <img class="icon-weizhi" :src="getImg('img/contact-addr@2x.png')" />
              <span>{{ showLocation(item) }}</span>
            </div>
          </template>
        </SchoolMateList>
      </van-list>
    </div>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import Api, { mate, cardParam } from '@/api/schoolmate';
import ApiByGroup from '@/api/group';
import alumniBanner from '@/assets/img/alumniBanner.png';
import SchoolMateList from '@/components/schoolmate-list/index.vue';
import { Toast } from 'vant';
import { useSettingStore } from '@/store';
import { Dialog } from "vant"
import { isChangshu,isShanDa,isGuangWenYi } from '@/utils/customizedType';
import { SchoolCode } from '@/constants';
import useCache from '@/hooks/useCache'
import { homeSwipePic } from '@/api/home'
import { useGoIdentifyPage } from '@/pages/home/useGoIdentifyPage'
import { getUserStatus } from '@/utils';
const settingStore = useSettingStore();
const { goIdentifyPage,getIdentifyPath } = useGoIdentifyPage()
const bannerData = ref('');
const active = ref(0);
const router = useRouter();
const loading = ref(false);
const finished = ref(false);
const isLastPageb = ref(false);
const total = ref(0);
const pages = ref(0);
const mateParam = reactive<mate>({
  type: '全部',
  keyWord: '',
  pageSize: 10,
  pageNum: 1,
});
const dataList = ref<any[]>([]);
const changeTabs = async () => {
  let n = active.value;
    console.log(active.value)
  if (isGuangWenYi()) {
    console.log('1222');
    if (n === 0) {
      mateParam.type = '全部';
      mateParam.pageNum = 1;
      finished.value = false;
      init();
    } else if (n === 1) {
      mateParam.pageNum = 1;
      mateParam.type = '同城';
      finished.value = false;
      init();
    } else if (n === 2) {
      mateParam.pageNum = 1;
      mateParam.type = '同级';
      finished.value = false;
      init();
    } else if (n === 3) {
      mateParam.pageNum = 1;
      mateParam.type = '同专业';
      finished.value = false;
      init();
    }
      else if (n === 4) {
      mateParam.pageNum = 1;
      mateParam.type = '同行业';
      //  mateParam.type = '同职业';
      //同职业
      finished.value = false;
      init();
    }    
  } else {
    if (n === 0) {
      mateParam.type = '全部';
      mateParam.pageNum = 1;
      finished.value = false;
      init();
      console.log(finished.value);
    } else if (n === 1) {
      mateParam.pageNum = 1;
      mateParam.type = '推荐';
      finished.value = false;
      init();
    } else if (n === 2) {
      mateParam.pageNum = 1;
      mateParam.type = '同级';//同级
      finished.value = false;
      init();
    } else if (n === 3) {
      mateParam.pageNum = 1;
      mateParam.type = '同城';
      finished.value = false;
      init();
    } else if (n === 4) {
      //mateParam.type = '同行';
      mateParam.pageNum = 1;
      mateParam.type = '同职';
      finished.value = false;
      init();
    }
  }
};
const jumpAlu = (item: any) => {
  router.push({ path: '/agreeAlumniCard', query: { userId: item.userId } });
};
const onLoad = async () => {
  if (!isLastPageb.value && loading.value) {
    finished.value = false;
    mateParam.pageNum = (mateParam.pageNum as number) + 1;
    await init();
  } else {
    loading.value = false;
    finished.value = true;
  }
};


const showLocation = (item:any) =>{
  if(isShanDa()){
    if(!!item.workLifeLocation){
      return item.workLifeLocation
    }else{
      return item.cityName
    }
  }else{
    return item.cityName
  }
}

const init = async () => {
  let userStatus = getUserStatus() as string;
  if(userStatus == '00'||userStatus == '06' || settingStore.isManagerMode){
    loading.value = true;
    const { data, code, msg } = await Api.getSchoolMate(mateParam);
    if (code == 200) {
      pages.value = data.pages;
      total.value = data.total;
      isLastPageb.value = data.isLastPage;
      dataList.value = data.pageNum == 1 ? data.list : [...dataList.value, ...data.list];
      loading.value = false;
    } else {
      Toast({
        message: msg,
        icon: 'none',
      });
       dataList.value = []
    }
    if (isLastPageb.value) {
      loading.value = false;
      finished.value = true;
    }
  }else{
    loading.value = false;
    if (userStatus == '04') {
      goIdentifyPage().then((res)=>{
        if(res)router.push({path:getIdentifyPath()})
      })
      return
    }
  }
};

const goSearchPage = () => {
  router.push({ path: '/schoolmate-search' });
};
onBeforeMount(() => {
  init();

  useCache({
    key: 'SCHOOLMATE_BANNER',
    service: homeSwipePic,
    params: {
      imageType: 'SCHOOLMATE_BANNER'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        bannerData.value = data?.images?.[0]?.fileAddress ?? ''
      }
    }
  })
});
function getImg(route: string) {
  return new URL(`../../assets/${route}`, import.meta.url).href;
}
</script>
<style lang="less" scoped>
.content {
  width: 100%;
  height: 100%;
  background-color: #ffffff;
  overflow: hidden;

  .banner {
    position: relative;

    .imgs {
      width: 100%;
      height: 350px;
      object-fit: cover;
    }

    .isdi {
      position: absolute;
      top: 160px;
      left: 30px;
      width: 690px;
      height: 80px;
      border-radius: 40px;
      --van-search-background-color: rgba(0, 0, 0, 0.5);
      --van-search-content-background-color: none;
      --van-search-action-padding: 5px;
      --van-search-action-text-color: rgba(255, 255, 255, 0.8);
      --van-search-left-icon-color: #fff;
      --van-field-input-text-color: #fff;
      --van-active-color: none;

      .iasd {
        background: rgba(255, 255, 255, 0.1);
        padding: 0 30px;
        border-radius: 40px;
      }
    }
  }

  .cenTab {
    position: absolute;
    top: 265px;
    width: 100%;
    height: 100px;
    line-height: 100px;
    box-shadow: 1px 2px 40px 0px rgba(0, 0, 0, 0.1);
    border-radius: 40px 40px 0px 0px;
    background: #fff;
    overflow: hidden;
  }

  .alumniList {
    height: 100%;
    overflow-y: auto;

    .van-list {
      padding: 10px 0 550px;

      :deep(.van-list__loading) {
        margin: 0 auto;
      }

      :deep(.van-list__finished-text) {
        width: 100%;
      }
    }
  }
}

.schoolmate-icon-wrap {
  position: absolute;
  left: 20px;
  bottom: 15px;

  .icon-recommend {
    width: 32px;
    height: 32px;
  }

  &.city-wrap {
    display: flex;
    flex-direction: row;
    align-items: center;
    font-size: 24px;
    color: #666;

    .icon-weizhi {
      margin-right: 15px;
      width: 32px;
      height: 32px;
    }
  }
}
</style>
