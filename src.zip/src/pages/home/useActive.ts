import { ref } from 'vue';
import { getActiveList as fetchActiveList } from '@/api/servive';
import { Toast } from 'vant';
import { useGoIdentifyPage } from '@/pages/home/useGoIdentifyPage'
import { useSettingStore } from '@/store';
import { useRouter } from 'vue-router';
import useCache from '@/hooks/useCache';
import { getUserStatus,isHasMenu } from '@/utils';

const settingStore:any = useSettingStore();
const { goIdentifyPage,getIdentifyPath } = useGoIdentifyPage()
export function useActive() {
  const router = useRouter();
  const activeList = ref<Activities[]>([]);

  async function getActiveList({status = '2', pageSize = 4}) {
    useCache({
      key: `home_fetchActiveList_${status}`,
      service: fetchActiveList,
      params: {
        pageNum: 1,
        pageSize,
        status,
      },
      callback: ({code, data, msg}: any) => {
        if (code == 200) {
          activeList.value = data.list;
        } else {
          Toast.fail(msg);
        }
      }
    })
  }

  /**跳转活动报名页 */
  function goJoinActivePage(item: any) {
    let userStatus = getUserStatus()
    if (userStatus == '00' || userStatus == '06' || settingStore.isManagerMode) {
      if (router.hasRoute('activeDetail')) {
        router.push({ path: '/activeDetail', query: { id: item.id } });
        return
      }
      if (item.status == '2') {
        router.push({ path: '/joinAct', query: { id: item.id, requiredInformation: item.requiredInformation } });
        return
      }
      router.push({ path: '/activeList' });
    } else {
      goIdentifyPage().then((res) => {
        if (res) router.push({ path: getIdentifyPath() })
      })
    }
  }

  /**跳转活动列表页 */
  function goActiveListPage() {
    if(isHasMenu('/activeList')){
      router.push({ path: '/activeList' });
    }else{
      Toast.fail("暂无权限")
    }
  }

  activeList;
  return {
    activeList,
    getActiveList,
    goJoinActivePage,
    goActiveListPage,
  };
}
