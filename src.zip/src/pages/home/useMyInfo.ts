import { fetchBaseInfo } from '@/api/my';
import { ref } from 'vue';
import useCache from '@/hooks/useCache';
import { getUserInfo, setUserInfo } from '@/utils';

export function useMyInfo() {
  const perInfo = ref<perInfo>({
    name: '',
    collegeName: '',
    schoolName: '',
    classes: '',
    userProfilePicture: '',
    classesName: '',
    mobile: '',
    educationInfoList: [],
    bareheadedPhoto: '',
    pictureStatus: '',
    nameDetail: '',
    schoolmateType: '',
    jobDepartment: '',
    jobDuration: '',
  });

  const initMy = async () => {
    await useCache({
      key: 'BaseInfo',
      service: fetchBaseInfo,
      params: {},
      callback: ({ code, data }: any) => {
        if (code == 200) {
          let userInfo = JSON.parse(getUserInfo() || '{}')
          setUserInfo(JSON.stringify({...userInfo, ...data}))
          if (data?.educationInfoList && data?.educationInfoList.length >0) {
            data.educationInfoList = data.educationInfoList.filter(
              (item: any) => Object.getOwnPropertyNames(item).length != 0
            );
          }else{
            data.educationInfoList = []
          }
					perInfo.value = data;
          console.log('initMy',perInfo.value)
        }
      },
    });
  };

  return {
    perInfo,
    initMy,
  };
}
