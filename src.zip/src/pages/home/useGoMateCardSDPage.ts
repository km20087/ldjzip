import { getCardList } from "@/api/home";
import { useRouter } from 'vue-router';
import { usePendingOpenDialog } from "@/pages/home/usePendingOpenDialog";
export function useGoMateCardSDPage() {
  const router = useRouter();
	const { showPendingOpenDialog } = usePendingOpenDialog()

  async function handleGoMateCardSDPage() {
    console.log('112233')
    let { code, data, msg } = await getCardList({});
    //审核通过直接跳转卡片页，否则进入申请页
    if (code == 200 && data) {
      let { auditStatus } = data;
      if (auditStatus == null || auditStatus == undefined) {
        router.push({ name: 'mateCardSD' });
      } else {
        router.push({ name: 'mateCardAP' });
      }
    } else {
      showPendingOpenDialog();
    }
  }

  return {
		handleGoMateCardSDPage
	};
}
