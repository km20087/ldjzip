import { getSchoolNews } from '@/api/home';
import useCache from '@/hooks/useCache';
import { Toast } from 'vant';

interface INewsParams {
  newsType: string
  pageNum?: number
  pageSize?: number
}
export function useNews() {
  /**直接请求接口获取新闻 */
  async function initList(params: INewsParams) {
    let { newsType, pageNum = 1, pageSize = 6} = params
    const { code, data, msg } = await getSchoolNews({
      newsType,
      pageNum,
      pageSize,
    });
    if (code == 200) {
      return data.list;
    } else {
      Toast.fail(msg);
      return [];
    }
  }

  /**先使用缓存展示，再请求接口更新新闻 */
  async function initListAndCache( params: INewsParams & {successCallback: (data: NewsData[]) => void})  {
    let { newsType, successCallback, pageNum = 1, pageSize = 6} = params
    useCache({
      key: newsType,
      service: getSchoolNews,
      params: {
        newsType,
        isReturnContent: '0',
        pageNum,
        pageSize
      },
      callback: ({code, data, msg}: any) => {
        if (code == 200) {
          successCallback(data.list)
        } else {
          Toast.fail(msg)
        }
      }
    })
  }

  return {
    initList,
    initListAndCache
  };
}
