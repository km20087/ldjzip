import { Dialog } from 'vant';

export function usePendingOpenDialog() {
  function showPendingOpenDialog() {
    Dialog.confirm({ title: '提示', message: '功能完善中，敬请期待。' })
      .then(() => {})
      .catch(() => {});
  }

  return {
    showPendingOpenDialog,
  };
}
