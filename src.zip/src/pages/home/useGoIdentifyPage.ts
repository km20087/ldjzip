import { Dialog } from 'vant';
import { SchoolCode } from '@/constants';
import { getSchoolCode, getToken } from '@/utils';
import { isAllowVisitorToUseSchool } from '@/utils/customizedType';
import { useLoginDialog } from '@/hooks/useLoginDialog';
import { registerTypeMole } from '@/pages/register/constant';
export function useGoIdentifyPage() {
  const { showLoginDialog } = useLoginDialog()

  function getIdentifyPath() {
    let schoolCode = getSchoolCode() as string;
    if (schoolCode == SchoolCode.ChangShu) {
      return '/register/speFirst';
    } 
    // else if (registerTypeMole.includes(schoolCode)) {
    //   //registerTypeMole
    //   //schoolCode == SchoolCode.ShanDa || schoolCode == SchoolCode.GuangWenYi
    //   return '/register/type';
    // } 
    else if (schoolCode == SchoolCode.LiaoShiDa) {
      return '/register/register_middle_first';
    }
     else {
      // return '/register/second';
      return '/register/type';
    }
  }

  async function goIdentifyPage() {
    if (isAllowVisitorToUseSchool() && !getToken()) {
      showLoginDialog()
      return
    }

    let b = null
    await Dialog.confirm({ title: '认证', message: '用户是否去填写完整信息' })
      .then(() => {
        b = true

      })
      .catch(() => {
        b = false
      });
      return b
  }

  return {
    getIdentifyPath,
    goIdentifyPage,
  };
}
