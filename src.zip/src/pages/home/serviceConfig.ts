import SvgReturnschool from '@/assets/server/returnschool.svg';
import SvgJuan from '@/assets/server/juan.svg';
import SvgMessage from '@/assets/server/message.svg';
import SvgAcList from '@/assets/server/acList.svg';
import SvgPhoto from '@/assets/server/photo.svg';
import SvgConnect from '@/assets/server/connect.svg';
import SvgSchoolMates from '@/assets/icons/mine-circle.svg';
import SvgQihan from '@/assets/server/qihan.svg';
import SvgArchive from '@/assets/server/archive.svg';
import SvgQuestion from '@/assets/server/question.svg';
import SvgFeedback from '@/assets/server/feedback.svg';
import SvgXiaoQing from '@/assets/server/xiaoqing.svg';
import xiaoyoufuli2 from '@/assets/server/xiaoyoufuli2.svg';
import qiyezhaopin from '@/assets/server/qiyezhaopin2.svg';
import chuangye from '@/assets/server/chuangye2.svg';
import SvgChanXueYan from '@/assets/server/chanxueyan.svg';
import SvgReturnSchool1 from '@/assets/home/return-school.svg';
import SvgActivity from '@/assets/home/activity.svg';
import SvgMineMessage from '@/assets/mine/message.svg';
import SvgTouXiangShenHe from '@/assets/server/touxiangshenhe.svg'
import SvgZhongShenXueXi from '@/assets/server/zhongshenxuexi.svg'
import SvgHuaZhuHui from '@/assets/server/huazhuhui.svg'
import SvgschoolMateBT from '@/assets/server/schoolMateBT.svg'
import SvgXiaoYouDiTu from '@/assets/server/xiaoyouditu.svg';
import SvgEMaTong from '@/assets/server/ematong.svg'; 
import SvgYinHangKaShenBan from '@/assets/server/yinhangkashenban.svg'; 
import { IdentifyMode, SchoolCode } from '@/constants';
import { useSettingStore } from '@/store';
import { getMenus, getSchoolCode, getUserStatus } from '@/utils';

//menuMode:0为外部跳转三方链接，1为内部跳转本地路由
const menList = [
  { label: '我要捐赠', svg: SvgJuan, jump: 'donate', menuMode: '0', params: '', path: '' },
  { label: '通知公告', svg: SvgMessage, jump: 'notice', menuMode: '1', params: '', path: '' },
  { label: '校友相册', svg: SvgPhoto, jump: 'matePictures', menuMode: '1', params: '', path: '' },
  {
    label: '校友期刊',
    svg: SvgQihan,
    jump: 'serviceNews',
    menuMode: '1',
    params: 'schoolmate_journal',
    path: '',
  },
  { label: '联系我们', svg: SvgConnect, jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: '活动列表', svg: SvgActivity, jump: 'activeList', menuMode: '1', params: '', path: '' },
  {
    label: '预约返校',
    svg: SvgReturnSchool1,
    jump: 'backSchool',
    menuMode: '1',
    params: '',
    path: '',
  },
  {
    label: '档案服务',
    svg: SvgArchive,
    jump: 'archive/index',
    menuMode: '1',
    params: '',
    path: '',
  },
  {
    label: '调查问卷',
    svg: SvgQuestion,
    jump: 'questionnaire',
    menuMode: '0',
    params: '',
    path: '',
  },
  { label: '反馈与建议', svg: SvgFeedback, jump: 'feedback', menuMode: '1', params: '', path: '' },
  { label: '校庆', svg: SvgXiaoQing, jump: 'xiaoqing', menuMode: '1', params: '', path: '' },
  // { label: '审核功能', svg: SvgXiaoQing, jump: 'examine', menuMode: '1', params: '', path: "" },
  { label: '理事会', svg: SvgConnect, jump: 'council', menuMode: '1', params: '', path: '' },
  { label: '校友企业', svg: qiyezhaopin, jump: 'schoolmate-enterprise', menuMode: '1', params: '', path: '' },
  { label: '校友地图', svg: SvgXiaoYouDiTu, jump: 'alumni-map', menuMode: '1', params: '', path: '' },
  { label: 'E码通', svg: SvgEMaTong, jump: 'e-ma-tong', menuMode: '0', params: '', path: '' },
  { label: '联名卡申办', svg: SvgYinHangKaShenBan, jump: 'bank-card-application', menuMode: '0', params: '', path: '' },
];

const ChengDuList = [
  //menuMode:0为外部跳转三方链接，1为内部跳转本地路由
  { label: '我要捐赠', svg: SvgJuan, jump: 'donate', menuMode: '0', params: '', path: '' },
  { label: '通知公告', svg: SvgMessage, jump: 'notice', menuMode: '1', params: '', path: '' },
  { label: '校友相册', svg: SvgPhoto, jump: 'matePictures', menuMode: '1', params: '', path: '' },
  {
    label: '校友期刊',
    svg: SvgQihan,
    jump: 'serviceNews',
    menuMode: '1',
    params: 'schoolmate_journal',
    path: '',
  },
  { label: '联系我们', svg: SvgConnect, jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: '活动列表', svg: SvgActivity, jump: 'activeList', menuMode: '1', params: '', path: '' },
  {
    label: '预约返校',
    svg: SvgReturnSchool1,
    jump: 'backSchool',
    menuMode: '1',
    params: '',
    path: '',
  },
  {
    label: '档案服务',
    svg: SvgArchive,
    jump: 'archive/index',
    menuMode: '1',
    params: '',
    path: '',
  },
  {
    label: '调查问卷',
    svg: SvgQuestion,
    jump: 'questionnaire',
    menuMode: '0',
    params: '',
    path: '',
  },
  { label: '反馈与建议', svg: SvgFeedback, jump: 'feedback', menuMode: '1', params: '', path: '' },
  { label: '校庆', svg: SvgXiaoQing, jump: 'xiaoqing', menuMode: '1', params: '', path: '' },
  { label: '华住会', svg: SvgHuaZhuHui, jump: 'huazhuhui', menuMode: '0', params: '', path: "" },//gen_basicLogin
  { label: '理事会', svg: SvgConnect, jump: 'council', menuMode: '1', params: '', path: '' },
  { label: 'E码通', svg: SvgEMaTong, jump: 'e-ma-tong', menuMode: '0', params: '', path: '' },
  { label: '联名卡申办', svg: SvgYinHangKaShenBan, jump: 'bank-card-application', menuMode: '0', params: '', path: '' },
];

const HeBeiShiFanList = [
  { label: '我的班级', svg: SvgMessage, jump: 'classes', menuMode: '1', params: '', path: '' },
  { label: '终身学习', svg: SvgZhongShenXueXi, jump: 'learn', menuMode: '0', params: '', path: '' },
  { label: 'E码通', svg: SvgEMaTong, jump: 'e-ma-tong', menuMode: '0', params: '', path: '' },
  { label: '联名卡申办', svg: SvgYinHangKaShenBan, jump: 'bank-card-application', menuMode: '0', params: '', path: '' },
]
const shanDaList = [
  // { label: '我要捐赠', svg: SvgJuan, jump: 'donate', menuMode: '0', params: '' },
  { label: '通知公告', svg: SvgMessage, jump: 'notice', menuMode: '1', params: '', path: '' },
  { label: '印象汕大', svg: SvgPhoto, jump: 'matePictures', menuMode: '1', params: '', path: '' },
  {
    label: '校友会刊',
    svg: SvgQihan,
    jump: 'serviceNews',
    menuMode: '1',
    params: 'schoolmate_journal',
    path: '',
  },
  {
    label: '校友福利',
    svg: xiaoyoufuli2,
    jump: 'schoolmateWelfare',
    menuMode: '1',
    params: 'shoolmate_welfare',
    path: '',
  },
  { label: '校内电话', svg: SvgConnect, jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: '活动列表', svg: SvgActivity, jump: 'activeList', menuMode: '1', params: '', path: '' },
  {
    label: '返校服务',
    svg: SvgReturnSchool1,
    jump: 'reserveBackSchoolDate',//backSchool
    menuMode: '1',
    params: '',
    path: '',
  },
  { label: '团体返校',svg: SvgReturnSchool1,jump: 'backSchoolMonth',menuMode: '1',params: '',path: '/backSchoolMonth',},
  {
    label: '档案服务',
    svg: SvgArchive,
    jump: 'archive/index',
    menuMode: '1',
    params: '',
    path: '',
  },
  {
    label: '调查问卷',
    svg: SvgQuestion,
    jump: 'questionnaire',
    menuMode: '0',
    params: '',
    path: '',
  },
  { label: '反馈与建议', svg: SvgFeedback, jump: 'feedback', menuMode: '1', params: '', path: '' },
  { label: '校庆', svg: SvgXiaoQing, jump: 'xiaoqing', menuMode: '1', params: '', path: '' },
  { label: '企业招聘', svg: qiyezhaopin, jump: 'recruitment', menuMode: '1', params: '', path: '' },
  {
    label: '创业创新',
    svg: chuangye,
    jump: 'entrepreneurship',
    menuMode: '1',
    params: '',
    path: '',
  },
  {
    label: '产学研合作',
    svg: SvgChanXueYan,
    jump: 'schoolEnterpriseCooperation',
    menuMode: '1',
    params: 'school_enterprise_cooperation',
    path: '',
  },
  { label: 'E码通', svg: SvgEMaTong, jump: 'e-ma-tong', menuMode: '0', params: '', path: '' },
  { label: '联名卡申办', svg: SvgYinHangKaShenBan, jump: 'bank-card-application', menuMode: '0', params: '', path: '' },
];
//辽宁师范
const LiaoShiDa = [
  { label: '通知公告', svg: SvgMessage, jump: 'notice', menuMode: '1', params: '', path: '' },
  { label: '校友活动', svg: SvgActivity, jump: 'activeList', menuMode: '1', params: '', path: '' },
  // { label: '校友期刊', svg: SvgConnect, jump: 'contactus', menuMode: '1', params: '', path: '' },
  {
    label: '校友期刊',
    svg: SvgQihan,
    jump: 'serviceNews',
    menuMode: '1',
    params: 'schoolmate_journal',
    path: '',
  },
  {
    label: '预约返校',
    svg: SvgReturnSchool1,
    jump: 'backSchool-ln',
    menuMode: '1',
    params: '',
    path: '',
  },
  {
    label: '档案服务',
    svg: SvgArchive,
    jump: 'archive/index',
    menuMode: '1',
    params: '',
    path: '',
  },
  // { label: '寻找校友', svg: SvgConnect, jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: '我要捐赠', svg: SvgJuan, jump: 'donate', menuMode: '0', params: '', path: '' },
  {
    label: '校友福利',
    svg: xiaoyoufuli2,
    jump: 'schoolmateWelfare',
    menuMode: '1',
    params: 'shoolmate_welfare',
    path: '',
  },
  // { label: '母校地图', svg: SvgConnect, jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: '建议反馈', svg: SvgFeedback, jump: 'feedback', menuMode: '1', params: '', path: '' },
  { label: '联系我们', svg: SvgConnect, jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: 'E码通', svg: SvgEMaTong, jump: 'e-ma-tong', menuMode: '0', params: '', path: '' },
  { label: '联名卡申办', svg: SvgYinHangKaShenBan, jump: 'bank-card-application', menuMode: '0', params: '', path: '' },
];
const LiaoShiDaManager = [
  { label: '通知公告', svg: SvgMessage, jump: 'notice', menuMode: '1', params: '', path: '' },
  { label: '校友活动', svg: SvgActivity, jump: 'activeList', menuMode: '1', params: '', path: '' },
  {
    label: '校友期刊',
    svg: SvgQihan,
    jump: 'headLogoCheck',
    menuMode: '1',
    params: 'schoolmate_journal',
    path: '',
  },
  {
    label: '头像审核',
    svg: SvgTouXiangShenHe,
    jump: 'serviceNews',
    menuMode: '1',
    params: 'schoolmate_journal',
    path: '',
  },

  {
    label: '档案服务',
    svg: SvgArchive,
    jump: 'archive/index',
    menuMode: '1',
    params: '',
    path: '',
  },
  { label: '建议反馈', svg: SvgFeedback, jump: 'feedback', menuMode: '1', params: '', path: '' },
  { label: '我的消息', svg: SvgMineMessage, jump: 'message', menuMode: '1', params: '', path: '' },
  { label: 'E码通', svg: SvgEMaTong, jump: 'e-ma-tong', menuMode: '0', params: '', path: '' },
  { label: '联名卡申办', svg: SvgYinHangKaShenBan, jump: 'bank-card-application', menuMode: '0', params: '', path: '' },
];

/**广东XX学校 */
const GuangWenYiList = [
  { label: '校友注册', imgPath: 'guangwenyi/xiaoyouzhuce.png', jump: 'second', menuMode: '1', params: '', path: '' },
  { label: '电子校友卡', imgPath: 'guangwenyi/xiaoyouka.png', jump: 'mateCard', menuMode: '1', params: '', path: '' },
  // { label: '返校预约', imgPath: 'guangwenyi/fanxiaoyuyue.png', jump: 'backSchool', menuMode: '1', params: '', path: '' },
  // { label: '值年返校', imgPath: 'guangwenyi/zhinianfanxiao.png', jump: 'backSchool-ln', menuMode: '1', params: '', path: '' },
  { label: '爱心捐赠', imgPath: 'guangwenyi/aixinjuanzeng.png', jump: 'donate', menuMode: '0', params: '', path: '' },
  { label: '找校友', imgPath: 'guangwenyi/zhaoxiaoyou.png', jump: 'alumni', menuMode: '1', params: '', path: '' },
  { label: '校友风采', imgPath: 'guangwenyi/xiaoyoufengcai.png', jump: 'news', menuMode: '1', params: 'schoolmate_show_gwy', path: '' },
  { label: '校园风光', imgPath: 'guangwenyi/xiaoyuanfengguang.png', jump: 'news', menuMode: '1', params: 'campus_scenery_gwy', path: '' },
  { label: '找组织', imgPath: 'guangwenyi/zhaozuzhi.png', jump: 'organization', menuMode: '1', params: '', path: '' },
  { label: '校友企业', imgPath: 'guangwenyi/xiaoyouqiye.png', jump: 'schoolmate-enterprise', menuMode: '1', params: '', path: '' },
  { label: '联系我们', imgPath: 'guangwenyi/lianxiwomen.png', jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: 'E码通', imgPath: 'guangwenyi/ematong.png', jump: 'e-ma-tong', menuMode: '0', params: '', path: '' },
  { label: '联名卡申办', imgPath: 'guangwenyi/yinhangkashenban.png', jump: 'bank-card-application', menuMode: '0', params: '', path: '' },
  { label: '校友福利', imgPath: 'guangwenyi/biyepai.png', jump: 'graduation', menuMode: '0', params: '', path: '' },
]

/**沈阳药科 */
const ShenYangYaoKeList = [
  { label: '校友注册', imgPath: 'guangwenyi/xiaoyouzhuce.png', jump: 'second', menuMode: '1', params: '', path: '' },
  { label: '校友卡', imgPath: 'guangwenyi/xiaoyouka.png', jump: 'mateCard', menuMode: '1', params: '', path: '' },
  { label: '返校预约', imgPath: 'guangwenyi/fanxiaoyuyue.png', jump: 'backSchool', menuMode: '1', params: '', path: '' },
  // { label: '值年返校', imgPath: 'guangwenyi/zhinianfanxiao.png', jump: 'backSchool-ln', menuMode: '1', params: '', path: '' },
  { label: '爱心捐赠', imgPath: 'guangwenyi/aixinjuanzeng.png', jump: 'donate', menuMode: '0', params: '', path: '' },
  { label: '找校友', imgPath: 'guangwenyi/zhaoxiaoyou.png', jump: 'alumni', menuMode: '1', params: '', path: '' },
  { label: '找组织', imgPath: 'guangwenyi/zhaozuzhi.png', jump: 'organization', menuMode: '1', params: '', path: '' },
  { label: '联系我们', imgPath: 'guangwenyi/lianxiwomen.png', jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: '期队风采', imgPath: 'guangwenyi/xiaoyoufengcai.png', jump: 'news', menuMode: '1', params: 'schoolmate_show_syyk', path: '' },
  // { label: '校友地图', svg: SvgXiaoYouDiTu, jump: 'alumni-map', menuMode: '1', params: '', path: '' },
  { label: '毕业派', imgPath: 'guangwenyi/biyepai.png', jump: 'graduation', menuMode: '0', params: '', path: '' },
]


/**乌鲁木齐职业大学 */
const WuLuMuQiZhiYeDaXueList = [
  { label: '校友注册', imgPath: 'wulumuqizhiyedaxue/xiaoyouzhuce.png', jump: 'second', menuMode: '1', params: '', path: '' },
  { label: '校友卡', imgPath: 'wulumuqizhiyedaxue/xiaoyouka.png', jump: 'mateCard', menuMode: '1', params: '', path: '' },
  { label: '返校预约', imgPath: 'wulumuqizhiyedaxue/fanxiaoyuyue.png', jump: 'backSchool', menuMode: '1', params: '', path: '' },
  // { label: '值年返校', imgPath: 'wulumuqizhiyedaxue/zhinianfanxiao.png', jump: 'backSchool-ln', menuMode: '1', params: '', path: '' },
  { label: '爱心捐赠', imgPath: 'wulumuqizhiyedaxue/aixinjuanzeng.png', jump: 'donate', menuMode: '0', params: '', path: '' },
  { label: '找校友', imgPath: 'wulumuqizhiyedaxue/zhaoxiaoyou.png', jump: 'alumni', menuMode: '1', params: '', path: '' },
  { label: '校友风采', imgPath: 'wulumuqizhiyedaxue/xiaoyoufengcai.png', jump: 'news', menuMode: '1', params: 'schoolmate_show_wlmqzydx', path: '' },
  { label: '校园风光', imgPath: 'wulumuqizhiyedaxue/xiaoyuanfengguang.png', jump: 'news', menuMode: '1', params: 'campus_scenery_wlmqzydx', path: '' },
  { label: '找组织', imgPath: 'wulumuqizhiyedaxue/zhaozuzhi.png', jump: 'organization', menuMode: '1', params: '', path: '' },
  { label: '校友企业', imgPath: 'wulumuqizhiyedaxue/xiaoyouqiye.png', jump: 'schoolmate-enterprise', menuMode: '1', params: '', path: '' },
  { label: '联系我们', imgPath: 'wulumuqizhiyedaxue/lianxiwomen.png', jump: 'contactus', menuMode: '1', params: '', path: '' },
]

const XiangXianZhongXue = [
  { label: '校友注册', imgPath: 'xiangxianzhongxue/xiaoyouzhuce.png', jump: 'second', menuMode: '1', params: '', path: '' },
  { label: '新闻动态', imgPath: 'xiangxianzhongxue/xinwendongtai.png', jump: 'news', menuMode: '1', params: 'latest_news_xxzx', path: '' },
  { label: '返校预约', imgPath: 'xiangxianzhongxue/fanxiaoyuyue.png', jump: 'backSchool', menuMode: '1', params: '', path: '' },
  // { label: '值年返校', imgPath: 'wulumuqizhiyedaxue/zhinianfanxiao.png', jump: 'backSchool-ln', menuMode: '1', params: '', path: '' },
  { label: '校友风采', imgPath: 'xiangxianzhongxue/xiaoyoufengcai.png', jump: 'news', menuMode: '1', params: 'schoolmate_show_xxzx', path: '' },
  { label: '我要捐赠', imgPath: 'xiangxianzhongxue/woyaojuanzeng.png', jump: 'donate', menuMode: '0', params: '', path: '' },
  { label: '找校友', imgPath: 'xiangxianzhongxue/zhaoxiaoyou.png', jump: 'alumni', menuMode: '1', params: '', path: '' },
  { label: '象贤拾忆', imgPath: 'xiangxianzhongxue/xiangxianshiyi.png', jump: 'matePictures', menuMode: '1', params: '', path: '' },
  { label: '象贤文创', imgPath: 'xiangxianzhongxue/xiangxianwenchuang.png', jump: 'cultural-product-list', menuMode: '1', params: '', path: '' },
  { label: '校友会', imgPath: 'xiangxianzhongxue/xiaoyouhui.png', jump: 'showAlumniXX', menuMode: '1', params: '', path: '' },
  { label: '校友企业', imgPath: 'xiangxianzhongxue/xiaoyouqiye.png', jump: 'schoolmate-enterprise', menuMode: '1', params: '', path: '' },
  { label: '联系我们', imgPath: 'xiangxianzhongxue/lianxiwomen.png', jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: '校友投稿', imgPath: 'xiangxianzhongxue/xiaoyoutougao.png', jump: 'submission-list', menuMode: '1', params: '', path: '' },
]

/**包头职业 */
const BaoTouZhiYeJiShu = [
  { label: '通知公告', svg: SvgMessage, jump: 'notice', menuMode: '1', params: '', path: '' },
  { label: '校园风光', svg: SvgPhoto, jump: 'matePictures', menuMode: '1', params: '', path: '' },
  {
    label: '校友期刊',
    svg: SvgQihan,
    jump: 'serviceNews',
    menuMode: '1',
    params: 'schoolmate_journal',//news  serviceNews
    path: '',
  },
  {
    label: '云上校史馆',
    svg: SvgQihan,
    jump: 'historyNews',
    menuMode: '1',
    params: 'school_history',//news  serviceNews
    path: '',
  },  
  {
    label: '校友福利',
    svg: xiaoyoufuli2,
    jump: 'schoolmateWelfare',
    menuMode: '1',
    params: 'shoolmate_welfare',
    path: '',
  },
  { label: '校友风采', svg: SvgschoolMateBT, jump: 'news', menuMode: '1', params: 'schoolmate_show_BTZY', path: '' },  
  { label: '活动列表', svg: SvgActivity, jump: 'activeList', menuMode: '1', params: '', path: '' },
  {
    label: '返校服务',
    svg: SvgReturnSchool1,
    jump: 'backSchool',
    menuMode: '1',
    params: '',
    path: '',
  },
  { label: '团体返校',svg: SvgReturnSchool1,jump: 'backSchoolMonth',menuMode: '1',params: '',path: '/backSchoolMonth',},
  {
    label: '档案服务',
    svg: SvgArchive,
    jump: 'archive/index',
    menuMode: '1',
    params: '',
    path: '',
  },
  {
    label: '调查问卷',
    svg: SvgQuestion,
    jump: 'questionnaire',
    menuMode: '0',
    params: '',
    path: '',
  },
  { label: '反馈与建议', svg: SvgFeedback, jump: 'feedback', menuMode: '1', params: '', path: '' },
  { label: '校庆', svg: SvgXiaoQing, jump: 'xiaoqing', menuMode: '1', params: '', path: '' },
  // { label: '企业招聘', svg: qiyezhaopin, jump: 'recruitment', menuMode: '1', params: '', path: '' },
  { label: '校友企业', svg: qiyezhaopin, jump: 'schoolmate-enterprise', menuMode: '1', params: '', path: '' },
  { label: '联系我们', svg: SvgConnect, jump: 'contactus', menuMode: '1', params: '', path: '' },
  // {
  //   label: '创业创新',
  //   svg: chuangye,
  //   jump: 'entrepreneurship',
  //   menuMode: '1',
  //   params: '',
  //   path: '',
  // },
  {
    label: '产学研合作',
    svg: SvgChanXueYan,
    jump: 'schoolEnterpriseCooperation',
    menuMode: '1',
    params: 'school_enterprise_cooperation',
    path: '',
  },
  { label: 'E码通', svg: SvgEMaTong, jump: 'e-ma-tong', menuMode: '0', params: '', path: '' },
  { label: '联名卡申办', svg: SvgYinHangKaShenBan, jump: 'bank-card-application', menuMode: '0', params: '', path: '' },
]

const PeiYingZhongXue = [
  { label: '通知公告', imgPath: 'peiyingzhongxue/tongzhi@2x.png', jump: 'notice', menuMode: '1', params: '', path: '' },
  { label: '活动列表', imgPath: 'peiyingzhongxue/huodongliebiao@2x.png', jump: 'activeList', menuMode: '1', params: '', path: '' },
  { label: '联系我们', imgPath: 'peiyingzhongxue/lianxiwomen@2x.png', jump: 'contactus', menuMode: '1', params: '', path: '' },
  { label: '反馈与建议', imgPath: 'peiyingzhongxue/fankui@2x.png', jump: 'feedback', menuMode: '1', params: '', path: '' },
  { label: '校友相册', imgPath: 'peiyingzhongxue/xiaoyouxiangce@2x.png', jump: 'matePictures', menuMode: '1', params: '', path: '' },
  {
    label: '校友期刊',
    imgPath: 'peiyingzhongxue/xiaoyouqikan@2x.png',
    jump: 'serviceNews',
    menuMode: '1',
    params: 'schoolmate_journal',
    path: '',
  },  
  {
    label: '档案服务',
    imgPath: 'peiyingzhongxue/danganfuwu@2x.png',
    jump: 'archive/index',
    menuMode: '1',
    params: '',
    path: '',
  },  
  {
    label: '校友认证',
    imgPath: 'peiyingzhongxue/xiaoyourenzheng@2x.png',
    jump: 'type',
    menuMode: '1',
    params: '',
    path: '',
  },
 
  {
    label: '校友组织',
    imgPath: 'peiyingzhongxue/xiaoyouzuzhi@2x.png',
    jump: 'organization',
    menuMode: '0',
    params: '',
    path: '/tab/organization',
  },
  { label: '电子校友卡', imgPath: 'peiyingzhongxue/dianzixiaoyouka@2x.png', jump: 'mateCard', menuMode: '1', params: '', path: '' },  
  {
    label: '祝福母校',
    imgPath: 'peiyingzhongxue/zf@2x.png',
    jump: 'xiaoqing',
    menuMode: '0',
    params: '',
    path: '',
  },  
  { label: '校友地图', imgPath: 'peiyingzhongxue/xiaoyouditu@2x.png', jump: 'alumni-map',menuMode: '1',params: '',path: '', },  
  { label: '校企联盟', imgPath: 'peiyingzhongxue/xiaoyoulianmeng@2x.png', jump: 'recruitment', menuMode: '1', params: '', path: '' },
  {
    label: '购物',
    imgPath: 'peiyingzhongxue/gouwu@2x.png',
    jump: 'NoUrl',
    menuMode: '0',
    params: '',
    path: '',
  },  
  {
    label: '缴费服务',
    imgPath: 'peiyingzhongxue/jiaofei@2x.png',
    jump: 'donate',
    menuMode: '0',
    params: '',
    path: '',
  },      
];

const initServiceList = () => {
  let arr = [];
  let menu = JSON.parse(getMenus() as string);
  for (let i in menu) {
    if (menu[i].menuFile == 'service') {
      arr.push({ perms: menu[i].perms, menuMode: menu[i].menuMode, url: menu[i].url });
    }
  }
  console.log('---arr---',arr)
  return arr;
};

export const serviceListConfig = () => {
  let result:any = [];
  let getArr = initServiceList();
  let schoolCode = getSchoolCode()
  const userStatus = getUserStatus()
  if (schoolCode == SchoolCode.ShanDa) {
    for (let a in shanDaList) {
      for (let i in getArr) {
        if (getArr[i].perms == shanDaList[a].jump) {
          shanDaList[a].path = getArr[i].url;
          result.push(shanDaList[a]);
          result[result.length - 1].menuMode = getArr[i].menuMode;
          break
        }
      }
    }
    //汕大校友服务页新增团体返校
    // let a =   { label: '团体返校',svg: SvgReturnSchool1,jump: 'backSchoolMonth',menuMode: '1',params: '',path: '/backSchoolMonth',}
    // result.push(a)
    // result.push(HeBeiShiFanList[0])
  } else if (schoolCode == SchoolCode.LiaoShiDa) {
    let settingStore = useSettingStore()
    let menuList = settingStore.identifyMode == IdentifyMode.Manage ? LiaoShiDaManager : LiaoShiDa
    for (let a in menuList) {
      for (let i in getArr) {
        if (getArr[i].perms == LiaoShiDa[a].jump) {
          LiaoShiDa[a].path = getArr[i].url;
          result.push(LiaoShiDa[a]);
          result[result.length - 1].menuMode = getArr[i].menuMode;
          break
        }
      }
    }

  } else if (schoolCode == SchoolCode.GuangWenYi) {
    let list = userStatus == '04' ? GuangWenYiList : GuangWenYiList.slice(1)
    list.forEach(item => {
      for(let subItem of getArr) {
        if (subItem.perms == item.jump) {
          item.path = subItem.url
          result.push(item)
          result[result.length - 1].menuMode = subItem.menuMode
          break
        }
      }
    })
  }else if (schoolCode == SchoolCode.BaoTouZhiYeJiShu) {
    let list = userStatus == '04' ? BaoTouZhiYeJiShu : BaoTouZhiYeJiShu.slice(1)
    list.forEach(item => {
      for(let subItem of getArr) {
        if (subItem.perms == item.jump) {
          item.path = subItem.url
          result.push(item)
          result[result.length - 1].menuMode = subItem.menuMode
          break
        }
      }
    })
  }  
  else if (schoolCode == SchoolCode.WuLuMuQiZhiYeDaXue) {
    let list = userStatus == '04' ? WuLuMuQiZhiYeDaXueList : WuLuMuQiZhiYeDaXueList.slice(1)
    list.forEach(item => {
      for(let subItem of getArr) {
        if (subItem.perms == item.jump) {
          item.path = subItem.url
          result.push(item)
          result[result.length - 1].menuMode = subItem.menuMode
          break
        }
      }
    })
  }else if(schoolCode == SchoolCode.HeBeiShiFan){
    console.log('HeBeiShiFan',getArr)
    let HeBeiList = menList.concat(HeBeiShiFanList)
    for (let a in HeBeiList) {
      for (let i in getArr) {
        if (getArr[i].perms == HeBeiList[a].jump) {
          HeBeiList[a].path = getArr[i].url;
          result.push(HeBeiList[a]);
          result[result.length - 1].menuMode = getArr[i].menuMode;
          break
        }     
      }
    }
  }else if(schoolCode == SchoolCode.ChengDuYiXueYuan){
    let list = userStatus == '04' ? ChengDuList : ChengDuList.slice(1)
    list.forEach(item => {
      for(let subItem of getArr) {
        if (subItem.perms == item.jump) {
          item.path = subItem.url
          result.push(item)
          result[result.length - 1].menuMode = subItem.menuMode
          break
        }
      }
    })
  }else if (schoolCode == SchoolCode.XiangXianZhongXue){
    let list = userStatus == '04' ? XiangXianZhongXue : XiangXianZhongXue.slice(1)
    list.forEach(item => {
      for(let subItem of getArr) {
        if (subItem.perms == item.jump) {
          item.path = subItem.url
          result.push(item)
          result[result.length - 1].menuMode = subItem.menuMode
          break
        }
      }
    })    
  }else if (schoolCode == SchoolCode.PeiYingZhongXue){
    let list:any = []
    list = list.concat(PeiYingZhongXue)
    if(userStatus !== '04'){
      list.splice(7,1)
    }
    list.forEach((item:any) => {
      for(let subItem of getArr) {
        if (subItem.perms == item.jump) {
          item.path = subItem.url
          result.push(item)
          result[result.length - 1].menuMode = subItem.menuMode
          break
        }
      }
    })    
  }else if(schoolCode == SchoolCode.ShenYangYaoKeDaXue){
    let list = userStatus == '04' ? ShenYangYaoKeList : ShenYangYaoKeList.slice(1)
    list.forEach(item => {
      for(let subItem of getArr) {
        if(item.jump == 'backSchool'){
          item.label = "集体返校"
        }
        if (subItem.perms == item.jump) {
          item.path = subItem.url
          result.push(item)
          result[result.length - 1].menuMode = subItem.menuMode
          break
        }
      }
    })
  }
  else {
    console.log('menList',menList)
    console.log('getArr',getArr)
    for (let a in menList) {
      for (let i in getArr) {
        if(menList[a].jump == "xiaoqing" && schoolCode == SchoolCode.ChengDeYiXueYuan){
          menList[a].label = '校友祝福'
        }

        // if(menList[a].jump == "backSchool" && schoolCode == SchoolCode.GuangDongShuiLiXueYuan){
        //   // menList[a].label = '校友祝福'
        //   console.log('1333/backSchool',a)
        //   menList.splice(Number(a),1)
        // }        
        if (getArr[i].perms == menList[a].jump) {
          menList[a].path = getArr[i].url;
          result.push(menList[a]);
          result[result.length - 1].menuMode = getArr[i].menuMode;
          break
        }
      }
    }
  }
  console.log('***result***',result);
  return result;
};
