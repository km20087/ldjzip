<template>
  <div class="content">
    <nav-bar title="服务" left-text="" />
    <div class="contentList">
      <ECard v-if="isShowECard && schoolCode !== SchoolCode.XiangXianZhongXue" :whiteFont="whiteFont" :per-info="perInfo"/>
      <div :class="schoolCode == SchoolCode.XiangXianZhongXue?'XiangxianService':'card'" v-else>
        <img :src="serviceBanner" v-if="schoolCode == SchoolCode.XiangXianZhongXue" alt="" class="ims">
        <UserCard :perInfo="perInfo" v-else />

        <!-- <div class="info">
          <div class="logo">
            <Avatar class="ims" :src="perInfo.userProfilePicture" />
          </div>
          <div class="perInfo">
            <p class="name">{{ perInfo.name }}</p>
            <p class="sda">{{ perInfo.schoolName }}</p>
            <p class="sda">{{ perInfo.collegeName }}{{ perInfo.classesName }}</p>
          </div>
        </div> -->
      </div>
      <div class="gap" v-if="schoolCode !== SchoolCode.XiangXianZhongXue"> </div>
      <div class="btn-title-wrap" v-if="isUseSkin2 && schoolCode !== SchoolCode.XiangXianZhongXue">
        <div class="btn-title">校友服务</div>
      </div>

      <div class="menList" :class="isUseSkin2 ? 'col-3' : ''">
        <div v-for="(item, index) in menList" :key="index" class="part" @click="toJump(item)">
          <img v-if="item.imgPath" :src="getImg(item.imgPath)" class="ims" />
          <component v-else :is="item.svg" class="ims" />
          <span class="title">{{ item.label }}</span>
        </div>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
  import { reactive, ref } from 'vue';
  import UserCard from './component/userCard.vue';
  import Avatar from '@/components/avatar/index.vue';
  import { nameHasRouter } from '@/hooks/hasRouter';
  import { Toast } from 'vant';
  import { getSecret, getLearnUrl,genBasicLogin } from '@/api/servive';
  import { serviceListConfig } from './serviceConfig';
  import { Dialog } from 'vant';
  import ApiUser from '@/api/user';
  import ApiData from '@/api/home';
  import { isLiaoShiDa } from '@/utils/customizedType';
  import { useMyInfo } from '@/pages/home/useMyInfo';
  import { useSettingStore } from '@/store';
  import { useLoadECard } from '@/pages/home/useLoadECard';
  import { getSchoolCode, getImg, getUserStatus,getPictures, getToken } from '@/utils';
  import { SchoolCode } from '@/constants';
  import serviceBanner from "@/assets/xiangxianzhongxue/serviceBanner.jpg"
  import { useGoIdentifyPage } from '@/pages/home/useGoIdentifyPage'
  import { usePendingOpenDialog } from "@/pages/home/usePendingOpenDialog";
  import { useGoMateCardSDPage } from "@/pages/home/useGoMateCardSDPage";
  import { useSkin2 } from './useSkin2'
  import { toSecretZHC } from '@/api/servive';

  const { isUseSkin2 ,cssHome} = useSkin2()
	const { showPendingOpenDialog } = usePendingOpenDialog()
  const { handleGoMateCardSDPage } = useGoMateCardSDPage()

  const { goIdentifyPage,getIdentifyPath } = useGoIdentifyPage()

  const schoolCode = getSchoolCode();

  const { ECard, isShowECard,whiteFont } = useLoadECard();

  const settingStore = useSettingStore();
  const { perInfo, initMy } = useMyInfo();

  const router = useRouter();

  const menList = shallowRef<any>([]);
  const jumpRes = ()=>{
    goIdentifyPage().then((res)=>{
      if(res)router.push({path:getIdentifyPath()})
    })  
  }  
  const toJump = async (item: { [propName: string]: string }) => {
    const userStatus = getUserStatus();
    let isAuthorized = userStatus == '00' || userStatus == '06' || settingStore.isManagerMode
    // 广东XX学校某些功能还未改造，所以不做跳转。要上乌鲁木齐故使用相同的条件判断吧。
    if ( isUseSkin2 ) {
      if (schoolCode != SchoolCode.GuangWenYi && item.jump == 'donate') {
        if(schoolCode == SchoolCode.XiangXianZhongXue){
          // Toast({ message: '捐款请联系校友办,梁老师,020-34877920' });
          // Dialog.confirm({ title: '提示', message: '捐款请联系校友办,梁老师,020-34877920。' })
          router.push({path:"/donateXX",query:{type:"donateXX"}})
          return
        }else if(schoolCode == SchoolCode.PeiYingZhongXue){
          router.push({path:"/donateXX",query:{type:"cost_pyzx"}})
        }else{
          showPendingOpenDialog()
        }
        return
      }
      if (['backSchool-ln'].includes(item.jump)) {
        showPendingOpenDialog()
        return
      }
      if (item.jump == 'mateCard') {
        isAuthorized ?  handleGoMateCardSDPage() : jumpRes()
        return
      }
    }
    
    if (item.jump == 'schoolmate-enterprise') {
      nameHasRouter(router, item.jump, item.path);
      return
    }
    if (isLiaoShiDa() && item.jump == 'activeList')
      return (window.location.href =
        'https://mp.weixin.qq.com/mp/homepage?__biz=MzAwNTUwNDY1OQ==&hid=2&sn=d496646f1b461936c6dc43c5509d449b&scene=1&devicetype=iOS18.1.1&version=18003531&lang=zh_CN&nettype=3G+&ascene=7&session_us=gh_a555bb03e8c8&fontScale=100');
    if (isLiaoShiDa() && item.jump == 'serviceNews')
      return (window.location.href = 'https://book.yunzhan365.com/wpfem/itss/mobile/index.html');
    if (['e-ma-tong', 'bank-card-application'].includes(item.jump)) {
      window.location.href = `${import.meta.env.VITE_APP_API_BASE_URL}/jumpE/alumniJumpEcard?token=${getToken()}`
      return
    }
    if (item.jump =='graduation') {
      // let {data,msg,code} = await toSecretZHC({})
      // if(code == 200){
      //   window.location.href = 'https://app.xiaoyuan.ccb.com/visitor/newPage/portalpageH5/index.html' + '?' + data;
      // } else {
      //   Toast({message: msg})
      // }
      window.location.href = 'https://app.xiaoyuan.ccb.com/visitor/newPage/xiaoyou/index.html'
      return
    }
    if (item.jump == 'learn') {
      const { code, data, msg } = await getLearnUrl()
      if (code == 200) {
        let { learnUrl } = data
        if (learnUrl)  {
          window.location.href = learnUrl
        } else {
          Toast({message: '请联系管理员补充配置信息'})
        }
      } else {
        Toast({message: msg })
      }
    }
    if (item.jump == 'donate') {  
      if (userStatus == '00' || userStatus == '06') {
        if(schoolCode == SchoolCode.BeiHuaHangTianGongYe){
          router.push({path:"/donateXX",query:{type:"donate_newsBH"}})
          return
        }
        // let { data } = await getSecret({});
        // console.log('getSecret',data)
        // window.location.href = import.meta.env.VITE_APP_DONATE_URL + '?' + data;
        window.location.href = '../juanzeng/index.html#id=dp6j74&p=首页&sc=1&c=1'
        return
      } else {
        Toast({ message: '您暂时还不是校友，暂时无法使用该功能' });
      }
    }else if(item.jump == 'huazhuhui'){
      if (userStatus == '00' || userStatus == '06') {
        let { data } = await genBasicLogin({});
        console.log('genBasicLogin',data)
        if(data.code == 200){
           window.location.href = data.msg;
        }
      } else {
        Toast({ message: '您暂时还不是校友，暂时无法使用该功能' });
      }      
      //genBasicLogin
    } else if (item.jump === 'questionnaire') {
      const { data, code, msg } = await ApiData.getSchoolNews({
        newsType: 'question',
        pageNum: 1,
        pageSize: 2,
      });
      let a = data.list[0].contentUrl.split('?channelCode=');
      await jumpDcwj(a[1]);
    } else if (['serviceNews', 'schoolmateWelfare', 'schoolEnterpriseCooperation', 'news','historyNews' ].includes(item.jump)) {
      nameHasRouter(router, item.jump, item.path, { type: item.params });
    } else if (item.jump == 'backSchool') {
      if (schoolCode === SchoolCode.ShenYangShiFan) {
        showPendingOpenDialog()
      }else if(schoolCode === SchoolCode.ShenYangYaoKeDaXue){
        nameHasRouter(router, 'reserveBackSchoolDate', '/reserveBackSchoolDate');
      }else {
        if(isAuthorized){
          nameHasRouter(router, item.jump, item.path);
        }else{
          jumpRes()
        }
        
      }
    } else if (item.jump == 'archive/index') {
      if (schoolCode === SchoolCode.LiaoShiDa) {
        window.location.href = 'https://dag.lnnu.edu.cn/fwdx/bys/xsdas.htm';
      } else {
        nameHasRouter(router, item.jump, item.path);
      }
    }else if(item.jump == 'classes'){
      nameHasRouter(router, item.jump, item.path);
    }else if(item.jump == 'NoUrl'){
      Toast({ message: '十分抱歉，该功能仍在开发中。' });
      return
    } 
    else {
      nameHasRouter(router, item.jump, item.path);
    }
  };

  const jumpDcwj = async (val: string) => {
    let { data } = await ApiUser.uentry(val);
    window.location.href = data.data.url;
  };

  watch(
    () => settingStore.identifyMode,
    () => {
      menList.value = menList.value.concat(serviceListConfig());
    },
    {
      immediate: true,
    }
  );

  onBeforeMount(() => { 
    initMy();
    console.log('whiteFont',whiteFont)
  });
</script>
<style lang="less" scoped>
  .content {
    width: 100%;
    // height: 100%;
    background-color: #ffffff;
    overflow-y: scroll;
    position: relative;

    .contentList {
      width: 100%;
      position: relative;
      .card {
        margin: 28px auto;
        width: 690px;
      }
      .XiangxianService{
        width: 100%;
        height: 613px;
        // background:url("@/")
        .ims{
          width: 100%;
          height: 100%;
        }
      }

      .gap {
        // margin-top: 30px;
        width: 100%;
        height: 20px;
        background-color: #f5f5f5;
      }
      .btn-title-wrap {
        padding: 24px 30px;
        .btn-title {
          padding: 27px 0;
          width: 100%;
          background: linear-gradient(28deg, var(--theme-color-0-6) 0%, var(--theme-color) 100%);
          border-radius: 50px;
          font-family: PingFangSC, PingFang SC;
          font-weight: 500;
          font-size: 36px;
          color: #FFFFFF;
          letter-spacing: 23px;
          text-align: center;
        }
      }

      .lebel {
        margin-left: 30px;
        width: 72px;
        height: 36px;
        font-size: 36px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #333333;
        line-height: 36px;
      }

      .menList {
        margin-top: 20px;
        display: flex;
        width: 100%;
        height: 100%;
        flex-wrap: wrap;
        // justify-content: space-around;
        align-content: center;

        .part {
          padding-top: 100px;
          width: 25%;
          text-align: center;

          .ims {
            // width: 100%;
            // height: auto;
            width: 64px;
            height: 64px;
            fill: #000;

            :deep(path:last-child) {
              fill: var(--theme-color);
            }

            &.change-first {
              :deep(path:first-child) {
                fill: var(--theme-color);
              }

              :deep(path:last-child) {
                fill: #000;
              }
            }
          }

          .title {
            display: block;
            font-size: 28px;
            font-family: PingFangSC-Regular, PingFang SC;
            font-weight: 400;
            color: #666666;
          }
        }

        &.col-3 {
          .part {
            padding-top: 100px;
            width: 33.3%;
            .ims{
              width: 90px;
              height: 90px;
            }
              
            &:nth-of-type(1),
            &:nth-of-type(2),
            &:nth-of-type(3){
              padding-top: 50px;
            }
          }
          
        }
      }
    }
  }
</style>
