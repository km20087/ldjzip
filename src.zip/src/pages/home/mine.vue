<template>
<div>
  <nav-bar title="我的" />
  <div class="gray-bg">
    <ECard v-if="isShowECard" :per-info="perInfo" :whiteFont="whiteFont"/>
    <SwitchIdentify v-if="isLiaoShiDa()" :per-info="perInfo" />
    <div class="gap" v-if="isLiaoShiDa()"> </div>
    <template v-if="!isShowECard">
      <!-- schoolCode == SchoolCode.PeiYingZhongXue -->
      <div class="top-bg" :class="cssHome.ecardCss"></div>
      <div class="card">
        <UserCard :perInfo="perInfo" />
      </div>
      <UserCardSwitchIdentify />
    </template>

    <div class="mine-tab" :class="{'fix-margin': !isShowECard}">
      <van-cell title="我的活动" is-link @click="jumpMyact" v-if="settingStore.isSchoolmateMode">
        <template #icon>
          <SvgMyAct class="svg-icon" />
        </template>
      </van-cell>
      <van-cell title="我的组织" is-link @click="jumpMyPer(1)" v-if="settingStore.isSchoolmateMode">
        <template #icon>
          <SvgMyOrg class="svg-icon" />
        </template>
        <template #value>
          <span class="circle-container" v-if="checkTipsFlag"> </span>
          <span v-else></span>
        </template>
      </van-cell>
      <van-cell title="我的消息" @click="jumpMessage" is-link>
        <template #value>
          <van-tag v-if="unReadCount > 0 && schoolCode !== SchoolCode.GuangWenYi" type="danger" round>{{ unReadCount }}</van-tag>
          <span class="circle-container" v-else-if="unReadCount > 0 && schoolCode == SchoolCode.GuangWenYi"> </span>
        </template>
        <template #icon>
          <SvgMessage class="svg-icon" />
        </template>
      </van-cell>
    </div>
    <div class="mine-jump-list">

      <van-cell title="名片夹" is-link @click="jumpUserCard" v-if="settingStore.isSchoolmateMode">
        <template #icon>
          <SvgMingPian class="svg-icon" />
        </template>
        <template #value>
          <span class="circle-container" v-if="changeNum > 0"> </span>
          <span v-else></span>
        </template>
      </van-cell>

      <van-cell
        :title="isLiaoShiDa() ? '个人资料' : '我的名片'"
        @click="jumpMyPer(0)"
        is-link
        v-if="settingStore.isSchoolmateMode"
      >
        <template #icon>
          <SvgMyInfo class="svg-icon" />
        </template>
      </van-cell>
      <van-cell
        title="我的预约"
        @click="jumpMyBack"
        is-link
        v-if="isLiaoShiDa() && settingStore.isSchoolmateMode"
      >
        <template #icon>
          <SvgReturnschool class="svg-icon" />
        </template>
      </van-cell>
      <van-cell title="修改个人信息" is-link @click="editPerInfo" v-if="schoolCode == SchoolCode.ChengDeYiXueYuan">
        <template #icon>
          <SvgbaseInfo class="svg-icon" />
        </template>
      </van-cell>      
      <van-cell
        v-if="protocolList.length"
        title="隐私协议"
        @click="goProtocolPage(protocolList[0])"
        is-link
      >
        <template #icon>
          <SvgProtocol class="svg-icon" />
        </template>
      </van-cell>
      <van-cell
        title="对外展示信息设置"
        is-link
        @click="jumpToUrl('/selInfoConfig')"
        v-if="settingStore.isSchoolmateMode"
      >
        <template #icon>
          <SvgShowPerInfo class="svg-icon" />
        </template>
      </van-cell>
      <van-cell title="账号设置" is-link @click="loginOut">
        <template #icon>
          <SvgSheZhi class="svg-icon" />
        </template>
      </van-cell>
    </div>
  </div>
</div>  
</template>
<script setup lang="ts">
  import { ref } from 'vue';
  import UserCard from './component/userCard.vue';
  import { useUserStore } from '@/store/index';
  import Api from '@/api/schoolmate';
  import ApiMy from '@/api/my';
  import SvgbaseInfo from '@/assets/icons/baseInfo.svg';
  import ApiUser from '@/api/user';
  import ApiGroup, { userGroupP } from '@/api/group';
  import { storeToRefs } from 'pinia';
  import { Dialog } from 'vant';
  import { Toast } from 'vant';
  import { useSettingStore } from '@/store';
  import { useProtocol } from '@/hooks/useProtocol';
  import SvgMyAct from '@/assets/mine/myAct.svg';
  import SvgMyInfo from '@/assets/mine/myInfo.svg';
  import SvgMyOrg from '@/assets/mine/myOrg.svg';
  import SvgProtocol from '@/assets/mine/protocol.svg';
  import SvgSheZhi from '@/assets/mine/shezhi.svg';
  import SvgShowPerInfo from '@/assets/mine/showPerInfo.svg';
  import SvgMingPian from '@/assets/mine/mingpian.svg';
  import SvgReturnschool from '@/assets/server/returnschool.svg';
  import SvgMessage from '@/assets/mine/message.svg';
  import { isLiaoShiDa } from '@/utils/customizedType';
  import { useGoIdentifyPage } from '@/pages/home/useGoIdentifyPage';
  import { useMyInfo } from '@/pages/home/useMyInfo';
  import SwitchIdentify from './component/switch-identify.vue';
  import { useUnRead } from './useUnRead';
  import { useLoadECard } from '@/pages/home/useLoadECard';
  import { SchoolCode } from '@/constants';
  import { getSchoolCode, getUserStatus, getUserId } from '@/utils';
  import UserCardSwitchIdentify from './component/userCard-switch-identify.vue'
  import { useSkin2 } from '@/pages/home/useSkin2'

  const { cssHome } = useSkin2()
  const { ECard, isShowECard,whiteFont } = useLoadECard()

  const { getUnReadCount, unReadCount } = useUnRead();
  const { goIdentifyPage, getIdentifyPath } = useGoIdentifyPage();
  const { perInfo, initMy } = useMyInfo();
  const settingStore = useSettingStore();
  const { getListDataByWatchSchoolId, list: protocolList, goProtocolPage } = useProtocol();
  getListDataByWatchSchoolId();
  const schoolCode = getSchoolCode();
  const changeNum = ref(0);
  const router = useRouter();
  const stateShow = ref(false);
  const checkTipsFlag = ref(false);
  const requiredList = reactive([
    'name',
    'cardNumber',
    'graduationSchoolName',
    'collegeId',
    'provinceCity',
    'employer',
    'cardType',
    'bareheadedPhoto',
    'schoolStartYear',
    'schoolEndYear',
    'major',
    'classesName',
  ]);
  //   name: '',
  const grNum = ref(0);
  const sliderval = ref(80);
  const linear = ref('linear-gradient(90deg, #2DEA0E 0%, #70FF3A 100%)');
  const actCount = useUserStore();
  const { myActivities } = storeToRefs(actCount);
  const userStatus = getUserStatus();


  const editPerInfo = () =>{
    router.push({path:"/infoConfig"})

  }
  const initChange = async () => {
    const { data, msg, code } = await Api.getUnreadExchangeCount({});
    changeNum.value = data;
    stateShow.value = true;
  };
  const getGroupNum = async () => {
    let userId = getUserId()  as string;
    const { data, code, msg } = await ApiGroup.userGroup({ userId });
    for (let i in data) {
      if (data[i].pendingAudit == '1') {
        checkTipsFlag.value = true;
      }
    }
  };

  /**校验用户状态， 判断是否需要拦截跳转地址 */
  function validateGoPath() {
    if (settingStore.isManagerMode) return ''
    let path = '';
    if (userStatus == '03') {
      path = '/submited';
    } else if (userStatus == '04') {
      path = getIdentifyPath();
    }
    return path;
  }
  const jumpToUrl = (url: string) => {
    router.push({ path: url });
  };

  const jumpMyPer = (num: number) => {
    let path = validateGoPath();
    if (path) {
      router.push({ path });
      return;
    }
    let userId = getUserId()
    if (num == 1) {
      router.push({ path: '/perInfoCard', query: { userId, active: num } });
    } else {
      router.push({ path: '/myPerInfoCard' });
    }
  };
  const jumpUserCard = () => {
    let path = validateGoPath();
    if (path) {
      router.push({ path });
      return;
    }
    let redTips = 0;
    if (changeNum.value > 0) {
      redTips = 1;
    }
    router.push({ path: '/user_card', query: { redTips: redTips } });
  };
  const loginOut = async () => {
    router.push({ name: 'loginOut', query: { mobile: perInfo.value.mobile } });
  };

  const jumpMyact = () => {
    let path = validateGoPath();
    if (path) {
      router.push({ path });
      return;
    }
    router.push({ name: 'myActlist' });
  };
  const jumpMyBack = () => {
    let path = validateGoPath();
    if (path) {
      router.push({ path });
      return;
    }
    if (isLiaoShiDa()) {
      router.push({ name: 'backSchoolList-ln' });
    } else {
      router.push({ name: 'backSchoolList' });
    }
  };

  const jumpMessage = () => {
    let path = validateGoPath();
    if (path) {
      router.push({ path });
      return;
    }
    router.push({ path: '/message' });
  };

  onBeforeMount(async () => {
    initChange();
    initMy();
    getGroupNum();
    getUnReadCount();
    await actCount.getMyactNum();
  });
</script>
<style lang="less" scoped>
  .gray-bg {
    width: 100%;
    min-height: 0% !important;
    position: relative;
    overflow-y: hidden;

    // overflow-y: scroll;
    .bottom12 {
      width: 100%;
      // position: absolute;
      // bottom: -1px;
      position: fixed;
      bottom: 0px;
      z-index: 1000;
    }
  }

  .flex {
    display: flex;
  }

  .gap {
    margin-top: 30px;
    width: 100%;
    // height: 20px;
    background-color: #f5f5f5;
  }

  .top-bg {
    height: 170px;
    background: url('@/assets/img/mine-top_bg.png');
  }
  .whitePart{
    width: 100%;
    background-image:none;
  }

  .card {
    position: absolute;
    top: 60px;
    left: 30px;
    width: 690px;
    height: 220px;
  }

  .fix-margin{
    margin-top: 140px;
  }

  .mine-tab {
    // height: 332px;
    background: #fff;
    .flex();
    flex-direction: column;
    justify-content: flex-end;

    :deep(.van-icon) {
      top: 1px;
    }

    .revert-bar {
      .flex();
      position: relative;
      justify-content: space-around;
      align-items: center;

      .divide-line {
        width: 2px;
        height: 50px;
        background: #dfdfdf;
        position: absolute;
      }

      .tab-list {
        .flex();

        .tab-list-right {
          .flex();
          flex-direction: column;
          align-items: center;
          margin: 0 30px;

          .list-account {
            font-size: 36px;
            font-weight: bold;
            line-height: 80px;
          }
        }
      }
    }

    .van-cell {
      align-items: center;
      height: 100px;
    }

    img {
      width: 20px;
      height: 20px;
      margin-right: 20px;
    }
  }

  .mine-jump-list {
    margin-top: 30px;
    // height: 100vh;
    background: #fff;

    img {
      margin-right: 20px;
    }

    .van-cell {
      align-items: center;
      height: 100px;
    }

    // .circle-container {
    //   display: inline-block;
    //   width: 14px;
    //   height: 14px;
    //   background: #ff0000;
    //   border-radius: 50%;
    //   position: relative;
    //   top: -2px;
    // }
  }

  .slider-bar {
    .flex();
    align-items: center;
    line-height: 44px;

    .van-slider {
      width: 60%;
      margin-left: 20px;
    }

    .custom-button {
      // width: 52px;
      padding: 0px 20px;
      color: #fff;
      font-size: 20px;
      line-height: 46px;
      text-align: center;
      background: linear-gradient(360deg, #404040 0%, #878787 100%);
      border-radius: 200px;
    }
  }

  .circle-container {
    display: inline-block;
    width: 14px;
    height: 14px;
    background: #ff0000;
    border-radius: 50%;
    position: relative;
    top: -2px;
  }

  .svg-icon {
    width: 40px;
    height: 40px;
    margin-right: 20px;
    fill: #000;

    :deep(path:last-child) {
      fill: var(--theme-color);
    }
  }
</style>
