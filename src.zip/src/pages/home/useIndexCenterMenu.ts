import SvgSchoolmate from '@/assets/home/schoolmate.svg';
import SvgReturnSchool from '@/assets/home/return-school.svg';
import SvgActivity from '@/assets/home/activity.svg';
import SvgDonate from '@/assets/home/donate.svg';
import SvgYinxiang from '@/assets/icons/shandayinxiang.svg';
import SvgXiaoYouDiTu from '@/assets/server/xiaoyouditu.svg';
import SvgTouXiangShenHe from '@/assets/server/touxiangshenhe.svg';
import SvgHuoDongShenHe from '@/assets/home/huodongshenhe.svg';
import SvgQihan from '@/assets/server/qihan.svg';
import { IdentifyMode, SchoolCode } from '@/constants';
import { useSettingStore } from '@/store/modules/setting';
import { getSchoolCode, getUserStatus } from '@/utils';
import SvgMyInfo from '@/assets/mine/myInfo.svg';
import SvgschoolMateBT from '@/assets/server/schoolMateBT.svg'
import SvgXiaoQing from '@/assets/server/xiaoqing.svg';
import SvgMessage from '@/assets/server/message.svg';
import SvgConnect from '@/assets/server/connect.svg';
import SvgXiaoYouRenZheng from '@/assets/server/xiaoyourenzheng.svg';
//xiaoyourenzheng
/**默认金刚图标 */
const cenLogoListNormal = [
  { label: '校友卡', img: SvgSchoolmate, jump: 'mateCard' },
  { label: '预约返校', img: SvgReturnSchool, jump: 'backSchool' },
  // { label: '活动列表', img: SvgActivity, jump: 'activeList' },
  { label: '我要捐赠', img: SvgDonate, jump: 'donate' },
];

/**成都医学院***/
const cenLogoListCD = [
  { label: '我的名片', img: SvgMyInfo, jump: 'myPerInfoCard' },
  { label: '预约返校', img: SvgReturnSchool, jump: 'backSchool' },
  // { label: '活动列表', img: SvgActivity, jump: 'activeList' },
  { label: '我要捐赠', img: SvgDonate, jump: 'donate' },
];
const cenLogoListSD = [
  { label: '校友卡', img: SvgSchoolmate, jump: 'mateCard' },
  // { label: '印象汕大', img: SvgYinxiang, jump: 'matePictures' },
  { label: '预约返校', img: SvgReturnSchool, jump: 'reserveBackSchoolDate' },
  { label: '活动列表', img: SvgActivity, jump: 'activeList' },
  // { label: '爱心捐赠', img: SvgDonate, jump: 'donate' },
  {
    label: '校友会刊',
    img: SvgQihan,
    jump: 'serviceNews',
    menuMode: '1',
    params: 'schoolmate_journal',
  },
];
// 没启用
// const cenLogoListSDManager = [
//   { label: '活动审核', img: SvgHuoDongShenHe, jump: 'activitiReview' },
//   { label: '印象汕大', img: SvgYinxiang, jump: 'matePictures' },
//   { label: '活动列表', img: SvgActivity, jump: 'activeList' },
//   { label: '爱心捐赠', img: SvgDonate, jump: 'donate' },
// ];
const cenLogoListLN = [
  // { label: '电子校友卡', img: SvgSchoolmate, jump: 'mateCard' },
  { label: '电子校友卡', img: SvgSchoolmate, jump: 'backSchoolAuditEntry' },
  { label: '预约返校', img: SvgReturnSchool, jump: 'backSchool-ln' },
  // { label: '活动列表', img: SvgActivity, jump: 'activeList' },
  { label: '我要捐赠', img: SvgDonate, jump: 'donate' },
  { label: '校友地图', img: SvgXiaoYouDiTu, jump: 'alumni-map' },
];

const cenLogoListLNManager = [
  { label: '头像审核', img: SvgTouXiangShenHe, jump: 'headLogoCheck' },
  { label: '活动审核', img: SvgHuoDongShenHe, jump: 'activitiReview' },
  { label: '校友地图', img: SvgXiaoYouDiTu, jump: 'alumni-map' },
  { label: '校友活动', img: SvgActivity, jump: 'activeList' },
];

/**广东XX学校 */
const cenLogoGuangWenYi = [
  { label: '校友注册', imgPath: 'guangwenyi/xiaoyouzhuce.png', jump: 'type' },
  { label: '校友卡', imgPath: 'guangwenyi/xiaoyouka.png', jump: 'mateCard' },
  { label: '返校预约', imgPath: 'guangwenyi/fanxiaoyuyue.png', jump: 'reserveBackSchoolDate' },
  { label: '值年返校', imgPath: 'guangwenyi/zhinianfanxiao.png', jump: 'groupBackSchool' },
  { label: '爱心捐赠', imgPath: 'guangwenyi/aixinjuanzeng.png', jump: 'donate' },
  { label: '找校友', imgPath: 'guangwenyi/zhaoxiaoyou.png', jump: 'tab/alumni' },
]

/**广东水利电力 */
const cenLogoGuangDongShuiLiDianLi = [
  { label: '校友注册', imgPath: 'guangdongshuilidianli/xiaoyouzhuce.png', jump: 'type' },
  { label: '校友卡', imgPath: 'guangdongshuilidianli/xiaoyouka.png', jump: 'mateCard' },
  { label: '返校预约', imgPath: 'guangdongshuilidianli/fanxiaoyuyue.png', jump: 'reserveBackSchoolDate' },
  { label: '值年返校', imgPath: 'guangdongshuilidianli/zhinianfanxiao.png', jump: 'groupBackSchool' },
  { label: '爱心捐赠', imgPath: 'guangdongshuilidianli/aixinjuanzeng.png', jump: 'donate' },
  // { label: '找校友', imgPath: 'guangwenyi/zhaoxiaoyou.png', jump: 'tab/alumni' },
]

/**乌鲁木齐职业大学 */
const cenLogoWuLuMuQiZhiYeDaXue = [
  { label: '校友注册', imgPath: 'wulumuqizhiyedaxue/xiaoyouzhuce.png', jump: 'type' },
  { label: '校友卡', imgPath: 'wulumuqizhiyedaxue/xiaoyouka.png', jump: 'mateCard' },
  { label: '返校预约', imgPath: 'wulumuqizhiyedaxue/fanxiaoyuyue.png', jump: 'backSchool' },
  // { label: '值年返校', imgPath: 'wulumuqizhiyedaxue/zhinianfanxiao.png', jump: 'backSchool-ln' },
  { label: '爱心捐赠', imgPath: 'wulumuqizhiyedaxue/aixinjuanzeng.png', jump: 'donate' },
  { label: '找校友', imgPath: 'wulumuqizhiyedaxue/zhaoxiaoyou.png', jump: 'tab/alumni' },
]

/**象贤中学 */
const cenLogoXiangXianZhongXue = [
  { label: '校友注册', imgPath: 'xiangxianzhongxue/xiaoyouzhuce.png', jump: 'type' },
  { label: '返校预约', imgPath: 'xiangxianzhongxue/fanxiaoyuyue.png', jump: 'backSchool' },
  { label: '校友会', imgPath: 'xiangxianzhongxue/xiaoyouhui.png', jump: 'showAlumniXX' },  
  { label: '象贤拾忆', imgPath: 'xiangxianzhongxue/xiangxianshiyi.png', jump: 'matePictures' },
  { label: '象贤文创', imgPath: 'xiangxianzhongxue/xiangxianwenchuang.png', jump: 'cultural-product-list' },   
  { label: '我要捐赠', imgPath: 'xiangxianzhongxue/woyaojuanzeng.png', jump: 'donate' }, 
]
const cenLogoBaoTouZhiYe = [
  { label: '校友卡', img: SvgSchoolmate, jump: 'mateCard' },
  { label: '预约返校', img: SvgReturnSchool, jump: 'backSchool' },
  // { label: '活动列表', img: SvgActivity, jump: 'activeList' },
  { label: '校友风采', img: SvgschoolMateBT, jump: 'news',params: 'schoolmate_show_BTZY', path: '' },
];

const cenLogoPeiYingZhongXue = [
  // { label: '校友注册', imgPath: 'peiyingzhongxue/zhuce.jpg', jump: 'type' },
  { label: '校友卡申领', imgPath: 'peiyingzhongxue/xiaoyouka.jpg', jump: 'mateCard' },  
  { label: '返校预约', imgPath: 'peiyingzhongxue/yuyue.jpg', jump: 'backSchool' },
  { label: '值年返校', imgPath: 'peiyingzhongxue/fanxiao.jpg', jump: 'groupBackSchool' },  
  { label: '爱心捐赠', imgPath: 'peiyingzhongxue/juanzeng.jpg', jump: 'donate' }, 
]

const cenLogoLiaoShiFuZhong = [
  { label: '校友卡', img: SvgSchoolmate, jump: 'mateCardAP' },
  { label: '预约返校', img: SvgReturnSchool, jump: 'backSchool' },
  // { label: '活动列表', img: SvgActivity, jump: 'activeList' },
  { label: '我要捐赠', img: SvgDonate, jump: 'donate' },
];

const cenlogoNORegisterPY = [
  { label: '校友认证', imgPath: 'peiyingzhongxue/zhuce.jpg', jump: 'type' },
  // { label: '校友卡', imgPath: 'peiyingzhongxue/schoolMateCard.png', jump: 'mateCardAP' },
  { label: '校友卡申领', imgPath: 'peiyingzhongxue/xiaoyouka.jpg', jump: 'mateCard' },  
  { label: '预约返校', imgPath: 'peiyingzhongxue/yuyue.jpg', jump: 'backSchool' },
  { label: '爱心捐赠', imgPath: 'peiyingzhongxue/juanzeng.jpg', jump: 'donate' },
]

const cenlogoChengDe = [
  { label: '我要捐赠', img: SvgDonate, jump: 'donate' },
  { label: '校友卡', img: SvgSchoolmate, jump: 'mateCardAP' },
  { label: '预约返校', img: SvgReturnSchool, jump: 'backSchool' },
  { label: '通知公告', img: SvgMessage, jump: 'notice' },
  { label: '联系我们', img: SvgConnect, jump: 'contactus' },
  { label: '校友祝福', img: SvgXiaoQing, jump: 'xiaoqing' },
]

const cenlogocenlogoNORegisterCD = [
  { label: '校友认证', img: SvgXiaoYouRenZheng, jump: 'type' },
  { label: '校友卡', img: SvgSchoolmate, jump: 'mateCardAP' },
  { label: '预约返校', img: SvgReturnSchool, jump: 'backSchool' },
  { label: '通知公告', img: SvgMessage, jump: 'notice' },
  { label: '联系我们', img: SvgConnect, jump: 'contactus' },
  { label: '我要捐赠', img: SvgDonate, jump: 'donate' },
]

const cenlogoShenYangYaoKe = [
  { label: '校友卡申领', imgPath: 'guangwenyi/xiaoyouka.png', jump: 'mateCard' },
  { label: '爱心捐赠', imgPath: 'guangwenyi/aixinjuanzeng.png', jump: 'donate' },
  { label: '集体返校', imgPath: 'guangwenyi/fanxiaoyuyue.png', jump: 'reserveBackSchoolDate' },
]

export function useIndexCenterMenu() {
  const cenLogoList = ref<any>([]);
  const settingStore = useSettingStore();

  watch(
    () => settingStore.identifyMode,
    () => {
      cenLogoList.value = getCenterMenuList();
    },
    {
      immediate: true,
    }
  );

  function getCenterMenuList() {
    let schoolCode = getSchoolCode()
    let userStatus = getUserStatus()
    if (schoolCode == SchoolCode.ShanDa) {
      return cenLogoListSD;
      // return settingStore.identifyMode == IdentifyMode.Manage
      //   ? cenLogoListSDManager
      //   : cenLogoListSD; 
    } 
    
    else if (schoolCode == SchoolCode.LiaoShiDa) {
      return settingStore.identifyMode == IdentifyMode.Manage
        ? cenLogoListLNManager
        : cenLogoListLN;
    } 
    
    else if ( schoolCode == SchoolCode.GuangWenYi) {
      // 非游客用户不展示校友注册菜单
      if (userStatus != '04') return cenLogoGuangWenYi.slice(1)
      return cenLogoGuangWenYi
    } 
    else if ( schoolCode == SchoolCode.GuangDongShuiLiXueYuan) {
      // 非游客用户不展示校友注册菜单
      if (userStatus != '04') return cenLogoGuangDongShuiLiDianLi.slice(1)
      return cenLogoGuangDongShuiLiDianLi
    }     
    else if ( schoolCode == SchoolCode.WuLuMuQiZhiYeDaXue) {
      // 非游客用户不展示校友注册菜单
      if (userStatus != '04') return cenLogoWuLuMuQiZhiYeDaXue.slice(1)
      return cenLogoWuLuMuQiZhiYeDaXue
    }

    else if ( schoolCode == SchoolCode.XiangXianZhongXue) {
      // 非游客用户不展示校友注册菜单
      if (userStatus != '04') return cenLogoXiangXianZhongXue.slice(1)
      return cenLogoXiangXianZhongXue
    }    
    
    else if(schoolCode == SchoolCode.ChengDuYiXueYuan){
      return cenLogoListCD
    }

    else if(schoolCode == SchoolCode.BaoTouZhiYeJiShu){
      return cenLogoBaoTouZhiYe
    }
    else if(schoolCode == SchoolCode.PeiYingZhongXue){
      // 非游客用户不展示校友注册菜单
      if (userStatus == '04'){
        return cenlogoNORegisterPY
      }else{
        return cenLogoPeiYingZhongXue
      }
    }
    else if(schoolCode == SchoolCode.LiaoShiFuShuZhongXue){
      return cenLogoLiaoShiFuZhong
    }else if(schoolCode == SchoolCode.ChengDeYiXueYuan){
      if (userStatus == '04'){
        return cenlogocenlogoNORegisterCD
      }else{
        return cenlogoChengDe
      }
    }
    else if(schoolCode == SchoolCode.ShenYangYaoKeDaXue){
      return cenlogoShenYangYaoKe
    }
    
    return cenLogoListNormal;
  }

  return {
    cenLogoList,
  };
}
