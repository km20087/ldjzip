<template>
  <div class="contet">
    <nav-bar title="组织" left-text="" />
    <div class="banner">
      <fix-image
        :src="bannerData"
        :defaultSrc="alumniBanner"
        alt=""
        class="imgs"
        width="750"
        height="350"
      />
      <van-search
        v-model="searchVa"
        show-action
        class="isdi"
        placeholder="请输入搜索关键词"
        @search="onSearch"
      >
        <template #action>
          <div @click="onSearch" class="iasd">搜索</div>
        </template>
      </van-search>
      <van-tabs v-model:active="active" class="cenTab" @change="changgeOt">
        <van-tab v-for="(item, index) in typeList" :key="index" :title="item.otName"></van-tab>
      </van-tabs>
    </div>
    <div class="heiw" v-if="orgList.length > 0">
      <van-index-bar
        :index-list="abcList"
        :sticky-offset-top="topNum"
        :sticky="showsticky"
        :class="recOrgList.length > 0 ? 'maar isua ' : 'maar'"
      >
        <div
          v-for="(item, index) in abcList"
          :key="index"
          class="sdao"
          :class="{ reCla: recOrgList.length > 0, mar40: (index == 0&& recOrgList.length > 0) }"
        >
          <!--           :class="recOrgList.length > 0 ? 'sdao reCla' : 'sdao'" -->
          <van-index-anchor :index="item" />
          <div v-for="(it, ind) in orgList" @click="showInde(it)" :key="ind" class="stPart">
            <van-cell :title="it.groupsName" v-if="it.en === item">
              <template #title>
                <div class="shwo">
                  <fix-image
                    v-if="settingStore.isShowGroupProfilePicture && it.groupsProfilePicture"
                    class="ims2"
                    :src="it.groupsProfilePicture"
                    width="44"
                    height="44"
                    alt="组织头像"
                  />
                  <span class="custom-title">{{ it.groupsName }}</span>
                  <img
                    v-for="(subitem, subindex) in it.icons"
                    :src="picUrl + subitem"
                    alt=""
                    class="asdi"
                    :key="subindex"
                  />
                  <SvgJoined class="tips" v-if='it.isJoin'/>                  
                </div>
                <div class="num">
                  <div class="icon">
                    <div class='head'></div>
                    <div class='body'></div>
                  </div>
                  <div class="number">{{it.numberOfMembers}}</div>
                </div>
              </template>
            </van-cell>
          </div>
        </div>
      </van-index-bar>
    </div>
    <div v-else class="cardList">
      <div class="imsaw">
        <img :src="noneData" alt="" class="ims" />
        <p class="p1">暂无数据~</p>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
import SvgJoined from "@/assets/home/joined.svg";
import noneData from "@/assets/img/noneData.png";
import ApiGroup, { userGroupP, groupListP } from "@/api/group";
import alumniBanner from "@/assets/img/alumniBanner.png";
import { useRouter } from "vue-router";
import { reactive, ref } from "vue";
import { pinyin } from "pinyin-pro";
import { useSettingStore } from "@/store";
import { Dialog } from "vant";
import { SchoolCode } from "@/constants";
import useCache from '@/hooks/useCache'
import { homeSwipePic } from '@/api/home'
import { useGoIdentifyPage } from '@/pages/home/useGoIdentifyPage'
import { getUserStatus } from "@/utils";
import trackPoint from '@/utils/apiTrack';
const { goIdentifyPage,getIdentifyPath } = useGoIdentifyPage()

const settingStore = useSettingStore();

const bannerData = ref("");
const router = useRouter();
const orgList = <any>ref([]);
const recOrgList = <any>ref([]);
interface typeData {
  otId: string;
  otName: string;
}
const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
const stateShow = ref(false);
const listP: groupListP = reactive({
  // groupsType: '',
});
const topNum = ref(443);
const showsticky = ref(false);
const searchVa = ref("");
const active = ref(0);
const typeList: typeData[] = reactive([]);
const abcList: string[] = reactive([]);
const onClickLeft = () => {
  router.back();
};
const onSearch = (val: any) => {
  trackPoint.run('/groups/list',"")
  if (searchVa.value) {
    let a: any = orgList.value.filter((item: any) => {
      return item.groupsName.indexOf(searchVa.value) > -1;
    });
    orgList.value = a.length > 0 ? a : [];
    iniAbc();
  } else {
    inidata();
  }
};
const changgeOt = async () => {
  // listP.groupsType = val;
  console.log(active.value);
  if (active.value > 0) {
    listP.groupsType = typeList[active.value].otId;
  } else {
    // listP = {};
    // Object.assign(listP, {});
    listP.groupsType = "";
  }
  console.log(listP);
  const { data, code, msg } = await ApiGroup.groupsList(listP);
  console.log(data);
  if (code == 200) {
    orgList.value = data.appGroupsVOS;
    recOrgList.value = data.topAppGroups;
    for (let i in recOrgList.value) {
      recOrgList.value[i].en = "*";
    }
    iniAbc();
  }
};
const initOrgList = (val: any) => {
  for (let i in val) {
    val[i].en = "";
    val[i].en = pinyin(val[i].groupsName, { toneType: "none" })
      .slice(0, 1)
      .toUpperCase();
  }
};
const unique6 = (arr: any) => {
  const newArray = Array.from(new Set(arr));
  newArray;
};
const unique3 = (arr: any) => {
  let newArray = arr.filter((item: string, index: number) => {
    return arr.indexOf(item) === index;
  });
  return newArray;
};

const showInde = (val: any) => {
  // return;
  console.log(val);
  router.push({ path: "/orgDetail", query: { groupsId: val.groupsId } });
};
const initType = async () => {
  const { data, code, msg } = await ApiGroup.getGroupType({});
  if (data.length > 0) {
    for (let i in data) {
      typeList.push({ otId: data[i].otId, otName: data[i].otName });
    }
    typeList.unshift({ otId: "", otName: "全部" });
  }
};
const iniAbc = () => {
  initOrgList(orgList.value);
  let arr1: string[] = [];
  for (let i in orgList.value) {
    arr1.push(orgList.value[i].en);
  }
  arr1 = unique3(arr1);
  abcList.length = 0;
  if (recOrgList.value.length > 0) abcList.push("*");
  for (let a in arr1) {
    abcList.push(arr1[a]);
  }
  orgList.value.unshift(...recOrgList.value);
  console.log(orgList.value);
};
const inidata = async () => {
  const { data, msg, code } = await ApiGroup.groupsList({});
  if (code == 200) {
    orgList.value = data.appGroupsVOS;
    // recOrgList.value = data.appGroupsVOS.slice(0, 2);
    recOrgList.value = data.topAppGroups;
    for (let i in recOrgList.value) {
      recOrgList.value[i].en = "*";
    }
  }

  iniAbc();
  stateShow.value = true;
};
onBeforeMount(() => {
  useCache({
    key: 'ORGANIZATION_BANNER',
    service: homeSwipePic,
    params: {
      imageType: 'ORGANIZATION_BANNER'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        bannerData.value = data?.images?.[0]?.fileAddress ?? ''
      }
    }
  })

  let userStatus = getUserStatus()
  if (settingStore.isSchoolmateMode && userStatus == "04") {
    goIdentifyPage().then((res)=>{
      if(res)router.push({path:getIdentifyPath()})
    })
    return
  }
  initType();
  inidata();
});
</script>
<style lang="less" scoped>
.cardList {
  padding: 0 30px;
  .imsaw {
    width: 100%;
    height: 100%;
    text-align: center;
    margin-top: 200px;
    .ims {
      width: 400px;
      height: 270px;
    }
    .p1 {
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #999999;
    }
    .but {
      margin-top: 40px;
    }
  }
}
.mar40 {
  border-bottom: 20px solid #f5f5f5;
  // width: 100%;
  // height: 20px;
  // background-color: #f5f5f5;
}
.maar {
  // background-color: #f5f5f5;
  /deep/.van-index-anchor {
    color: #999999;
    font-size: 24px;
  }
  div:nth-child(2).reCla {
    font-size: 0px;
    // margin-bottom: 40px;
    /deep/.van-index-anchor {
      font-size: 0px;
      background: url("@/assets/img/start.png") no-repeat;
      background-size: 25px;
      background-position: 3% 40%;
    }
  }
  .sdao:nth-last-child(1) {
    margin-bottom: 100px !important;
  }
  /deep/.van-cell__title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-bottom: 20px;
    box-sizing: border-box;
    border-bottom: 1px solid #e5e5e5;
  }

  .stPart {
    width: 100%;
    // display: flex;
    // align-items: center;
    // justify-content: space-between;
    .shwo {
      display: flex;
      align-items: center;
    }

    .ims2 {
      margin-right: 10px;
      width: 44px;
      height: 44px;
      border-radius: 50%;
    }

    .tips {
      margin-left: 10px;
      width: 76px;
      height: 34px;
    }
    .num {
      // position: absolute;
      // right: 90px;
      display: flex;
      width: 60px;
      align-items: center;

      .icon {
        display: flex;
        flex-direction: column;
        align-items: center;
        .head {
          width: 10px;
          height: 10px;
          background: #c6c6c6;
          border-radius: 50%;
        }
        .body {
          margin-top: 3px;
          width: 18px;
          height: 9px;
          background: #c6c6c6;
          border-radius: 5px;
        }
      }
      .number {
        margin-left: 5px;
        font-size: 22px;
        color: #999999;
      }
    }
    .asdi {
      width: 36px;
      height: 36px;
      margin-left: 5px;
    }
    /deep/ .van-cell__title {
      display: flex;
      align-items: center;
      // width: 100%;
    }
  }
}
/deep/ .van-index-bar__index {
  margin-bottom: 10px;
}
.contet {
  width: 100%;
  height: 100%;
  background-color: #ffffff;
  // overflow: hidden;
  .banner {
    position: relative;
    .imgs {
      width: 750px;
      height: 350px;
    }
  }
  .custom-title {
    font-size: 28px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    color: #666666;
  }
  .cenTab {
    position: absolute;
    top: 265px;
    width: 100%;
    height: 100px;
    line-height: 100px;
    box-shadow: 1px 2px 40px 0px rgba(0, 0, 0, 0.1);
    border-radius: 40px 40px 0px 0px;
    background: #fff;
    overflow: hidden;
  }
  .mar20 {
    margin-bottom: 20px;
  }
  .heiw1 {
  }
  .heiw {
    width: 100%;
    height: 70%;
    margin-bottom: 50px;
    overflow-y: scroll;
  }
  .stPart1 {
    width: 100%;
    .ims2 {
      margin-right: 10px;
      width: 44px;
      height: 44px;
      border-radius: 50%;
    }

    .tips {
      position: absolute;
      right: 50px;
      font-size: 24px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #999999;
    }
    .asdi {
      width: 24px;
      height: 28px;
      margin-left: 5px;
    }
    /deep/ .van-cell__title {
      display: flex;
      align-items: center;
      // width: 100%;
    }
  }
  .isdi {
    position: absolute;
    top: 160px;
    left: 30px;
    width: 690px;
    height: 80px;
    border-radius: 40px;
    --van-search-background-color: rgba(0, 0, 0, 0.5);
    --van-search-content-background-color: none;
    --van-search-action-padding: 5px;
    --van-search-action-text-color: rgba(255, 255, 255, 0.8);
    --van-search-left-icon-color: #fff;
    --van-field-input-text-color: #fff;
    --van-active-color: none;
    .iasd {
      background: rgba(255, 255, 255, 0.1);
      padding: 0 30px;
      border-radius: 40px;
    }
  }
  .bomar {
    // width: 100%;
    // height: 100px;
    // position: fixed;
    // bottom: 0px;
    // margin-top: 80px;
  }
  .isua {
    /deep/.van-index-bar__index:nth-child(1) {
      font-size: 0px;
      text-align: center;
      background: url("@/assets/img/blueStart.png") no-repeat;
      background-size: 20px;
      background-position: 70% 50%;
      // color: red;
    }
  }
  // /deep/ .van-index-bar
  /deep/ .van-index-bar {
    padding-bottom: 40px !important;
    position: relative;

    .van-index-bar__sidebar {
      top: 65%;
      text-align: center;
      // top: calc(50vh-20px);
      // font-size: 20px;
    }
    .van-index-bar__index {
      font-size: 20px;
    }
    // /deep/.van-index-bar__index:nth-child(1) {
    //   font-size: 0px;
    //   text-align: center;
    //   background: url('@/assets/img/blueStart.png') no-repeat;
    //   background-size: 20px;
    //   background-position: 70% 50%;
    //   // color: red;
    // }
  }
}
</style>
