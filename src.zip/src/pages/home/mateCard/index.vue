<template>
  <van-sticky>
    <van-nav-bar title="校友卡" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="gray-bg">
    <div style="padding: 15px; background: #fff">
    <ECard v-if="isShowECard" :per-info="perInfo"/>    
    </div>
    <div class="QRcode-area">
      <div class="QRcode-bg">
        <van-image :src="codeUrl" width="237.5" height="205" />
      </div>
    </div>
  </div>

</template>
<script lang="ts" setup>
import Api from '@/api/home';
import { Toast } from 'vant';
import { SchoolCode } from '@/constants';
import { useLoadECard } from '@/pages/home/useLoadECard';
  import { getSchoolCode } from '@/utils';
  import { useMyInfo } from '@/pages/home/useMyInfo';

const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
  const schoolCode = getSchoolCode();
const onClickLeft = () => history.back();
  const { perInfo, initMy } = useMyInfo();
let codeUrl = ref('');

  const { ECard, isShowECard } = useLoadECard();

const getQRcode = async () => {
  try {
    let res = (await Api.getMateQRcode()) as unknown as BlobPart;
    const blob = new Blob([res]);
    codeUrl.value = window.URL.createObjectURL(blob);
  } catch (error) {
    console.log(error);
  }
};

onMounted(()=>{
  initMy()
  getQRcode();
})
// getQRcode();
</script>
<style lang="less" scoped>
.QRcode-area {
  .QRcode-bg {
    padding: 53px 49px;
    margin: 128px 88px;
    width: 574px;
    height: 566px;
    background: url(@/assets/img/QRcode_bg@3x.png);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
  }
}
</style>