<template>
  <div>
    <nav-bar-2 left-arrow @click-left="goBack" :title="title" />
    <div class="con">
      <img :src="remen" alt="" v-if="type == '1'" class="ims">
      <img :src="lianmingka_1" alt="" v-if="type == '2' && showRange == '1'" class="ims" @click="sureSelect">
      <img :src="lianmingka_2" alt="" v-if="type == '2' && showRange == '2'" class="ims" @click="sureSelect2">
      <img :src="lianmingka_3" alt="" v-if="type == '2' && showRange == '3'" class="ims1" >
      <img :src="lianmingka_4" alt="" v-if="type == '2' && showRange == '4'" class="ims1" >
      <div class="su1" v-if="showSu1">
        <van-icon name="success" color="#409EFF" size="0.5rem"/>
      </div>
      <div class="button1" @click="nextImg('2')">

      </div>      
      <div class="button2" @click="nextImg('3')">

      </div>          
      <div class="button3" @click="nextImg('4')">

      </div>                
    </div>
  </div>
</template>
<script lang="ts" setup>
import remen from '@/assets/schoolmateCode/remen.png'
import lianmingka_1 from '@/assets/schoolmateCode/lianmingka_1.png'
import lianmingka_2 from '@/assets/schoolmateCode/lianmingka_2.png'
import lianmingka_3 from '@/assets/schoolmateCode/lianmingka_3.png'
import lianmingka_4 from '@/assets/schoolmateCode/lianmingka_4.png'
import { useGoBack } from '@/hooks/useGoBack'

const { goBack } = useGoBack()
const $route = useRoute();
const title = ref('')
const type = ref('')
const showSu1 = ref(false)
const showRange = ref('1')

const sureSelect = () => { 
  showSu1.value = true
}

const sureSelect2 = () => {
  
}

const nextImg = (val:string) => { 
  showRange.value = val
  showSu1.value = false
}

onMounted(() => { 
  if (!!$route.query?.type)type.value = $route.query?.type as string
  if (type.value == '1') {
    title.value = '校友福利聚合站'
  } else if (type.value == '2') { 
    title.value = '校园e码通'
  }
})
</script>
<style lang="less" scoped>
.con{
  width: 100vw;
  // height: calc(100vh - var(--van-nav-bar-height));
  position: relative;
  .ims{
    width: 100%;
    height: 100%;
  }
  .ims1{
    width: 100%;
    height: auto;
  }
  .su1{
    position: absolute;
    right: 5%;
    top: 16.5%;
  }
  .button1{
    position: absolute;
    width: 92vw;
    height: 6vh;
    // right: 5%;
    // top: 16.5%;
    // background-color: #111;
    top: 41%;
    left: 50%;
    transform: translate(-50%,-50%);  
  }
  .button2{
    position: absolute;
    width: 66vw;
    height: 5vh;
    // right: 5%;
    // top: 16.5%;
    // background-color: #111;
    top: 61%;
    left: 50%;
    transform: translate(-50%,-50%); 
  }
  .button3{
    position: absolute;
    width: 92vw;
    height: 6vh;
    // right: 5%;
    // top: 16.5%;
    // background-color: #111;
    // top: 121%;
    bottom: 3vh;
    left: 50%;
    transform: translate(-50%,-50%);      
  }
}
</style>