<template>
  <div class="card-cont">
    <nav-bar-2 left-arrow @click-left="goBack" title="校友卡" />
    <div class="top-bg">
      <fix-image :src="bannerData" class="bg-img" />
    </div>
    <div class="card-main">
      <div class="card-list">
        <div style="border: 1px solid #eee; border-radius: 8px">
          <div class="card-tit">
            <SvgCardTitle class="card-title-bg" />
            <span>电子校友卡</span>
          </div>
          <div class="card-msg">
            <div class="card-wrap">
              <img class="card-bg" :src="cardImg" />
              <div class="info-wrap">
                <img class="avatar" :src="DefaultAvatar" />
                <ul v-if="schoolCode == SchoolCode.ShanDa">
                  <template v-if="userInfo.schoolmateType == '2'">
                    <li>姓名：某某某</li>
                    <li>部门：某某部门</li>
                    <li>职务：莫某职务</li>
                    <li>入职时间：某某时间</li>
                  </template>
                  <template>
                    <li>姓名：某某某</li>
                    <li>院系：某某院系</li>
                    <li>专业：莫某专业</li>
                    <li>年级：某某年级</li>
                  </template>
                </ul>
                <ul v-else>
                  <li>姓名：某某某</li>
                  <li>学院：某某学院</li>
                  <li>专业：某某专业</li>
                  <!-- <li>班级：某某班级</li> -->
                </ul>
              </div>
            </div>
            <span>{{ context }}</span>
          </div>
          <div class="apply-btn">
            <span @click="toApply">立即申请</span>
          </div>
        </div>
      </div>
    </div>
    <van-popup v-model:show="showTips" round :style="{ 'overflow-y': 'unset' }">
      <div class="tips-cont">
        <SvgCardLing class="ling-pic" />
        <span class="tit">温馨提示</span>
        <p class="txt">请您妥善保管本校友卡 本卡不得出借、转让、转赠、售卖 本卡等同于实体校友卡</p>
        <div>
          <van-button
            round
            color="var(--theme-color)"
            plain
            class="pup-btn"
            @click="showTips = false"
            >取消</van-button
          >
          <van-button
            round
            type="primary"
            color="var(--theme-color)"
            class="pup-btn"
            @click="confirmJump"
            >我已知晓</van-button
          >
        </div>
      </div>
    </van-popup>
  </div>
</template>
<script setup lang="ts">
  import { useGoBack } from '@/hooks/useGoBack'
  import { getSchoolCode, getRealFilePath, getUserInfo } from '@/utils'
  import SvgCardLing from '@/assets/img/card_ling.svg'
  import SvgCardTitle from '@/assets/img/card_title.svg'
  import { SchoolCode } from '@/constants'
  import useCache from '@/hooks/useCache'
  import { homeSwipePic } from '@/api/home'
  import DefaultAvatar from '@/assets/mine/default-avatar.png'

  const userInfo = JSON.parse(getUserInfo() || '{}')

  const schoolCode = getSchoolCode()
  const context = computed(() => {
    if (!schoolCode) return ''
    let textObj: any = {
      [SchoolCode.ShanDa]:
        '面向汕头大学1981级以来全日制专科、本科、研究生毕业生（含汕头医学专科学校毕业生）发放。',
      [SchoolCode.GuangWenYi]:
        '面向广东XX学校(含原华南人民文学艺术学院、华南文艺业余大学、华南文艺成人学院、广东省旅游职业技术学校有关院、校、系、科)学习过的学生及工作过的教职员工发放。',
      [SchoolCode.WuLuMuQiZhiYeDaXue]: '面向乌鲁木齐职业大学学习过的学生及工作过的教职工发放。',
    }
    return textObj[schoolCode]
  })

  let bannerData = ref('')
  let showTips = ref<boolean>(false)
  const { goBack } = useGoBack()
  const router = useRouter()
  const toApply = (): void => {
    showTips.value = true
  }
  const confirmJump = (): void => {
    router.push({ name: 'mateCardAP' })
  }
  const cardImg = ref('')
  onMounted(() => {
    useCache({
      key: 'SCHOOLMATE_CARD_BACKGROUND',
      service: homeSwipePic,
      params: {
        imageType: 'SCHOOLMATE_CARD_BACKGROUND',
      },
      callback: ({ code, data, mag }: any) => {
        if (code == 200 && data.images.length) {
          bannerData.value = getRealFilePath(data.images[0].fileAddress)
        }
      },
    })

    if (schoolCode == SchoolCode.ShanDa && userInfo.schoolmateType == '2') {
      useCache({
        key: 'CARD_STYLE_PIC_TEACHER',
        service: homeSwipePic,
        params: {
          imageType: 'CARD_STYLE_PIC_TEACHER',
        },
        callback: ({ code, data, mag }: any) => {
          if (code == 200 && data?.images?.length) {
            cardImg.value = getRealFilePath(data.images[0].fileAddress)
          }
        },
      })
    } else {
      useCache({
        key: 'CARD_STYLE_PIC',
        service: homeSwipePic,
        params: {
          imageType: 'CARD_STYLE_PIC',
        },
        callback: ({ code, data, mag }: any) => {
          if (code == 200 && data?.images?.length) {
            cardImg.value = getRealFilePath(data.images[0].fileAddress)
          }
        },
      })
    }
  })
</script>
<style lang="less" scoped>
  .card-cont {
    min-height: 100vh;
    background: #f5f5f5;

    .top-bg {
      .bg-img {
        width: 100vw;
        height: 600px;
      }
    }

    .card-main {
      padding: 32px;

      .card-list {
        width: 100%;
        background: #fff;
        border-radius: 16px;
        margin-top: 30px;
        padding: 10px;
        box-shadow: 2px 2px 30px 2px rgba(172, 125, 82, 0.14);

        .card-tit {
          text-align: center;
          margin-top: -10px;
          margin-bottom: 10px;
          position: relative;
          z-index: 1;
          .card-title-bg {
            position: absolute;
            top: -16.5px;
            z-index: -1;
          }

          span {
            display: inline-block;
            width: 351px;
            height: 66px;
            margin-top: -33px;
            background-repeat: no-repeat;
            background-position: center center;
            background-size: cover;
            color: #fff;
            font-size: 32px;
            line-height: 66px;
          }
        }
      }

      .card-msg {
        display: flex;
        padding: 10px;
        .card-wrap {
          margin: 0 10px 0 0;
          width: 300px;
          height: 188px;
          position: relative;
          z-index: 0;
          .card-bg {
            position: absolute;
            left: 0;
            top: 0;
            width: 300px;
            height: 188px;
            z-index: -1;
            border-radius: 10px;
          }
          .info-wrap {
            width: 300px;
            margin: 60px 0 0 20px;
            display: flex;
            flex-direction: row;
            .avatar {
              flex: 0 0 auto;
              width: 70px;
              height: 100px;
            }
            ul {
              flex: 1;
              list-style: none;
              font-size: 10px;
              color: #fff;
              transform: scale(0.6) translate(-60px, -50px);
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
              li {
                margin: 8px 0 0;
                &:first-of-type {
                  margin: 0;
                }
              }
            }
          }
        }

        span {
          font-size: 24px;
        }
      }

      .apply-btn {
        text-align: center;
        padding-top: 30px;
        padding-bottom: 40px;

        span {
          padding: 20px 50px;
          background: var(--theme-color-0-2);
          color: var(--theme-color);
          border-radius: 50px;
          font-size: 32px;
        }
      }
    }

    .tips-cont {
      width: 600px;
      height: 481px;
      background-image: linear-gradient(180deg, var(--theme-color-0-4) 0%, #fff 25%),
        radial-gradient(circle at 580px 60px, var(--theme-color-0-6) 15%, var(--theme-color-0-2) 8%),
        radial-gradient(circle at 20px 20px, var(--theme-color-0-2) 10%, #fff 0%);
      // background-size: contain;
      display: flex;
      flex-direction: column;
      align-items: center;
      border-radius: 30px;

      .ling-pic {
        margin-top: -60px;
        background-image: linear-gradient(
          180deg,
          var(--theme-color) 48%,
          var(--theme-color-0-2) 85%
        );
        border-radius: 50%;
      }

      .tit {
        font-size: 36px;
        line-height: 82px;
        font-weight: 500;
      }

      .txt {
        width: 80%;
        font-size: 28px;
        color: #333333;
        text-align: center;
        line-height: 44px;
        font-weight: 400;
      }

      .pup-btn {
        width: 240px;

        &:first-child {
          margin-right: 40px;
        }
      }
    }
  }
</style>
