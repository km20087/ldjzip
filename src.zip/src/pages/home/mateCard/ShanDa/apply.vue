<template>
  <div class="apply-page">
    <nav-bar-2 left-arrow @click-left="goBack" title="校友卡申请" />
    <div  class="up-bar noBotP">
      <div class="card-bg" ref="cardBG">
        <div class="user">
          <fix-image
            class="header"
            :src="detail.userProfilePicture"
            object-fit="fill"
            v-if="detail.userProfilePicture"
          ></fix-image>

          <van-image class="header" :src="defaultSrc" v-else />
          <ul v-if="schoolCode == SchoolCode.ShanDa">
            <template v-if="userInfo.schoolmateType == '2'">
              <li>姓名：{{ detail.username }}</li>
              <li>部门：{{ detail.jobDepartment }}</li>
              <li>职务：{{ detail.jobTitle }}</li>
              <li>入职时间：{{ detail.jobDuration }}</li>
              <li v-if="detail.userNO">编号：{{ detail.userNO }}</li>
            </template>
            <template v-else>
              <li>姓名：{{ detail.username }}</li>
              <li>院系：{{ detail.collegeName }}</li>
              <li>专业：{{ detail.majorName }}</li>
              <li>年级：{{ detail.schoolStartYear }}</li>
              <li v-if="detail.userNO">编号：{{ detail.userNO }}</li>
            </template>
          </ul>
          <ul v-else-if="schoolLevel == '2'">
            <!-- <li>姓名：{{ detail.username }}</li> -->
            <li>
              <div class="typeName">
                姓名：
              </div>
              <div class="perInfo">
                {{ detail.username }}
              </div>
            </li>
            <!-- <li>学院：{{ detail.collegeName }}</li> -->
            <li>
              <div class="typeName">
                {{schoolCode == SchoolCode.BaoTouZhiYeJiShu?"系部：":"学院："}}
              </div>
              <div class="perInfo">
                {{ detail.collegeName }}
              </div>
            </li>
            <!-- <li>专业：{{ detail.majorName }}</li> -->
            <li>
              <div class="typeName">
                专业：
              </div>
              <div class="perInfo">
                {{ detail.majorName }}
              </div>
            </li>            
            <li v-if="schoolCode == SchoolCode.GuangWenYi">校友编号：{{ detail.userNO }}</li>
            <!-- <li>班级：{{ detail.classesName }}</li> -->
          </ul>
          <ul v-else-if="schoolLevel == '1'">
            <li>姓名：{{ detail.username }}</li>
            <!-- <li>{{schoolConfig.education}}：{{ detail.education }}</li> -->
            <li>{{schoolConfig.schoolEndYear}}：{{ userInfo.schoolEndYear }}</li>
            <li>{{schoolConfig.class}}：{{ userInfo.classesName }}</li>
            <li class="NO" v-if="schoolCode == SchoolCode.LiaoShiFuShuZhongXue && !!detail.userNO">您是第{{detail.userNO}}位申请校友卡的校友</li>
          </ul>
        </div>
      </div>
      <div class="switch-btn" @click="switchShow = true">
        <van-image :src="swtBtn" width="80" height="15"></van-image>
      </div>
      <div v-if="schoolCode == SchoolCode.ShanDa && detail.auditStatus == '1'" class="SDtime">
          <p class="sii">{{timeNow}}</p>
      </div>        
    </div>
    <div :class="(xiaoyouma || lianmingka || biyeji)?'down-bar noTopP':' down-bar'">
      <template v-if="!isGuangWenYi()">
        <div class="title">上传个人照片</div>
        <div class="upload-area" v-if="detail.auditStatus !== '1'">
          <compress-uploader v-model="fileList" max-count="1" :after-read="afterRead">
            <div class="up-pic">
              <van-image :src="upBtn" width="82" height="94"></van-image>
              <span>点击上传照片( 图片规格仅限jpg,jpeg,png)</span>
            </div>
          </compress-uploader>
        </div>
      </template>
      <ul class="upload-explain" v-if="detail.auditStatus !== '1' && !isGuangWenYi()">
        <li>上传说明：</li>
        <li>· 上传标准证件照（5:7）</li>
        <li>· 正面照片，清晰、免冠、表情正常</li>
      </ul>
      <ul class="upload-explain" v-if="detail.auditStatus == '1' && !(xiaoyouma || lianmingka || biyeji)" style="padding-top: 10px">
        <li>注意事项：</li>
        <li>· 电子校友卡不可转让、转赠、借予他人使用</li>
        <li>· 请您妥善保管本校友卡</li>
      </ul>
      <div class="status-tip" v-if="detail.auditStatus == '0' || detail.auditStatus == '2'">
        <img :src="wicon" class="wicon" />
        <span v-if="detail.auditStatus == '0'">已提交，请耐心等待审核</span>
        <span v-else-if="detail.auditStatus == '2'"
          >已拒绝，拒绝原因：{{ detail.rejectReason }}</span
        >
      </div>
      <div class="receive-btn" v-if="detail.auditStatus !== '1'">
        <van-button
          @click="goBack"
          round
          type="primary"
          color="var(--theme-color)"
          style="width: 135px"
          v-if="detail.auditStatus == '0'"
          >返 回</van-button
        >
        <van-button
          @click="confirmApply"
          round
          type="primary"
          color="var(--theme-color)"
          style="width: 135px"
          v-else-if="detail.auditStatus == '2'"
          >重新申请</van-button
        >
        <van-button
          @click="confirmApply"
          round
          type="primary"
          color="var(--theme-color)"
          style="width: 135px"
          v-else
          >确认领取</van-button
        >
      </div>
    <div v-if="detail.auditStatus == '1' && (xiaoyouma || lianmingka)" class="center-bar">
        <div class="part" v-if="lianmingka" @click="jumpEcardUrl()">
          <Svglianming class="svg-icon"/>
          <div class="title-svg">
            联名卡申领
          </div>
        </div>
        <div class="part" v-if="xiaoyouma" @click="getQrcode()">
          <Svgxiaoyouma class="svg-icon" />
            <div class="title-svg">
              校友码
            </div>
        </div>
    </div>
    <div class="hot-act" v-if="detail.auditStatus == '1' && biyeji">
        <div class="hot-title">
          <img :src="huobao"  class="hot-img" />
          <div class="title">
            热门活动
          </div>
        </div>
    </div>
    <div class="gradutationBanner"  v-if="detail.auditStatus == '1' && biyeji">
        <fix-image :src="gradutationBanner" @click="jumpWeChat()" class="banner-img" />
    </div>        
      <div class="receive-btn" v-if="detail.auditStatus == '1'">
        <van-button
          @click="goBack"
          round
          type="primary"
          color="var(--theme-color)"
          style="width: 135px"
          >返 回</van-button
        >
      </div>   
    </div>     
    <van-popup v-model:show="switchShow" position="bottom">
      <div class="switch-cont">
        <div class="switch-tit">请选择校友卡</div>
        <div class="switch-pick">
          <div class="pick-li" v-for="(item, index) in stylePicList" :key="index">
            <div class="name">校友卡{{ index + 1 }}</div>
            <fix-image :src="item" @click="switchBg(item)" class="list-img" />
          </div>
        </div>
      </div>
    </van-popup>
    <van-image-preview v-model:show="qrPre" :images="qrImg" :showInde="false">
      <template #image="{ src }">
        <img :src="src" alt="" class="ims">
      </template>
    </van-image-preview>
  </div>
</template>
<script setup lang="ts">
  import Api from '@/api/home'
  import FILE from '@/api/uploadfile'
  import topbg from '@/assets/mine/default-avatar.png'
  import swtBtn from '@/assets/img/switch_btn@2x.png'
  import upBtn from '@/assets/img/upload_btn@2x.png'
  import wicon from '@/assets/img/warning_icon@2x.png'
  import { useGoBack } from '@/hooks/useGoBack'
  import { Toast } from 'vant'
  import { SchoolCode } from '@/constants'
  import { getSchoolCode, getUserInfo,isHasButton,getToken,getRealFilePath } from '@/utils'
  import useCache from '@/hooks/useCache'
  import { homeSwipePic } from '@/api/home'
  import { isGuangWenYi } from '@/utils/customizedType'
  import defaultHead from '@/assets/mine/default-head@2x.png'
  import defaultHeadMan from '@/assets/mine/default-user-man.jpg'
  import male from '@/assets/mine/male.png'
  import {schoolShowConfig,zhongxueConfig} from "@/utils/schoolLevelShow"
  import Svglianming from "@/assets/icons/lianming.svg"
  import Svgxiaoyouma from "@/assets/icons/xiaoyouma.svg"
  import huobao from '@/assets/img/huobao.png'
  import ApiSer from "@/api/appService";
  import { useRouter } from 'vue-router'
  import { toSecretZHC } from '@/api/servive';
const schoolCode = getSchoolCode()
  const router = useRouter()
  interface obj {
    id: string
    username: string
    collegeName: string
    classesName: string
    schoolStartYear: string
    userProfilePicture: string
    backgroundPicture: string
    majorName: string
    auditStatus: string
    rejectReason: string
    userNO?: string
    jobDepartment?: string
    jobTitle?: string
    jobDuration?: string
    education?:string
  }

  const { goBack } = useGoBack()
  let cardBG = ref()
  const userInfo = JSON.parse(getUserInfo() || '{}')
  console.log('userInfo', userInfo)
  console.log('userInfo.schoolmateType',userInfo.schoolmateType)
  const stylePicList = ref<string[]>([])
  const schoolLevel = ref('')
  const schoolConfig = <any>ref({})
  const SDtimeF = <any>ref(null)
  const timeNow = <any>ref(null)

  const xiaoyouma = ref(true)
  const lianmingka = ref(true)
  const biyeji = ref(true)
  const qrImg = ref<string[]>([])
  const qrPre = ref(false)

  let detail = ref<Partial<obj>>({
    username: '',
    collegeName: '',
    schoolStartYear: '',
    education:'',
  })
  let fileList = ref<File[] | any>([])
  let params = ref<Partial<obj>>({})
  let switchShow = ref(false)
  const defaultSrc = <any>ref()
  const gradutationBanner = ref<string>('')
  const getList = async () => {
    let { code, data, msg } = await Api.getCardList({})
    if (code == 200) {
      detail.value = data
      console.log('getList--detail.value',detail.value)
      if (isGuangWenYi() && !detail.value.userProfilePicture) {
        defaultSrc.value = defaultHead
        // if (userInfo.gender === '0') {
        //   defaultSrc.value = defaultHead
        // } else {
        //   defaultSrc.value = defaultHeadMan
        // }
      } else {
        defaultSrc.value = topbg
      }
    } else {
      Toast(msg)
    }
  }

  const initSDTime = ()=>{
    SDtimeF.value = setInterval(()=>{
      let date1 = new Date()
      timeNow.value = date1.getFullYear() +"年"+ Number(date1.getMonth()+1) + "月" + date1.getDate()+"日 "+ date1.getHours() + ":" + date1.getMinutes() + ":" + date1.getSeconds()
    },1000)
  }

  const switchBg = async (p: any) => {
    let { code, msg } = await Api.updateCardbg({ id: detail.value.id, backgroundPicture: p })
    if (code == 200) {
      Toast('操作成功！')
      switchShow.value = false
    } else {
      Toast(msg)
    }
    getList()
  }

  //上传图片
  const afterRead: any = async (file: any) => {
    let formData1 = new FormData()

    formData1.append('file', file.file)
    // formData.append('flag', 'Y');//加密上传
    file.status = 'uploading'
    file.message = '上传中...'
    await FILE.uploadFile(formData1)
      .then((res) => {
        if (res.code == 200) {
          file.status = ''
          file.message = ''
          nextTick(() => {
            if (
              res.data.tokenUrl &&
              res.data.tokenUrl == '' &&
              res.data.tokenUrl == undefined &&
              res.data.tokenUrl == null
            ) {
              params.value.userProfilePicture = res.data.tokenUrl as string
            } else {
              params.value.userProfilePicture = res.data.uploadUrl as string
            }
          })

          Toast.success('上传成功')
        } else {
          file.status = 'failed'
          file.message = '上传失败'
          Toast.fail(res.msg)
        }
      })
      .catch((err) => {
        file.status = 'failed'
        file.message = '上传失败'
        Toast.fail(`上传失败：${err}`)
      })
  }

  const jumpEcardUrl = () =>{
    router.push({ path: "/demoImg", query: {type:"2"} })
  } 

  const confirmApply = async () => {
    params.value.id = detail.value.id
    params.value.backgroundPicture = detail.value.backgroundPicture
    let { code, msg } = await Api.cardapply(params.value)
    if (code == 200) {
      Toast('已提交，请耐心等待审核')
      getList()
    } else {
      Toast(msg)
    }
  }

  const getQrcode = async () =>{
    console.log('getQrcode')
    router.push({path:"/qrcodeShow"})
    let {data,msg,code} = await ApiSer.returnQR({})
    if(code == 200){
      qrImg.value = []
      qrImg.value.push(data)
      qrPre.value = true
    }else{
      Toast.fail(msg)
    }
  }

  const jumpWeChat = async ()=>{
    // window.location.href="https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx5c0732d92f5fd5a1&redirect_uri=https%3A%2F%2Fapp.xiaoyuan.ccb.com%2Fvisitor%2FnewPage%2FportalpageH5%2Findex.html&response_type=code&scope=snsapi_base&state=1#wechat_redirect"
    router.push({ path: "/demoImg", query: {type:"1"} })
  }
  watch([stylePicList, detail], async ([newStylePicList, newDetail]) => {
    await nextTick()
    let { auditStatus, backgroundPicture } = newDetail
    let fileList = !auditStatus && newStylePicList?.length ? newStylePicList[0] : backgroundPicture
    // cardBG.value.style.backgroundImage = `url(${import.meta.env.VITE_APP_PIC_BASE_URL + fileList})`
    console.log('stylePicList', getRealFilePath(fileList))
    cardBG.value.style.backgroundImage = `url(${getRealFilePath(fileList)})`
      console.log(' cardBG.value.style', cardBG.value.style)

  })
onBeforeMount(()=>{
   if (schoolCode == SchoolCode.GuangWenYi){
    useCache({
      key: 'graduationBanner',
      service: homeSwipePic,
      params: {
        imageType: 'graduationBanner'
      },
      callback: ({code, data, msg}: any) => {
        if (code == 200) {
          if (data.images.length > 0) {
            // eCardBg.value = BaseFileUrl + data.images[0].fileAddress
            gradutationBanner.value =data.images[0].fileAddress
          }
        }
      }
    })  
   }
})
  onMounted(async () => {
    schoolLevel.value = schoolShowConfig() as string
    console.log('schoolLevel.value',schoolLevel.value)
    schoolConfig.value =  zhongxueConfig()
    getList()
    // if(schoolCode == SchoolCode.ShanDa)initSDTime()
    // xiaoyouma.value = isHasButton('APP_RETURN_QR')
    // lianmingka.value = isHasButton('lianmingka')
    // biyeji.value = isHasButton('APPZHC')
    // console.log(xiaoyouma.value,lianmingka.value,biyeji.value)

    if (schoolCode == SchoolCode.ShanDa && userInfo.schoolmateType == '2') {
      useCache({
        key: 'CARD_STYLE_PIC_TEACHER',
        service: homeSwipePic,
        params: {
          imageType: 'CARD_STYLE_PIC_TEACHER',
        },
        callback: ({ code, data, mag }: any) => {
          if (code == 200 && data.images.length) {
            stylePicList.value = data.images.map((item: ImageInfo) => item.fileAddress)
          }
        },
      })
    } else {
      useCache({
        key: 'CARD_STYLE_PIC',
        service: homeSwipePic,
        params: {
          imageType: 'CARD_STYLE_PIC',
        },
        callback: ({ code, data, mag }: any) => {
          if (code == 200 && data.images.length) {
            stylePicList.value = data.images.map((item: ImageInfo) => item.fileAddress)
          }
        },
      })
    }
  })
  onUnmounted(()=>{
    if(!!SDtimeF.value){
      clearInterval(SDtimeF.value)
    }
  })
</script>
<style lang="less" scoped>
  .apply-page {
    background: #f3f3f3;
    min-height: 100vh;

    .up-bar {
      background: linear-gradient(179deg, var(--theme-color-0-2) 0%, rgba(255, 245, 236, 0) 100%);
      padding: 55px;
      height: 535px;

      .card-bg {
        width: 100%;
        height: 400px;
        padding: 20px;
        background-position: center center;
        background-repeat: no-repeat;
        background-size: 100% 100%;
        border-radius: 16px;
        overflow: hidden;
        display: flex;
        align-items: flex-end;

        .user {
          width: 100%;
          display: flex;
          align-items: center;

          .header {
            width: 146px;
            height: 204px;
            margin: 20px;
          }
          ul{
            width: 100%;
          }
          ul > li {
            line-height: 36px;
            color: #fff;
            font-size: 28px;
            font-size: 500;
            display: flex;
            width: 100%;
            .typeName{
              width: 100px;
            }
            .perInfo{
                // width: 100%;
                flex:1;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 1;
                overflow: hidden;
                word-break: break-all;              
            }
          }
        }
      }

      .switch-btn {
        text-align: center;
      }
    }

    .down-bar {
      background: #fff;
      margin-top: 30px;
      padding: 55px;
      min-height: 900px;

      // display: flex;
      // flex-wrap: wrap;
      .title {
        font-size: 32px;
        font-weight: 500;
        border-left: 5px solid var(--theme-color);
        padding-left: 20px;
      }

      .upload-area {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 30px;
        background: #f9f9f9;
        margin: 30px 0;

        .up-pic {
          display: flex;
          flex-direction: column;
          align-items: center;
          background: #fff;
          padding: 14px 18px;

          span {
            font-size: 22px;
            color: #666666;
            padding-top: 14px;
          }
        }
      }

      .upload-explain {
        font-size: 24px;
        color: #666666;
        line-height: 48px;

        li {
          &:first-child {
            color: #ff0000;
            font-weight: 500;
          }
        }
      }

      .status-tip {
        min-width: 510px;
        margin: 44px auto 33px;
        background-color: rgba(255, 242, 242, 1);
        border-radius: 16px;
        justify-content: center;
        display: flex;
        align-items: center;

        .wicon {
          width: 60px;
          height: 60px;
          margin: 20px;
        }

        span {
          color: rgba(255, 0, 0, 1);
          font-size: 28px;
          font-weight: 500;
          // line-height: 100px;
        }
      }

      .receive-btn {
        text-align: center;
        margin: 80px 0;
      }
    }
    .noTopP{
      padding-top: 0px;
      margin-top:0px;
    }
    .noBotP{
      margin-bottom: 0px;
      padding-bottom: 0px;
    }
    .center-bar{
      background-color: #fff;
      width: 100%;
      box-sizing: border-box;
      height: 179px;
      // padding: 0 55px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .part{
        position: relative;
      }
      .svg-icon{
        width: 306px;
        height: 100px;
        :deep(path:last-child) {
          fill: var(--theme-color);
        }        
      }
      .title-svg{
        color:  var(--theme-color);
        font-weight: 600;
        position: absolute;
        top:50%;
        left: 50%;
        transform: translate(-30%,-50%);
      }
    }
    .hot-act{
      width: 100%;
      height: 80px;
      box-sizing: border-box;
      // padding-top: 32px;
      // padding-left: 55px;
      .hot-title{
        width: 300px;
        height: 80px;
        display: flex;
        align-items: center;
      }
      .hot-img{
        width: 40px;
        height: 40px;
      }
      .title{
        color: #222;
        font-size: 36px;
        font-weight: 500;
        margin-left: 16px;
      }
    }
    .gradutationBanner{
      width: 100%;
      display: flex;
      // align-items: center;
      justify-content: center;
      margin-top: 22px;
      .banner-img{
        width: 640px;
        height: 214px;
      }
    }
    .switch-cont {
      max-height: 800px;
      background: #fff;
      overflow-y: scroll;

      .switch-tit {
        line-height: 88px;
        text-align: center;
        font-weight: 600;
        font-size: 32px;
        border-bottom: 2px solid #f9f9f9;
      }

      .switch-pick {
        padding: 30px 40px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;

        .pick-li {
          margin-top: 20px;

          .name {
            line-height: 48px;
          }

          .list-img {
            width: 320px;
            height: 200px;
            border-radius: 8px;
          }
        }
      }
    }
  }
  .SDtime{
    width: 100%;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #fff;
    border-radius: 10px;
    .sii{
      font-size: 30px;
      color: #222;
    }
  }
  .ims{
    width:400px;
    height: 400px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);    
  }
</style>
