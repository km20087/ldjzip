<template>
  <div>
<nav-bar-2 left-arrow @click-left="goBack" title="校友码" />
<div class="con1">
<div class="title1">
<SvgschoolmateCardWelcome class="svgSize" />
</div>
<div class="qrcodeCss">
<div class="logo">
<!-- <img :src="schoolmateCodeLogo_gwy" class="ims" alt=""> -->
</div>
<div class="tips">
请将二维码对准扫描设备
</div>
<div class="showqrcode">
<img :src="qrcodeShow" alt="" class="qrIMs">
</div>
<div class="buttonQr">
<van-button type="primary" :disabled="loading" round block @click="getQrcode">刷新</van-button>
</div>
</div>
</div>
  </div>
</template>
<script setup lang="ts">


import SvgschoolmateCardWelcome from '@/assets/schoolmateCode/schoolmateCardWelcome.svg'
  import schoolmateCodeBG_gwy from '@/assets/schoolmateCode/schoolmateCodeBG_gwy.jpg'
  import schoolmateCodeinside from '@/assets/schoolmateCode/schoolmateCodeinside.png'
  import qrcodeShow from '@/assets/schoolmateCode/qrcodeShow.png'
  import { useGoBack } from '@/hooks/useGoBack'
  import ApiSer from "@/api/appService";


// import { storeToRefs } from 'pinia';
// import { useSettingStore } from '@/store';
// const settingStore = useSettingStore();
// const { isShowTitle } = storeToRefs(settingStore);


const { goBack } = useGoBack()
const qrUrl = ref('')
let bg = ref()
const loading = ref(false)
const getQrcode = async () =>{
loading.value = true
let {data,msg,code} = await ApiSer.returnQR({})
if(code == 200){
// qrUrl.value = data
loading.value = false
}else{
loading.value = false
}

}
onMounted(()=>{
// bg.value.style.backgroundImage = `url(${schoolmateCodeBG_gwy})`
// console.log('onMounted',bg.value.style)
getQrcode()
})
</script>

<style lang="less" scoped>
.con1{
width: 100vw;
height: calc(100vh - var(--van-nav-bar-height));
background-image: url('@/assets/schoolmateCode/schoolmateCodeBG_gwy.jpg');
background-size:100% 100%;
background-repeat:no-repeat;
padding-top:80px;
padding-left:50px;
padding-right:50px;
box-sizing: border-box;
.title1{
width: 100%;
height:72px;
// margin:37px 0px;
text-align: center;
.svgSize{
width: 100%;
height: 100%;
}
}
.qrcodeCss{
  margin-top:80px;
  width:100%;
  height:960px;
  background-image: url('@/assets/schoolmateCode/schoolmateCodeinside.png');
  background-size:100% auto;
  background-repeat:no-repeat;
  display: flex;
  flex-direction: column;
  align-items: center;
  // justify-content: center;
  padding:0 51px;
  padding-top:31px;
  box-sizing: border-box;
.logo{
  width:100%;
  text-align: center;
  height: 96px;
  line-height: 48px;
.ims{
  width: 446px;
  height: 100%;
  // width:446px;
  // height: 48px;
}


}
.tips{
  width: 100%;
  margin-top:94px;
  text-align: center;
  color:#999;
  font-size: 28px;
}
.showqrcode{
  // width: 210px;
  // height: 210px;
    width: 100%;
    text-align: center;
  .qrIMs{
    margin-top:25px;
    width: 400px;
    height: 400px;
    border-radius: 10% 10% 10% 10%;
  //  border-radius:20px;
  }
}
  .buttonQr{
    margin-top:41px;
    width: 60%;
  }
}
}
</style>

