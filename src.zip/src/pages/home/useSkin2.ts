import { getSchoolCode, getImg } from '@/utils'
import { UseSkin2SchoolList, Skin2Config,UseHomeConfigByCSS,UseHomeConfigByItems } from '@/constants'
export function useSkin2() {
  const schoolCode = getSchoolCode() as string
  const isUseSkin2 = UseSkin2SchoolList.includes(schoolCode)
  const { skin2AssetsPrefix, skin2NewsTypeSuffix } =  Skin2Config[schoolCode!] || {}
  const cssHome = UseHomeConfigByCSS[schoolCode!] || {}
  const skin2Config = UseHomeConfigByItems[schoolCode!] || {}
  const getSkin2Img = (file: string) => {
    return getImg(`${skin2AssetsPrefix}/${file}`)
  }
  
  return {
    isUseSkin2,
    skin2AssetsPrefix, 
    skin2NewsTypeSuffix,
    getSkin2Img,
    cssHome,
    skin2Config,
  }
}