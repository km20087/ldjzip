// import { getSchoolCode } from '@/utils';
// import { SchoolCode } from '@/constants';

// export function useLoadECard() {
//   const schoolCode = getSchoolCode() || '';
//   // @ts-ignore
//   const isShowECard = [SchoolCode.GuangWenYi,SchoolCode.WuLuMuQiZhiYeDaXue, SchoolCode.LiaoShiDa,SchoolCode.ShenYangShiFan, SchoolCode.ChengDuYiXueYuan,SchoolCode.XiangXianZhongXue,SchoolCode.BaoTouZhiYeJiShu].includes(schoolCode)
//   const whiteFont = [SchoolCode.ShenYangShiFan as string,SchoolCode.BaoTouZhiYeJiShu as string].includes(schoolCode)
//   const ECard = defineAsyncComponent(() => {
//     let cardFileObj: Record<string, any> = {
//       [SchoolCode.GuangWenYi]: import('./component/ECard-GuangWenYi.vue'),
//       [SchoolCode.WuLuMuQiZhiYeDaXue]: import('./component/ECard-GuangWenYi.vue'),
//       [SchoolCode.LiaoShiDa]: import('./component/ECard.vue'),
//       [SchoolCode.ShenYangShiFan]: import('@/components/E-card/index.vue'),
//       [SchoolCode.ChengDuYiXueYuan]: import('@/components/E-card/index.vue'),
//       [SchoolCode.BaoTouZhiYeJiShu]: import('@/components/E-card/index.vue'),
//       [SchoolCode.XiangXianZhongXue]:import('./component/ECard-XiangXianZhongXue.vue')
//     };
//     return cardFileObj[schoolCode];
//   });

//   return {
//     ECard,
//     isShowECard,
//     whiteFont
//   };
// }



import { getSchoolCode } from '@/utils';
import { SchoolCode } from '@/constants';
import { defineAsyncComponent, ref, computed } from 'vue';

// 预定义学校列表常量，避免重复创建数组
const SHOW_ECARD_SCHOOLS:string[] = [
  SchoolCode.GuangWenYi,
  SchoolCode.WuLuMuQiZhiYeDaXue,
  SchoolCode.LiaoShiDa,
  SchoolCode.ShenYangShiFan,
  SchoolCode.ChengDuYiXueYuan,
  SchoolCode.XiangXianZhongXue,
  SchoolCode.BaoTouZhiYeJiShu,
  SchoolCode.ChengDeYiXueYuan,
  SchoolCode.ShenYangYaoKeDaXue,
];

const WHITE_FONT_SCHOOLS:string[] = [
  SchoolCode.ShenYangShiFan,
  SchoolCode.BaoTouZhiYeJiShu,
  SchoolCode.ChengDeYiXueYuan,
  SchoolCode.ShenYangYaoKeDaXue,
];

// 组件映射表，使用函数形式实现真正的懒加载
const getComponentImport = (schoolCode:string) => {
  const componentMap: Record<string, any> = {
    [SchoolCode.GuangWenYi]: () => import('./component/ECard-GuangWenYi.vue'),
    [SchoolCode.WuLuMuQiZhiYeDaXue]: () => import('./component/ECard-GuangWenYi.vue'),
    [SchoolCode.LiaoShiDa]: () => import('./component/ECard.vue'),
    [SchoolCode.ShenYangShiFan]: () => import('@/components/E-card/index.vue'),
    [SchoolCode.ChengDuYiXueYuan]: () => import('@/components/E-card/index.vue'),
    [SchoolCode.BaoTouZhiYeJiShu]: () => import('./component/Ecard-BaoTou.vue'),
    [SchoolCode.XiangXianZhongXue]: () => import('./component/ECard-XiangXianZhongXue.vue'),
    [SchoolCode.ChengDeYiXueYuan]: () => import('@/components/E-card/index.vue'),
    [SchoolCode.ShenYangYaoKeDaXue]: () => import('@/components/E-card/index.vue'),
  };
  
  return componentMap[schoolCode];        
};

export function useLoadECard() {
  // 使用 ref 缓存 schoolCode，避免重复调用 getSchoolCode
  const schoolCodeRef = ref(getSchoolCode() || '');
  
  // 使用 computed 实现响应式计算，只在依赖变化时重新计算
  const isShowECard = computed(() => 
    SHOW_ECARD_SCHOOLS.includes(schoolCodeRef.value)
  );
  
  const whiteFont = computed(() => 
    WHITE_FONT_SCHOOLS.includes(schoolCodeRef.value)
  );
  
  // 更高效的异步组件定义
  const ECard = computed(() => {
    const componentImporter = getComponentImport(schoolCodeRef.value);
    
    // 只有当学校需要显示 ECard 时才创建异步组件
    if (componentImporter && isShowECard.value) {
      return defineAsyncComponent({
        loader: componentImporter,
        // 添加加载状态和错误处理
        loadingComponent: {
          template: '<div class="ecard-loading">加载中...</div>'
        },
        errorComponent: {
          template: '<div class="ecard-error">加载失败</div>'
        },
        delay: 200,
        timeout: 10000
      });
    }
    
    // 如果不需要显示，返回 null 或空组件
    return null;
  });

  return {
    ECard: ECard.value,
    isShowECard: isShowECard.value,
    whiteFont: whiteFont.value
  };
}

