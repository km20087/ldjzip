import { ref } from 'vue';
import { fetchUnreadCount } from '@/api/message';

export function useUnRead() {
  const unReadCount = ref(0);

  async function getUnReadCount() {
    const { code, data, msg } = await fetchUnreadCount();
    if (code == 200) {
      unReadCount.value = data;
    }
  }

  return {
    unReadCount,
    getUnReadCount,
  };
}
