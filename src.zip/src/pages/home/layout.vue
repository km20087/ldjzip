<template>
  <router-view />
  <bottomTab :active="active" />
</template>

<script lang="ts" setup>
  import bottomTab from '@/components/bottomTab/index.vue';
  import { useRoute } from 'vue-router';
  const route = useRoute();
  const active = computed(() => (route?.name as string) ?? 'index');
</script>
