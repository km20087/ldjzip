<template>
  <div class="E-card">
    <div class="card-in">
      <div class="up-in">
        <van-image class="schoolnameIMG" :src="schoolnameIMG" />
        <van-image class="cardnameIMG" :src="cardnameIMG" />
      </div>
      <div class="down-in">
        <div class="left">
          <fix-image class="defaultHead" :src="perInfo.userProfilePicture" :default-src="sexFunction(perInfo.gender)">
          </fix-image>
          <!-- 只有校友模式需要展示用户的头像审核状态 -->
          <div class="picStatus" v-if="settingStore.isSchoolmateMode">
            <img :src="willCheck" class="ims" v-if="perInfo.pictureStatus == '0'" />
            <img :src="checkedPassed" class="ims" v-if="perInfo.pictureStatus == '1'" />
            <img :src="checkNoPass" class="ims" v-if="perInfo.pictureStatus == '2'" />
          </div>
        </div>
        <div class="right">
          <div class="username">
            <van-image class="LNlogo" :src="LNlogo" />
            <div class="row-wrap">
              <span class="name">{{ perInfo.nameDetail || perInfo.sysName }}</span>
              <SvgV class="icon-v" v-if="settingStore.h5Manager == '1'" />
            </div>
          </div>
          <div class="xueli" v-if="identifyMode == IdentifyMode.Schoolmate">
            <div class="l">
              <div class="xuewei"><span v-if="perInfo?.educationInfoList?.length > 1">第{{ cn }}学历&ensp;</span><span>{{
                eduName(perInfo?.educationInfoList[num]?.education) }}</span></div>
              <div class="detail">
                <div class="li">学院：{{ perInfo?.educationInfoList[num]?.collegeName }}</div>
                <div class="li">年级：{{ perInfo?.educationInfoList[num]?.schoolStartYear }}</div>
                <div class="li">专业：{{ perInfo?.educationInfoList[num]?.majorName }}</div>
                <div class="li">班级：{{ perInfo?.educationInfoList[num]?.classesName }}</div>
              </div>
            </div>
            <van-image class="tabR" :src="tabR" @click="toggleXueli" v-if="perInfo?.educationInfoList?.length > 1" />
          </div>
          <div class="xueli" v-if="identifyMode == IdentifyMode.Manage">
            <div class="l">
              <div class="detail">
                <div class="li">学工号：{{ perInfo?.campusUserId }}</div>
                <div class="li">职务：{{ perInfo?.sysDuties }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
import schoolnameIMG from "@/assets/mine/school-name@2x.png";
import cardnameIMG from "@/assets/mine/Ecard-name@2x.png";
import { eduName } from '@/utils';
import checkedPassed from "@/assets/mine/checkedPassed.png";
import willCheck from "@/assets/mine/willCheck.png";
import checkNoPass from "@/assets/mine/checkNoPass.png";

import LNlogo from "@/assets/mine/schoolBadge.png";
import defaultHead from "@/assets/mine/default-head@2x.png";
import defaultHeadMan from "@/assets/mine/default-user-man.jpg";
import defaultAvatar from "@/assets/mine/default-avatar.png";
import tabR from "@/assets/mine/tabs-r@2x.png";
import { numTohan } from "@/utils/num";
import { useSettingStore } from "@/store";
import { storeToRefs } from "pinia";
import { IdentifyMode } from "@/constants";
import SvgV from "@/assets/mine/v.svg"

const settingStore = useSettingStore();
const { identifyMode } = storeToRefs(settingStore);

const props = withDefaults(
  defineProps<{
    hanIDX?: string;
    xueliIDX?: number;
    perInfo: perInfo;
  }>(),
  {
    hanIDX: "一",
    xueliIDX: 0
  }
);
let num = ref(props.xueliIDX);
let cn = ref(props.hanIDX);
const toggleXueli = () => {
  let len = props.perInfo.educationInfoList.length - 1;
  num.value++;
  if (num.value > len) {
    num.value = 0;
  }
  cn.value = numTohan(num.value + 1);
};

const sexFunction = (val:any)=>{
  if(val=='0'){
    return defaultHead
  }else if(val == '1'){
    return defaultHeadMan
  }else{
    return  defaultAvatar
  }
}
</script>
<style lang="less" scoped>
.row-wrap {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.icon-v {
  margin-left: 10px;
  width: 32px;
  height: 32px;
}
.E-card {
  width: 100%;
  height: 480px;
  background: url("@/assets/mine/content-bg@2x.png") no-repeat;
  background-size: 100% 100%;
  padding: 28px 43px;

  .card-in {
    width: 100%;
    height: 100%;
    background: url("@/assets/mine/Ecard-bg@2x.png") no-repeat;
    background-size: 100% 100%;
    padding: 15px;

    .up-in {
      display: flex;
      align-items: center;
      justify-content: space-between;

      .schoolnameIMG {
        width: 222px;
        height: 59px;
      }

      .cardnameIMG {
        width: 140px;
        height: 30px;
        margin: 0 10px;
      }
    }

    .down-in {
      margin-top: 41px;
      display: flex;

      .defaultHead {
        width: 166px;
        height: 230px;
        // margin-left: 20px;
        // margin-right: 27px;
        border-radius: 10px;
        position: relative;
        overflow: hidden;
        // img{
        //   width: 136px;
        //   height: 136px;
        // }
      }
      .left{
        position: relative;
        height: auto;
        box-sizing: border-box;
        // display: float;
        display: flex;
        align-items: flex-start;
        padding-left: 20px;
        padding-right: 27px;

      }
      .picStatus {
        width: 166px;
        height: 40px;
        // color:rgb(225,182,15);
        position: absolute;
        // left: 20px;
        bottom: 0px;
        .ims{
          width:100%;
          height:100%
        }
      }

      .right {
        .username {
          display: flex;
          align-items: center;

          .LNlogo {
            width: 34px;
            height: 34px;
            margin-right: 10px;
          }

          .name {
            font-family: PingFangSC-Medium;
            font-size: 32px;
            color: #ffffff;
            line-height: 26px;
            font-weight: 500;
          }
        }

        .xueli {
          margin-top: 20px;
          display: flex;
          align-items: center;

          .l {
            background: url("@/assets/mine/xueli-bg@2x.png") no-repeat;
            background-size: 100% 100%;

            .xuewei {
              width: 378px;
              min-height: 40px;
              line-height: 40px;
              background: url("@/assets/mine/xueli-tit@2x.png") no-repeat;
              background-size: 100% 100%;
              font-family: PingFangSC-Regular;
              font-size: 20px;
              color: #ffffff;
              text-align: center;
              display: flex;
              justify-content: center;

              span {
                display: inline;
                text-align: center;
                width: fit-content;
              }
            }

            .detail {
              .li {
                font-family: PingFangSC-Regular;
                font-size: 20px;
                color: #ffffff;
                margin: 5px 0;
              }
            }
          }

          .tabR {
            width: 40px;
            height: 40px;
          }
        }
      }
    }
  }
}
</style>