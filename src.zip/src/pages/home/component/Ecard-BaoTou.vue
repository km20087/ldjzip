<template>
<div class='box'>
    <div class='syBg' v-if="!eCardWrapBg">
      <div class="back"> </div>
      <div class="tran"> </div>      
    </div>
    <div class='ecardBg' v-else  :style="{ 'background-image': `url(${eCardWrapBg})` }">
      <!-- <div class="back"> </div>
      <div class="tran"> </div>       -->
    </div>    
  <div class="E-card">
    <div class="card-in" :style="{ 'background-image': `url(${eCardBg})` }">
      <div class="up-in">
        <fix-image :src='schoolnameIMG' class="schoolnameIMG" />
        <van-image class="cardnameIMG" :src="cardnameIMG" v-if="isEcard"/>
      </div>
      <div class="down-in">
        <div class="left">
          <fix-image class="defaultHead" :src="perInfo.userProfilePicture" :default-src="sexFunction(perInfo.gender)">
          </fix-image>
          <!-- 只有校友模式需要展示用户的头像审核状态 -->
          <div class="picStatus" v-if="settingStore.isSchoolmateMode && SchoolmateModeShow">
            <img :src="willCheck" class="ims" v-if="perInfo.pictureStatus == '0'" />
            <img :src="checkedPassed" class="ims" v-if="perInfo.pictureStatus == '1'" />
            <img :src="checkNoPass" class="ims" v-if="perInfo.pictureStatus == '2'" />
          </div>
        </div>
        <div class="right">
          <div class="username">
            <!-- <van-image class="logo" :src="schoolLogo" /> -->
            <!-- <fix-image :src='schoolLogo' class="logo" /> -->
            <div class="row-wrap">
              <span class="name" :class="whiteFont?'whiteFontColor':''">{{ perInfo.nameDetail || perInfo.sysName ||perInfo.name }}</span>
              <SvgV class="icon-v" v-if="settingStore.h5Manager == '1'" />
            </div>
          </div>
          <div class="xueli" v-if="identifyMode == IdentifyMode.Schoolmate">
            <div class="l">
              <!-- <div class="xuewei" :class="whiteFont?'whiteFontColor':''" v-if="perInfo?.educationInfoList?.length > 0">
                <span v-if="perInfo?.educationInfoList?.length > 1">第{{ cn }}学历&ensp;</span><span>{{
                eduName(perInfo?.educationInfoList[num]?.education) }}</span></div> -->
              <div class="detail">
                <div class="li" :class="whiteFont?'whiteFontColor':''">系部：{{ perInfo.collegeName}}</div>
                <div class="li" :class="whiteFont?'whiteFontColor':''">专业：{{  perInfo.majorName }}</div>
                <div class="li" :class="whiteFont?'whiteFontColor':''">班级：{{ perInfo.classesName }}</div>
                <!-- <div class="li" :class="whiteFont?'whiteFontColor':''" v-else>入学年级：{{ perInfo?.educationInfoList[num]?.schoolStartYear || perInfo.schoolStartYear }}</div> -->
              </div>
            </div>
            <van-image class="tabR" :src="tabR" @click="toggleXueli" v-if="perInfo?.educationInfoList?.length > 1" />
          </div>
          <div class="xueli" v-if="identifyMode == IdentifyMode.Manage">
            <div class="l">
              <div class="detail">
                <div class="li" :class="whiteFont?'whiteFontColor':''">学工号：{{ perInfo?.campusUserId }}</div>
                <div class="li" :class="whiteFont?'whiteFontColor':''">职务：{{ perInfo?.sysDuties }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
        <div class="edit" @click="jumpInfoconfig" v-if="showEdit">
          <img :src="editLogo" alt="" class="ims" />
        </div>      
    </div>
  </div>

  </div>
</template>
<script lang="ts" setup>
import cardnameIMG from "@/assets/mine/Ecard-name@2x.png";
import { eduName } from '@/utils';
import checkedPassed from "@/assets/mine/checkedPassed.png";
import willCheck from "@/assets/mine/willCheck.png";
import checkNoPass from "@/assets/mine/checkNoPass.png";
import defaultHead from "@/assets/mine/default-head@2x.png";
import defaultHeadMan from "@/assets/mine/default-user-man.jpg";
import defaultAvatar from "@/assets/mine/default-avatar.png";
import editLogo from '@/assets/icons/editLogo.png';
import tabR from "@/assets/mine/tabs-r@2x.png";
import { numTohan } from "@/utils/num";
import { useSettingStore } from "@/store";
import { storeToRefs } from "pinia";
import { IdentifyMode, SchoolCode } from "@/constants";
import SvgV from "@/assets/mine/v.svg"
import useCache from '@/hooks/useCache'
import { homeSwipePic } from '@/api/home'
import { getSchoolCode } from '@/utils';

const BaseFileUrl = import.meta.env.VITE_APP_PIC_BASE_URL;
const schoolCode = getSchoolCode();
const router = useRouter();
const settingStore = useSettingStore();
const { identifyMode } = storeToRefs(settingStore);

const props = withDefaults(
  defineProps<{
    hanIDX?: string;
    xueliIDX?: number;
    perInfo: perInfo;
    isEcard?:boolean;
    SchoolmateModeShow?:boolean;
    showEdit?:boolean,
    whiteFont?:boolean,
  }>(),
  {
    hanIDX: "一",
    xueliIDX: 0,
    isEcard:false,
    SchoolmateModeShow:false,
    showEdit:false,
    whiteFont:false,
  }
);
// let isChengDuYiXueYuan = ref(schoolCode === SchoolCode.ChengDuYiXueYuan)
let num = ref(props.xueliIDX);
let cn = ref(props.hanIDX);
let eCardBg = ref('')
const eCardWrapBg = ref('')
let schoolnameIMG = ref('')
let schoolLogo = ref('')
const toggleXueli = () => {
  let len = props.perInfo.educationInfoList.length - 1;
  num.value++;
  if (num.value > len) {
    num.value = 0;
  }
  cn.value = numTohan(num.value + 1);
};

const sexFunction = (val:any)=>{
  if(val==='0'){
    return defaultHead
  }else if (val ==='1'){
    return defaultHeadMan
  } else {
    return  defaultAvatar
  }
}

const jumpInfoconfig = () => {
  if (!props.showEdit) {
    return;
  }
  router.push({ path: '/infoConfig' });
};

onBeforeMount(() => {
  console.log('whiteFont',props.whiteFont)
  useCache({
    key: 'ECARD_BACKGROUND',
    service: homeSwipePic,
    params: {
      imageType: 'ECARD_BACKGROUND'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        if (data.images.length > 0) {
          eCardBg.value = BaseFileUrl + data.images[0].fileAddress
        }
      }
    }
  })
  
  useCache({
    key: 'ECARD_WRAP_BACKGROUND',
    service: homeSwipePic,
    params: {
      imageType: 'ECARD_WRAP_BACKGROUND'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        if (data.images.length > 0) {
          eCardWrapBg.value = BaseFileUrl + data.images[0].fileAddress
        }
      }
    }
  })

  useCache({
    key: 'HOME_HEADER_ICON',
    service: homeSwipePic,
    params: {
      imageType: 'HOME_HEADER_ICON'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        if (data.images.length > 0) {
          schoolnameIMG.value = BaseFileUrl + data.images[0].fileAddress
        }
      }
    }
  })

})

</script>


<style lang="less" scoped>
.whiteFontColor{
  color:#ffffff !important;
}
.box{
  width:100%;
  height: 480px;
  position: relative;
}
.syBg{
  width: 100%;
  position: relative;
  // z-index:3;
  top:0px;
  .back {
    position: relative;
    width: 100%;
    height: 285px;
    background: var(--theme-color);
    // border-radius: 0 0 10% 10%;
  }
  .tran {
    width: 0;
    height: 0;
    border-top: 96px solid var(--theme-color);
    border-right: 50vw solid transparent;
    border-left: 50vw solid transparent;
  }  
}

.ecardBg{
    position: relative;
    width: 100%;
    height: 285px;
    background-repeat: no-repeat;
    background-size: 100% 100%;
}

.row-wrap {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.icon-v {
  margin-left: 10px;
  width: 32px;
  height: 32px;
}
.E-card {
  width: 100%;
  height: 480px;
  // position: relative;
  // top:-20px;
  position: absolute;
  top:0px;
  z-index:10;
  // background: url("@/assets/mine/content-bg@2x.png") no-repeat;
  background-size: 100% 100%;
  padding: 28px 43px;

  .card-in {
    width: 100%;
    height: 100%;
    // height: 480px;
    // background: url("@/assets/mine/Ecard-bg@2x.png") no-repeat;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    padding: 15px;

    .up-in {
      display: flex;
      align-items: center;
      justify-content: space-between;

      .schoolnameIMG {
        width: auto;
        height: 59px;
      }

      .cardnameIMG {
        width: 140px;
        height: 30px;
        margin: 0 10px;
      }
    }

    .down-in {
      margin-top: 41px;
      display: flex;

      .defaultHead {
        width: 166px;
        height: 230px;
        // margin-left: 20px;
        // margin-right: 27px;
        border-radius: 10px;
        position: relative;
        overflow: hidden;
        // img{
        //   width: 136px;
        //   height: 136px;
        // }
      }
      .left{
        position: relative;
        height: auto;
        box-sizing: border-box;
        // display: float;
        display: flex;
        align-items: flex-start;
        padding-left: 20px;
        padding-right: 27px;

      }
      .picStatus {
        width: 166px;
        height: 40px;
        // color:rgb(225,182,15);
        position: absolute;
        // left: 20px;
        bottom: 0px;
        .ims{
          width:100%;
          height:100%
        }
      }

      .right {
        .username {
          display: flex;
          align-items: center;

          .logo {
            width: 34px;
            height: 34px;
            margin-right: 10px;
          }

          .name {
            font-family: PingFangSC-Medium;
            font-size: 32px;
            color: #000000;
            line-height: 26px;
            font-weight: 500;
          }
        }

        .xueli {
          margin-top: 20px;
          display: flex;
          align-items: center;

          .l {
            // background: url("@/assets/mine/xueli-bg@2x.png") no-repeat;
            background-size: 100% 100%;

            .xuewei {
              width: 378px;
              min-height: 40px;
              line-height: 40px;
              background: url("@/assets/mine/xueli-tit@2x.png") no-repeat;
              background-size: 100% 100%;
              font-family: PingFangSC-Regular;
              font-size: 20px;
              color: #000000;
              text-align: center;
              display: flex;
              justify-content: center;

              span {
                display: inline;
                text-align: center;
                width: fit-content;
              }
            }

            .detail {
              .li {
                font-family: PingFangSC-Regular;
                font-size: 20px;
                color: #000000;
                margin: 5px 0;
              }
            }
          }

          .tabR {
            width: 40px;
            height: 40px;
          }
        }
      }
    }
    .edit {
      position: absolute;
      right: 65px;
      bottom: 40px;
      .ims {
        width: 36px;
        height: 34px;
        // width:20px;
        // height:20px;
      }
    }    
  }
}
</style>