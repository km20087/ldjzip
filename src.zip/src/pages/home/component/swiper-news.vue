<template>
  <div class="swiper-box">
    <swiper
      class="swiper-wrap"
      :modules="modules"
      :space-between="20"
      slides-per-view="auto"
      :autoplay="autoplay"
      :centered-slides="true"
      :loop="list && list.length > 3"
      :pagination="false"
    >
      <swiper-slide class="swiper-wrap_item" v-for="(item, index) in list" :key="index" @click="emit('clickItem', item.niId)">
        <fix-image class="img" :src="item.coverImage" width="325" height="150" />
        <div class="newsTitle">
            {{item.newsTitle}}
        </div>
      </swiper-slide>
    </swiper>
    <div class="swiper-pagination"></div>
  </div>
</template>

<script lang="ts" setup>
  import { Autoplay, Pagination } from 'swiper';
  import { Swiper, SwiperSlide } from 'swiper/vue';
  import 'swiper/css';
  import 'swiper/css/pagination';

  const props = withDefaults(
    defineProps<{
      list: any[];
    }>(),
    {
      list: () => ([]),
    }
  );
  const emit = defineEmits<{
    (e: 'clickItem', item: any): void
  }>()
  const modules = [Autoplay, Pagination];
  const autoplay = computed(() => ({
    delay: 5000,
    disableOnInteraction: false,
  }));

  // 分页器配置
  const pagination = {
    el: '.swiper-pagination',
    clickable: true,
    bulletClass: 'custom-bullet', // 自定义类名
    bulletActiveClass: 'custom-bullet-active'
  };

</script>

<style lang="less" scoped>
  @width: 546px;
  @height: 273px;
  .swiper-box {
    position: relative;
    overflow: hidden;
  }
  .swiper-wrap {
    min-height: @height;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    transition: all 0.5s ease;
    .swiper-wrap_item {
      flex: 0 0 @width;
      border-radius: 10px;
      overflow: hidden;
      box-sizing: border-box;
      transition: all linear;
    }
    .img {
      width: @width;
      height: @height;
    }
    .newsTitle{
      margin-top: 12px;
      color: #222222;
      font-size: 32px;
      text-align: left;
      font-weight: 500;
      text-overflow: ellipsis;
      overflow: hidden;
      word-break: break-all;
      white-space: nowrap;
    }
  }

  .swiper-slide-active {
    transform: scale(1);
    z-index: 1;
  }

  .swiper-slide-prev,
  .swiper-slide-next {
    transform: scale(0.8) translateX(15%);
  }

  .swiper-slide-next {
    transform: scale(0.8) translateX(-15%);
  }

  /* 新增分页器样式 */
.swiper-pagination {
  position: relative;
  margin-top: 35px;
  width: 100vw;
  height: 10px;
}

:deep(.custom-bullet) {
  width: 10px;
  height: 10px;
  background: rgba(215,36,21,0.4);
  opacity: 1;
  margin: 0 8px !important;
  transition: all 0.3s;
  border-radius: 20px;
  display: inline-block;
}

:deep(.custom-bullet-active) {
  background: var(--theme-color);
  width: 24px;
}
</style>
