<template>
  <div class="E-card" :style="{'background-image': `url(${eCardWrapBg})`}">
    <div class="card-in" :style="{'background-image': `url(${eCardBg})`}">
      <div class="up-in">
      </div>
      <div class="down-in">
        <div class="left">
          <fix-image class="defaultHead" :src="perInfo.userProfilePicture" :default-src="sexFunction(perInfo.gender)">
          </fix-image>
          <!-- 只有校友模式需要展示用户的头像审核状态 -->
          <!-- <div class="picStatus" v-if="settingStore.isSchoolmateMode">
            <img :src="willCheck" class="ims" v-if="perInfo.pictureStatus == '0'" />
            <img :src="checkedPassed" class="ims" v-if="perInfo.pictureStatus == '1'" />
            <img :src="checkNoPass" class="ims" v-if="perInfo.pictureStatus == '2'" />
          </div> -->
        </div>
        <div class="right">
          <div class="username">
            <div class="row-wrap">
              <span class="name">{{ perInfo.nameDetail || perInfo.sysName }}</span>
              <SvgV class="icon-v" v-if="settingStore.h5Manager == '1'" />
            </div>
          </div>
          <div class="xueli" v-if="identifyMode == IdentifyMode.Schoolmate">
           <div class="detail1">
                <div class="li" v-if="perInfo.collegeName">
                  <div class="typeName">学院：</div>
                  <div class="perInfo">
                    {{ perInfo.collegeName }}
                    <!-- 1123123 -->
                  </div>
                </div>
                <div class="li" v-if="perInfo.majorName">
                  <!-- 专业：{{ perInfo.majorName }} -->
                  <div class="typeName">专业：</div>
                  <div class="perInfo">
                    {{ perInfo.majorName }}
                    <!-- 1231 -->
                  </div>                
                </div>
                <div class="li" v-if="perInfo.classesName">
                  <!-- 班级：{{ perInfo.classesName }} -->
                  <div class="typeName">班级：</div>
                  <div class="perInfo">
                    {{ perInfo.classesName }}
                    <!-- 123123 -->
                  </div>                
                
                </div>
                <div class="li" v-if="perInfo.userNo">
                  <!-- 校友编号：{{ perInfo.userNo }} -->
                  <div class="typeName">编号：</div>
                  <div class="perInfo">
                    {{ perInfo.userNo }}
                  </div>                
                
                </div>
              </div>
            <van-image class="tabR" :src="tabR" @click="toggleXueli" v-if="perInfo?.educationInfoList?.length > 1" />
          </div>
          <div class="xueli" v-if="identifyMode == IdentifyMode.Manage">
            <div class="l">
              <div class="detail">
                <div class="li">学工号：{{ perInfo?.campusUserId }}</div>
                <div class="li">职务：{{ perInfo?.sysDuties }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>

import checkedPassed from "@/assets/mine/checkedPassed.png";
import willCheck from "@/assets/mine/willCheck.png";
import checkNoPass from "@/assets/mine/checkNoPass.png";

import defaultHead from "@/assets/mine/default-head@2x.png";
import defaultHeadMan from "@/assets/mine/default-user-man.jpg";
import defaultAvatar from "@/assets/mine/default-avatar.png";
import tabR from "@/assets/mine/tabs-r@2x.png";
import { numTohan } from "@/utils/num";
import { useSettingStore } from "@/store";
import { storeToRefs } from "pinia";
import { IdentifyMode } from "@/constants";
import SvgV from "@/assets/mine/v.svg"
import { useSkin2 } from '../useSkin2'
import useCache from '@/hooks/useCache'
import { homeSwipePic } from '@/api/home'
import { getRealFilePath } from '@/utils'
const BaseFileUrl = import.meta.env.VITE_APP_PIC_BASE_URL;
const { getSkin2Img } = useSkin2()

const settingStore = useSettingStore();
const { identifyMode } = storeToRefs(settingStore);

const props = withDefaults(
  defineProps<{
    hanIDX?: string;
    xueliIDX?: number;
    perInfo: perInfo;
  }>(),
  {
    hanIDX: "一",
    xueliIDX: 0
  }
);

const eCardWrapBg = ref('')
const eCardBg = ref('')

const sexFunction = (val:any)=>{
  if(val=='0'){
    return defaultHead
  }else if(val == '1'){
    return defaultHeadMan
  }else{
    return  defaultAvatar
  }
}

let num = ref(props.xueliIDX);
let cn = ref(props.hanIDX);
const toggleXueli = () => {
  let len = props.perInfo.educationInfoList.length - 1;
  num.value++;
  if (num.value > len) {
    num.value = 0;
  }
  cn.value = numTohan(num.value + 1);
};

onBeforeMount(() => {
  useCache({
    key: 'ECARD_WRAP_BACKGROUND',
    service: homeSwipePic,
    params: {
      imageType: 'ECARD_WRAP_BACKGROUND'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        if (data.images.length > 0) {
          eCardWrapBg.value = getRealFilePath(data.images[0].fileAddress)
        }
      }
    }
  })

  useCache({
    key: 'ECARD_BACKGROUND',
    service: homeSwipePic,
    params: {
      imageType: 'ECARD_BACKGROUND'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        if (data.images.length > 0) {
          eCardBg.value = getRealFilePath(data.images[0].fileAddress)
        }
      }
    }
  })
})

</script>
<style lang="less" scoped>
.row-wrap {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.icon-v {
  margin-left: 10px;
  width: 32px;
  height: 32px;
}
.E-card {
  width: 100%;
  height: 480px;
  background-repeat: no-repeat;
  background-size: 100% 100%;
  padding: 28px 43px;

  .card-in {
    width: 100%;
    height: 100%;
    background-repeat: no-repeat;
    background-size: 100% 100%;
    padding: 15px;

    .up-in {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .down-in {
      margin-top: 120px;
      display: flex;

      .defaultHead {
        width: 166px;
        height: 230px;
        // margin-left: 20px;
        // margin-right: 27px;
        border-radius: 10px;
        position: relative;
        overflow: hidden;
        // img{
        //   width: 136px;
        //   height: 136px;
        // }
      }
      .left{
        position: relative;
        height: auto;
        box-sizing: border-box;
        // display: float;
        display: flex;
        align-items: flex-start;
        padding-left: 20px;
        padding-right: 27px;

      }
      .picStatus {
        width: 166px;
        height: 40px;
        // color:rgb(225,182,15);
        position: absolute;
        // left: 20px;
        bottom: 0px;
        .ims{
          width:100%;
          height:100%
        }
      }

      .right {
        .username {
          display: flex;
          align-items: center;

          .LNlogo {
            width: 34px;
            height: 34px;
            margin-right: 10px;
          }

          .name {
            font-family: PingFangSC-Medium;
            font-size: 32px;
            color: #ffffff;
            line-height: 26px;
            font-weight: 500;
          }
        }

        .xueli {
          margin-top: 20px;
          display: flex;
          align-items: center;
          color: #fff;

          .l {
            background: url("@/assets/mine/xueli-bg@2x.png") no-repeat;
            background-size: 100% 100%;

            .xuewei {
              width: 378px;
              min-height: 40px;
              line-height: 40px;
              background: url("@/assets/mine/xueli-tit@2x.png") no-repeat;
              background-size: 100% 100%;
              font-family: PingFangSC-Regular;
              font-size: 20px;
              color: #ffffff;
              text-align: center;
              display: flex;
              justify-content: center;

              span {
                display: inline;
                text-align: center;
                width: fit-content;
              }
            }

            .detail {
              .li {
                font-family: PingFangSC-Regular;
                font-size: 20px;
                color: #ffffff;
                margin: 5px 0;
                // margin-top: 10px;
              }
            }
          }
          .detail1 {
            .li {
              font-family: PingFangSC-Regular;
              font-size: 26px;
              color: #ffffff;
              margin: 5px 0;
              display: flex;
              width: 100%;
              .typeName{
                min-width: 100px;
                // color: #222;
              }
              .perInfo{
                width: 100%;
                flex:1;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                overflow: hidden;
                word-break: break-all;
              }
              // margin-top: 10px;
            }
          }
          .tabR {
            width: 40px;
            height: 40px;
          }
        }
      }
    }
  }
}


</style>