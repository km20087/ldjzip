<template>
  <div class="user-card" :class="bgClassName">
    <Avatar class="imgLogo" :src="perInfo.userProfilePicture" />
    <div class="perInfo">
      <div class="row-wrap">
        <p class="name">{{ settingStore.isManagerMode ? perInfo.sysName : perInfo.name }}</p>
        <SvgV class="icon-v" v-if="settingStore.isManagerMode" />
      </div>
      <template v-if="settingStore.isManagerMode">
        <p class="sda">{{ perInfo.campusUserId }}</p>
        <p class="sda">{{ perInfo.sysDuties }}</p>
      </template>
      <template v-else>
        <template v-if="schoolCode == SchoolCode.ShanDa &&  perInfo.schoolmateType == '2'">
          <p class="sda">{{ perInfo.jobDepartment }}</p>
          <p class="sda">{{ perInfo.jobTitle }}</p>
        </template>
        <template v-else>
          <p class="sda">{{ perInfo.schoolName }}</p>
          <p class="sda mar5">{{ perInfo.collegeName }}{{ perInfo.classesName }}</p>
        </template>
      </template>
        <slot name="slider"></slot>
    </div>
  </div>
</template>
<script lang="ts" setup>
  import Avatar from '@/components/avatar/index.vue';
  import { useSettingStore } from '@/store'
  import SvgV from "@/assets/mine/v.svg"
  import { SchoolCode } from '@/constants'
  import { getSchoolCode } from '@/utils'

  const settingStore = useSettingStore()
  const schoolCode = getSchoolCode()

  const props = defineProps<{
    perInfo: perInfo
  }>()

  const bgClassName = computed(() => {
    if ( schoolCode == SchoolCode.ShanDa && props.perInfo.schoolmateType == '2') {
      return 'teacher'
    }
    else if(schoolCode == SchoolCode.PeiYingZhongXue){
      return 'pyzx'
    }
    return 'normal'
  })

</script>
<style lang="less" scoped>
  .row-wrap {
    display: flex;
    flex-direction: row;
    align-items: center;
  }
  .icon-v {
    margin-left: 10px;
    width: 32px;
    height: 32px;
  }
  .imgLogo {
    width: 88px;
    height: 88px;
    border-radius: 50%;
  }
  .flex {
    display: flex;
  }
  .user-card {
    width: 100%;
    height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    box-shadow: 1px 2px 24px 0px rgba(0, 0, 0, 0.1);
    border-radius: 32px;
    padding: 30px;
    &.normal{
      background-image: url('@/assets/img/perinfo.png');
    }
    &.pyzx{
      background-image: url('@/assets/img/perinfo-py.png');
      // color:#ffffff;
      .name{
        color:#ffffff;
      }
      .sda{
         color:#ffffff;
      }
    }
    &.teacher{
      background-image: url('@/assets/img/perinfo-teacher.png');
    }
    .flex();
    .card-text {
      width: 80%;
      margin-left: 30px;
      color: #573201;
      .flex();
      flex-direction: column;
      font-size: 24px;
      h5 {
        margin-bottom: 10px;
        margin-top: 0;
        font-size: 36px;
        font-family: PingFang-SC-Bold, PingFang-SC;
        font-weight: bold;
      }
    }
    .perInfo {
      width: 80%;
      margin-left: 30px;
      p {
        margin: 0px;
        font-family: PingFang-SC-Bold, PingFang-SC;
        color: #573201;
        text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
      }
      .name {
        font-size: 36px;
        font-weight: bold;
      }
      .sda {
        margin-top: 20px;
        font-size: 24px;
        font-family: PingFang-SC-Medium, PingFang-SC;
        font-weight: 500;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
        word-break: break-all;           
        // .txt{
        //   margin:0 5px 0 0;
        //   width: 72px;
        //   display: inline-block;
        //   text-align: justify;
        //   text-align-last: justify;
        // }
      }
      .mar5{
        margin-top: 5px;
      }      
    }
  }
</style>
