<template>
  <template v-if="settingStore.canSwitchIdentify">
    <div class="switch-wrap">
      <img class="icon" v-if="settingStore" :src="ImgSwitchIdentify" @click="show = true" />
    </div>
    <div class="fix-switch-wrap"></div>
  </template>
  <van-popup v-model:show="show" round position="bottom">
    <van-picker title="身份切换" :default-index="defulePickerIndex" :columns="modeOpt" @confirm="handleSwitch" @cancel="handleClose"/>
  </van-popup>
</template>

<script lang="ts" setup>
  import { ref } from 'vue'
  import ImgSwitchIdentify from '@/assets/mine/switch-identify.png'
  import { useSettingStore } from '@/store'
  import { IdentifyMode } from '@/constants'
  import { storeToRefs } from "pinia";

  const settingStore = useSettingStore()
  const { identifyMode } = storeToRefs(settingStore)

  const show = ref(false)

  const modeOpt = [
    { text: '校友', value: IdentifyMode.Schoolmate },
    { text: '管理员', value: IdentifyMode.Manage },
  ]
  const modeIndexObj = modeOpt.reduce((obj: Record<string, number>, {value}, index) => (obj[value] = index, obj), {})
  const defulePickerIndex = computed(() => modeIndexObj[identifyMode.value])
  function handleSwitch(chooseItem: typeof modeOpt[number]) {
    let { value } = chooseItem
    settingStore.setIdentifyMode(value)
    show.value = false
  }
  function handleClose() {
    show.value = false
  }
</script>

<style lang="less" scoped>
  .switch-wrap {
    position: absolute;
    top: 280px;
    left: 50%;
    transform: translateX(-50%);
    padding: 0 0 28px;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    background: transparent;

    .icon {
      width: 140px;
      height: 28px;
    }
  }
  .fix-switch-wrap {
    width: 1px;
    height: 28px;
  }
  .title-wrap {
    padding: 30px 0;
    text-align: center;
    font-size: 36px;
    color: #222222;
    font-weight: 500;
    background: #f5f5f5;
  }
  .card-wrap {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    padding: 24px 32px;
    .E-card {
      margin-right: 24px;
      &:nth-of-type(2n) {
        margin-right: 0;
      }
    }
  }
</style>
