<template>
  <div class="E-card">
    <div class="card-in">
      <div class="up-in">
        <van-image class="schoolnameIMG" :src="schoolnameIMG" />
      </div>
      <div class="down-in">
        <fix-image class="defaultHead" :src="perInfo.userProfilePicture" :default-src="defaultHead" />
        <div class="right">
          <div class="username">
            <van-image class="LNlogo" :src="LNlogo" />
            <span class="name">{{ perInfo.name || perInfo.sysName }}</span>
          </div>
          <div class="xueli" v-if="mode == IdentifyMode.Schoolmate">
            <div class="l">
              <!-- <div class="xuewei"><span v-if="perInfo?.educationInfoList?.length > 1">第{{ cn }}学历&ensp;</span><span>{{
                perInfo?.educationInfoList[num]?.education }}</span></div> -->
              <div class="detail">
                <div class="li van-ellipsis">学院：{{ perInfo?.educationInfoList[num]?.collegeName }}</div>
                <div class="li van-ellipsis">年级：{{ perInfo?.educationInfoList[num]?.schoolStartYear }}</div>
                <!-- <div class="li van-ellipsis">专业：{{ perInfo?.educationInfoList[num]?.majorName }}</div> -->
                <!-- <div class="li van-ellipsis">班级：{{ perInfo?.educationInfoList[num]?.classesName }}</div> -->
              </div>
            </div>
            <!-- <van-image class="tabR" :src="tabR" @click="toggleXueli" v-if="perInfo?.educationInfoList?.length > 1" /> -->
          </div>
          <div class="xueli" v-if="mode == IdentifyMode.Manage">
            <div class="l">
              <div class="detail">
                <div class="li van-ellipsis">学工号：{{ perInfo?.campusUserId }}</div>
                <div class="li van-ellipsis">职务：{{ perInfo?.sysDuties }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>
import schoolnameIMG from '@/assets/mine/school-name@2x.png';
import LNlogo from '@/assets/mine/schoolBadge.png';
import defaultHead from '@/assets/mine/default-head@2x.png';
import tabR from '@/assets/mine/tabs-r@2x.png';
import { numTohan } from '@/utils/num';
import { IdentifyMode } from '@/constants';

const props = withDefaults(
  defineProps<{
    hanIDX?: string;
    xueliIDX?: number;
    perInfo: perInfo;
    mode: (typeof IdentifyMode)[keyof typeof IdentifyMode]
  }>(),
  {
    hanIDX: '一',
    xueliIDX: 0,
  }
);
let num = ref(props.xueliIDX);
let cn = ref(props.hanIDX);
const toggleXueli = () => {
  let len = props.perInfo.educationInfoList.length - 1;
  num.value++;
  if (num.value > len) {
    num.value = 0;
  }
  cn.value = numTohan(num.value + 1);
};

</script>
<style lang="less" scoped>
.E-card {
  width: 331px;
  height: 211px;

  .card-in {
    width: 100%;
    height: 100%;
    background: url('@/assets/mine/Ecard-bg@2x.png') no-repeat;
    background-size: 100% 100%;
    padding: 7px;

    .up-in {
      display: flex;
      align-items: center;
      justify-content: space-between;

      .schoolnameIMG {
        width: 111px;
        height: 28px;
      }
    }

    .down-in {
      margin-top: 20px;
      display: flex;

      .defaultHead {
        flex: 0 0 auto;
        width: 83px;
        height: 115px;
        margin-left: 10px;
        margin-right: 13px;
        border-radius: 5px;
        overflow: hidden;
      }

      .right {
        flex: 1;
        overflow: hidden;
        .username {
          display: flex;
          align-items: center;

          .LNlogo {
            width: 17px;
            height: 17px;
            margin-right: 5px;
          }

          .name {
            font-family: PingFangSC-Medium;
            font-size: 16px;
            color: #ffffff;
            // line-height: 13px;
            font-weight: 500;
          }
        }

        .xueli {
          margin-top: 10px;
          display: flex;
          align-items: center;

          .l {
            background: url('@/assets/mine/xueli-bg@2x.png') no-repeat;
            background-size: 100% 100%;

            .xuewei {
              width: 189px;
              min-height: 20px;
              line-height: 20px;
              background: url('@/assets/mine/xueli-tit@2x.png') no-repeat;
              background-size: 100% 100%;
              font-family: PingFangSC-Regular;
              font-size: 10px;
              color: #ffffff;
              text-align: center;
              display: flex;
              justify-content: center;

              span {
                display: inline;
                text-align: center;
                width: fit-content;
              }
            }

            .detail {
              .li {
                font-family: PingFangSC-Regular;
                font-size: 10px;
                color: #ffffff;
                margin: 2.5px 0;
                scale: 0.85;
                width: 220px;
              }
            }
          }

          .tabR {
            width: 20px;
            height: 20px;
          }
        }
      }
    }
  }
}
</style>