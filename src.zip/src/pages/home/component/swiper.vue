<template>
  <div class="swiper-box">
    <swiper
      class="swiper-wrap"
      :modules="modules"
      :space-between="10"
      slides-per-view="auto"
      :autoplay="autoplay"
      :centered-slides="true"
      :loop="list && list.length > 3"
    >
      <swiper-slide class="swiper-wrap_item" v-for="(item, index) in list" :key="index">
        <a :href="item.jumpUrl ? item.jumpUrl : 'javascript:void(0);'">
          <fix-image class="img" :src="item.fileAddress" width="650" height="300" :isOriginal="true" />
        </a>
      </swiper-slide>
    </swiper>
    <div class="perInfoCard" :class="isLiaoShiDa() ? 'lncard' : ''" v-if="showFlag">
      <div class="logo">
        <fix-image
          class="ims"
          v-if="perInfo.bareheadedPhoto"
          :src="perInfo.bareheadedPhoto"
          width="56"
          height="56"
        />
        <SvgAvatar v-else class="ims" />
      </div>
      <div class="per">
        <div class="name">
          <span> {{ perInfo.name || perInfo.sysName }}</span>
          <SvgV class="icon-v" v-if="settingStore.h5Manager == '1'" />
        </div>
        <div class="colleageName van-ellipsis" v-if="settingStore.isSchoolmateMode">
          {{ subInfo }}
        </div>
        <div class="colleageName van-ellipsis" v-if="settingStore.isManagerMode">
          {{ perInfo.sysDuties }}
        </div>
      </div>
    </div>
    <div class="shwoAuth" v-if="authFlag"> {{UseResConfigByCSS().noRegister?'校友卡申请':'未认证'}} </div>
  </div>
</template>

<script lang="ts" setup>
  import { ref, computed } from 'vue';
  import { Autoplay } from 'swiper';
  import SvgAvatar from '@/assets/icons/avatar.svg';
  import { useSettingStore } from '@/store';
  import { Swiper, SwiperSlide } from 'swiper/vue';
  import 'swiper/css';
  import { isAllowVisitorToUseSchool, isLiaoShiDa } from '@/utils/customizedType';
  import { useMyInfo } from '@/pages/home/useMyInfo';
  import SvgV from "@/assets/mine/v.svg"
  import { getToken, getUserStatus, getSchoolCode } from '@/utils';
  import { SchoolCode,UseResConfigByCSS } from '@/constants'

  const { perInfo, initMy } = useMyInfo();
  const schoolCode = getSchoolCode()

  const subInfo = computed(() => {
    return schoolCode == SchoolCode.ShanDa && perInfo.value.schoolmateType == '2' ? perInfo.value.jobDepartment : perInfo.value.collegeName
  })

  const showFlag = ref(false);
  const authFlag = ref(false);

  const props = withDefaults(
    defineProps<{
      list: any[];
      interval: string;
    }>(),
    {
      list: () => [] as any[],
      interval: '2',
    }
  );
  const modules = [Autoplay];
  const autoplay = computed(() => ({
    // delay: parseInt(props.interval) * 1000,
    delay: 2000,
    disableOnInteraction: false,
  }));

  const settingStore = useSettingStore();

  function initMode() {
    //00正常，01封禁，02删除，03待审核，04待完善资料，05审核失败，06-校友修改资料待审核，07-封禁的游客;
    let userStatus = getUserStatus();
    if (settingStore.uiMode == '0') {
      if (userStatus == '00' || userStatus == '06' || settingStore.isManagerMode) {
        showFlag.value = true;
      } else {
        authFlag.value = true;
      }
    } else {
      showFlag.value = false;
    }
  }

  watch(
    () => settingStore.uiMode,
    async () => {
      setTimeout(initMode, 0);
    },
    {
      immediate: true,
    }
  );

  onMounted(() => {
    if (!isAllowVisitorToUseSchool() || getToken()) {
      initMy();
    }
  });
</script>

<style lang="less" scoped>
  .perInfoCard {
    position: absolute;
    width: 410px;
    height: 100px;
    left: 50px;
    // top: 100px;
    bottom: 0px;
    z-index: 2000;
    background-color: #ffffff;
    background: url('@/assets/home/card.png') no-repeat;
    background-size: 100% 100%;
    display: flex;
    align-items: center;
    &.lncard {
      background: url('@/assets/home/cardLN.png') no-repeat;
      background-size: 100% 100%;
    }
    .logo {
      margin-left: 22px;
      width: 56px;
      height: 56px;
      border-radius: 50%;
      .ims {
        width: 56px;
        height: 56px;
        border-radius: 50%;
      }
    }
    .per {
      // width: 100%;s
      font-family: PingFang-SC-Medium, PingFang-SC;
      color: #ffffff;
      margin-left: 20px;
      .name {
        display: flex;
        flex-direction: row;
        align-items: center;

        font-size: 28px;
        font-weight: 500;
        margin-bottom: 5px;
        .icon-v{
          margin-left: 10px;
          width: 32px;
          height: 32px;
        }
      }
      .colleageName {
        width: 290px; 
        font-size: 24px;
        font-weight: 400;
      }
    }

    // border-radius: 0px 120px 40px 40px;
  }
  .shwoAuth {
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    // width: 174px;
    // height: 70px;
    padding: 15px 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #000000;
    opacity: 0.76;
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 35px;
    font-size: 36px;
    font-weight: 500;
    z-index: 2000;
    color: #ffffff;
    // ::backdrop-filter: blur(0px);
  }
  .swiper-box {
    overflow: hidden;
    position: relative;
  }
  .swiper-wrap {
    height: 300px;
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    transition: all 0.5s ease;
    .swiper-wrap_item {
      flex: 0 0 650px;
      border-radius: 10px;
      overflow: hidden;
      box-sizing: border-box;
    }
    .img {
      width: 650px;
      height: 300px;
    }
  }
</style>
