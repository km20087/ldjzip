<template>
  <div class="switch-wrap" v-if="settingStore.canSwitchIdentify">
    <img class="icon" v-if="settingStore" :src="ImgSwitchIdentify" @click="show = true" />
  </div>
  <van-popup v-model:show="show" round position="bottom" :style="{ height: '45%' }" closeable>
    <div class="title-wrap">切换卡</div>
    <div class="card-wrap">
      <ECard v-for="mode in modeList" :key="mode" :per-info="perInfo" :mode="mode" @click="handleSwitch(mode)"/>
    </div>
  </van-popup>
</template>

<script lang="ts" setup>
  import { ref } from 'vue';
  import ImgSwitchIdentify from '@/assets/mine/switch-identify.png';
  import { useSettingStore } from '@/store';
  import { IdentifyMode } from '@/constants';
  import ECard from './ECard2.vue';

  const props = defineProps<{
    perInfo: perInfo;
  }>();

  const settingStore = useSettingStore();

  const show = ref(false);

  const modeList = [IdentifyMode.Manage, IdentifyMode.Schoolmate]

  function handleSwitch(mode: (typeof IdentifyMode)[keyof typeof IdentifyMode]) {
    settingStore.setIdentifyMode(mode);
    show.value = false
  }
</script>

<style lang="less" scoped>
  .switch-wrap {
    padding: 0 0 28px;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    background: #fff;

    .icon {
      width: 140px;
      height: 28px;
    }
  }
  .title-wrap {
    padding: 30px 0;
    text-align: center;
    font-size: 36px;
    color: #222222;
    font-weight: 500;
    background: #f5f5f5;
  }
  .card-wrap {
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    padding: 24px 32px;
    .E-card {
      margin-right: 24px;
      &:nth-of-type(2n) {
        margin-right: 0;
      }
    }
  }
</style>
