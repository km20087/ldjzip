<template>
  <div class="E-card">
    <div class="eCardWrapBg" :style="{'background-image': `url(${eCardWrapBg})`}">

    </div>
    <div class="card-in" :style="{'background-image': `url(${eCardBg})`}">
      <div class="up-in">
      </div>
      <div class="down-in">
        <div class="left">
          <fix-image v-if="perInfo.userProfilePicture" class="defaultHead" :src="perInfo.userProfilePicture">
          </fix-image>
          <DefaultAvatar v-else class="defaultHead"/>
          <!-- 只有校友模式需要展示用户的头像审核状态 -->
          <!-- <div class="picStatus" v-if="settingStore.isSchoolmateMode">
            <img :src="willCheck" class="ims" v-if="perInfo.pictureStatus == '0'" />
            <img :src="checkedPassed" class="ims" v-if="perInfo.pictureStatus == '1'" />
            <img :src="checkNoPass" class="ims" v-if="perInfo.pictureStatus == '2'" />
          </div> -->
        </div>
        <div class="right">
          <div class="username">
            <div class="row-wrap">
              <span class="name">{{ perInfo.nameDetail || perInfo.sysName }}</span>
              <SvgV class="icon-v" v-if="settingStore.h5Manager == '1'" />
            </div>
          </div>
          <div class="xueli" v-if="identifyMode == IdentifyMode.Schoolmate">
           <div class="detail">
                <div class="liNew" v-if="perInfo.schoolName">{{ perInfo.schoolName }}</div>
                <div class="liNew" v-if="perInfo.schoolStartYear">{{ perInfo.schoolStartYear }}届</div>
                <div class="liNew" v-if="perInfo.classesName">{{ perInfo.classesName }}</div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts" setup>

import checkedPassed from "@/assets/mine/checkedPassed.png";
import willCheck from "@/assets/mine/willCheck.png";
import checkNoPass from "@/assets/mine/checkNoPass.png";

// import defaultHead from "@/assets/mine/default-head@2x.png";
// import defaultHeadMan from "@/assets/mine/default-user-man.jpg";
import DefaultAvatar from '@/assets/mine/default-avatar.svg';
import tabR from "@/assets/mine/tabs-r@2x.png";
import { numTohan } from "@/utils/num";
import { useSettingStore } from "@/store";
import { storeToRefs } from "pinia";
import { IdentifyMode } from "@/constants";
import SvgV from "@/assets/mine/v.svg"
import { useSkin2 } from '../useSkin2'
import useCache from '@/hooks/useCache'
import { homeSwipePic } from '@/api/home'

const BaseFileUrl = import.meta.env.VITE_APP_PIC_BASE_URL;
const { getSkin2Img } = useSkin2()

const settingStore = useSettingStore();
const { identifyMode } = storeToRefs(settingStore);

const props = withDefaults(
  defineProps<{
    hanIDX?: string;
    xueliIDX?: number;
    perInfo: perInfo;
  }>(),
  {
    hanIDX: "一",
    xueliIDX: 0
  }
);

const eCardWrapBg = ref('')
const eCardBg = ref('')

const sexFunction = (val:any)=>{
  return  DefaultAvatar

}

let num = ref(props.xueliIDX);
let cn = ref(props.hanIDX);
const toggleXueli = () => {
  let len = props.perInfo.educationInfoList.length - 1;
  num.value++;
  if (num.value > len) {
    num.value = 0;
  }
  cn.value = numTohan(num.value + 1);
};

onBeforeMount(() => {
  useCache({
    key: 'ECARD_WRAP_BACKGROUND',
    service: homeSwipePic,
    params: {
      imageType: 'ECARD_WRAP_BACKGROUND'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        if (data.images.length > 0) {
          eCardWrapBg.value = BaseFileUrl + data.images[0].fileAddress
        }
      }
    }
  })

  useCache({
    key: 'ECARD_BACKGROUND',
    service: homeSwipePic,
    params: {
      imageType: 'ECARD_BACKGROUND'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        if (data.images.length > 0) {
          eCardBg.value = BaseFileUrl + data.images[0].fileAddress
        }
      }
    }
  })
})

</script>
<style lang="less" scoped>
.row-wrap {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.icon-v {
  margin-left: 10px;
  width: 32px;
  height: 32px;
}
.E-card {
  width: 100%;
  height: 280px;
  margin-bottom: 40px;
//   padding: 28px 43px;
.eCardWrapBg{
    // margin:0 30px;
    // margin-top: 60px;
    width: 100%;
    height: 170px;
    background-repeat: no-repeat;
    background-size: 100% 100%;    
}
  .card-in {
    width: 690px;
    // height: 100%;
    background-repeat: no-repeat;
    background-size: auto 100%;
    position: absolute;
    height: 220px;
    left: 30px;
    top: 60px;
    padding: 0 30px;
    box-sizing: border-box;

    .up-in {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .down-in {
      margin-top: 20px;
      display: flex;
      // align-items: center;
      .defaultHead {
        width: 140px;
        height: 140px;

          // width: 136px;
          // height: 136px;

        // margin-left: 20px;
        // margin-right: 27px;
        border-radius: 50%;
        position: relative;
        // overflow: hidden;
        // img{
        //   width: 136px;
        //   height: 136px;
        // }
      }
      .left{
        position: relative;
        height: auto;
        box-sizing: border-box;
        // display: float;
        display: flex;
        // align-items: flex-start;
        align-items: center;
        // padding-left: 20px;
        // padding-right: 27px;

      }

      .right {
        margin-left: 30px;
        .username {
            margin-top: 10px;
          display: flex;
          align-items: center;

          .name {
            font-family: PingFangSC-Medium;
            font-size: 36px;
            color: #ffffff;
            // line-height: 26px;
            font-weight: 500;
          }
        }

        .xueli {
          margin-top: 10px;
          display: flex;
          align-items: center;
          color: #fff;
            .liNew {
                font-family: PingFangSC-Regular;
                font-size: 24px;
                color: #ffffff;
                margin: 5px 0;
              }
          .l {
            background: url("@/assets/mine/xueli-bg@2x.png") no-repeat;
            background-size: 100% 100%;

          .detail {
              width: 100%;
            .liNew {
                font-family: PingFangSC-Regular;
                font-size: 24px;
                color: #ffffff;
                margin: 5px 0;
              }
            }
          }

          .tabR {
            width: 40px;
            height: 40px;
          }
        }
      }
    }
  }
}
</style>