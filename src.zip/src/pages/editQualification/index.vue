<template>
<!-- //审核后需要消息提醒 H5要加一个申请修改原因，和显示后管管理员审核的是否通过的原因 -->
<div>
  <van-sticky>
    <nav-bar :title="tit" left-arrow @click-left="onClickLeft" :key="tit" />
  </van-sticky>
  <div class='main'>      
    <div class='eduList' v-for="(item,index) in educationInfoList" :key="index">
      <div class="eduTitle" >
        <div class='leftPart'>
           <span class="tit1"></span>
          <span>学历：{{showEduName(item.education)}}</span> 
        </div>
      </div>
      <div class="eduCon">
        <van-field
          v-model="item.education"
          name="picker"
          label="学历"
          input-align="right"
          placeholder=""
          readonly
          @click="showColumnType('education',index)"
          v-if="editEducationFlag"
        >      
        </van-field>        
        <van-field
          v-model="educationNameNoLN"
          name="picker"
          label="学历"
          input-align="right"
          placeholder=""
          readonly
          @click="showColumnType('education',index)"
          v-else
        >    
        </van-field>        
        <van-field
          v-model="item.academicType"
          name="picker"
          label="学历性质"
          input-align="right"
          placeholder=""
          readonly
          @click="showColumnType('academicType',index)"
           v-if="editEducationFlag"
        >
        </van-field>
        <van-field
          v-model="item.schoolingPeriod"
          name="picker"
          label="学制"
          input-align="right"
          placeholder=""
          readonly
          @click="showColumnType('schoolingPeriod',index)"
          v-if="editEducationFlag"
        >     
        </van-field>     

        <van-field
          v-model="item.startYear"
          
          
          name="picker"
          label="年级"
          input-align="right"
          placeholder=""
          
        />             

        <van-field
          v-if="!isChengDu"
          v-model="item.collegeName"
          name="picker"
          label="学院"
          input-align="right"
          placeholder=""
          readonly
          @click="showColumnType('collegeName',index)"          
          
        />
 
        <van-field
          v-if="!isChengDu && majorList.length == 0"
          v-model="item.majorName"
          
          name="picker"
          label="专业"
          input-align="right"
          placeholder=""
          
        />       
        <van-field
          v-if="!isChengDu && majorList.length != 0"
          v-model="item.majorName"
          
          name="picker"
          label="专业"
          input-align="right"
          @click="showColumnType('majorName',index)"
          placeholder=""
          
        />               
        <van-field
          v-if="isChengDu"
          v-model="item.collegeName"
          name="picker"
          label="学院"
          input-align="right"
          placeholder=""
          readonly          
        />
 
        <van-field
          v-if="isChengDu"
          v-model="item.majorName"
          name="picker"
          label="专业"
          input-align="right"
          @click="showColumnType('majorName',index)"          
          placeholder=""
          
        />               
        <van-field
          v-model="item.classesName"
          v-if="editEducationFlag"
          name="picker"
          label="班级"
          input-align="right"
          placeholder=""
          
        />     
      <van-field v-model="proofFile" readonly name="diplomaImage" input-align="left" error-message-align="left">
        <template #input>
          <div class="upload-tit">证明材料
            <span class="red">（请上传本人毕业证书或学位证书等可以证明本人 学历信息的材料）</span>
          </div>
          <compress-uploader v-model="healthFileList" max-count="1" :after-read="afterRead" accept=".jpg,.png,.jpeg,.pdf" />
          <span class="tips">注意：上传证明材料仅支持jpg、pdf格式，大小不超过2M。</span>
        </template>
      </van-field>
      <van-field v-model="applyReason" rows="3" autosize label="问题描述" type="textarea" maxlength="100" show-word-limit></van-field>
        <van-button class="editButton" @click="submitForm()">
          提交
        </van-button>
        <!-- /appEducationCorrection/apply -->
      </div>
      <van-popup v-model:show="showPicker" position="bottom" >
        <van-picker :columns="columns" @confirm="sureItem" @cancel="clearColumns" />
      </van-popup>      
      <van-popup v-model:show="majorShowFlag" class="bottomPo" position="bottom" :style="{ height: '40%' }">
        <van-search class="fixtop" show-action v-model="inp" :clearable="false" input-align="left" placeholder="请输入"
          @update:model-value="showChoice">
          <template #action>
            <!-- <div @click="sureChoice"> 确认 </div> -->
          </template>
        </van-search>
        <div class="itemShow">
          <div class="item" v-for="(item, index) in columns" :key="index" @click="sureItem(item)">
            {{ item.deptName }}
          </div>
        </div>
      </van-popup>       
    </div>
  </div>
</div>
</template>
<script lang="ts" setup>
import { Dialog, Toast } from "vant";
import { useRouter, useRoute } from "vue-router";
import { ref, reactive } from "vue";
import { useDept } from "./useDept";
import ApiUpload from '@/api/uploadfile';
import ApiBase from '@/api/common';
import editEDu from "@/api/appEducationCorrection";
import Api from "@/api/user/index";
import ApiDept from '@/api/common';
import { isChengDuYiXueYuan } from '@/utils/customizedType';
import {schoolEducationMode} from '@/constants' 
import { getLocalStorageItem, getSchoolId,getSchoolCode } from "@/utils";

interface sugP {
  academicType?: string
  classesName?: string
  collegeId?: string
  collegeName?: string
  diplomaFile?: string
  education?: string
  major?: string
  majorName?: string
  startYear?: string
  schoolingPeriod?: string
  educationType:string
  applyReason?:string
}


const isChengDu = ref(false)
const router = useRouter(); //editQualification
const { getDept } = useDept();
const route = useRoute();
const tit = ref("学历修改");
const onClickLeft = () => {
  router.back();
};
const column = ref([]);
const typeMoadl = ref("");
const pickerFlag = ref(false);
const pickerValue = ref([]);

const xueyuanList = ref([]);

const description = ref("");
const proofFile = ref("");
const healthFileList = ref([]);

const applyReason = ref('')
const educationType = ref(0)
const educationInfoList = ref([] as any);
const eduData = ref({} as sugP)

const schoolPeriodList = ref([] as any)
const academicTypeList = ref([] as any)
const colleageList = ref([] as any)
const majorList = ref([] as any)
const educationList = ref([] as any)

const typeParam = ref('')
const itemParam = ref({})


const showPicker = ref(false)
const majorShowFlag = ref(false)
const inp = ref('')
const inpId = ref('')
const columns = ref([] as any)

const eduIndex = ref(0)
const eduList = ref([
  { text: '小学', value: '0' },
  { text: '初中', value: '1' },
  { text: '高中', value: '2' },
  { text: '专科', value: '3' },
  { text: '本科', value: '4' },
  { text: '硕士研究生', value: '5' },
  { text: '博士研究生', value: '6' },
]);
const newMode = ref([
  '4121010165',//辽师
  // '4151013705',//成都医学院
  // '4121010166'//沈阳师范
])
const editEducationFlag = ref(false)

const educationNameNoLN = ref('')

const shoolTypeByCode = ()=>{
    let schoolCode = getSchoolCode();
    if(schoolEducationMode.includes(schoolCode!)){//辽师的学历修改是特殊的。education直接传学历名称，其他学校传学历code
      editEducationFlag.value = true
    }else{
      editEducationFlag.value = false
    }  
}

const handleEduName = ()=>{
    let eduArr = educationInfoList.value
    if(!editEducationFlag.value){
      for(let i in eduArr){
        for(let a in eduList.value){
          if(eduArr[i].education == eduList.value[a].value){
            educationNameNoLN.value = eduList.value[a].text
          }
        }
      }
    }
}

const showEduName = (val:string) => {
  for(let i in eduList.value){
    if(val == eduList.value[i].value){
      return eduList.value[i].text
    }
  }
}

const showColumnType = (type:string,index:number)=>{
  eduIndex.value = index
  typeParam.value = type
  columns.value = []
  console.log('editEducationFlag',editEducationFlag.value)
  if(type == 'academicType'){
    for(let i in academicTypeList.value){
      columns.value.push(
        {
          text:academicTypeList.value[i].dictName || '',
          ...academicTypeList.value[i]
        }
      )
    }
  }
  else if(type == 'schoolingPeriod'){
    for(let i in schoolPeriodList.value){
      columns.value.push(
        {
          text:schoolPeriodList.value[i].dictName,
          ...schoolPeriodList.value[i]
        }
      )      
    }
  }
  else if(type == 'collegeName'){
    for(let i in colleageList.value){
      columns.value.push(
        {
          text:colleageList.value[i].deptName,
          ...colleageList.value[i]
        }
      )        
    }
  }
  else if(type == 'majorName'){
    // if(isChengDu.value){
      for(let i in majorList.value){
        columns.value.push(
          {
            text:majorList.value[i].deptName,
            ...majorList.value[i]
          }
        )        
      }
    // }

  }  
  else if(type == 'education'){
    if(editEducationFlag.value){//辽师的学历
      for(let i in educationList.value){
        columns.value.push(
          {
            text:educationList.value[i].dictName,
            ...educationList.value[i]
          }
        ) 
      }
    }else{
      columns.value =  columns.value.concat(eduList.value)
    }

        
  }
  if(isChengDu.value && type == 'majorName'){
    majorShowFlag.value = true
  }else{
    showPicker.value = true
  }
  
}

const searchFiltering = (list: any, keywords: string) => {
  // let arr = JSON.parse(JSON.stringfy(list))
  let arr = [];
  // for(let a in keywords){}
  for (let i in list) {
    arr = list.filter((x: any) => {
      return x.deptName.indexOf(keywords) > -1;
    });
  }
  return arr;
}

// const sureItem = (val: any) => {
//   ChengDuVal.value = val
//   inp.value = val.deptName;
//   inpId.value = val.deptId;
// };

const sureChoice = () => {
  console.log('---sureChoice---')
  // formData.majorName = inp.value;
  // formData.major = inpId.value;
  // formData.collegeName = ChengDuVal.value.parentName;
  // formData.collegeId = ChengDuVal.value.parentId;    
  // majorShowFlag.value = false;
};

const showChoice = () => {
  console.log('showChoice',inp.value,!inp.value)
  if(!inp.value){
    columns.value = []
    for(let i in majorList.value){
      columns.value.push(
        {
          text:majorList.value[i].deptName,
          ...majorList.value[i]
        }
      )        
    }    
  }
  if (inp.value) {
    columns.value = searchFiltering(columns.value, inp.value);
  } 
  // inpId.value = '';  
};

const sureItem = (value:any)=>{
  console.log('sureItem',value)
  if(typeParam.value == 'academicType'){
    educationInfoList.value[eduIndex.value].academicType = value.text
    // educationInfoList.value[0].academicType

  }else if(typeParam.value == 'schoolingPeriod'){
    educationInfoList.value[eduIndex.value].schoolingPeriod = value.text
    // educationInfoList.value[0].schoolingPeriod
  }else if(typeParam.value == 'collegeName'){
    educationInfoList.value[eduIndex.value].collegeName = value.text
    educationInfoList.value[eduIndex.value].collegeId	 = value.deptId
    if(!isChengDu.value){//成都医学院是先选专业，然后直接反显学员，其他则是先选学校，然后专业
      educationInfoList.value[eduIndex.value].majorName = ''
      educationInfoList.value[eduIndex.value].major	 = ''
      getMejor()
    }
  }else if(typeParam.value == 'majorName'){
    if(isChengDu.value){//成都医学院专有，成都是专业能选，学院不能选择，通过专业反显学院
      educationInfoList.value[eduIndex.value].collegeName = value.parentName
      educationInfoList.value[eduIndex.value].collegeId	 = value.parentId
    }
    educationInfoList.value[eduIndex.value].majorName = value.text
    educationInfoList.value[eduIndex.value].major	 = value.deptId
  }
  else if(typeParam.value == 'education'){
    if(editEducationFlag.value){//辽师
      educationInfoList.value[eduIndex.value].education = value.text
    }else{//其他学校
      educationInfoList.value[eduIndex.value].education = value.value
      educationNameNoLN.value = value.text
    }
   
  }
  if(isChengDu.value && typeParam.value == 'majorName'){
    majorShowFlag.value = false
  }else{
    showPicker.value = false    
  }

} 

const clearColumns = ()=>{
  columns.value = []
  showPicker.value = false
}

const afterRead = async (file: any) => {
  let formData1 = new FormData();
  formData1.append('file', file.file);
  // formData.append('flag', 'Y');//加密上传
  file.status = 'uploading';
  file.message = '上传中...';
  await ApiUpload.uploadFile(formData1)
    .then((res) => {
      if (res.code == 200) {
        file.status = '';
        file.message = '';
        proofFile.value = res.data.uploadUrl;
        Toast.success('上传成功');
      } else {
        file.status = 'failed';
        file.message = '上传失败';
        Toast.fail(res.msg);
      }
    })
    .catch((err) => {
      file.status = 'failed';
      file.message = '上传失败';
      Toast.fail(`上传失败：${err}`);
    });
};

const submitForm =async () =>{
  // let param = educationInfoList.value[0]
  let param:any = {}
  Object.assign(param, educationInfoList.value[0]);
  param['diplomaFile'] = proofFile.value
  param['applyReason'] = applyReason.value
  // console.log(param)
  // return
  let funSubmit:any = null
  if(editEducationFlag.value){
    funSubmit = editEDu.apply
  }else{
    funSubmit = editEDu.applyAll
  }
  // let {data,code,msg} = await editEDu.apply(param)
  let {data,code,msg} = await funSubmit(param)
  if(code == 200){
    Toast.success(msg)
    router.push({path:'/tab/index'})
  }else{
    Toast.fail(msg);
  }

}

const addItemByArr =(res:any,index:number,educationType:number) =>{
      if(index == 0){
        educationInfoList.value.push({
          education:res.data.education || '',
          collegeId:res.data.collegeId || '',
          collegeName:res.data.collegeName || '',
          major:res.data.major || '',
          majorName:res.data.majorName || '',
          startYear:res.data.startYear || '',
          diplomaFile:res.data.diplomaFile || '',
          applyReason:'',
          educationType:String(educationType),
          showFlag:true,
        })
      }
      // else{
      //   let item = {
      //     education:"",
      //     collegeId:"",
      //     collegeName:"",
      //     major:"",
      //     majorName:"",
      //     startYear:"",
      //     diplomaFile:"",
      //     applyReason:"",   
      //     educationType:String(educationType),
      //     showFlag:false,               
      //   }
      //   educationInfoList.value.push({...item})        
      // }
} 

const initPerinfo =  () => {
    shoolTypeByCode()
    let edu = JSON.parse(getLocalStorageItem('Cache__BaseInfo') as string)
    console.log('edu',edu)
    let a = route.query as any
    // educationType.value = a.type as number    
    let eduIndex = Number(a.index) 
    educationType.value = Number(route.query?.educationType) as unknown as number
    if(edu.data.educationInfoList && edu.data.educationInfoList.length > 0){
      let obj =  edu.data?.educationInfoList[eduIndex]
      eduData.value = {...obj,startYear:obj.schoolStartYear}
      educationInfoList.value.push(eduData.value)
    }else{
      addItemByArr(edu,eduIndex,educationType.value)
    }

    handleEduName()
};

const initBaseInfo = async ()=>{
  let index = Number(route.query?.index) as unknown as number 
  let param = ''
  if(index == 0){
    param = 'first_schooling_period'
  }else if(index == 1){
    param = 'second_schooling_period'
  }else if(index == 2){
    param = 'third_schooling_period'
  }
  let {data,code,msg} = await ApiBase.industryList({dictCode:param})
  if(code == 200){
    schoolPeriodList.value = data
  }
  // await ApiBase.industryList({dictCode:'first_education'})
  //first_education---第一学历-辽宁广东XX学校
  //second_education---第二学历-辽宁广东XX学校
  //third_education---第三学历-辽宁广东XX学校
  //academicType---学历性质-辽宁广东XX学校
  //first_schooling_period---第一学历学制-辽宁广东XX学校
  //second_schooling_period---第二学历学制-辽宁广东XX学校
  //third_schooling_period---第三学历学制-辽宁广东XX学校
}

const inintEducation = async ()=>{
  let index = Number(route.query?.index) as unknown as number
    let param = ''
  if(index == 0){
    param = 'first_education'
  }else if(index == 1){
    param = 'second_education'
  }else if(index == 2){
    param = 'third_education'
  }  
  let {data,code,msg} = await ApiBase.industryList({dictCode:param})
  if(code == 200){
    educationList.value = data
  }  
}

const initListCollages = async ()=>{
  let schoolId = getSchoolId() as string;
  const { data, msg, code } = await ApiDept.deptList({schoolId})
  if(code == 200){
    colleageList.value = data
  }
}

const initMajor = async ()=>{
   let schoolId = getSchoolId() as string;
    let {code,msg,data} = await ApiDept.getCollageBylike({schoolId, deptName:""})
    if(code == 200){
      majorList.value =  data
    }  
}

const getMejor = async ()=>{
  columns.value = []
  let schoolId = getSchoolId() as string;
  try{
    // let {code,msg,data} = await ApiDept.getMajor({
    //       schoolYear:educationInfoList.value[0].schoolStartYear || '',
    //       // college:educationInfoList.value[0].collegeName || ''
    //       college:educationInfoList.value[0].collegeId
    // })
    const { data, msg, code } = await ApiDept.deptList({
      schoolId: schoolId,
      parentId: educationInfoList.value[0].collegeId,
    });    
    majorList.value = data
    // for(let i in majorList.value){
    //   columns.value.push(
    //     {
    //       text:majorList.value[i].deptName,
    //       ...majorList.value[i]
    //     }
    //   )        
    // }    
    console.log('getMejor',columns.value)
  }catch(err){
     majorList.value = []
  }
  

}

const initAcademicType = async ()=>{
  let {data,code,msg} = await ApiBase.industryList({dictCode:'academicType'})
  if(code == 200){
    academicTypeList.value = data
  }
}

onMounted(() => {
  isChengDu.value = isChengDuYiXueYuan()
  initPerinfo();
  initBaseInfo();
  inintEducation()
  initAcademicType()
  initListCollages()
  if(isChengDu.value){
    initMajor()
  }
});
</script>
<style lang="less" scoped>
.fixtop {
  position: fixed;
  width: 100%;
}
.bottomPo {
  position: relative;
  width: 100%;
}
.itemShow {
  margin-top: 120px;
  width: 98%;
  height: 100%;
  // text-align: center;
  text-align: left;
  padding-left: 12.5%;
  background-color: rgba(225,232,228,0.18);
  box-sizing: border-box;
  // overflow-y: scroll;
  .item {
    width: 100%;
    height: 80px;
    line-height: 80px;
    // background-color: #E5EAF3;
    // padding-left: 12.5%;
    font-size: 28px;
    border-bottom: 1px solid #f8f8f8;
  }
}
.main {
  width: 100%;
  min-height: 100vh;
  background-color: #f5f5f5;
  padding: 0 24px;
  box-sizing: border-box;
  padding-top: 6px;
  padding-bottom: 24px;
  .eduList {
    width: 100%;
    margin-top: 24px;
    border-radius: 24px;
    // margin-top: 24px;
    // padding-top: 32px;
    background-color: #ffffff;
    // height: 100%;
    // min-height: 100vh;
    // background-color: #f5f5f5;
    // padding: 0 24px;
    // box-sizing: border-box;
  }
  .eduTitle {
    padding: 32px 40px;
    // margin-top: 32px;
    // height: 45px;

    // padding-left: 40px;
    // padding-right: 40px;
    color: #222222;
    font-size: 36px;
    background-color: #ffffff;
    font-weight: 600;
    font-style: normal;
    font-family: PingFangSC PingFang SC;
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .leftPart {
      background-color: #ffffff;
      display: flex;
      align-items: center;
    }
    .tit1 {
      width: 5px;
      height: 36px;
      background-color: #b42d3b;
      margin-right: 19px;
    }
    // margin: 24px 0;
  }
  .wrap {
    background: #f5f5f5;
    padding: 34px 30px;
    min-height: 100vh;

    .title {
      padding-left: 20px;
      margin: 0 0 33px;
      font-family: PingFangSC-Medium;
      font-size: 32px;
      color: #333333;
      letter-spacing: 0;
      line-height: 32px;
      font-weight: 500;
      border-left: 5px solid var(--theme-color);
    }

    .poosa {
      border-radius: 16px;
      margin-bottom: 40px;
      // height: 300px;
    }

    .submit-btn {
      margin: 50px 0;
    }
    :deep(.van-field__control--custom) {
      display: flex;
      flex-direction: column;
      align-items: normal;
      min-height: var(--van-cell-line-height);

      .upload-tit {
        font-size: 24px;
        line-height: 40px;

        .red {
          color: #ff0000;
        }
      }

      .tips {
        font-size: 24px;
        color: #999999;
        line-height: 40px;
      }

      .van-uploader {
        margin: 24px 0;
      }
    }
  }
}
.eduCon {
  padding-bottom: 44px;
}
.eduConDisplay {
  // display: none;
  border-radius: 24px;
  // margin-top: 24px;
  padding-bottom: 24px;
  // background-color: #ffffff;
}
.editButton {
  width: 100%;
  display: flex;
  align-items: center;
  padding: 0 24px;
  border: 0px;
  margin-top: 83px;

  box-sizing: border-box;
  :deep(.van-button__content) {
    width: 100%;
    background-color: var(--theme-color);
    border: 2px solid  var(--theme-color);
    font-size: 36px;
    border-radius: 44px;
    color: #ffffff;
  }
}

:deep(.van-field__control--custom) {
  display: flex;
  flex-direction: column;
  align-items: normal;
  min-height: var(--van-cell-line-height);

  .upload-tit {
    font-size: 24px;
    line-height: 40px;

    .red {
      color: #ff0000;
    }
  }

  .tips {
    font-size: 24px;
    color: #999999;
    line-height: 40px;
  }

  .van-uploader {
    margin: 24px 0;
  }
}
</style>
