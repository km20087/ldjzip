<template>
  <div class="content">
    <van-nav-bar title="我的组织" left-text="" left-arrow @click-left="onClickLeft" />
    <div class="info">
    <ECard v-if="isShowECard" :per-info="perInfo" :whiteFont="whiteFont" />
      <div class="bac" :class="cssHome.ecardCss" v-if="!isShowECard"></div>
      <div class="card" v-if="!isShowECard">
        <div class="per">
          <Avatar class="ims" :src="perInfo.userProfilePicture" />
          <div class="perInfo">
            <p class="name">{{ perInfo.name }}</p>
            <p class="sda">{{ perInfo.schoolName }}</p>
            <p class="sda">{{ perInfo.collegeName }}{{ perInfo.classesName }}</p>
          </div>
        </div>
      </div>
      <!-- <div class="tabtwo">
        <van-tabs v-model:active="active" color="#1E93EF" title-active-color="#1E93EF">
        </van-tabs>
      </div> -->
      <div class="cardList" :class="isShowECard ? 'isLiaoning' : ''">
        <!-- <div v-if="active === 0" class="detail">
          <div class="coL">
            <p>毕业时学校名称:</p>
            <p>{{ perDetail['graduationSchoolName'] }}</p>
          </div>
          <div class="coL">
            <p>学院:</p>
            <p>{{ perDetail['collegeName'] }}</p>
          </div>
          <div class="coL">
            <p>学号:</p>
            <p>{{ perDetail['studentIdNumber'] }}</p>
          </div>
          <div class="coL">
            <p>省市:</p>
            <p>{{ perDetail['provinceCity'] }}</p>
          </div>
          <div class="coL">
            <p>工作单位:</p>
            <p>{{ perDetail['employer'] }}</p>
          </div>
          <div class="coL">
            <p>职务:</p>
            <p>{{ perDetail['occupationName'] }}</p>
          </div>
          <div class="coL">
            <p>联系电话:</p>
            <p>{{ perDetail['mobile'] }}</p>
          </div>
        </div> -->

        <!-- v-else-if="active === 1" -->
        <div class="org">
          <div class="heiw" v-if="orgList.length > 0">
            <div v-for="(it, ind) in orgList" :key="ind" class="stPart" @click="jumpOrgDetail(it)">
              <van-cell :title="it.groupsName || orgLogo">
                <template #title>
                  <fix-image
                    v-if="settingStore.isShowGroupProfilePicture && it.groupsProfilePicture"
                    :src="picUrl + it.groupsProfilePicture"
                    alt=""
                    width="44"
                    height="44"
                    class="ims2"
                  />
                  <span class="circle-container" v-if="it.pendingAudit == '1'"> </span>
                  <span class="custom-title">{{ it.groupsName }}</span>
                  <img
                    v-for="(subitem, subindex) in it.icons"
                    :src="picUrl + subitem"
                    alt=""
                    class="asdi"
                    :key="subindex"
                  />
                  <span class="tips" v-if="it.isJoin">已加入</span>
                </template>
              </van-cell>
            </div>
            <!-- <van-index-bar
              :index-list="abcList"
              :sticky-offset-top="topNum"
              :sticky="showsticky"
              class="maar"
              @select="getIndex"

            >
              <div v-for="(item, index) in abcList" :key="index" class="sdao">
                <van-index-anchor :index="item" />
                <div
                  v-for="(it, ind) in orgList"
                  :key="ind"
                  class="stPart"
                  @click="jumpOrgDetail(it)"
                >
                  <van-cell :title="it.groupsName || orgLogo" v-if="it.en === item">
                    <template #title>
                      <fix-image
                        v-if="settingStore.isShowGroupProfilePicture && it.groupsProfilePicture"
                        :src="picUrl + it.groupsProfilePicture"
                        alt=""
                        width="44"
                        height="44"
                        class="ims2"
                      />
                      <span class="circle-container" v-if="it.pendingAudit == '1'"> </span>
                      <span class="custom-title">{{ it.groupsName }}</span>
                      <img
                        v-for="(subitem, subindex) in it.icons"
                        :src="picUrl + subitem"
                        alt=""
                        class="asdi"
                        :key="subindex"
                      />
                      <span class="tips" v-if="it.isJoin">已加入</span>
                    </template>
                  </van-cell>
                </div>

              </div>
            </van-index-bar> -->
          </div>
          <div v-else>
            <div class="imsaw">
              <img :src="noneData" alt="" class="ims" />
              <p class="p1">暂无数据~</p>
            </div>
          </div>
        </div>
      </div>
      <!-- <div class="butt1" v-if="active === 0">
        <van-button round block type="primary" native-type="submit" @click="jumpEdtiPer">
          修改个人信息
        </van-button>
      </div> -->
    </div>
  </div>
</template>
<script lang="ts" setup>
import noneData from '@/assets/img/noneData.png';
import Api, { userParam } from '@/api/schoolmate';
import ApiMy from '@/api/my';
import ApiGroup, { userGroupP } from '@/api/group';
import orgLogo from '@/assets/img/orgLogo.png';
import { pinyin } from 'pinyin-pro';
import { useRouter, useRoute } from 'vue-router';
import { Toast } from 'vant';
import { useUserStore, useSettingStore } from '@/store';
import Avatar from '@/components/avatar/index.vue';
import { isLiaoShiDa,isShenYangShiFan ,isChengDuYiXueYuan} from '@/utils/customizedType';
import { useLoadECard } from '@/pages/home/useLoadECard';
import { useSkin2 } from '@/pages/home/useSkin2'

const { cssHome } = useSkin2()
const userStore = useUserStore();
const settingStore = useSettingStore();
const route = useRoute();
const { ECard, isShowECard,whiteFont } = useLoadECard();
const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
const active = ref(0);
const topNum = ref(443);
const showsticky = ref(false);
const perDetail = reactive({
  schoolName: '',
  collegeName: '',
  graduationSchoolName: '', //毕业时学校名称
  provinceCity: '',
  // detailedAddress: '',
  studentIdNumber: '',
  employer: '',
  occupationName: '',
  mobile: '',
});
const perInfo = reactive({
  userProfilePicture: '',
  collegeName: '',
  classes: '',
  name: '',
  schoolName: '',
  classesName: '',
  educationInfoList: [],
});

const cardExchangeId = ref('');
const router = useRouter();
let orgList = <any>reactive([]);
const getIndex = (val: number | string) => {
  console.log(val);
};
const pasd = <userParam>reactive({
  userId: '',
});
const paso = <userGroupP>reactive({
  userId: '',
});

const jumpOrgDetail = (it: any) => {
  console.log(it.groupsId);
  router.push({
    path: '/orgDetail',
    query: { groupsId: it.groupsId, active: 'member', pendingAudit: it.pendingAudit },
  });
};
const showInde = (item: any, val: any) => {
  console.log(item);
  console.log(val);
};
const jumpEdtiPer = () => {
  // 跳转编辑页的时候先重置个人的职务信息
  userStore.isNeedInitOccupation = true;
  router.push({ path: '/editPerInfo' });
};

const initOrgList = (val: any) => {
  for (let i in val) {
    val[i].en = '';
    val[i].en = pinyin(val[i].groupsName, { toneType: 'none' }).slice(0, 1).toUpperCase();
  }
};
const exchangeCard = async () => {
  const { data, code, msg } = await Api.exchangeSchoolmateCard({
    userId: cardExchangeId.value,
    exchangeResult: '1',
  });
  Toast({ message: msg });
};
const getOrgList = async () => {
  paso.userId = cardExchangeId.value;
  const { data, code, msg } = await ApiGroup.userGroup(paso);
  console.log('getOrgList',data)
  if (code == 200) {
    orgList.push(...data);
    initOrgList(orgList);
    let arr1: string[] = [];
    for (let i in orgList) {
      arr1.push(orgList[i].en);
    }
    arr1 = unique3(arr1);
    for (let a in arr1) {
      abcList.push(arr1[a]);
    }
  }
};
const initPer = async () => {
  const { data, code, msg } = await ApiMy.baseInfo({});
  if (code == 200) {
    cardExchangeId.value = data.userId || '';
    getOrgList();
    Object.assign(perInfo, data);
    // Object.assign(perDetail, data);
  }
};
const unique3 = (arr: any) => {
  let newArray = arr.filter((item: string, index: number) => {
    return arr.indexOf(item) === index;
  });
  return newArray;
};
const abcList: string[] = reactive([]);
const onClickLeft = () => {
  router.back();
};
onBeforeMount(async () => {
  await initPer(); 
  if (route.query.active) {
    active.value = Number(route.query.active);
  }  
});
</script>
<style lang="less" scoped>
.stPart {
  width: 100%;
  .asdi {
    width: 24px;
    height: 24px;
    margin-left: 5px;
  }
  /deep/.van-cell {
    border-bottom: 1px solid #e5e5e5;
    position: relative;
  }
  /deep/ .van-cell__title {
    display: flex;
    align-items: center;
    // width: 100%;
  }
  .ims2 {
    margin-right: 10px;
    width: 44px;
    height: 44px;
    border-radius: 50%;
  }
  .tips {
    position: absolute;
    right: 50px;
    font-size: 24px;
    font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 400;
    color: #999999;
  }
}
.content {
  width: 100%;
  height: 100%;
  overflow-y: scroll;
}
.info {
  width: 100%;
  position: relative;
  .bac {
    width: 100%;
    height: 170px;
    background: url('@/assets/img/mine-top_bg.png') no-repeat;
    background-size: 100% 170px;
    position: relative;
  }
  .top-bg {
    height: 170px;
    background: url('@/assets/img/mine-top_bg.png');
  }  
  .card {
    width: 690px;
    height: 220px;
    margin: 0 auto;
    position: relative;
    // left: 220px;
    background: url('@/assets/img/perinfo.png') no-repeat;
    // background-size: 100% 220px;
    background-size: cover;
    top: -110px;
    .per {
      width: 100%;
      height: 100%;
      display: flex;
      // align-items: center;
      // margin-left: 30px;
      padding: 30px;
      .ims {
        width: 88px;
        height: 88px;
        position: relative;
        // top: -20px;
        border-radius: 50%;
      }
      .perdetail {
        margin-left: 30px;
        .name {
          font-size: 36px;
          font-family: PingFang-SC-Bold, PingFang-SC;
          font-weight: bold;
          color: #573201;
          line-height: 36px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
          padding-bottom: 20px;
        }
        .uni {
          font-size: 24px;
          font-family: PingFang-SC-Medium, PingFang-SC;
          font-weight: 500;
          color: #573201;
          line-height: 24px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
        }
        .mar10 {
          margin-top: 10px;
        }
      }
      .perInfo {
        width: 80%;
        margin-left: 30px;
        p {
          margin: 0px;
        }
        .name {
          font-size: 36px;
          font-family: PingFang-SC-Bold, PingFang-SC;
          font-weight: bold;
          color: #573201;
          line-height: 36px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
        }
        .sda {
          margin-top: 20px;
          font-size: 24px;
          font-family: PingFang-SC-Medium, PingFang-SC;
          font-weight: 500;
          color: #573201;
          line-height: 24px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
        }
      }
    }
  }
  .bor {
    width: 100%;
    height: 24px;
    background-color: #dfdfdf;
    position: relative;
  }
  .tabtwo {
    // width: 100%;
    // // height: 88px;
    // position: relative;
    // top: -80px;
    // border-bottom: 1px solid #dfdfdf;
  }
  .cardList {
    position: relative;
    top: -80px;
    padding: 0 30px;
    &.isLiaoning {
      top: 0;
    }
    .detail {
      .coL {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
    }
    .heiw {
      width: 100%;
      height: 70%;
      overflow-y: scroll;
      // margin-bottom: 50px;
      .maar {
        // margin-bottom: 260px;
        .sdao:nth-last-child(1) {
          margin-bottom: 100px !important;
          /deep/ .van-cell:nth-last-child(1) {
            .van-cell__title {
              // margin-bottom: 100px !important;
            }
          }
        }
        .sdao {
          /deep/.van-index-anchor {
            font-size: 24px;
            font-family: PingFangSC-Medium, PingFang SC;
            font-weight: 500;
            color: #999999;
          }
        }
      }
    }
  }
  .butt1 {
    // position: fixed;
    // bottom: 5px;
    // left: 50%;
    // transform: translate(-50%, -50%);
    margin: 0px 100px;
    margin-top: 60px;
    // height: 200px;
    text-align: center;

    /deep/ .van-butto {
      margin: 0 auto;
    }
    /deep/.van-button__content {
      // width: 300px;
    }
    // margin-top: 10px;
    // margin: 10px 20px;
  }
  .imsaw {
    width: 100%;
    height: 100%;
    margin-top: 60px;
    text-align: center;
    margin-top: 200px;
    .ims {
      width: 400px;
      height: 270px;
    }
    .p1 {
      font-size: 28px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #999999;
    }
    .but {
      margin-top: 40px;
    }
  }
}
.circle-container {
  display: inline-block;
  width: 10px;
  height: 10px;
  background: #ff0000;
  border-radius: 50%;
  position: relative;
  top: -18px;
  left: -12px;
}
</style>
