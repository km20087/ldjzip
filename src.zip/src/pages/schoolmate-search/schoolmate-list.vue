<template>
  <span class="empty" v-if="!list.length">暂无校友数据</span>
  <van-list
    class="user-list"
    v-model:loading="loadingClone"
    :finished="finishedClone"
    @load="emits('load')"
    :immediate-check="false"
  >
    <div
      class="van-hairline--bottom user-wrap"
      v-for="(item,index) in list"
      :key="item.userId"
    >
      <Avatar class="avatar" :src="item.userProfilePicture" @click="goPage(item,index)" />
      <div class="info-wrap">
        <span class="name" v-html="item.name"></span>
        <span class="date">{{ item.schoolStartYear }}{{ item.schoolEndYear ? `-${item.schoolEndYear}` : '' }}</span>
        <span class="invite" v-if="inviteFlag" @click="inviteSchoolMate(item)">
          邀请
        </span>
      </div>
    </div>
    <div class="fix-list" />
  </van-list>
</template>

<script setup lang="ts">
  import Avatar from '@/components/avatar/index.vue';
  import { useVModel } from '@/hooks/useVModel';
  import { useRouter } from 'vue-router';
  const router = useRouter();
  const props = defineProps<{
    list: SchoolMate[];
    loading: boolean;
    finished: boolean;
    inviteFlag:boolean
  }>();
  const emits = defineEmits<{
    (e: 'load'): void;
    (e: 'update:loading', loading: boolean): void;
    (e: 'update:finished', finished: boolean): void;
    (e: 'inviteMate',mateId:string): void;
  }>();

  const loadingClone = useVModel(props, 'loading', emits);
  const finishedClone = useVModel(props, 'finished', emits);

  const inviteSchoolMate = (item:any)=>{
    console.log('inviteSchoolMate',item.userId)
    emits('inviteMate',item.userId)
    // console.log('emits',emits('inviteMate',))
  }

  function goPage(item: SchoolMate,index:number) {
    // return
    router.push({ path: '/agreeAlumniCard', query: { userId: item.userId } });
  }
</script>

<style lang="less" scoped>
  .empty {
    padding: 20px;
    display: inline-block;
  }
  .user-list {
    padding-left: 20px;
  }
  .user-wrap {
    padding: 20px 0;
    width: 100%;
    --van-border-color: #dfdfdf;
    display: flex;
    flex-direction: row;
    align-items: center;
    .avatar {
      margin-right: 20px;
      width: 88px;
      height: 88px;
      border-radius: 50%;
    }
    .info-wrap {
      padding: 8px 0;
      display: flex;
      // flex:1;
      flex-direction: column;
      justify-content: space-around;
      .name {
        font-size: 32px;
        color: #666666;
      }
      .invite{
        font-size: 24px;
        color: #ffffff;
        width: 100px;
        text-align: center;
        background-color:rgba(245,108,108,1);
        height: 32px;
        line-height: 32px;
      }
      .date {
        font-size: 24px;
        color: #999999;
      }
    }
  }
  .fix-list {
    width: 1px;
    height: 130px;
  }
</style>
