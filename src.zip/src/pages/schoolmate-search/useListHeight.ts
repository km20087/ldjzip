import { ref, onMounted } from 'vue';
export function useListHeight() {
  const searchBoxRef = ref();
  const listHeight = ref();
  onMounted(() => {
    let windowHeight = window.innerHeight;
    listHeight.value = windowHeight - searchBoxRef.value.$el.clientHeight;
  });

  return {
    searchBoxRef,
    listHeight,
  };
}
