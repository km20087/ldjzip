<template>
  <main class="wrap">
    <van-nav-bar title="搜索" left-arrow @click-left="onClickLeft" />
    <van-search ref="searchBoxRef" v-if="!isShanDa()" v-model="searchData" placeholder="请输入校友名字搜索">
    </van-search>      
    <van-search ref="searchBoxRef" v-else show-action class="isdi" v-model="searchDataSD" placeholder="请输入校友姓名、学院、专业来搜索">
      <template #action>
        <div @click="clickSeachSchoolMate"  class="iasd">
          搜索
        </div>
      </template>
    </van-search>  
    <van-empty v-if="collegeList.length == 0" description="本校暂无该校友入驻" />
    <div v-else-if="!isShanDa()" class="list-box" :style="{ height: `${listHeight}px` }">
      <aside class="list-wrap">
        <span
          class="dept-wrap"
          :class="{ active: activeCollegeId == item.deptId }"
          v-for="item in collegeList"
          :key="item.deptId"
          @click="changeCollege(item)"
        >
          {{ item.deptName }}
        </span>
        <div class="dept-wrap" />
      </aside>
      <aside class="list-wrap" v-if="isShowMajor">
        <span class="empty-txt" v-if="majorList.length == 0">暂无专业数据</span>
        <template v-else>
          <span
            class="dept-wrap"
            :class="{ active: activeMajorId == item.deptId }"
            v-for="item in majorList"
            :key="item.deptId"
            @click="changeMajor(item)"
          >
            {{ item.deptName }}
          </span>
          <div class="dept-wrap" />
        </template>
      </aside>
      <aside class="list-wrap">
        <SchoolMateList
          v-model:loading="loading"
          v-model:finished="finished"
          :list="schoolMateList"
          :inviteFlag="inviteFlag"
          @load="loadSchoolMate"
          @inviteMate="inviteMate"
        />
      </aside>
    </div>
    <div v-else class="alumniList">
      <div class="totalShow" v-if="total > 0">
        <p class="wwe">为你搜索到以下内容：</p>
        <div class="itp">
          <p class="wwe">共</p>
          <p class="wwe wids"> {{total}}</p>
          <p class="wwe">项</p>
        </div>
      </div>
      <van-list v-model:loading="loading" :finished="finished" finished-text="没有更多了" @load="onLoad" :offset="100">
        <SchoolMateList2 :list="dataList" @jump="jumpAlu">
        </SchoolMateList2>
      </van-list>
    </div>    
  </main>
</template>

<script lang="ts" setup>
  import { ref, onBeforeMount, watch } from 'vue';
  import { useDept } from '@/hooks/useDept';
  import { useListHeight } from './useListHeight';
  import { genTree } from './util';
  import SchoolMateApi from '@/api/schoolmate';
  import SchoolMateList from './schoolmate-list.vue';
  import SchoolMateList2 from '@/components/schoolmate-list/index.vue';
  import { Toast } from 'vant';
  import { debounce } from 'lodash-es';
  import router from '@/router';
  import { useSettingStore } from '@/store';
  import { isLiaoShiDa,isShanDa } from '@/utils/customizedType';
  import { invitSchoolmate } from '@/api/backSchoolMonth/index'  
  const settingStore = useSettingStore();

  defineOptions({
    name: 'schoolmate-search'
  })

  // 辽宁师大不展示专业列
  const isShowMajor = ref(!isLiaoShiDa() && !isShanDa());
  const $route = useRoute();
  const { getDept } = useDept();
  const { searchBoxRef, listHeight } = useListHeight();

  let cacheCollegeList: Dept[] = [];
  const collegeList = ref<Dept[]>([]);
  const activeCollege = ref<Dept>();
  const activeCollegeId = ref('');
  const majorList = ref<Dept[]>([]);
  const activeMajorId = ref('');

  const loading = ref(false);
  const finished = ref(false);
  const isLastPageb = ref(false);
  const total = ref(0);
  const dataList = <any>ref([])
  const pages = ref(0);
  const schoolMateList = ref([]);
  const pageNum = ref(0);
  const inviteFlag = ref(false)


  let toastInstance = ref();

  const searchData = ref('');
  const searchDataSD = ref('')
  async function searchSchoolMate() {
    const { code, data } = await SchoolMateApi.listCollegeAndMajorByKeyword({
      keyWord: searchData.value,
    });
    if (code == 200) {
      collegeList.value = genTree(data);
      if (collegeList.value.length) {
        changeCollege(collegeList.value[0]);
      }
    }
    return [];
  }
  const debounceSearchSchoolMate = debounce(searchSchoolMate, 500, { trailing: true });
  const clickSeachSchoolMate = ()=>{
    console.log('clickSeachSchoolMate')
    pageNum.value = 1
    dataList.value = []
    init()
    // debounce(init, 500, { trailing: true });
  }
  // 监听searchData的变动， 以防抖的方式请求接口
  watch(searchData, async (str: string) => {
    activeCollegeId.value = '';
    activeMajorId.value = '';
    str.length ? debounceSearchSchoolMate() : initCollegeListData();
  });

  // 监听searchData的变动， 以防抖的方式请求接口
 watch(
  ()=>$route.query,
  (val:any)=>{
    console.log('$route.query',val)
    if(val.type=='invite'){
      inviteFlag.value = true
    }
  },
  {immediate:true}
 )

  function changeCollege(item: Dept) {
    activeCollege.value = item;
    activeCollegeId.value = item.deptId;
  }

  function changeMajor({ deptId }: Dept) {
    activeMajorId.value = deptId;
  }

  const inviteMate =async (mateId:string)=>{
    let returnActivityId = $route.query?.id || ""
    console.log('inviteMate',mateId)
    try{
      let {code,msg,data} = await invitSchoolmate({userId:mateId,returnActivityId})
      if(code == 200){
        Toast.success(msg)
      }else{
        Toast.fail(msg)
      }
    }catch(err:any){
      Toast.fail(err)
    }
  }

  const jumpAlu = (item: any) => {
    router.push({ path: '/agreeAlumniCard', query: { userId: item.userId } });
  };

  async function loadSchoolMate() {
    loading.value = true;
    let param = isShowMajor.value
      ? { major: activeMajorId.value }
      : { collegeId: activeCollegeId.value };
    const result = await SchoolMateApi.getSchoolMate({
      keyWord: searchData.value ? searchData.value : undefined,
      ...param,
      pageSize: 10,
      pageNum: ++pageNum.value,
    });
    if (result.code == 200) {
      const { list, pageNum: page, pages } = result.data;
      if (searchData.value.length) {
        let reg = new RegExp(searchData.value, 'ig');
        list.forEach((item: SchoolMate) => {
          item.name = item.name.replace(
            reg,
            `<span style='color:${settingStore.themeColor}'>$&</span>`
          );
        });
      }
      pageNum.value = page;
      finished.value = page >= pages;
      schoolMateList.value = page == 1 ? list : [...schoolMateList.value, ...list];
    } else {
      finished.value = true;
    }
    loading.value = false;
  }

  async function reloadSchoolMate() {
    pageNum.value = 0;
    await loadSchoolMate();
    toastInstance.value.clear();
  }

  watch(activeMajorId, async () => {
    await reloadSchoolMate();
  });

  watch(activeCollegeId, async (id: string) => {
    console.log('watch2')
    if (!id) return;
    console.log('watch2--1')
    toastInstance.value = Toast.loading({ message: '加载中' });
    if (isShowMajor.value) {
      majorList.value = searchData.value ? activeCollege.value?.children ?? [] : await getDept(id);
      majorList.value.length && (activeMajorId.value = majorList.value[0].deptId);
    } else {
      console.log('watch2--2')
      if(isShanDa()){
        await onLoad()
      }else{
        await reloadSchoolMate();
      }
    }
  });
  const init = async () => {
    console.log('initShanda')
      if(pageNum.value == 0){
        pageNum.value = 1
      }
      loading.value = true;
      const { data, code ,msg} = await SchoolMateApi.getSchoolMate({
        keyWord: searchDataSD.value,
          pageSize: 10,
          pageNum: pageNum.value,
      });
      if (code == 200) {
        pages.value = data.pages;
        total.value = data.total;
        isLastPageb.value = data.isLastPage;
        dataList.value = data.pageNum == 1 ? data.list : [...dataList.value, ...data.list];
        loading.value = false;
      } else {
        Toast({
          message: msg,
          icon: 'none',
        });
        dataList.value = []
      }
      if (isLastPageb.value) {
        loading.value = false;
        finished.value = true;
      }
  };
  const onLoad = async () => {
    // if(pageNum.value == 0){
    //   pageNum.value = 1
    // }
    // await init();
    // loading.value = false;
    // finished.value = true;    
    // return
    // && loading.value
    if (!isLastPageb.value ) {
      console.log('onLoad--1')
      finished.value = false;
      pageNum.value++
      await init();
    } else {
      console.log('onLoad--2')
      loading.value = false;
      finished.value = true;
    }
  };  
  // 从接口或缓存中获取全部的学院列表信息
  async function initCollegeListData() {
    let listData = cacheCollegeList;
    if (!listData.length) {
      listData = await getDept();
    }
    collegeList.value = listData;
    listData && (activeCollegeId.value = listData[0].deptId);
  }

  onBeforeMount(() => {
    initCollegeListData();
  });

  function onClickLeft() {
    router.back();
  }
</script>

<style lang="less" scoped>
  .wrap {
    width: 100vw;
    height: 100vh;
    background: #f9f9f9;
    overflow: hidden;
  }
  :deep(.van-search) {
    --van-border-radius-sm: 200px;
    margin-bottom: 20px;
  }
  .empty-txt {
    padding: 20px;
    display: block;
  }
  .list-box {
    display: flex;
    flex-direction: row;
    .list-wrap {
      overflow-y: auto;
      &:nth-child(1) {
        flex: 0 0 208px;
        background: #efefef;
      }
      &:nth-child(2) {
        flex: 0 0 208px;
        background: #fafafa;
      }
      &:last-of-type {
        flex: 1;
        background: #fff;
      }
    }
    .dept-wrap {
      padding: 20px;
      min-height: 80px;
      font-size: 28px;
      color: #222;
      box-sizing: content-box;
      display: flex;
      flex-direction: column;
      &.active {
        font-weight: 500;
        background: #fff;
        &::after {
          content: '';
          margin-top: 10px;
          background: var(--van-button-primary-background-color);
          width: 55px;
          height: 4px;
          border-radius: 2px;
          display: inline-block;
        }
      }
    }
  }
  .alumniList {
    height: 100%;
    overflow-y: scroll;
    .totalShow{
      width: 100vw;
      height: 36px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 26px;
      margin-bottom: 20px;
      box-sizing: border-box;
      padding: 0 20px;
      color: #666666;
      .itp{
        display: flex;
        align-items: center;
      }
      .wwe{
        padding: 0px;
      }
      .wids{
        color:#222222;
        font-weight: 700;
      }
    }
    .van-list {
      padding: 10px 0 550px;
      background-color: #fff;
      :deep(.van-list__loading) {
        margin: 0 auto;
      }

      :deep(.van-list__finished-text) {
        width: 100%;
      }
    }
  }  
  // :deep(.van-search__action){
  //   position: relative;
  //   // left: -25px;
  //   left:-5%;
  //   border-radius: 40px 40px 40px 40px;
  //   color: #fff;
  //   width: 140px;
  //   text-align: center;
  //   background: var(--theme-color);
  // }
  .isdi {
    // position: absolute;
    // top: 160px;
    // left: 30px;
    // width: 100%;
    margin: 10px 20px 20px 20px;
    // background: #fff;
    height: 80px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 40px;
    --van-search-background-color:#fff;
    --van-search-content-background-color: none;
    --van-search-action-padding: 5px;
    --van-search-action-text-color: #222;
    --van-search-left-icon-color: #222;
    --van-field-input-text-color: #222;
    --van-active-color: none;
    .iasd {
      // background: rgba(255, 255, 255, 0.1);
      background: var(--theme-color);
      color: #fff;
      padding: 0 30px;
      border-radius: 40px;
    }
  }  
  :deep(.van-field__control){
    font-size: 24px;
  }
</style>
