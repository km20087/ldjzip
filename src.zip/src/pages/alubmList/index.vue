<template>
  <van-nav-bar :title="title" left-text="" left-arrow @click-left="onClickLeft" />
  <div class="content" @click="cancelShowSelect($event)">
    <div class="phtotList" v-if="newList.length > 0">
      <van-list
        v-model:loading="loading"
        :finished="finished"
        finished-text="没有更多了"
        @load="onLoad"
        :offset="100"
      >
        <div v-for="(item, index) in newList" :key="index">
          <div class="titFirst">
            <div class="date">
              {{ dateChangeShow(item.createTime.slice(5, 10)) }}
            </div>
            <div
              class="selsect"
              :style="{ color: settingStore.themeColor }"
              v-show="showSelect"
              @click="getChoice(index)"
            >
              选择
            </div>
          </div>

          <div class="list">
            <div class="item" v-for="(it, id) in item.picList" :key="id">
              <div
                class="cliTou"
                @click="showImg(it)"
                @touchstart="touchStart($event)"
                @touchend="touchEnd"
              >
                <van-checkbox v-model="it.check" v-if="showSelect" class="checkFlag"></van-checkbox>
                <fix-image
                  class="ims"
                  v-if="/\.(png|jpeg|jpg)$/.test(it.photoUrl)"
                  :src="it.photoUrl"
                  @error="imgNOFind"
                  width="226"
                  height="230"
                  alt="相册图片"
                />
                <div class="video-wrap" v-else>
                  <video class="ims" :src="getRealFilePath(it.photoUrl)"></video>
                  <van-icon class="icon-play" name="play-circle-o" />
                </div>
                <div class='thum'>
                  <van-icon name='like-o' v-if='it.isThumbsUp == "0"' color='#FFFFFF'/>
                  <van-icon name='like' v-if='it.isThumbsUp == "1"' color='#ee0a24'/>
                  <p class="poi">{{it.thumbsUpCount}}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </van-list>
    </div>
    <div v-else class="noData">
      <img :src="photoNone" alt="" class="ims" />
      <div class="poTip">还没有图片</div>
      <div class="poTip">快上传给TA看看吧~</div>
    </div>
    <!-- 预留一个汕大版本的预览，后续没爆出有问题的话代码可删除 -- 20260116 -->
    <!-- <van-image-preview v-model:show="show" :images="images" :closeable="true" @close="onClosePreviewImage">
      <template #image="{ src }">
        <FixImage class="van-image__img" v-if="/\.(png|jpeg|jpg)$/.test(src)" :src="src" />
        <video ref="previewVideoRef" v-else style="width: 100%;" controls :src="src"></video>
      </template>
      <template #cover>
        <div class="osi">
          <div>
            <div class="oius" v-if="describePic">
              <img :src="pencil" alt="" class="imsM" />{{ describePic }}
            </div>
            <div class="oius mar19" v-if="positionDetail">
              <img :src="jinghao" alt="" class="imsM" />{{ positionDetail }}
            </div>
          </div>
          <div class='support'>
            <van-icon name='like-o' v-if='isThumbsUp == "0"' color="#ffffff" @click='thumUpPhotoClick'/>
            <van-icon name='like' v-if='isThumbsUp == "1"' color='#ee0a24' @click='thumUpPhotoClick'/>
            <p class="poi">{{thumbsUpCount}}</p>
          </div>
        </div>
      </template>
    </van-image-preview> -->
    <van-popup v-model:show="show" style="width: 100vw; height: 100vh; background: #333" :close-on-click-overlay="false" :close-on-popstate="true">
      <van-icon class="van-image-preview__close-icon van-image-preview__close-icon--top-right" name="close" @click="onClosePreviewImage"></van-icon>
      <div style="position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); width: 100%">
        <FixImage class="van-image__img" v-if="/\.(png|jpeg|jpg)$/.test(images[0])" :src="images[0]" />
        <video ref="previewVideoRef" v-else style="width: 100%;" controls :src="images[0]"></video>
      </div>
      <div class="van-image-preview__cover">
        <div class="osi">
          <div>
            <div class="oius" v-if="describePic">
              <img :src="pencil" alt="" class="imsM" />{{ describePic }}
            </div>
            <div class="oius mar19" v-if="positionDetail">
              <img :src="jinghao" alt="" class="imsM" />{{ positionDetail }}
            </div>
          </div>
          <div class='support'>
            <van-icon name='like-o' v-if='isThumbsUp == "0"' color="#ffffff" @click='thumUpPhotoClick'/>
            <van-icon name='like' v-if='isThumbsUp == "1"' color='#ee0a24' @click='thumUpPhotoClick'/>
            <p class="poi">{{thumbsUpCount}}</p>
          </div>
        </div>
      </div>
    </van-popup>
    <div class="icon" v-if="orgRight == '1' || serviceRight == '1'">
      <img :src="plus" @click="jumpAddPic" class="iconIms" alt="" />
    </div>
    <div class="buttonTab" v-if="showSelect">
      <div class="but1" @click="tranAlu">
        <img :src="changeBut" alt="" class="imsBUt" />
        <span class="fo12">转移</span>
      </div>
      <div class="but1" @click="deleteAlbumt">
        <img :src="deletBut" alt="" class="imsBUt" />
        <span class="fo12">删除</span>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import { reactive, ref } from 'vue';
  import Api from '@/api/orgPhoto';
  import photoNone from '@/assets/img/photoNone.png';
  import plus from '@/assets/img/icon_publish.png';
  import deletBut from '@/assets/img/delete.png';
  import changeBut from '@/assets/img/change.png';
  import pencil from '@/assets/img/pencil.png';
  import jinghao from '@/assets/img/jinghao.png';
  import { Toast } from 'vant';
  import { Dialog } from 'vant';
  import { albumParam, rightCon } from '@/store';
  import { useSettingStore } from '@/store';
  import { getRealFilePath } from '@/utils';
  import 'vant/es/image-preview/style'

  const settingStore = useSettingStore();
  const setAlbumParam = albumParam();
  const rightConFlag = rightCon();
  
  const router = useRouter();
  const $route = useRoute();
  const orgRight = ref('0');
  const serviceRight = ref('0');
  const title = ref('');
  const show = ref(false);
  const previewVideoRef = ref()
  const positionDetail = ref('');
  const describePic = ref('');
  const isThumbsUp = ref('0');
  const photoId = ref('')
  const thumbsUpCount = ref('0');
  const images = ref([] as Array<string>);
  interface photoP {
    photoId: string;
    photoUrl: string;
    describe: string;
    albumId: string;
    createTime: string;
    check?: boolean;
    address?: string;
    isThumbsUp?:string;
    thumbsUpCount?:string;
  }
  interface newP {
    createTime: string;
    picList: photoP[];
  }
  const listP = ref({
    albumId: '',
    pageNum: 1,
    pageSize: 10,
  });
  const imgNOFind = (e: any) => {
    e.target.src = photoNone;
  };
  const loading = ref(false);
  const finished = ref(false);
  const isLastPageb = ref(false);
  const photoList = ref([] as Array<photoP>);
  const newList = ref([] as Array<newP>);
  const timeOutEvent = <any>ref('');
  const showSelect = ref(false);
  const thumUpPhotoClick =async ()=>{
    console.log('thumUpPhotoClick')
    if(isThumbsUp.value == '0'){
      isThumbsUp.value = '1'
    }else{
      isThumbsUp.value = '0'
    }
    if(isThumbsUp.value == '1'){
      thumbsUpCount.value = String(Number(thumbsUpCount.value) + 1);
    }else{
      if(Number(thumbsUpCount.value)>0){
          thumbsUpCount.value = String(Number(thumbsUpCount.value) - 1);
        }else{
           thumbsUpCount.value = '0'
      }
    }    
    let dp = {
      photoId:photoId.value,
      isThumbsUp:isThumbsUp.value
    }
    const {data,code,msg} = await Api.thumbUpPhoto(dp)

  };
  const onClickLeft = () => router.back()
  const dateChangeShow = (val: string) => {
    return val.replace('-', '/');
  };
  const getChoice = (index: number) => {
    let b = newList.value[index].picList;
    for (let a in b) {
      b[a].check = !b[a].check;
    }
  };
  const showImg = (value: any) => {
    // console.log(value)
    isThumbsUp.value = value.isThumbsUp
    thumbsUpCount.value = value.thumbsUpCount
    photoId.value = value.photoId
    if (!showSelect.value) {
      images.value = [];
      images.value.push(getRealFilePath(value.photoUrl));
      show.value = true;
      positionDetail.value = value.address;
      describePic.value = value.describe;
    } else {
    }
  };
  const onClosePreviewImage = () => {
    show.value = false
    previewVideoRef.value && previewVideoRef.value.pause();
  }
  const touchStart = (e: any) => {
    if (orgRight.value == '0' && serviceRight.value == '0') {
      return;
    }
    timeOutEvent.value && clearTimeout(timeOutEvent.value);
    timeOutEvent.value = setTimeout(() => {
      showSelect.value = true;
      console.log(showSelect.value);
    }, 500);
    // e.preventDefault();
  };
  const touchEnd = () => {
    timeOutEvent.value && clearTimeout(timeOutEvent.value);
  };
  const jumpAddPic = () => {
    setAlbumParam.albumName = title.value;
    // let albumId = $route.query.albumId as string;
    router.push({ path: '/addPic' });
  };
  const onLoad = async () => {
    if (!isLastPageb.value && loading.value) {
      finished.value = false;
      listP.value.pageNum = (listP.value.pageNum as number) + 1;
      // await init();
      let albumId = $route.query.albumId as string;
      await initPhotoList(albumId);
    } else {
      loading.value = false;
      finished.value = true;
    }
  };
  const cancelShowSelect = (e: any) => {
    // console.log(e.target.classList[0]);
    let classList = ['van-badge__wrapper', 'ims', 'selsect', 'buttonTab', 'imsBUt', 'fo12'];
    let a = e.target.classList[0];
    if (classList.includes(a)) {
      return;
    } else {
      showSelect.value = false;
    }
  };
  const initPhotoList = async (albumId: string) => {
    loading.value = true;
    listP.value.albumId = albumId;
    const { data, code, msg } = await Api.listAlbumPhotos(listP.value);
    if (listP.value.pageNum == 1) {
      photoList.value = [];
      newList.value = [];
    }
    if (code == 200) {
      isLastPageb.value = data.isLastPage;
      loading.value = false;
      photoList.value = photoList.value.concat(data.list);
    } else {
      Toast({
        message: msg,
        icon: 'none',
      });
    }
    if (isLastPageb.value) {
      loading.value = false;
      finished.value = true;
    }
    initDateArr(data.list);
  };
  const tranAlu = () => {
    // setAlbumParam.fromAlbumId =
    let idList: string[] = [];
    for (let i in newList.value) {
      let b = newList.value[i];
      for (let a in b.picList) {
        if (b.picList[a].check) {
          idList.push(b.picList[a].photoId);
        }
      }
    }
    setAlbumParam.photoList = idList as string[];
    router.push({ path: '/selectAlubmt' });
  };

  const deleteAlbumt = async () => {
    // console.log(newList.value);
    let idList: string[] = [];
    for (let i in newList.value) {
      let b = newList.value[i];
      for (let a in b.picList) {
        if (b.picList[a].check) {
          idList.push(b.picList[a].photoId);
        }
      }
    }
    Dialog.confirm({
      title: '警告',
      message: '确定删除吗',
      confirmButtonText: '确定删除',
    })
      .then(async () => {
        let { code, data, msg } = await Api.deleteAlbumPhotos({
          albumId: setAlbumParam.albumId,
          photoList: idList,
        });
        Toast({ message: msg });
        if (code == 200) {
          showSelect.value = false;
          listP.value.pageNum = 1;
          initPhotoList(setAlbumParam.albumId);
        }
      })
      .catch((err) => {
        // on cancel
      });
  };
  const initDateArr = (arr: Array<photoP>) => {
    for (let i in arr) {
      arr[i].createTime = arr[i].createTime.slice(0, 10);
      arr[i].check = false;
    }
    if (newList.value.length > 0) {
      let arr3: string[] = [];
      newList.value.forEach((item) => {
        arr3.push(item.createTime);
      });
      for (let a in arr) {
        let num = arr3.indexOf(arr[a].createTime);
        if (num === -1) {
          newList.value.push({ createTime: arr[a].createTime, picList: [] });
          let len = newList.value.length;
          newList.value[len - 1].picList.push(arr[a]);
        } else {
          newList.value[num].picList.push(arr[a]);
        }
      }
    } else {
      let arr2: string[] = [];
      for (let i in arr) {
        let flag = arr2.indexOf(arr[i].createTime);
        if (flag == -1) {
          arr2.push(arr[i].createTime);
        }
      }
      for (let i in arr2) {
        newList.value.push({ createTime: arr2[i] as string, picList: [] });
      }
      for (let i in newList.value) {
        for (let a in arr) {
          if (newList.value[i].createTime === arr[a].createTime) {
            newList.value[i].picList.push(arr[a]);
          }
        }
      }
    }
    console.log(newList.value);
  };
  onMounted(() => {
    console.log($route.query.albumName);
    title.value = $route.query.albumName
      ? ($route.query.albumName as string)
      : (setAlbumParam.albumId as string);
    let albumId = $route.query.albumId as string;
    setAlbumParam.albumName = $route.query.albumName as string;
    setAlbumParam.albumId = $route.query.albumId as string;
    // setAlbumParam.permissionScope = $route.query.permissionScope as string;
    orgRight.value = rightConFlag.orgR;
    serviceRight.value = rightConFlag.serviceR;
    initPhotoList(albumId);
  });
</script>

<style lang="less" scoped>
.content {
  width: 100%;
  height: calc(100% - var(--van-nav-bar-height));
  overflow-y: scroll;
  padding: 0px 24px;
  position: relative;
  .icon {
    position: fixed;
    top: 70%;
    left: 86%;
    width: 96px;
    height: 96px;
    .iconIms {
      width: 96px;
      height: 96px;
    }
  }
  .phtotList {
    width: 100%;
    .titFirst {
      margin-top: 20px;
      width: 100%;
      display: flex;
      justify-content: space-between;
    }
    .date {
      font-size: 32px;
      font-family: DINAlternate-Bold, DINAlternate;
      font-weight: bold;
      color: #000000;
      margin-bottom: 20px;
    }
    .selsect {
      font-size: 32px;
      font-family: PingFangSC-Regular, PingFang SC;
      font-weight: 400;
      color: #1e93ef;
    }
    .list {
      width: 100%;
      display: flex;
      flex-wrap: wrap;
      .item {
        // width: 100%;
        width: 32%;
        margin-right: 2%;
        margin-top: 2%;
        // height: 230px;

        .cliTou {
          // width: 32%;
          width: 100%;
          height: 230px;
          // margin-right: 2%;
          // margin-top: 2%;
          position: relative;
          .checkFlag {
            position: absolute;
            right: 10px;
            top: 10px;
          }
          .thum {
            position: absolute;
            bottom: 15px;
            right: 10px;
            display: flex;
            /deep/ .van-icon {
              font-size: 28px;
            }
            text-align: center;
            .poi {
              color: #ffffff;
              font-family: ArialMt;
              margin: 0;
              margin-left: 5px;
            }
          }
        }
        .ims {
          width: 100%;
          height: 100%;
          // margin: 1% 1%;
          // margin-right: 2%;
          // margin-top: 2%;
        }
        .video-wrap{
          width: 100%;
          height: 100%;
          position: relative;
          background-color: rgba(0,0,0,0.5);
          z-index: -1;
          .icon-play{
            position: absolute; 
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: #fff;
            font-size: 80px;
          }
        }
      }
      .item:nth-child(3n) {
        margin-right: 0;
      }
    }
  }
  .noData {
    width: 100%;
    height: 100%;
    text-align: center;
    .ims {
      margin-top: 300px;
      width: 240px;
      height: 240px;
    }
    .poTip {
      font-size: 28px;
      font-family: PingFang-SC-Medium, PingFang-SC;
      font-weight: 500;
      color: #999999;
    }
  }
  .buttonTab {
    position: fixed;
    bottom: 0px;
    width: 100%;
    height: 80px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    background-color: #fff;
    .but1 {
      // line-height: 80px;
      height: 100%;
      display: flex;
      align-items: center;
      .imsBUt {
        width: 30px;
        height: 30px;
      }
      .fo12 {
        margin-left: 12px;
        font-size: 32px;
        font-family: PingFangSC-Medium, PingFang SC;
        font-weight: 500;
        color: #222222;
      }
    }
  }
  /deep/.van-image-preview__cover {
    // background: #fff;
    position: absolute;
    // display: inline-block;
    // bottom: 30px !important;
    top: 92vh;
    left: 33px;
    width: 90%;
    // right: 0;
    // transform: translate(-50%, 0%);
  }
  /deep/ .van-image__img {
    width: 100%;
    max-height: 80vh;
    // position: absolute;
    // top: 50%;
    // transform: translate(0%, -50%);
    object-fit: fill !important;
  }
  /deep/ .van-image-preview__swipe-item {
    background: #333;
  }
}
.osi {
  color: #fff;
  width: 100%;
  display: flex;
  justify-content: space-between;
  .imsM {
    width: 36px;
    height: 36px;
    border: 1px dashed #fff;
    margin-right: 10px;
  }
  .oius {
    display: flex;
    align-items: center;
  }
  .mar19 {
    margin-top: 19px;
  }
  .support {
    /deep/ .van-icon {
      font-size: 48px;
    }
    text-align: center;
    .poi {
      margin: 0;
    }
  }
}
.preview-wrap {
  position: fixed;
  top: 0;
  left: 0;
  background: #333;
}
</style>
