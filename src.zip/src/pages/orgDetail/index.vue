<template>
  <div class="con">
    <van-nav-bar title="组织" left-text="" left-arrow @click-left="onClickLeft" />
    <div class="orgCard" :style="orgCardStyle">
    </div>
    <div class="per">
      <fix-image class="ims" :src="org.groupsProfilePicture" :defaultSrc="defaultOrgDetail" width="140" height="140" alt="头像" />
      <div class="orgName">
          {{org.groupsName}}
      </div>
      <div class="memberNumbers">
         <div class="nem">
            <img :src="orgDetailPer" alt="" class="imsA">
            <div class="per1">
              组织人数：
            </div>
         </div>
         <div class="per1">
           {{org.numberOfMembers}}人
         </div>
      </div>
      <div class="connectInfo">
        <div class="connect">
          <div class="con1">
            联系人：
          </div>
          <div class="con2">
            {{org.primaryLeaderName}}
          </div>
        </div>
        <div class="connect">
          <div class="con1">
            联系方式：
          </div>
          <div class="con2">
            {{org.contactInformation}}
          </div>
        </div>    
        <div class="connect noCenter" @click="showAll">
          <div class="con11">
            简介：
          </div>
          <div class="con22" ref="conIntro">
            {{org.introduction}}
          </div>
        </div>             
      </div>
    </div>    
    <van-tabs v-model:active="active" class="cenTab van-hairline--bottom">
      <van-tab name="member" title="成员"></van-tab>
      <van-tab name="active" :title-class="showTab ? 'hiddenShow' : ''" title="活动"></van-tab>
      <van-tab name="album" title="相册"></van-tab>

      <!-- v-if="org.hasAuditRight === '1'" -->
      <van-tab name="adminManage" v-if="org.isAdministrator === '1' || org.isPrimaryLeader === '1'">
        <template #title>
          <span v-if="isLiaoShiDa()">消息</span>
          <span v-else>管理</span>
          <span v-if="redPointTips" class="circle-container"> </span>
        </template>
      </van-tab>
      <van-tab name="manage" v-if="isShowManageTab">
        <template #title>
          <span v-if="isLiaoShiDa()">消息</span>
          <span v-else>管理</span>
          <span v-if="redPointTips" class="circle-container"> </span>
        </template>
      </van-tab>
      <van-tab name="audit" title="管理" v-if="isLiaoShiDa() && settingStore.identifyMode == IdentifyMode.Manage"></van-tab>
    </van-tabs>
    <div v-if="active === 'member'" class="siasd">
      <van-tabs class="member-tabs-wrap" type="card"
        v-if="isLiaoShiDa() && org.isJoin && (org.isAdministrator == '1' || org.isPrimaryLeader == '1')">
        <van-tab title="已加入组织">
          <member :groupsId="gouId" :hasAuditRight="org.hasAuditRight" :isAdministrator="org.isAdministrator"
            :isPrimaryLeader="org.isPrimaryLeader" />
        </van-tab>
        <van-tab title="未加入组织">
          <SchoolmateSearch :groupsId="org.groupsId" />
        </van-tab>
      </van-tabs>

      <member v-else :groupsId="gouId" :hasAuditRight="org.hasAuditRight" :isAdministrator="org.isAdministrator"
        :isPrimaryLeader="org.isPrimaryLeader" />

      <div class="but1" v-if="!org.isJoin">
        <van-button type="primary" :disabled="isApplyDisabled" round @click="joinOrg">申请加入</van-button>
      </div>
    </div>
    <div v-else-if="active === 'active'" class="siasd">
      <div v-if="org.isJoin">
        <template v-if="isLiaoShiDa()">
          <lnsf-act :groupsId="gouId" @actClick="addACt" />
        </template>
        <template v-else>
          <act :groupsId="gouId" />
          <div class="but1" v-if="org.isAdministrator === '1' || org.isPrimaryLeader === '1'">
            <van-button type="primary" round @click="addACt">创建活动</van-button>
          </div>
        </template>

      </div>
      <div class="tips" v-else>
        <p class="sese">您不是该组织成员，无法查看组织活动</p>
      </div>
    </div>
    <div class="photo" v-else-if="active === 'album'">
      <photo :groupsId="gouId" :creAl="creAl" :key="keyRe" />
    </div>
    <div class="siasd"
      v-else-if="active === 'adminManage' && org.isJoin && (org.isAdministrator == '1' || org.isPrimaryLeader == '1')">
      <check :groupsId="gouId" />
    </div>
    <div class="siasd" v-else-if="active === 'manage' && isShowManageTab">
      <BeInvited :inviteData="inviteData" :category="org.category" @initInviteData="initInviteData" @refresh="initGroup"/>
    </div>
    <div class="sisad" v-else-if="active === 'audit'">
      <activitiesReview :groups-id="gouId" :need-title="false" cont-class="review-cont" />
    </div>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref, onDeactivated } from 'vue';
import member from './member.vue';
import ApiGroup, { userGroupP, groupListP } from '@/api/group';
import act from './act.vue';
import lnsfAct from './lnsf-act.vue';
import check from './check.vue';
import photo from './photo.vue';
import activitiesReview from "@/pages/activitiesReview/index.vue"
import { useSettingStore } from '@/store';
import { SchoolCode } from '@/constants';
import SchoolmateSearch from './schoolmate-search/index.vue';
import BeInvited from './be-invited.vue';
import { useKeepAliveStore } from '@/store'
import { useBeInvited } from '@/pages/orgDetail/useBeInvited'
import { InviteStatus } from './constants';
import { isLiaoShiDa } from '@/utils/customizedType';
import { IdentifyMode } from '@/constants'
import { useOrgCard } from '@/hooks/useOrgCard'
import { getSchoolCode } from '@/utils';
import {Dialog} from "vant"
// import transparentBg from "@/assets/img/transparentBg.png"
import orgDetailBg from "@/assets/img/orgDetailBg.jpg"
import orgDetailPer from "@/assets/img/orgDetailPer.jpg"
import defaultOrgDetail from "@/assets/img/defaultOrgDetail.jpg"


const ComponentName = 'orgDetail'
defineOptions({
  name: ComponentName,
  // 当页面从机构列表、我的组织页面进入且不是上次查看的组织时，重置当前页面缓存实例
  beforeRouteEnter(to, from) {
    const keepAliveStore = useKeepAliveStore()
    let formName = from.name as string
    let groupsId = to.query.groupsId as string
    let oldGroupsId = sessionStorage.getItem('gouId')
    console.log('removeCacheEntry',formName)
    if (formName && ['activitiDetail', 'activitiAdd', 'message'].includes(formName)) {
      keepAliveStore.removeCacheEntry(ComponentName)
    }
    if (formName && ['organization', 'perInfoCard',].includes(formName) && groupsId != oldGroupsId) {
      keepAliveStore.removeCacheEntry(ComponentName)
    }
    if (formName && ['groupActSD','groupsbuild','joinClub'].includes(formName) ) {
      keepAliveStore.removeCacheEntry(ComponentName)
    }
  }
})
const { orgCardStyle } = useOrgCard()
const { inviteData, getInviteData, initInviteData } = useBeInvited()
const isShowManageTab = computed(() => !!inviteData.value?.id && inviteData.value.status == InviteStatus.PendingHandle)

const _SchoolCode = getSchoolCode();
const isApplyDisabled = ref(false)
const settingStore = useSettingStore();
const router = useRouter();
const route = useRoute();
const active = ref('member');
const keyRe = ref(0);
const creAl = ref(false);
const showTab = ref(false);
const conIntro = ref()
const org = reactive({
  groupsId: '',
  groupsName: '',
  jianjie: '',
  numberOfMembers: '',
  groupsProfilePicture: '',
  isJoin: false,
  auditStatus: '',
  hasAuditRight: '',
  isAdministrator: '',
  isPrimaryLeader: '',
  groupsType: '',
  category: '',
  primaryLeaderName:"",
  introduction:"",
  contactInformation:"",
});
const fakeData = ref('这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介')
const fakeData2 = ref('这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介这是测试简介这是测试')
const showHide = ref(false)
const redPointTips = ref(false);
const gouId = ref('');

const onClickLeft = () => router.back()
const joinOrg = () => {
  router.push({ path: '/joinClub', query: { groupsId: org.groupsId } });
};
const addACt = () => {
  if (isLiaoShiDa()) {
    router.push({ path: '/activitiAdd', query: { groupsId: org.groupsId, groupsName: org.groupsName } });
  } else {
    router.push({ path: '/groupsbuild', query: { groupsId: org.groupsId } });
  }
};
const initGroup = async () => {
  console.log('initGroup');
  const { data, code, msg } = await ApiGroup.groupsDetail({ groupsId: gouId.value });
  if (code == 200) {
    Object.assign(org, data);
    if (org.isAdministrator == '1' || org.isPrimaryLeader == '1') {
      creAl.value = true;
      keyRe.value++;
    }
  }
};
  const initIsApplyDisabled =async (groupsId: string)=>{
    const { data, code, msg } = await ApiGroup.isApply({ groupsId });
    if(code == 200){
      isApplyDisabled.value = data
    }
  }
watch(() => active.value, (newVal) => {
  router.replace({
    path: '/orgDetail',
    query: {
      ...route.query,
      active: newVal
    },
  })
}, {
  immediate: true
})

function initPageLoad() {
  if (_SchoolCode == SchoolCode.ChangShu) {
    showTab.value = true;
  }
  let { groupsId, pendingAudit } = route.query
  active.value = route.query.active as string || 'member'
  gouId.value = groupsId as string;
  if (pendingAudit == "1") {
    redPointTips.value = true;
  }
  if (gouId.value != sessionStorage.getItem("gouId") || !org.groupsName) {
    initGroup();
  }
  sessionStorage.setItem("gouId", gouId.value);
}

const getShow = ()=>{
  // console.log('getShow',conIntro.value.scrollHeight,conIntro.value.clientHeight)
  if(conIntro.value.scrollHeight > conIntro.value.clientHeight){
    showHide.value = true
  }else{
    showHide.value = false
  }
}

const showAll = () =>{
  if(showHide.value && org.introduction ){
    Dialog.alert({
      title:"组织简介",
      message:org.introduction
    }).then(()=>{})
  }
}

onBeforeMount(() => { 
  initPageLoad()
  getInviteData(gouId.value)
});

onMounted(()=>{
  initIsApplyDisabled(route.query.groupsId as string)
  getShow()
})
onActivated(() => {
  console.log('--> call onActivated');
  initPageLoad()
});
onDeactivated(() => {
  console.log('--> call onDeactivated');
})
onUnmounted(async () => {
  console.log('--> call onUnmounted');
})
</script>
<style lang="less" scoped>
/deep/ .hiddenShow {
  display: none;
  // visibility: hidden;
}

.tips {
  width: 100%;
  height: 60px;
  text-align: center;
  line-height: 60px;

  // margin-top: 10px;
  .sese {
    font-size: 30px;
    color: #969799;
  }
}

.con {
  width: 100%;
  height: 100%;
  overflow-y: scroll;
  background: #f5f5f5;

  .orgCard {
    // margin: 10px 32px;
    width: 750px;
    height: 280px;
    // background: url('@/assets/img/orgBac.png');
     background: url('@/assets/img/transparentBg.png');
    //  background-color:#0570C9;
    background-color: rgba(var(--theme-color-rgb), 1);
    background-repeat: no-repeat;
    background-size: 100% 100%;
    position: relative;
  }
    .per {
      // width: calc(100vw-60px);
      // width: 92vw;
      // height: 100%;
      // height: 468px;
      margin:0 30px;
      padding-left:20px;
      padding-right:16px;
      padding-bottom: 34px;
      box-sizing: border-box;
      display: flex;
      align-items: center;
      background-color: #fff;
      flex-direction: column;
      position: relative;
      // position: fixed;
      // top:160px;
      // left: 50%;
      // transform: translate(-50%,0);
      background-image: url("@/assets/img/orgDetailBg.jpg");
      background-repeat:no-repeat;
      background-size:100% 266px;
      background-position: 0% 0%;
      top: -160px;
      border-radius: 10px;
      .ims {
        width: 140px;
        height: 140px;
        position: absolute;
        top: -70px;
        left: 50%;
        transform: translate(-50%,0);
        border-radius: 50%;
      }
      .orgName{
        margin-top: 90px;
        color: #222222;
        font-size: 32px;
      }
      .memberNumbers{
        margin-top: 16px;
        width: 282px;
        height: 60px;
        background-color: #F1F5F9;
        border-radius:30px;
        display: flex;
        align-items: center;
        justify-content: center;
        .nem{
          display: flex;
          align-items: center;
          height: 60px;
          .imsA{
            width: 26px;
            height: 26px;
          }
          .per1{
            margin-left: 13px;
            font-size: 26px;
            color:#6a7074;
          }
        }
        .per1{
            font-size: 26px;
            color:#6a7074;
        }
      }
      .connectInfo{
        width: 100%;
        margin-top:24px;
        .connect{
          display: flex;
          align-items: center;
          .con1{
            font-size: 28px;
            color:#454848; 
            margin-left: 10px;   
            min-width: 90px;           
          }       
          .con11{
            font-size: 28px;
            color:#454848; 
            margin-left: 10px;   
            min-width: 90px;           
          }                
          .con2{
            font-size: 28px;
            color:#6a7074;
          }
          .con22{
            font-size: 28px;
            color:#6a7074;
            // height: 104px;
            flex:1;
            display: -webkit-box;
            -webkit-box-orient:vertical;
            -webkit-line-clamp:3;
            overflow: hidden;
            text-overflow: ellipsis;
            // display: flex;
            // flex-wrap: wrap;
            
          }          
            &:before{
              width: 6px;
              height: 26px;
              background-color: rgb(211,217,222);
              // F1F5F9
              content:"";
            }          
        }
        .noCenter{
          align-items: flex-start;
          justify-content: flex-start;
          flex-wrap: wrap;

        }

      }


    }
  .siasd {
    // margin-top: 80px;
    margin-top: 8px;
    position: relative;
    top: -160px;
  }

  .photo {
    text-align: center;

    .ims {
      width: 300px;
      height: 300px;
    }

    .is {
      font-weight: 500;
    }
  }
}

.member-tabs-wrap {
  margin: 16px 0 0;
  --van-tabs-default-color: rgb(180, 45, 59);

  ::v-deep(.van-tabs__content) {
    padding: 16px 0 0;
  }
}

.cenTab {
  border-color: #333;
  // margin-top: 320px;
  position: relative;
  top: -140px;
}

.but1 {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translate(-50%, 0%);
  z-index: 9999;

  /deep/.van-button--round {
    width: 400px;
  }
}

.circle-container {
  display: inline-block;
  width: 10px;
  height: 10px;
  background: #ff0000;
  border-radius: 50%;
  position: relative;
  top: -18px;
  left: -6px;
}

.review-cont {
  background: #969799;
}
</style>
