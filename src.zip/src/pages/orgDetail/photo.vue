<template>
  <div class="picCard-list">
        <van-list
      v-model:loading="loading"
      :finished="finished"
      finished-text="没有更多了"
      v-model:error="error"
      error-text="请求失败，点击重新加载"
      @load="onLoad"
    >
    <addpicCard @jumpAddOrEditPhoto="jumpAdd" v-if="props.creAl" />

    <picturesCard
      v-for="(item, index) in albumList"
      :key="index"
      :src="item.coverImage"
      :name="item.albumName"
      :number="item.photosCount"
      :thumbsUpCount="item.thumbsUpCount"
      @jumpAlubmList="jumpAluList(item)"
      @touchStart="touchStart($event, item)"
      @touchEnd="touchEnd"
    />
        </van-list>
  </div>
  <div class="picNone" v-if="!props.creAl && albumList.length == 0">
    <img :src="photoNone" alt="" class="ims" />
    <div class="poa"> 暂无相册 </div>
  </div>
</template>
<script lang="ts" setup>
  import { reactive, ref } from 'vue';
  import photoNone from '@/assets/img/photoNone.png';
  import picturesCard from '@/components/picCom/picturesCard.vue';
  import addpicCard from '@/components/picCom/addpicCard.vue';
  import Api from '@/api/orgPhoto';
  import { Toast } from "vant";
  import { albumParam, rightCon } from '@/store';
  const setAlbumParam = albumParam();
  const setOrgRight = rightCon();
  const router = useRouter();
  const props = defineProps({
    groupsId: { type: String, default: '' },
    creAl: { type: Boolean, default: false },
  });
  interface albumP {
    address: string;
    albumId: string;
    albumName: string;
    coverImage: string;
    clickCount: string;
    albumType: string;
    permissionScope: string;
    photosCount: string;
    thumbsUpCount:string;
  }
  const timeOutEvent = <any>ref('');
  const showSelect = ref(false);
  const albumList = ref([] as Array<albumP>);
  const listP = ref({
    pageNum: 1,
    pageSize: 5
  });
  const error = ref(false);
  const loading = ref(false);
  const finished = ref(false);
  const isLastPageb = ref(false);
  const refreshing = ref(false);
  const onLoad = async () => {
    if (!isLastPageb.value && loading.value) {
      finished.value = false;
      listP.value.pageNum = (listP.value.pageNum as number) + 1;
      // await init();
      await initAlbum();
    } else {
      loading.value = false;
      finished.value = true;
    }
  };
  const initAlbum = async () => {
    loading.value = true;
    const { data, code, msg } = await Api.listAlbum({ 
      groupsId: props.groupsId, 
      albumType: '1',
      pageSize:listP.value.pageSize,
      pageNum:listP.value.pageNum 
    });
    // albumList.value = data.list;
    if (listP.value.pageNum == 1) {
      albumList.value = [];
    }
    if (code == 200) {
      isLastPageb.value = data.isLastPage;
      loading.value = false;
      albumList.value = albumList.value.concat(data.list);
    } else {
      Toast({
        message: msg,
        icon: "none"
      });
    }
    if (isLastPageb.value) {
      loading.value = false;
      finished.value = true;
    }
  };
  const jumpAdd = () => {
    setAlbumParam.groupsId = props.groupsId;
    setAlbumParam.type = '1';
    router.push({ path: '/orgAlubm', query: { type: 'add', groupsId: props.groupsId } });
  };
  const touchStart = (e: any, item: any) => {
    if (!props.creAl) {
      return;
    }
    setAlbumParam.type = '1';
    timeOutEvent.value && clearTimeout(timeOutEvent.value);
    timeOutEvent.value = setTimeout(() => {
      // showSelect.value = true;
      router.push({
        path: '/orgAlubm',
        query: {
          albumId: item.albumId,
          albumName: item.albumName,
          groupsId: item.groupsId,
          permissionScope: item.permissionScope,
          type: 'edit',
        },
      });
    }, 500);

    // e.preventDefault();
  };
  const touchEnd = () => {
    timeOutEvent.value && clearTimeout(timeOutEvent.value);
  };
  const jumpAluList = (value: albumP) => {
    // if (!props.creAl) {
    //   return;
    // }
    setAlbumParam.groupsId = props.groupsId;
    setAlbumParam.permissionScope = value.permissionScope;
    router.push({
      path: '/alubmList',
      query: {
        albumId: value.albumId,
        albumName: value.albumName,
      },
    });
    setAlbumParam.type = '1';
  };
  onMounted(() => {    
    if (props.creAl) {
      setOrgRight.orgR = '1';
      setOrgRight.serviceR = '0';
    } else {
      setOrgRight.orgR = '0';
      setOrgRight.serviceR = '0';
    }
    initAlbum();
  });

  onActivated(() => {
    listP.value.pageNum = 1
    initAlbum();
  })
</script>
<style lang="less" scoped>
.picNone {
  // width: 100%;
  // height: 100%;
  text-align: center;
  // background: #f5f5f5;
  .poa {
    // font-size: 28px;
    padding: 42px;
    // font-family: PingFangSC-Regular, PingFang SC;
    font-weight: 500;
    // color: #999999;
  }
  .ims {
    width: 300px;
    height: 300px;
  }
}
/deep/ .van-list {
  padding: 30px;
  display: flex;
  // align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
}
/deep/.van-list__finished-text {
  width: 100%;
}
.picCard-list {
  width: 100%;
}
</style>
