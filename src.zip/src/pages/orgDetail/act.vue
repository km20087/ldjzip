<template>
  <div class="boas">
    <van-list v-model:loading="loading" :finished="finished" :finished-text="finsText" @load="onLoad">
      <van-cell v-for="(item, index) in actList" :key="index">
        <div class="cell">
          <div class="con" @click="jumpAct(item)">
            <div class="logo">
              <!-- 
                @ApiModelProperty(value = "审核状态：0-待审核，1-通过，2-拒绝, 3-草稿, 4-退回，5-撤回")
                private String auditStatus; 
              -->
              <!--   
                @ApiModelProperty(value = "状态：1-进行中，2-报名中，3-未开始，4-已结束，5-终止")
                private String status; 
              -->
              <span class="act-tag" v-if="item.status === '2' && item.auditStatus == '1'"> 报名中 </span>
              <span class="act-tag noCheck" v-else-if="item.auditStatus === '0'"> 待审核 </span>
              <span class="act-tag refuse" v-else-if="item.auditStatus === '2'"> 拒绝 </span>
              <span class="act-tag nosiu" v-else-if="item.auditStatus === '5'"> 撤回 </span>
              <span class="act-tag ing" v-else-if="item.status === '1' && item.auditStatus == '1'"> 进行中 </span>
              <span class="act-tag noStart" v-else-if="item.status === '3' && item.auditStatus == '1'"> 未开始 </span>
              <span class="act-tag end" v-else-if="item.status === '4'"> 已结束 </span>
              <img :src="picUrl + item.eventPoster" alt="" class="ims" />
            </div>
            <div class="actDetail">
              <div class="actName">{{ item.theme }}</div>
              <div class="isoa tit">发起组织：{{ item.organizer }}</div>
              <!-- <div class="isoa">活动类型：{{ item.actType }}</div> -->
              <div class="isoa">已报名人数：{{ item.currentNumberOfParticipants }}</div>
            </div>
            <div class="join" v-if="item.registrationFlag === '0' && item.status === '2'" >
              <p class="pos">报名</p>
            </div>
            <div class="join green" v-else-if="item.registrationFlag === '1'" >
              <p class="pos">已报名</p>
            </div>
            <div class="join green" v-else-if="item.status === '1'" >
              <p class="pos">进行中</p>
            </div>
            <div class="join end" v-else>
              <p class="pos">已结束</p>
            </div>
          </div>
          <div class="time">
            <p>活动时间:{{ item.startTime }}至{{ item.endTime }}</p>
            <p>报名截止时间:{{ item.registrationDeadline }}</p>
          </div>
        </div>
      </van-cell>
    </van-list>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import Api from '@/api/servive';
import { isShanDa } from '@/utils/customizedType';
const loading = ref(false);
const finished = ref(false);
const isLastPageb = ref(false);
const total = ref(0);
const pages = ref(0);
const finsText = ref('没有更多了');
const router = useRouter();
const pro = defineProps(['groupsId']);
const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
const actData = reactive({
  groupsId: '',
  pageNum: 1,
  pageSize: 10,
});
const actList = <any>reactive([]);
const onLoad = () => {
  if (!isLastPageb.value) {
    actData.pageNum++;
    initActData();
  } else {
    loading.value = false;
    finished.value = true;
  }
};
const jumpAct = (item: any) => {
  // router.push({ name: 'joinAct', query: item });
  // router.push({ path: '/groupActSD', query: {id:item.id,groupsId:actData.groupsId} });
  // return
  if(isShanDa()){
    router.push({ path: '/groupActSD', query: {id:item.id,groupsId:actData.groupsId} });
  }else if(!isShanDa() && item.registrationFlag === '0' && item.status === '2'){
    router.push({ path: '/groupJoinAct', query: item });
  }
  
};
const initActData = async () => {
  actData.groupsId = pro.groupsId as string;
  loading.value = true;
  const { data, code, msg } = await Api.getActiveList(actData);
  if (code == 200) {
    pages.value = data.pages;
    total.value = data.total;
    isLastPageb.value = data.isLastPage;
    if (pages.value == 1) {
      actList.length = 0;
    }
    if (isLastPageb.value) {
      finished.value = true;
      loading.value = false;
    }
    actList.push(...data.list);
  } else {
    finsText.value = msg;
    loading.value = false;
    finished.value = true;
  }
};
onMounted(() => {
  initActData();
});
</script>
<style lang="less" scoped>
.boas {
  width: 100%;
  height: 100%;
  padding: 0 30px;
  position: relative;

  .cell {
    width: 100%;

    .con {
      font-size: 0px;
      display: flex;
      justify-content: space-around;

      .logo {
        // width: 20%;
        width: 130px;
        height: 180px;
        border-radius: 16px;
        overflow: hidden;
        position: relative;

        .act-tag {
          display: inline-block;
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          line-height: 46px;
          font-size: 24px;
          color: #fff;
          text-align: center;
          background: #fe6f5d8f;
        }

        .ing {
          background: #21ca0e97;
        }
        .noStart{
          background: #0e7fca60;
        }
        .noCheck{
          background-color: #E6A23C;
        }
        .refuse{
          background-color: #909399;
        }
        .nosiu{
          background-color: #ff976a;
        }
        .end {
          background: #888b948d;
          color: #fff;
        }

        .green {
          background: #d8f5eb;
          color: #3ccf9c;
        }

        .ims {
          width: 100%;
          height: 180px;
          border-radius: 50%;
        }
      }

      .actDetail {
        margin-left: 20px;
        width: 55%;
        height: 180px;
        // overflow-x: hidden;

        .actName {
          width: 240px;
          font-size: 32px;
          font-family: PingFangSC-Medium, PingFang SC;
          font-weight: 500;
          overflow-x: hidden;
          color: #333333;
          white-space: nowrap;
          text-overflow: ellipsis;
        }

        .isoa {
          font-size: 24px;
          font-family: PingFang-SC-Regular, PingFang-SC;
          font-weight: 400;
          color: #666666;
        }

        .tit {
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
        }
      }

      .unuse {
        width: 20%;
      }

      .join {
        width: 20%;
        height: 60px;
        background: #d2e9fc;
        border-radius: 35px;
        text-align: center;
        color: #1e93ef;

        .pos {
          font-size: 32px;
          margin: 0px;
          line-height: 60px;
          font-family: PingFangSC-Medium, PingFang SC;
          font-weight: 500;

          .end {
            background: #888b948d;
          }
        }
      }

      .end {
        background: #888b948d;
        color: #fff;
      }

      // .green {
      //   background: #3ccf9c;
      // }

      .ing {
        background: #21ca0e97;
      }
      .noCheck{
        background-color: #E6A23C;
      }
      // .end {
      //   background: #888b948d;
      //   color: #333333 !important;
      // }
    }

    .time {
      margin-top: 10px;
      box-sizing: border-box;
      padding-top: 20px;
      padding-left: 20px;
      background: #f8f8f8;

      p {
        font-size: 24px;
        margin: 0;
        font-family: PingFang-SC-Regular, PingFang-SC;
        font-weight: 400;
        color: #666666;
      }
    }
  }
}

.button1 {
  // width: 100%;
  position: fixed;
  left: 50%;
  transform: translate(0, -50%);
  bottom: 10px;
}</style>
