<template>
  <div class="con" v-if="!state && dataList.length > 0">
    <div class="perInfo">
      <div class="per">
        <Avatar class="ims" :src="perX.avatar" />
        <div class="perdetail">
          <div class="name"> {{ perX['name'] }} </div>
          <div class="uni">{{ perX['collageName'] }}</div>
          <!-- <div class="uni mar10">{{ perX['class'] }}</div> -->
        </div>
      </div>
    </div>
    <div class="reason">
      <div class="title">申请原因</div>
      <div class="content">{{ perX['reason'] }}</div>
    </div>
    <div class="choice">
      <!-- <div class="ref" @click="disagreefun"> 拒绝 </div>
      <div class="agree" @click="agreefun"> 同意{{ ind }} </div> -->
      <van-button round type="default" class="ref" :disabled="state" @click="disagreefun"
        >拒绝</van-button
      >
      <van-button round type="primary" class="agree" @click="agreefun" :disabled="state"
        >同意</van-button
      >
    </div>
  </div>
  <div class="photo" v-else-if="state || dataList.length == 0">
    <img :src="nodata2" alt="" class="ims" />
    <p class="is">暂无数据</p>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from "vue";
import Avatar from '@/components/avatar/index.vue';
import nodata2 from "@/assets/img/nodata2.png";
import ApiGroup from "@/api/group";
import { Toast } from "vant";
const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
const perX: ex1 = reactive({
  name: "",
  collageName: "",
  class: "",
  reason: "",
  id: "",
  avatar: ""
});
interface ex1 {
  name: string;
  collageName: string;
  class: string;
  reason: string;
  id: string;
  avatar: string;
}
const pro = defineProps(["groupsId"]);
const ind = ref(0);
const state = ref(false);
const dataList = <any>ref([]);
const agreefun = async () => {
  const { data, code, msg } = await ApiGroup.groupsAudit({
    id: perX.id,
    auditStatus: "1"
  });
  Toast({ message: msg });
  if (ind.value < dataList.value.length - 1) {
    ind.value++;
  } else {
    state.value = true;
    return;
  }
  console.log(ind.value);
  initData();
};
const disagreefun = async () => {
  const { data, code, msg } = await ApiGroup.groupsAudit({
    id: perX.id,
    auditStatus: "2"
  });
  Toast({ message: msg });
  if (ind.value < dataList.value.length - 1) {
    ind.value++;
  } else {
    state.value = true;
    return;
  }
  initData();
};
const initData = () => {
  if (dataList.value.length > 0) {
    if (ind.value < dataList.value.length) {
      Object.assign(perX, dataList.value[ind.value]);
    }
  }
};
const initApply = async () => {
  const { data, code, msg } = await ApiGroup.groupsApplyPage({
    groupsId: pro.groupsId as string,
    pageNum: 1,
    pageSize: 1000
  });
  dataList.value.length = 0;
  dataList.value.push(...data.list);
  if (dataList.value.length > 0) {
    initData();
  }
  if (data.list.length > 0) {
    // initDetail(data.list[0].id, pro as string);
  }
};
const initDetail = async (id: string, groupsId: string) => {
  await ApiGroup.groupsApplyDetail({ id: id, groupsId: groupsId });
};
onBeforeMount(() => {
  initApply();
});
</script>
<style lang="less" scoped>
.photo {
  text-align: center;
  .ims {
    width: 300px;
    height: 300px;
  }
  .is {
    font-weight: 500;
  }
}
.con {
  width: 100%;
  height: 100%;
  .perInfo {
    background-color: #f8f8f8;
    width: 90%;
    height: 220px;
    background: linear-gradient(90deg, #f2f2f2 0%, #f8f8f8 100%);
    border-radius: 16px;
    margin: 0 auto;
    .per {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      margin-left: 30px;
      .ims {
        width: 88px;
        height: 88px;
        border-radius: 50%;
        position: relative;
        top: -20px;
      }
      .perdetail {
        margin-left: 30px;
        .name {
          font-size: 36px;
          font-family: PingFang-SC-Bold, PingFang-SC;
          font-weight: bold;
          color: #333333;
          line-height: 36px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
          padding-bottom: 20px;
        }
        .uni {
          // display: inline-block;
          display: flex;
          align-items: center;
          font-size: 24px;
          font-family: PingFang-SC-Medium, PingFang-SC;
          font-weight: 500;
          color: #666666;
          line-height: 24px;
          text-shadow: 1px 2px 24px rgba(0, 0, 0, 0.1);
        }
        .uni::before {
          content: "";
          margin: 3px;
          display: table;
          width: 8px;
          height: 8px;
          // background: #2090ff;
          background: linear-gradient(
            270deg,
            #eaeaea 0%,
            #aaa9a9 100%,
            #ffffff 100%
          );
          border-radius: 50%;
        }
        .mar10 {
          margin-top: 10px;
        }
      }
    }
  }
  .reason {
    width: 90%;
    margin: 0 auto;
    margin-top: 30px;
    .title {
      font-size: 36px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #333333;
      line-height: 36px;
    }
    .content {
      margin-top: 20px;
      width: 100%;
      height: 260px;
      background: #ffffff;
      border-radius: 16px;
      border: 1px solid #dfdfdf;
      padding: 20px 20px;
    }
  }
  .choice {
    width: 90%;
    margin: 0 auto;
    margin-top: 20px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    .ref {
      width: 240px;
      height: 88px;
      background: #ffffff;
      border-radius: 44px;
      border: 2px solid #dfdfdf;
      font-size: 36px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #333333;
      text-align: center;
      line-height: 88px;
    }
    .agree {
      width: 240px;
      height: 88px;
      border-radius: 44px;
      font-size: 36px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      color: #ffffff;
      text-align: center;
      line-height: 88px;
    }
    .van-button:before {
    }
  }
}
</style>
