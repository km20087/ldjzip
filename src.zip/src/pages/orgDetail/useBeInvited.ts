import { ref } from 'vue';
import { fetchInviteRecent } from '@/api/group';
import { Toast } from 'vant';

const InitialInviteData = {
  id: '',
  groupsId: '',
  groupsName: '',
  inviterName: '',
  status: '',
};

export function useBeInvited() {
  const inviteData = ref({ ...InitialInviteData });

  /**获取被邀请信息 */
  async function getInviteData(groupsId: string) {
    try {
      const { code, data, msg } = await fetchInviteRecent({ groupsId });
      if (code == 200) {
        inviteData.value = data;
      } else {
        Toast({
          message: msg,
          icon: 'none',
        });
      }
    } catch (err) {
      console.log(err);
    }
  }

  /** 初始化数据 */
  function initInviteData() {
    inviteData.value = {...InitialInviteData}
  }

  return {
    inviteData,
    getInviteData,
    initInviteData
  };
}
