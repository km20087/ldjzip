<template>
  <van-nav-bar title="创建活动" left-arrow @click-left="onClickLeft" />
  <div>
    <van-form @failed="onFailed" @submit="onSubmit" input-align="right" error-message-align="right">
      <van-cell-group inset>
        <van-field
          label="活动主题"
          required
          v-model="actForm.theme"
          name="theme"
          placeholder="请输入活动主题"
          :rules="[{ required: true, message: '请输入活动主题' }]"
        />
        <!-- 通过 validator 返回错误提示 -->
        <van-field
          label="主办方"
          required
          v-model="actForm.organizer"
          name="organizer"
          placeholder="请输入主办方"
          :rules="[{ required: true, message: '请输入主办方' }]"
        />
        <van-field
          v-model="actForm.startTime"
          readonly
          required
          name="startTime"
          label="开始时间"
          placeholder="点击选择日期"
          @click="show2cli()"
          :rules="stimeRules"
        />
        <van-popup v-model:show="showCalendar2" position="bottom" round>
          <van-datetime-picker
            v-model="currentDate"
            type="datetime"
            title="选择完整时间"
            :min-date="minDate"
            :max-date="maxDate"
            @confirm="onConfirm2"
            @cancel="showCalendar2 = false"
          />
        </van-popup>

        <van-field
          v-model="actForm.endTime"
          readonly
          required
          name="endTime"
          label="结束时间"
          placeholder="点击选择日期"
          @click="show3cli()"
          :rules="etimeRules"
        />
        <van-popup v-model:show="showCalendar3" position="bottom" round>
          <van-datetime-picker
            v-model="currentDate"
            type="datetime"
            title="选择完整时间"
            :min-date="minDate"
            :max-date="maxDate"
            @confirm="onConfirm3"
            @cancel="showCalendar3 = false"
          />
        </van-popup>

        <van-field
          v-model="actForm.registrationDeadline"
          readonly
          required
          label-width="100px"
          name="registrationDeadline"
          label="报名截止时间"
          placeholder="点击选择日期"
          @click="showCalendar4 = true"
          :rules="dtimeRules"
        />
        <van-popup v-model:show="showCalendar4" position="bottom" round>
          <van-datetime-picker
            v-model="currentDate"
            type="datetime"
            title="选择完整时间"
            :min-date="minDate"
            :max-date="maxDate"
            @confirm="onConfirm4"
            @cancel="showCalendar4 = false"
          />
        </van-popup>

        <van-field
          label="活动简介"
          v-model="actForm.introduction"
          name="introduction"
          type="textarea"
          autosize
          placeholder="输入活动简介"
          maxlength="300"
          show-word-limit
        />

        <van-field
          readonly
          required
          label-width="100px"
          name="requiredInformation"
          v-model="actForm.requiredInformation"
          label="报名必填信息"
          placeholder="请选择"
          @click="showPicker2 = true"
          :rules="[{ required: true, message: '请选择必填信息' }]"
        />
        <van-field
          label="是否对外开放"
          required
          name="openFlag"
          v-model="actForm.openFlag"
          error-message-align="right"
          :rules="openRules"
        >
          <template #input>
            <div class="cost-num">
              <span>{{ actForm.openFlag == '1' ? '是' : '否' }}</span>
            </div>
          </template>
          <template #right-icon>
            <van-switch
              v-model="actForm.openFlag"
              active-value="1"
              inactive-value="0"
              inactive-color="#ee0a24"
              @click="getChange"
            />
          </template>
        </van-field>
        <!-- <van-field
          readonly
          required
          name="eventPoster"
          label="活动海报"
          input-align="left"
          error-message-align="left"
          :rules="[{ required: true, message: '请上传海报' }]"
        >
          <template #input>
            <van-uploader
              v-model="healthFileList"
              max-size="5242880"
              multiple
              @oversize="oversize"
              :before-delete="healthBeforeDel"
              :max-count="1"
            >
              <van-button class="upload-btn">
                <van-icon name="plus" size="30" color="#999999" />
              </van-button>
              <div class="upload-tips">上传图片不超过5M, 仅支持PNG、JPG、JPEG格式</div>
            </van-uploader>
          </template>
        </van-field> -->
        <van-field
          v-model="actForm.eventPoster"
          readonly
          required
          class="upField"          
          name="eventPoster"
          label="活动海报"
          input-align="left"
          error-message-align="left"
          :rules="[{ required: true, message: '请上传海报' }]"
        >
          <!-- <template #button>
            <span class="upload-text">上传</span>
          </template> -->
          <template #input>
            <compress-uploader v-model="fileList" max-count="1" :after-read="afterRead" />
            <p class="uptips">图片规格仅限jpg,jpeg,png,图片比例最好是65:90</p>
          </template>
        </van-field>
        <van-popup
          v-model:show="showPicker2"
          position="bottom"
          closeable
          style="padding: 10px 15px"
          round
        >
          <van-checkbox-group v-model="checked" style="margin: 60px 0 20px">
            <van-cell-group inset>
              <van-cell
                v-for="(item, index) in list"
                clickable
                :key="index"
                :title="item"
                @click="toggle(index)"
              >
                <template #right-icon>
                  <van-checkbox
                    :name="item"
                    :ref="(el: any) => (checkboxRefs[index] = el)"
                    @click.stop
                  />
                </template>
              </van-cell>
            </van-cell-group>
          </van-checkbox-group>
          <van-button type="primary" round block @click="checkMust">确定</van-button>
        </van-popup>
      </van-cell-group>
      <div class="butp">
        <van-button round block type="primary" native-type="submit"> 创建 </van-button>
      </div>
    </van-form>
  </div>
</template>
<script lang="ts" setup>
import { ref } from 'vue';
import { Toast } from 'vant';
// import Api from '@/api/act';
import activities from '@/api/servive';
import ApiUp from '@/api/uploadfile';
import { fommatDate } from '@/utils/fommatDate';
import FileHandle from '@/utils/file-handle';
import { getRealFilePath } from '@/utils'
let fileHandle = new FileHandle(['eventPoster']);
const router = useRouter();
const route = useRoute();
const currentDate = ref(new Date());
const minDate = ref(new Date());
const maxDate = ref(new Date());
let fileList = ref<File[] | any>([]);
let actForm = <any>ref({
  groupsId: '',
  theme: '',
  organizer: '',
  startTime: '',
  openFlag: '0', //0-不对外开放，1-对外开放
  endTime: '',
  registrationDeadline: '',
  introduction: '',
  requiredInformation: '',
  eventPoster: '',
});
const changeValue = ref('');
const healthFileList = <any>ref([]);
const showCalendar2 = ref(false);
const showCalendar3 = ref(false);
const showCalendar4 = ref(false);
const checked = ref([]);
const checkboxRefs = <any>ref([]);
const list = ref(['姓名','QQ','院系', '班级','入学年级','专业','联系电话','备注',]);
//自定义校验
const stimeRules: any = [
  { required: true, message: '开始时间不能为空' },
  {
    validator: (value?: any) => {
      if (new Date(value).getTime() < new Date().getTime()) {
        return false;
      }
    },
    message: '开始时间不能早于当前时间',
    trigger: ['onChange', 'onBlur'],
  },
];
const openRules: any = [
  { required: true, message: '请选择是否对外开放' },
  {
    validator: (value?: any) => {
      console.log(value);
      if (!value) {
        return false;
      }
    },
    message: '请选择是否对外开放',
    trigger: ['onChange', 'onBlur'],
  },
];
const etimeRules: any = [
  { required: true, message: '结束时间不能为空' },
  {
    validator: (value?: any) => {
      if (new Date(value).getTime() < new Date(actForm.value.startTime).getTime()) {
        return false;
      }
    },
    message: '结束时间不能早于开始时间',
    trigger: ['onChange', 'onBlur'],
  },
];
const dtimeRules: any = [
  { required: true, message: '报名截止时间不能为空' },
  {
    validator: (value?: any) => {
      if (new Date(value).getTime() > new Date(actForm.value.startTime).getTime()) {
        return false;
      }
    },
    message: '截止时间不能晚于开始时间',
    trigger: ['onChange', 'onBlur'],
  },
];

const toggle = (index: string | number) => {
  checkboxRefs.value[index].toggle();
};
const afterRead: any = async (file: any) => {
  let formData = new FormData();

  formData.append('file', file.file);
  // formData.append('flag', 'Y');//加密上传
  file.status = 'uploading';
  file.message = '上传中...';
  await ApiUp.uploadFile(formData)
    .then((res) => {
      if (res.code == 200) {
        file.status = '';
        file.message = '';
        nextTick(() => {
          if (
            res.data.tokenUrl &&
            res.data.tokenUrl == '' &&
            res.data.tokenUrl == undefined &&
            res.data.tokenUrl == null
          ) {
            actForm.value['eventPoster'] = res.data.tokenUrl as string;
          } else {
            actForm.value['eventPoster'] = res.data.uploadUrl as string;
          }
        });

        Toast.success('上传成功');
      } else {
        file.status = 'failed';
        file.message = '上传失败';
        Toast.fail(res.msg);
      }
    })
    .catch((err) => {
      file.status = 'failed';
      file.message = '上传失败';
      Toast.fail(`上传失败：${err}`);
    });
};
const onClickLeft = () => {
  console.log('asd');
  console.log(router);
  history.back();
};
const checkMust = () => {
  actForm.value.requiredInformation = checked.value.join(',');
  showPicker2.value = false;
};
onBeforeUpdate(() => {
  checkboxRefs.value = [];
});

const getChange = (val: any) => {
  if (actForm.openFlag == '1') {
    changeValue.value = '是';
  } else {
    changeValue.value = '否';
  }
  console.log(changeValue.value);
};
const onFailed = (errorInfo?: any) => {
  console.log('failed', errorInfo);
};

const show2cli = () => {
    dateRange()
    showCalendar2.value = true;
};
const show3cli = () => {
    dateRange()
    showCalendar3.value = true;
};

const dateRange = ()=>{
    let dateNow = new Date();
    const currentYear = new Date().getFullYear()
    minDate.value = dateNow;
    let nextYear = currentYear + 1
    let nextMonth = new Date().getMonth()
    // let nextDay = new Date().getDate()    
    let nextDay = new Date(new Date().setFullYear(nextYear)).getDate() 
    maxDate.value = new Date(nextYear,nextMonth,nextDay);
}

const onConfirm2 = (date: any) => {
  actForm.value.startTime = fommatDate(date, 'yyyy-MM-dd hh:mm:ss');
  showCalendar2.value = false;
};
const onConfirm3 = (date: any) => {
  actForm.value.endTime = fommatDate(date, 'yyyy-MM-dd hh:mm:ss');
  showCalendar3.value = false;
};
const onConfirm4 = (date: any) => {
  actForm.value.registrationDeadline = fommatDate(date, 'yyyy-MM-dd hh:mm:ss');
  showCalendar4.value = false;
};
const showPicker2 = ref(false);

const onSubmit = async (val?: FormData) => {
  console.log(val);
  actForm.value.groupsId = router.currentRoute.value.query.groupsId as string;
  console.log("actForm",{
    ...actForm.value,
    ...fileHandle.compare(actForm.value),
  });
  if(!!route.query?.type && route.query?.type == 'reSubmit'){
    let id = route.query.id
        let {code,data,msg} = await activities.auditCXFQ({
    ...actForm.value,
    ...fileHandle.compare(actForm.value),          
        id,
        auditStatus: "0",
    })
    Toast.success(msg)
    if(code == 200){
        router.back()
    }    
  }else{
      const { code, data, msg } = await activities.addActivities({
      ...actForm.value,
      ...fileHandle.compare(actForm.value),
    });
    if (code == 200) {
      Toast.success(msg);
      router.go(-1);
    } else {
      Toast.fail(msg);
    }
  }
};

const initData = async ()=>{
    let id = route.query.id
    let groupsId = route.query.groupsId
    let {code,data,msg} = await activities.detailActivities({
        id,
        groupsId
    })
    if(code == 200){
        actForm.value = data
        actForm.value.eventPoster = data.oriEventPoster
        fileList.value.push({ url: getRealFilePath( data.oriEventPoster) })
        console.log('dataDetail.value',actForm.value)
        // timeEndFlag
        console.log(new Date().getTime())
        console.log('start',new Date(actForm.value.registrationDeadline).getTime())
        // if(new Date().getTime() > new Date(actForm.value.registrationDeadline).getTime()){
        //     timeEndFlag.value = true//现在时间已经超过截止时间
        // }
    }
}

onMounted(()=>{
  if(route.query.type == 'reSubmit'){
    initData()
  }
})
</script>
<style lang="less" scoped>
.upload-text {
  font-size: 28px;
  color: #004dff;
}
.up {
  margin: 15px 15px;
  // display: flex;
  // align-items: center;
  &-label {
    // font-size: 24px;
    color: #646566;
    padding: 0 15px;
  }
  &-border {
    margin: 0 15px;
    border-bottom: 1px solid #e7e7e7;
  }
}
.up-label::before {
  margin-right: 0.05333rem;
  color: red;
  content: '*';
}
.upload {
  margin: 15px 15px 0;
  padding-bottom: 15px;
  border-bottom: 1px solid #e7e7e7;
  text-align: center;
  &-btn {
    width: 100px;
    height: 100px;
    background-color: #e7e7e7;
    border-radius: 5px;
  }
  &-tips {
    width: 95%;
    margin-top: 10px;
    color: #fe2f2f;
    font-size: 12px;
  }
  &-up {
    text-align: center;
    margin-top: 5px;
    .van-button--normal {
      font-size: 12px;
      height: 20px;
    }
  }
}
  .upField{
    position: relative;
    height: 360px;
    // padding-bottom: 0px;
  }
  .uptips{
      position: absolute;
      top:170px;
      // top:75%;
      // left: 0px;
      width: 500px;
      word-break:break-all;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      transform: translate(-30%,0%);
      font-size: 16px;
      color: #FF0000;
      font-weight: 500;      
  }
  .butp{
    margin:16px;
    margin-top: 40px;
  }
</style>
