<template>
    <div class="gray-bg">
        <van-sticky>
            <nav-bar title="活动详情" left-arrow @click-left="onClickLeft" />
        </van-sticky>         
        <div class="main">
            <div class="banner">
                <fix-image :src="dataDetail.oriEventPoster" alt="" class="ims"></fix-image>
                <div class="themeContent">
                    <div class="title">
                        {{dataDetail.theme}}
                    </div>
                    <div class="item1 mar16">
                        <p class="po">主办方：</p><p class="organizer">{{dataDetail.organizer}}</p>
                    </div>
                    <div class="item1 mar24">
                        <!-- <p class="po">活动时间：</p><p class="time">{{timeShow(dataDetail.startTime)}}至{{timeShow(dataDetail.endTime)}}</p> -->
                        <p class="po">活动时间：</p><p class="time">{{dataDetail.startTime}}至{{dataDetail.endTime}}</p>
                    </div>
                    <div class="item1 mar16">
                       <!-- <p class="po"> 活动截止时间：</p><p class="registrationDeadline">{{timeShow(dataDetail.registrationDeadline)}}</p> -->
                       <p class="po"> 报名截止时间：</p><p class="registrationDeadline">{{dataDetail.registrationDeadline}}</p>
                    </div>
                </div>
            </div>
            <div class="introduction">
                <div class="part1">
                    活动介绍
                </div>
                <div class="part2">
                    {{dataDetail.introduction}}
                </div>
            </div>
            <div class="member">
                <div class="part1">
                    报名人员
                </div>
                <div class="part2M">
                    <van-swipe :loop="false" :show-indicatiors="false" ref='indoSwipe' :show-indicators="false">
                        <van-swipe-item v-for="(item,index) in dataItem" :key="index">
                            <div v-for="(it,id) in item" :key="id" class="item" @click="showMember(it)">
                                <!-- <fix-image :src="it.avatar" class="logo"></fix-image> -->
                                <Avatar class="logo" :src="it.avatar" />
                                <p class="name">{{it.name}}</p>
                            </div>
                        </van-swipe-item>
                    </van-swipe>   
                </div>
            </div>
        </div>
        <div class="join">
            <van-button v-if="dataDetail.auditStatus == '1' && dataDetail.registrationFlag !=='1' && !timeEndFlag" type="primary" round @click="jumpJoinWeb">报名</van-button>
            <van-button v-if="dataDetail.admin && dataDetail.auditStatus == '0' && !timeEndFlag" type="primary" round @click="progressBack">撤回</van-button>
            <van-button v-if="dataDetail.admin && (dataDetail.auditStatus == '2'|| dataDetail.auditStatus == '5') " type="primary" round @click="reCallProgress">重新发起</van-button>
            <van-button v-if="dataDetail.admin && (dataDetail.auditStatus == '5' || dataDetail.auditStatus == '0' || dataDetail.auditStatus == '2' || dataDetail.auditStatus == '4')" type="danger" round @click="deleteProgress">删除</van-button>
        </div>
        <van-dialog :show="memberShow" class="diaCss" @confirm="closeDia">
            <div class="alumnisection">
                <!-- <fix-image  class="bg-wrap"         
                    src="/assets/schoolmate/card_1.png"
                    width="330"
                    height="330"                    
                >
                </fix-image> -->
                <img :src="Card1" class="bg-wrap" alt="">
                <Avatar class="imgLogo" :src="memberVal.avatar" />     
                <div class="con">
                    <p class="name">
                    <span>{{ memberVal.name }}</span>
                    </p>         
                    <div class="cosna" v-if="memberVal.qq">
                        <div class="ric">QQ:</div>
                        <div class="yuanxi"> {{ memberVal.qq }}</div>
                    </div>                      
                    <div class="cosna" v-if="memberVal.collageName">
                        <div class="ric">学院:</div>
                        <div class="yuanxi">{{ memberVal.collageName }}</div>
                    </div>
                    <div class="cosna" v-if="memberVal.majorName">
                        <div class="ric">专业:</div>
                        <div class="yuanxi"> {{ memberVal.majorName }}</div>
                    </div>                    
                    <div class="cosna" v-if="memberVal.classes">
                        <div class="ric">班级:</div>
                        <div class="yuanxi"> {{ memberVal.classes }}</div>
                    </div>           
                    <div class="cosna" v-if="memberVal.schoolStartYear">
                        <div class="ric">入学年级:</div>
                        <div class="yuanxi"> {{ memberVal.schoolStartYear }}</div>
                    </div>         
                    <div class="cosna" v-if="memberVal.contact">
                        <div class="ric">联系电话:</div>
                        <div class="yuanxi"> {{ memberVal.contact }}</div>
                    </div>          
                    <div class="cosna" v-if="memberVal.remark">
                        <div class="ric">备注:</div>
                        <div class="yuanxi"> {{ memberVal.remark }}</div>
                    </div>                                                                                            
                </div>           
            </div>
        </van-dialog>
    </div>
</template>
<script lang="ts" setup>
import Avatar from '@/components/avatar/index.vue';
import iconlibrary from '@/assets/returnSchoolMonth/icon-library.png'
import icondeadline from '@/assets/returnSchoolMonth/icon-deadline.png'
import iconduring from '@/assets/returnSchoolMonth/icon-during.png'
import { Dialog, Toast } from 'vant'
import { getSchoolCode} from '@/utils/util';
import {  SchoolCode } from '@/constants';
import activities from '@/api/servive';
import { getPictures } from '@/utils';
import Card1 from "@/assets/schoolmate/card_1.png"
const imageCardList = ref<string[]>([]);
const imageCardLength = computed(() => imageCardList.value.length);  
getPictures('SCHOOLMATE_CARD').then(
  (result: ImageList) => (imageCardList.value = result.images.map((item) => item.fileAddress))
);

const route = useRoute()
const router = useRouter()
const schoolFlagSD = ref(false)
const memberPage  = ref({
    pageNum:1,
    pageSize:10
})

const dataDetail = <any>ref({})
const memberData = <any>ref({})
const memberShow = ref(false)
const memberVal = <any>ref(null)
const timeEndFlag = ref(false)
const fakeMemberList  = <any>ref([
    {
        avatar:iconlibrary,
        name:"1"
    },
])

const dataItem = <any>ref([])

const onClickLeft = () =>{
     router.back()
}
const onCancel = () => {
    onClickLeft()
}

const showMember = (val:any)=>{
    memberVal.value = val
    console.log('showMember',val)
    if(dataDetail.value.admin){
        memberShow.value = true
    }
    
}

const jumpJoinWeb = ()=>{
     router.push({ 
        path: '/groupJoinAct', 
        query:{
                requiredInformation:dataDetail.value.requiredInformation,
                id:dataDetail.value.id
                }
            });
}
const initFake = ()=>{
    let a = 30
    for(let i = 0;i <= a;i++){
        fakeMemberList.value.push({
             avatar:iconlibrary,
             name:String(i) + "test"
        })
    }
    handleMember(fakeMemberList.value)
}

const handleMember = (arr:any)=>{
    console.log('front',arr)
    let len = fakeMemberList.value.length
    let rowAll = Math.floor(len/10)
    // let rowAll = len/10
    let leftM =  len%10
    if(leftM > 0 && len > 10)rowAll++
    console.log('handleMember',len,rowAll,leftM)
    //slice
    if(rowAll > 0){
        for(let a = 0;a < rowAll;a++){
            dataItem.value.push(arr.slice(Number(a)*10,Number(a)*10+10))
        }
    }else{
        dataItem.value.push(arr)
    }

    console.log('dataItem.value',dataItem.value)

}

const toJoin = () => {
    // router.push('groupReturnJoin')
    router.push({ path: '/groupJoinAct', query: dataDetail.value });
}
const toEdit = () => {
    router.push({ path: 'groupReturnAdd', query: { flag: 'edit' } })
}
const timeShow = (val:string) =>{
    if(!!val)return val.slice(0,10)
}
const initData = async ()=>{
    let id = route.query.id
    let groupsId = route.query.groupsId
    let {code,data,msg} = await activities.detailActivities({
        id,
        groupsId
    })
    if(code == 200){
        dataDetail.value = data
        console.log('dataDetail.value',dataDetail.value)
        // timeEndFlag
        console.log(new Date().getTime())
        console.log('start',new Date(dataDetail.value.registrationDeadline).getTime())
        if(new Date().getTime() > new Date(dataDetail.value.registrationDeadline).getTime()){
            timeEndFlag.value = true//现在时间已经超过截止时间
        }
    }
}

function getImg(name: string) {
  return new URL(`../../assets/schoolmate/${name}`, import.meta.url).href;
}


const initMember = async () =>{
    let {code ,data,msg } = await activities.activityMemberPageApp(
        {
            pageNum:memberPage.value.pageNum,
            pageSize:memberPage.value.pageSize,
            actId:route.query.id || ''
        }
    )
    if(code == 200)memberData.value = data.list
    handleMember(memberData.value)
}

const progressBack =async ()=>{
    let id = route.query.id
        let {code,data,msg} = await activities.auditCHActivities({
        id,
        auditStatus: "5"
    })
    Toast.success(msg)
    if(code == 200){
        router.back()
    }
}

const reCallProgress =async ()=>{
    router.push({path:"/groupsbuild",query:{
        groupsId:route.query.groupsId,
        id:route.query.id,
        type:"reSubmit",
        // dataDetail:dataDetail.value
    }})
    return
    let id = route.query.id
        let {code,data,msg} = await activities.auditCXFQ({
        id,
        auditStatus: "0"
    })
    Toast.success(msg)
    if(code == 200){
        router.back()
    }
}

const deleteProgress =  ()=>{
    Dialog.confirm({
        title:"警告",
        message:"是否要删除该活动"
    }).then(async ()=>{
        let id = route.query.id
        let {code,data,msg} = await activities.deleteActivities({
        id,
        auditStatus: "0"
        })
        Toast.success(msg)
        if(code == 200){
            router.back()
        }
    }).catch(()=>{

        console.log('cancel')
    })

}

const closeDia = ()=>{
    memberShow.value = false
}

onMounted(()=>{
    // judegeFlag()
    console.log('onMounted')
    initData()
    initMember()
    // initFake()
})
onActivated(()=>{
    console.log('onActivated')
    initData()
    initMember()  
})
</script>
<style lang="less" scoped>
.main{
    width: 100%;
    height: 100%;
    position: relative;
    .banner{
        width: 100%;
        box-sizing: border-box;
        padding: 20px 30px;
        background-color: #fff;
        .ims{
            width: 690px;
            height: 325px;
        }
    }
    .themeContent{
        width: 100%;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        .title{
            color: #222;
            font-size: 34px;
            font-weight: 600;
            margin-top: 24px;
        }
        .mar24{
            margin-top: 24px;
        }
        .mar16{
            margin-top: 16px;
        }        
        .item1{
            display: flex;
            align-items: center;
            width: 100%;
            height: 40px;
            font-size: 24px;
            .po{
                color: #666;
            }
            .organizer{
                color: #666;
            }
            .time{
                color: #222;
                font-weight: 700;
            }
            .registrationDeadline{
                color: #ff0000;
            }
        }
    }
    .introduction{
        background-color: #fff;
        width: 100%;
        box-sizing: border-box;
        padding: 30px;
        margin-top: 20px;
        height: 468px;
        overflow-y:auto ;
        .part1{
            color: #222;
            font-size: 34px;
            font-weight: 700;
        }
        .part2{
            margin-top: 24px;
            width: 100%;
            font-size: 28px;
            color:#333;
            white-space:pre-wrap;
            word-break: break-all;
        }
    }
    .member{
        background-color: #fff;
        width: 100%;
        box-sizing: border-box;
        padding: 30px;
        margin-top: 20px;
        margin-bottom: 60px;
        // height: 468px;
        // overflow-y:auto ;
        .part1{
            color: #222;
            font-size: 34px;
            font-weight: 700;
        }     
        .part2M{
            margin-top: 24px;
            width: 100%;
            font-size: 28px;
            color:#333;
            :deep(.van-swipe){
                width: 100%;
            }
            :deep(.van-swipe-item){
                width: 100%;
                display: flex;
                flex-wrap: wrap;
            }
            .item{
                flex:1;
                padding: 24px 0px;
                box-sizing: border-box;
                margin-bottom: 10px;
                width: calc(84vw/5);
                min-width: calc(84vw/5);
                max-width: calc(84vw/5);
                background-color: #ffffff;
                color: #222;         
                &:nth-child(5n){
                    margin-right: 0px;
                } 
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;        
                .logo{
                    width: 80px;
                    height: 80px;
                }   
                .name{
                    font-size: 26px;
                    color: #222222;
                }                       
            }
            // white-space:pre-wrap;
            // word-break: break-all;

        }           
    }
}
.join{
    position: fixed;
    bottom: 40px;
    width: 100vw;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    left: 50%;
    transform: translate(-50%, 0%);
    z-index: 9999;
    :deep(.van-button--round){
        width: 690px;
    }
    .dada{
        background-color: #F56C6C;
        
    }
}

    .alumnisection {
      position: relative;
    //   width: 400px;
      min-height: 350px;
      // height: 330px;
      margin: 60px 30px 30px 0;
      border-radius: 8px;
      position: relative;
      box-sizing: border-box;
      z-index: 1;
      .bg-wrap {
        position: absolute;
        width: 440px;
        // height: 350px;
        height: 100%;
        top: 0;
        // left: 0;
        left: 50%; /* 向右移动元素自身宽度的一半 */
        transform: translate(-50%, 0%);
        // border-radius: 50%;        
        overflow: hidden;
        z-index: -1;
      }
      &:nth-child(2n-1) {
        margin-left: 30px;
      }
      .imgLogo {
        width: 88px;
        height: 88px;
        border: 2px solid #dfdfdf;
        position: absolute; /* 或 relative */
        top: 0; /* 向下移动元素自身高度的一半 */
        left: 50%; /* 向右移动元素自身宽度的一半 */
        transform: translate(-50%, -50%);
        border-radius: 50%;
        object-fit: cover;
        background: #fff;
      }
      .con {
        text-align: center;
        // height: 100%;
        padding: 0 20px;
        .name {
          padding-top: 30px;
          font-size: 30px;
          font-family: PingFangSC-Medium, PingFang SC;
          font-weight: 500;
          color: #333333;
          // justify-content: center;
          // text-align: center;
          display: flex;
          justify-content: center;
          align-items: center;
          .ims {
            margin-left: 5px;
            width: 28px;
            height: 28px;
          }
        }
        .ric {
          margin-top: 13px;
        //   width: 8px;
        //   height: 8px;
        //   background: linear-gradient(270deg, #eaeaea 0%, #aaa9a9 100%, #ffffff 100%);
        width: 160px;
        height: 40px;
        line-height: 40px;
        font-size: 24px;
        text-align: left;
        }
        .iniDiv {
          display: block;
          height: 30px;
          font-size: 0px;
        }
        .cosna {
          width: 100%;
          // height: 30px;
          display: flex;
          margin-bottom: 10px; // word-break: break-all;
          align-items: center;
          // display: -webkit-box;
          // -webkit-line-clamp: 2;
          // -webkit-box-orient: vertical;
          // over-flow: hidden;
          // word-wrap: break-word;
          // flex-wrap: wrap;
        }
        .daxue {
            width: 200px;
            text-align: left;
            overflow-x: hidden;
          margin-left: 8px;
          font-size: 24px;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          color: #666666;
        }
        .yuanxi {
        //   width: 100%;
        width: 200px;
          // height: 30px;
          margin-left: 8px;
          font-size: 24px;
          font-family: PingFangSC-Regular, PingFang SC;
          font-weight: 400;
          color: #666666;
          text-align: left;
          // word-break: break-all;
        //   word-break: break-all;
        //   display: -webkit-box;
        //   -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow-x: hidden;
        }
      }
    }
    :deep(.van-dialog__content){
        display: flex;
        justify-content: center;
        align-items: center;
    }
    :deep(.van-dialog){
        // min-width: 70vw;
        width: auto;
        box-sizing: border-box;
        padding: 0 40px;
    }
</style>