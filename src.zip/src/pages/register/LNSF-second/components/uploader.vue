<template>
  <van-field v-model="dataClone" :class="required ? 'required' : ''"
    :rules="required ? [{ required: true, message: `请上传${label}` }] : []" :placeholder="`请选择${label}`" readonly
    name="diplomaImage" input-align="left" error-message-align="left">
    <template #input>
      <div class="upload-tit">{{ label }} <span class="red">（{{ uploadTips }}）</span>
      </div>
      <compress-uploader v-model="healthFileList"  max-count="1" :after-read="afterRead"
        :before-read="beforeUpload" :accept="accept" />
      <span class="tips">{{ uploadLimit }}</span>
    </template>
  </van-field>
</template>
<script lang="ts" setup>
import { useVModel } from '@/hooks/useVModel';
import ApiUpload from '@/api/uploadfile';
import { Toast } from 'vant';

const uploadTips = ref('');
const uploadLimit = ref('');
const props = withDefaults(
  defineProps<{ picUrl: string; label: string; required: boolean; param?: string; accept?: string }>(),
  {}
);
const accept = computed(() => props.param && ['userProfilePicture'].includes(props.param) ? '.png,.jpg,.jpeg' :  '.png,.jpg,.jpeg,.pdf')
watch(
  () => props.param,
  (val) => {
    if (val == 'diplomaImage') {
      uploadTips.value = '请上传本人毕业证书或学位证书等可以证明本人学历信息的材料';
      uploadLimit.value = '注意：上传证明材料仅支持jpg、pdf格式，大小不超过2M。';
    } else if (val == 'userProfilePicture') {
      uploadTips.value = '请上传本人近期免冠证明照，本人照片用于入校核验身份使用';
      uploadLimit.value =
        '特别提示：不得上传明星照、卡通头像、风景照、他人照片等非本人照片；上传照片仅支持jpg格式，文件大小不超过1M。';
    } else {
      uploadTips.value = '请上传相关材料文件';
      uploadLimit.value = '注意：上传证明材料仅支持jpg、pdf格式，大小不超过2M。';
    }
  },
  { immediate: true }
);
const emits = defineEmits<{ (e: 'update:picUrl', picUrl: string): void }>();
const dataClone = useVModel(props, 'picUrl', emits);
const healthFileList = ref<any[]>([]);
if (dataClone.value) {
  healthFileList.value[0] = dataClone.value;
}
const beforeUpload = async (file: any) => {
  //userProfilePicture
  let maxSize = 0
  if(props.param == 'userProfilePicture'){
    maxSize = 1 * 1024 * 1024
  }else{
    maxSize = 2 * 1024 * 1024
  }
  if(file.size <= maxSize){
    const arr = file?.name.split('.')
    const typeName = arr.pop().toLowerCase()
    const newName = arr.join('') + '.' + typeName
    const newFile = new File([file], newName, {
      type: file.type
    })
    console.log('beforeUpload',file)
    return newFile;
  }else{
    Toast('文件大小不能超过2MB！')
    return false
  }

}
const afterRead = async (file: any) => {
  console.log('afterRead')
  let formData1 = new FormData();
  formData1.append('file', file.file);
  let isFlagY = ['userProfilePicture'].includes(props.param!)
  formData1.append('flag', isFlagY ? 'Y' : '');// 头像需要加密上传
  file.status = 'uploading';
  file.message = '上传中...';
  await ApiUpload.uploadFile(formData1)
    .then((res) => {
      if (res.code == 200) {
        file.status = '';
        file.message = '';
        dataClone.value = isFlagY ? res.data.tokenUrl : res.data.uploadUrl;
        Toast.success('上传成功');
      } else {
        file.status = 'failed';
        file.message = '上传失败';
        Toast.fail(res.msg);
      }
    })
    .catch((err) => {
      file.status = 'failed';
      file.message = '上传失败';
      Toast.fail(`上传失败：${err}`);
    });
};
</script>
<style lang="less" scoped>
.required {
  &::before {
    content: "*";
    color: #ff0000;
  }
}

:deep(.van-field__control--custom) {
  display: flex;
  flex-direction: column;
  align-items: normal;
  min-height: var(--van-cell-line-height);

  .upload-tit {
    font-size: 24px;
    line-height: 40px;

    .red {
      color: #ff0000;
    }
  }

  .tips {
    font-size: 24px;
    color: #999999;
  }

  .van-uploader {
    margin: 24px 0;
  }
}
</style>