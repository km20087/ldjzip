<template>
  <div class="education-list">
    <div class="name" @click="foldFun($event)">
      <span>第{{ idx }}学历：{{ name }}</span>
      <van-icon name="arrow-down"></van-icon>
    </div>
    <div class="cont">
      <div class="li" v-if="!notAllShow"> 
        <span>学历性质</span>
        <span class="val">{{ type }}</span>
      </div>
      <div class="li" v-if="!notAllShow">
        <span>学制</span>
        <span class="val">{{ period }}</span>
      </div>
      <!-- isShenYangShiFan -->
      <div class="li" v-if="!isShenYangShiFan()">
        <span>学院</span>
        <span class="val">{{ college }}</span>
      </div>      
      <div class="li" v-else-if="isShenYangShiFan() && !!college && !collegeCodeName">
        <span>学院</span>
        <span class="val">{{ college }}</span>
      </div>
      <div class="noCell" v-else-if="isShenYangShiFan()">
        <van-field  label="学院" 
        v-model="collegeCodeName" 
        @click="getColumnShow('collegeName')" placeholder="请选择学院"  is-link readonly >
        </van-field>
      </div>
      <div class="li" v-if="!isShenYangShiFan()">
        <span>年级</span>
        <span class="val">{{ year }}</span>
      </div>      
      <div class="li" v-else-if="isShenYangShiFan() && !!year && !inpYear">
        <span>年级</span>
        <span class="val">{{ year }}</span>
      </div>
      <div class="noCell" v-else-if="isShenYangShiFan()">
          <van-field v-model="inpYear"  label="年级" @blur="getInpVal" placeholder="请输入年级">
          </van-field>
      </div>
      <div class="li" v-if="!isShenYangShiFan()">
        <span>专业</span>
        <span class="val">{{ major }}</span>
      </div>      
      <div class="li" v-if="isShenYangShiFan() && !!major && !majorCodeName">
        <span>专业</span>
        <span class="val">{{ major }}</span>
      </div>
      <div class="noCell" v-else-if="isShenYangShiFan()">
        <van-field  label="专业" 
        v-model="majorCodeName" 
        @click="getColumnShow('majorName')" placeholder="请选择学院"  is-link readonly >
        </van-field>
      </div>      
      <div class="li" v-if="!notAllShow">
        <span>班级</span>
        <span class="val">{{ classes }}</span>
      </div>
    </div>
  </div>
  <van-popup v-model:show="showPicker" position="bottom" ref="showNewColumns">
      <van-picker :columns="newColumns" @confirm="onConfirmPickerCom" @cancel="showPicker = false" />
  </van-popup>   
</template>
<script lang="ts" setup>
import { isShenYangShiFan } from '@/utils/customizedType';
const props = withDefaults(
  defineProps<{
    idx?: string;
    name?: string;
    type?: string;
    period?: string;
    college?: string;
    year?: string;
    major?: string;
    classes?: string;
    notAllShow?:boolean
    majorCode?:string,
    collegeId?:string,
    newColumns?:any,
    sureEdu:Function,
    sureYear:Function,
  }>(),
  {
    idx: '',
    notAllShow:false,
    collegeId:''
  }
);
const emits = defineEmits<{
  (e:'initCollege'):void
  (e:'initMajorName'):void
  (e: 'update:collegeId', collegeId: string): void
  (e: 'update:major', major: string): void
}>()
const collegeCodeName = ref('')
const majorCodeName = ref('')
const inpYear = ref('')
// const emits = defineEmits(['initCollege','initMajorName'])
const showPicker = ref(false)
const typePicker = ref('')
const foldFun = (e: any) => {
  if (e.target.children[1].className == 'van-badge__wrapper van-icon van-icon-arrow-down') {
    e.target.parentNode.style = 'padding-bottom:1px';
    e.target.nextElementSibling.style = 'display:none;transition:.8s';
    e.target.children[1].setAttribute('class', 'van-badge__wrapper van-icon van-icon-arrow-up');
  } else {
    e.target.parentNode.style = 'padding-bottom:3.2vw';
    e.target.nextElementSibling.style = 'display:block;transition:.8s';
    e.target.children[1].setAttribute('class', 'van-badge__wrapper van-icon van-icon-arrow-down');
  }
};
const getColumnShow = (val:string) =>{
  console.log(val)
  // emits('getColumn',val)
  typePicker.value = val
  if(val == 'collegeName'){
    emits('initCollege')
  }else{
    emits('initMajorName')
  }
  showPicker.value = true
}
const onConfirmPickerCom = (value:any)=>{
  console.log('onConfirmPickerCom',value)
  props.sureEdu(props.idx,typePicker.value,value.deptName,value.deptId)
  if(typePicker.value == 'collegeName'){
    collegeCodeName.value = value.deptName
  }else{
    majorCodeName.value = value.deptName
  }
  showPicker.value = false
}

const getInpVal = (value:string) =>{
  props.sureYear(props.idx,value)
}
</script>
<style lang="less" scoped>
.education-list {
  background: #ffffff;
  border-radius: 16px;
  padding: 20px;
  margin-bottom: 24px;
  .name {
    font-size: 32px;
    color: #222222;
    font-weight: 500;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 23px 0 43px;
  }
  .cont {
    background: #cccccc6e;
    border-radius: 8px;
    padding: 0.5px;
    .li {
      display: flex;
      justify-content: space-between;
      margin: 40px 20px;
      color: #666;
      font-size: 30px;
      span:first-child {
        display: inline;
        min-width: 150px;
      }
      .val {
        color: #222222;
      }
    }
  }
}
.noCell{
  :deep(.van-cell){
    padding-left:0px;
    padding-right:0px;
  }
  :deep(.van-field__control){
    text-align: right;
  }
}
</style>