<template>
  <van-field
    v-model="dataText"
    :label="label"
    :required="required"
    :disabled="disabled"
    :rules="required ? [{ required: true, message: `请选择${label}` }] : []"
    :placeholder="`请选择${label}`"
    is-link
    readonly
    @click="disabled ? '' : showPicker()"
  />
  <!-- <van-field
    v-if="isNormal == '1'"
    v-model="dataText"
    :label="label"
    :required="required"
    :rules="required ? [{ required: true, message: `请选择${label}` }] : []"
    :placeholder="`请选择${label}`"
    is-link
    readonly
    @click="isShow = true"
  /> -->
  <van-popup v-model:show="isShow" position="bottom" round lock-scroll>
    <van-picker
      :columns-field-names="{ text: 'label' }"
      :title="`选择${label}`"
      :columns="columns"
      @confirm="onConfirm"
      @cancel="isShow = false"
      v-if="pickerType == 'default'"
    />
    <van-picker :columns="columns" title="请选择年份" show-toolbar :default-index="defaultTime" @confirm="onConfirm"
      @cancel="isShow = false" v-else-if="pickerType == 'time'" />    
  </van-popup>
</template>
<script lang="ts" setup>
import { useVModel } from '@/hooks/useVModel';


const defaultTime = ref('')
const isShow = ref(false);
const dataText = ref<string|number>('');
const props = withDefaults(
  defineProps<{
    selectedData: string;
    columns: Array<any>;
    label: string;
    required: boolean;
    disabled?: boolean;
    pickerType?:string
  }>(),
  {
    pickerType:'default'
  }
);

const emits = defineEmits<{ (e: 'update:selectedData', selectedData: string): void }>();
const dataClone = useVModel(props, 'selectedData', emits);
for (let i of props.columns) {
  if (typeof i === 'string') {
    dataText.value = dataClone.value;
  } else if (typeof i === 'object') {
    if (dataClone.value == i.value) {
      dataText.value = i.label;
    }
  }
}


//区分string[]和object[]
const onConfirm = (v: any) => {
  if (typeof v === 'string' || typeof v === 'number') {
    dataClone.value = v;
    dataText.value = v;
    console.log(dataClone.value, 'dataClone.value');
  } else if (typeof v === 'object') {
    dataClone.value = v.value;
    dataText.value = v.label;
    console.log(dataClone.value, 'dataClone.value', dataText.value);
  }
  isShow.value = false;
};

const initDefaultTime = () =>{
  if(props.pickerType == 'time'){
    let nowTime = new Date();
    let years = nowTime.getFullYear();
    defaultTime.value = props.columns.indexOf(Number(years)).toString();
  }
}

const showPicker = () =>{
  isShow.value = true
  initDefaultTime()
}
</script>