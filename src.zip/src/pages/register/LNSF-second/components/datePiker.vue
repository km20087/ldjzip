<template>
  <van-field
    v-model="currentDateClone"
    :label="label"
    :required="required"
    :disabled="disabled"
    :rules="required ? [{ required: true, message: `请选择${label}` }] : []"
    :placeholder="`请选择${label}`"
    is-link
    @click="disabled ? '' : (isShow = true)"
  ></van-field>
  <van-popup v-model:show="isShow" position="bottom" round lock-scroll>
    <van-datetime-picker
      v-model="pickerCurrent"
      :type="type"
      title="选择日期"
      :min-date="minDate"
      @confirm="onConfirm"
      @cancel="isShow = false"
    />
  </van-popup>
</template>
<script lang="ts" setup>
import { useVModel } from '@/hooks/useVModel';
import { fommatDate } from '@/utils/fommatDate';
import { WritableComputedRef } from 'vue';

const props = withDefaults(
  defineProps<{
    label?: string;
    required?: boolean;
    disabled: boolean;
    currentDate?: string;
  }>(),
  {
    currentDate: fommatDate(new Date(), 'yyyy-MM-dd'),
  }
);
// const date = ref(props.currentDate);
const isShow = ref(false);
const minDate = ref(new Date(1790, 0, 1));
const pickerCurrent = ref<Date>(new Date());
// const maxDate=ref(new Date())
const type = ref('date');

const emits = defineEmits<{ (e: 'update:currentDate', currentDate: string): void }>();
const currentDateClone = useVModel(props, 'currentDate', emits);

onBeforeMount(() => {
  if (!props.currentDate) return;
  if (props.currentDate.split('-').length == 2) {
    type.value = 'year-month';
    pickerCurrent.value = new Date(
      Number(props.currentDate.split('-')[0]),
      Number(props.currentDate.split('-')[1])
    );
  } else if (props.currentDate.split('-').length == 3) {
    type.value = 'date';
    pickerCurrent.value = new Date(
      Number(props.currentDate.split('-')[0]),
      Number(props.currentDate.split('-')[1]),
      Number(props.currentDate.split('-')[2])
    );
  }
});
const onConfirm = (v: any) => {
  currentDateClone.value = fommatDate(v, 'yyyy-MM-dd');
  isShow.value = false;
};
</script>