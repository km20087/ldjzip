<template>
  <van-field v-if="areaMode == 'other'" v-model="dataClone[values]" :label="label" :autofocus="true"
    :placeholder="`请输入${label}`" :disabled="disabled" :required="required" />
  <van-field v-else v-model="dataClone[values]" is-link readonly :label="label" :placeholder="`请选择${label}`"
    @click="isShow = true" :disabled="disabled" :required="required" />
  <van-popup v-model:show="isShow" round position="bottom">
    <van-cascader v-model="cascaderValue" :title="`请选择${label}`" :options="areaList" active-color="var(--theme-color)"
      :field-names="fieldName" @close="isShow = false" @finish="onFinish" @change="onChange" />
  </van-popup>
</template>
<script lang="ts" setup>
import { useVModel } from '@/hooks/useVModel';
import ApiDept from '@/api/common';

interface areaParams {
  parentNo: string;
  addrLevel: string;
  addrName: string;
  pageSize: number;
  pageNum: number;
}
const cascaderValue = ref('');
const isShow = ref(false);
const areaP = ref<areaParams>({
  parentNo: '',
  addrLevel: '1',
  addrName: '',
  pageSize: 100,
  pageNum: 1,
});
const areaList = ref<Array<any>>([]);
const fieldName = ref({
  text: 'addrName',
  value: 'addrNo',
  children: 'children',
});
const areaMode = ref('');
const props = withDefaults(
  defineProps<{
    datas: any;
    label?: string;
    values: string;
    level?: string;
    disabled: boolean;
    required?: boolean
  }>(),
  {
    label: '地区',
    level: '3',
  }
);
const emits = defineEmits<{ (e: 'update:datas', datas: string): void }>();
const dataClone = useVModel(props, 'datas', emits);

const addTree = (selectedOptions: any, children: any, id: any) => {
  selectedOptions.forEach((item: any) => {
    if (item.addrNo === id) {
      item.children = children;
    }
  });
};
//查询地区列表
const initArea = async () => {
  const { data, code, msg } = await ApiDept.areaList(areaP.value);
  if (code == 200) {
    let list = data.list;
    // areaList.value.push(...list, { addrLevel: '1', addrNo: 'other', addrName: '其他' });
    areaList.value.push(...list);
  }
};
initArea();
const onChange = async ({ value, selectedOptions, tabIndex }: any) => {
  let le = selectedOptions.length - 1;
  let ao = selectedOptions[le];
  if (ao.hasChild == '1' && ao.addrLevel < props.level) {
    areaP.value.parentNo = String(value);
    areaP.value.addrLevel = String(Number(ao.addrLevel) + 1);
    const { data, code, msg } = await ApiDept.areaList(areaP.value);
    addTree(selectedOptions, data.list, value);
  } else {
    isShow.value = false;
  }
};
const onFinish = ({ value, selectedOptions, tabIndex }: any) => {
  if (value == 'other') {
    areaMode.value = 'other';
    // dataClone.value[props.values] = '';
    return;
  }
  let a = selectedOptions.length - 1;
  if (selectedOptions[a].addrLevel == '1') {
    dataClone.value.provinceName = selectedOptions[a].addrName;
    dataClone.value.provinceId = selectedOptions[a].addrNo;
  } else if (selectedOptions[a].addrLevel == '2') {
    dataClone.value.cityName = selectedOptions[a].addrName;
    dataClone.value.cityId = selectedOptions[a].addrNo;
  } else if (selectedOptions[a].addrLevel == '3') {
    dataClone.value.areaName = selectedOptions[a].addrName;
    dataClone.value.areaId = selectedOptions[a].addrNo;
  }
  dataClone.value[props.values] = selectedOptions.map((option: any) => option.addrName).join('');
};
</script>