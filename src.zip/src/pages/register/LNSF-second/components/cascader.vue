<template>
  <van-field
    v-model="dataText"
    :label="label"
    :required="required"
    :disabled="disabled"
    :rules="required ? [{ required: true, message: `请选择${label}` }] : []"
    :placeholder="`请选择${label}`"
    is-link
    readonly
    @click="disabled ? '' : (isShow = true)"
  />
  <van-popup v-model:show="isShow" position="bottom" round lock-scroll>
            <!-- <van-cascader v-model="cascaderValue" title="请选择所在地区" :options="options" :field-names="fieldName"
              @close="cancelOptionsDia" @change="onChange" @finish="onFinish"  v-if="!areaInputFlag"/> -->
  </van-popup>
</template>
<script lang="ts" setup>
import { useVModel } from '@/hooks/useVModel';
import ApiDept from '@/api/common';
const isShow = ref(false);
const dataText = ref('');
const options = <any>reactive([]);
const props = withDefaults(
  defineProps<{
    selectedData: string;
    columns?: Array<any>;
    label: string;
    required: boolean;
    disabled?: boolean;
    param?:string
  }>(),
  {}
);
const areaP = reactive({
  parentNo: '',
  addrLevel: '1',
  addrName: '',
  pageSize: 100,
  pageNum: 1,
});
const emits = defineEmits<{ (e: 'update:selectedData', selectedData: string): void }>();


const initArea = async () => {
    areaP.addrLevel = '0'//国内和国外
    areaP.parentNo = ''
    let arr:any = []
    // param
    if(props.param == 'areaName' || props.param == 'residentArea'){
        arr = [
          {
            addrName:"国内",
            addrNo:"0",
            children:[],
            hasChild:"1",
            addrLevel:"0"
          },          
        ]        
    }
}
onMounted(()=>{
  initArea()
})
</script>