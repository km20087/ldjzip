<template>
  <!-- <van-sticky>
    <van-nav-bar title="" left-arrow @click-left="onClickLeft" />
  </van-sticky> -->
  <main class="wrap">
    <div v-if="educationInfoList.length > 0">
      <div class="title"> 学历信息 </div>
      <education-bar v-for="(item, index) in educationInfoList" :notAllShow="!isLiaoShiDa()" :key="index" :idx="numTohan(index + 1)"
        :name="item.education" :type="item.academicType" :period="item.schoolingPeriod" :college="item.collegeName" :collegeId="item.collegeId"
        :year="item.schoolStartYear" :major="item.majorName" :majorCode="item.major" :newColumns="newColumns" :sureYear="sureYear" :sureEdu="sureEdu" @initCollege="initCollege" @initMajorName="initMajorName" :classes="item.classesName" />
      <div class="revise-btn" @click="toRevise" v-if="isLiaoShiDa()">
        <van-image :src="reviseBTN" style="width: 18px; height: 18px"></van-image>
        <span style="padding: 0 5px">学历信息更正申请</span>
      </div>
    </div>
    <div class="title"> 信息填写 </div>
    <van-form input-align="right" error-message-align="right" @submit="onSubmit">
      <van-cell-group>
        <div v-for="(item, index) in configData" :key="index">
          <datePiker v-if="item.param == 'birthday' || item.param == 'dateOfBirth'"
            v-model:currentDate="formData[item.param]" :label="item.label" :required="item.required"
            :disabled="item.disabled" />
          <picker v-else-if="item.param == 'gender'" :columns="sexArr" v-model:selectedData="formData[item.param]"
            :label="item.label" :required="item.required" :disabled="item.disabled" />
          <picker v-else-if="item.param == 'cardType'" :columns="initColumns(item.param)" v-model:selectedData="formData[item.param]"
            :label="item.label" :required="item.required" :disabled="item.disabled" />
          <picker v-else-if="item.param == 'location'" :columns="initColumns(item.param)" v-model:selectedData="formData[item.param]"
            :label="item.label" :required="item.required" :disabled="item.disabled" />
          <picker v-else-if="item.param == 'positionType'" :columns="initColumns(item.param)" v-model:selectedData="formData[item.param]"
            :label="item.label" :required="item.required" :disabled="item.disabled" />
          <picker v-else-if="item.param == 'politicalStatus'" :columns="initColumns(item.param)" v-model:selectedData="formData[item.param]"
            :label="item.label" :required="item.required" :disabled="item.disabled" />                            
          <!-- positionType -->
            <!-- 证件类型 -->
          <picker v-else-if="item.param == 'workField'" :columns="industryArr" v-model:selectedData="formData[item.param]"
            :label="item.label" :required="item.required" :disabled="item.disabled" />
          <picker v-else-if="item.param == 'schoolStartYear'" 
          :columns="timeList" v-model:selectedData="formData[item.param]"
            :label="item.label" :required="item.required" pickerType="time"  :disabled="item.disabled" />                  
          <picker v-else-if="item.param == 'schoolEndYear'" 
          :columns="timeList" v-model:selectedData="formData[item.param]"
            :label="item.label" :required="item.required" pickerType="time"  
            :disabled="item.disabled" />            
          <picker v-else-if="item.param == 'ethnic'" :columns="nation" v-model:selectedData="formData[item.param]"
            :label="item.label" :required="item.required" :disabled="item.disabled" />
          <uploaderVue v-else-if="item.param == 'diplomaImage' ||
            item.param == 'bareheadedPhoto' ||
            item.param == 'userProfilePicture' ||
            item.param == 'identificationDocumentImage'
            " v-model:picUrl="formData[item.param]" :label="item.label" :param="item.param" :required="item.required" />
          <area-cascader v-else-if="item.param == 'residentArea'" label="常住地区" :values="item.param"
            :disabled="item.disabled" :required="true" level="2" v-model:datas="formData" />

          <div v-else-if="item.param == 'provinceName'"></div>
          <div v-else-if="item.param == 'cityName'"></div>
          <area-cascader v-else-if="item.param == 'areaName'" label="省市区" :values="item.param"
            :disabled="item.disabled" :required="item.required" level="3" v-model:datas="formData" />
            <van-field v-else-if="item.param == 'jobTitle' && !inPJobTitleFlag" :label="item.label"
              v-model="occupation.occupationName" :required="item.required" name="validator" :placeholder="'请选择'+item.label" readonly
              @click="goOccupationPage" />       
            <picker v-else-if="item.param == 'education' && educationInfoList.length == 0" :columns="initColumns(item.param)" v-model:selectedData="formData[item.param]"
            :label="item.label"  :required="item.required" :disabled="item.disabled" />    
            <picker v-else-if="item.param == 'academicDegree'" :columns="initColumns(item.param)" v-model:selectedData="formData[item.param]"
            :label="item.label"  :required="item.required" :disabled="item.disabled" />                                 
            <van-field v-else-if="item.param == 'collegeName' && educationInfoList.length == 0" :label="item.label" :name="item.param"
             v-model="formData[item.param]" :required="item.required" 
             :rules="item.required ? [{ required: true, message: `请选择${item.label}` }] : []"
             @click="columnShow('collegeName')" :placeholder="'请选择'+item.label"  is-link readonly >
            </van-field>
            <van-field v-else-if="item.param == 'majorName' && educationInfoList.length == 0" :label="item.label" :name="item.param"
             v-model="formData[item.param]" :required="item.required" 
            :rules="item.required ? [{ required: true, message: `请选择${item.label}` }] : []"
             @click="columnShow('majorName')" :placeholder="'请选择'+item.label" is-link readonly >
            </van-field>            
                      <!--  && !isLiaoShiDa()  手动输入职务 -->
          <van-field v-model="formData[item.param]" v-else :label="item.label" :name="item.param" :placeholder="item.param == 'professionTitle' ? `请填写完整${item.label}名称` : `请输入${item.label}`
            " :required="item.required" :disabled="item.disabled"
            :rules="item.required ? [{ required: true, message: `请输入${item.label}` }] : []">
          </van-field>
        </div>
      </van-cell-group>
      <van-popup v-model:show="showPickerVan" position="bottom" ref="showNewColumns">
          <van-picker :columns="newColumns" @confirm="onConfirmPicker" @cancel="showPickerVan = false" />
      </van-popup>         
      <div class="submit-btn">
        <van-button color="var(--theme-color)" block round native-type="submit">提 交</van-button>
      </div>
    </van-form> 
  </main>
</template>
<script lang="ts" setup>
import educationBar from './components/education-bar.vue';
import reviseBTN from '@/assets/icons/revise@2x.png';
import { numTohan } from '@/utils/num';
import ApiConfig from '@/api/config';
import listForm from '@/utils/dataList/infoConfig';
import datePiker from './components/datePiker.vue';
import picker from './components/picker.vue';
import uploaderVue from './components/uploader.vue';
import areaCascader from './components/area-cascader.vue';
import nation from '@/utils/dataList/nation';
import datalist from '@/utils/dataList/datalist';
import ApiDept from '@/api/common';
import Api from '@/api/user';
import { initMenu } from '@/router';
import FileHandle from '@/utils/file-handle';
import { Toast } from 'vant';
import { useMenuStore } from "@/store";
import { DynamicRoutes } from "@/router/list";
import { useOccupation } from '@/hooks/useOccupation';
import { useUserStore } from '@/store';
import { isShenYangShiFan,isLiaoShiDa,isChengDuYiXueYuan,isChengDeYiXueYuan } from '@/utils/customizedType';
import { formatDate, formatDateTime } from '@/utils/tool/time';
import { setButtons, setMenus, setUserStatus,getSchoolId,getSchoolCode } from '@/utils';
interface areaParams {
  parentNo: string;
  addrLevel: string;
  addrName: string;
  pageSize: number;
  pageNum: number;
}
const $router = useRouter();
const $route = useRoute();
const inPJobTitleFlag = ref(false)
const onClickLeft = () => $router.back();
let configData = ref<any[]>([]);
let formData = ref<any>({});
let educationInfoList = ref<any[]>([]);
const initList = listForm.listForm().list;
const areaName = computed(() => {
  return (
    getName(formData.value.provinceName) + getName(formData.value.cityName) + getName(formData.value.areaName) + ''
  );
});
//性别列表
const sexArr = ref([
  { value: '1', label: '男' },
  { value: '0', label: '女' },
]);
const areaList = ref<Array<any>>([]);
const areaP = ref<areaParams>({
  parentNo: '',
  addrLevel: '2',
  addrName: '',
  pageSize: 100,
  pageNum: 1,
});

const educationCorrection = ref('0')//是否手动填写学历信息0-无修改，1-手动填写
const loadingFlag = ref(false);
const newColumns = <any>ref([])
const showPickerVan = ref(false)
const industryArr = ref<Array<any>>([]);
let fileHandle = new FileHandle(['bareheadedPhoto']);
let diplomaImageFile = new FileHandle(['diplomaImage']);
let userProfilePictureFile = new FileHandle(['userProfilePicture']);
let identificationDocumentImageFile = new FileHandle(['identificationDocumentImage']);

const timeList = <any>ref([]);
const dateValue = ref('');
const paramType = ref('')
const userStore = useUserStore();

const {
  occupation,
  initOccupation,
  goOccupationPage,
  pickOccupationToSubmit,
  getDataFromCache,
  getDataListCache,
} = useOccupation(formData.value, {});

function getName(name: string | null) {
  return name || '';
}
const toRevise = () => {
  $router.push({
    path: 'LNSF_revise',
  });
};

const initData = async () => {
  const { data, code, msg } = await ApiConfig.infoConfigSchoolGet({enable:'1'});
  let allConfig = null
  if(data.length == 1){
    allConfig = data[0];
  }else{
    let schoolcode = getSchoolCode() as string
    let setName = schoolcode + "type" 
    let schoolUserType = sessionStorage.getItem(setName)
    for(let i in data){
      if(data[i].identityType == schoolUserType){
        allConfig = data[i];
      }
    }
  }
  console.log('initData',allConfig)
  for (let key in allConfig) {
    if (allConfig[key] != '1' && allConfig[key] != null) {
      configData.value.push({
        param: key,
        value: allConfig[key] == '2' || allConfig[key] == '3' ? '' : allConfig[key],
        required: allConfig[key] == '3' ? true : false,
        label: '',
        disabled: false,
      });
    }
  }
  //需要隐藏的字段
  configData.value.map((item, index, arr) => {
    if (
      item.param == 'mobile' ||
      item.param == 'diplomaImage' ||
      item.param == 'formerName' ||
      item.param == 'dateOfBirth'
    ) {
      arr.splice(index, 1);
    }
    if (
      item.param == 'name' ||
      item.param == 'gender' ||
      item.param == 'birthday' ||
      item.param == 'administrativeLevel'
    ) {
      item.disabled = true;
    }
  });
  let arrConfig = []
  for (let i in initList) {
    for (let j in configData.value) {
      if (configData.value[j].param == initList[i].enLabel) {
        configData.value[j].label = initList[i].cnName;
        configData.value[j].lnNO = initList[i].lnNO || 20;
        arrConfig.push(configData.value[j])
      }
    }
  }
  configData.value = []
  configData.value =  configData.value.concat(arrConfig)

  //根据配置项数组configData初始化表单项对象formData的值
  if(isLiaoShiDa()){
    for (let k = 0; k < configData.value.length; k++) {
      if (
        configData.value[k].param != 'academicType' &&
        configData.value[k].param != 'classesName' &&
        configData.value[k].param != 'collegeName' &&
        configData.value[k].param != 'education' &&
        configData.value[k].param != 'majorName' &&
        configData.value[k].param != 'schoolStartYear' &&
        configData.value[k].param != 'schoolingPeriod'
      ) {
        formData.value[configData.value[k].param] = configData.value[k].value;
      }
    }
  }
  // console.log('initData---configData',configData.value)
  // console.log('initData---initList',initList)  
  let cacheForm = JSON.parse(sessionStorage.getItem('regQueryData') as string);  
  if(!!cacheForm.educationInfoList && cacheForm.educationInfoList.length > 0){
    educationInfoList.value = cacheForm.educationInfoList.filter(
      (item: any) => Object.getOwnPropertyNames(item).length != 0
    );
  }else{
    educationInfoList.value = []
  }
  for (let key in cacheForm) {
    for (let sub in formData.value) {
      if (key == sub) {
        formData.value[sub] = cacheForm[key];
      }
    }
  }
  console.log('initData---cacheForm',cacheForm) 

  if(!isLiaoShiDa()){
    // formData.value['name'] = cacheForm['name'] || ''
    // formData.value['gender'] = cacheForm['gender'] || ""
    // formData.value['diplomaImage'] =  cacheForm['diplomaImage'] || ""
    // formData.value['birthday'] =  cacheForm['birthday'] || ""
    Object.assign(formData.value,cacheForm)
    console.log(formData.value)
  }

  //辽师配置项中已经组装入学历信息的项过滤掉
  if(isLiaoShiDa() || educationInfoList.value.length > 0){
    configData.value = configData.value.filter(
      (item) =>
        item.value == '' &&
        !!item.label &&
        item.param != 'academicType' &&
        item.param != 'classesName' &&
        item.param != 'collegeName' &&
        item.param != 'education' &&
        item.param != 'majorName' &&
        item.param != 'schoolStartYear' &&
        item.param != 'schoolingPeriod'
    );
  }else{
    configData.value = configData.value.filter(
      (item) =>
        item.value == '' &&
        !!item.label 
    ); 
  }
  configData.value.sort(function (a, b) {
    return a.lnNO - b.lnNO;
  });
  console.log('******configData******',configData.value);

  //将图片上传组件移到最后
  for (let i = 0; i < configData.value.length; i++) {
    if (
      configData.value[i].param == 'diplomaImage' ||
      configData.value[i].param == 'bareheadedPhoto' ||
      configData.value[i].param == 'userProfilePicture' ||
      configData.value[i].param == 'identificationDocumentImage'
    ) {
      let item = configData.value.splice(i, 1);
      configData.value[configData.value.length] = item[0];
    }
  }
  console.log(configData.value, 'configData.value');
};

const getYearData = () => {
  var nowTime = new Date(dateValue.value);
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  for (let i: number = 1900; i < 2035; i++) {
    timeList.value.push(i);
  }
};

const onOverSize = (file: File) => {
  return Toast('文件大小不能超过1MB！')
}
const initAppMenu = async () => {
  const { data, code, msg } = await Api.appAutMenu({});
  if (code == 200) {
    setMenus(JSON.stringify(data.menus));
    setButtons(JSON.stringify(data.buttons))
    let alList: any = [];
    const menuUrlList = useMenuStore();
    let menulist = [...(data.menus || [])]
    for (let i in menulist) {
      for (let u in DynamicRoutes) {
        if (menulist[i].url == DynamicRoutes[u].path) {
          alList.push({ ...DynamicRoutes[u] })
          break
        }
      }
    }
    menuUrlList.menu = menuUrlList.menu.concat(alList);
  } else {
    setMenus(JSON.stringify('[]'));
    setButtons(JSON.stringify('[]'))
  }

  await initMenu();
};
//查询地区列表
const initArea = async () => {
  const { data, code, msg } = await ApiDept.areaList(areaP.value);
  if (code == 200) {
    let list = data.list;
    areaList.value.push(list);
  }
};

const initColumns = (value:string) =>{
  let arr = []
  for(let i in datalist){
    if(datalist[i].type == value){
      // arr.push({label:datalist[i].text,value:datalist[i].value})
      let ramArr = datalist[i].list
      for(let a in ramArr){
        arr.push({label:ramArr[a].text,value:ramArr[a].value})
      }
    }
  }
  return arr
}

const columnShow =async (value:string) =>{
  console.log('columnShow---value',value)
  paramType.value = value
  if(value == 'collegeName'){
    await initCollege()
    // console.log('newColumns',newColumns.value)
    showPickerVan.value = true
  }else if(value == 'majorName'){
    if(!formData.value.collegeId && value == 'majorName'){
      Toast({ message: '请选择院系' });
    }else{
      await initMajorName()
      showPickerVan.value = true
    }
  }
  console.log('newColumns',newColumns.value)
  // showPickerVan.value = true
}
const sureEdu = (idx:string,type:string,name:string,id:string)=>{
  let num = 0
  if(idx == '一'){
    num = 0
  }else if(idx == '二'){
    num = 1
  }else if(idx == '三'){
    num = 2
  }
  console.log(idx)
  console.log(educationInfoList.value[num])
  // return
  if(type == 'collegeName'){
    educationInfoList.value[num].collegeName = name
    educationInfoList.value[num].collegeId = id
  }else{
    educationInfoList.value[num].majorName = name
    educationInfoList.value[num].major = id
  }
  educationCorrection.value = '1'
}

const sureYear = (idx:string,val:string)=>{
  let num = 0
  if(idx == '一'){
    num = 0
  }else if(idx == '二'){
    num = 1
  }else if(idx == '三'){
    num = 2
  }
  educationInfoList.value[num].schoolStartYear = val
  educationCorrection.value = '1'
}

const initCollege =async () =>{
    let schoolId = getSchoolId() as string;
      newColumns.value = []
      let arr = []
    const { data, msg, code } = await ApiDept.deptList({
      schoolId: schoolId,
    });
    for(let i in data){
      arr.push({ text: data[i].deptName,...data[i] })
    }
    newColumns.value =  newColumns.value.concat(arr)
    // showPickerVan.value = true
}

const initMajorName = async () =>{
    let schoolId = getSchoolId() as string;
    let arr = []
      newColumns.value = []
    const { data, msg, code } = await ApiDept.deptList({
      schoolId: schoolId,
      parentId: formData.value.collegeId,
    });
    for(let i in data){
      arr.push({ text: data[i].deptName,...data[i] })
    }    
     newColumns.value =  newColumns.value.concat(arr)
    // showPickerVan.value = true
}

const onConfirmPicker = (value:any)=>{
  //value.deptId value.text
  if(paramType.value == 'collegeName'){
    formData.value['collegeId'] = value.deptId;
    formData.value['collegeName'] = value.text;    
  }else if(paramType.value == 'majorName'){
    formData.value['major'] = value.deptId;
    formData.value['majorName'] = value.text;    
  }
  showPickerVan.value = false
}

//查询工作领域列表
const initIndustry = async () => {
  const { data, code, msg } = await ApiDept.industryList({ dictCode: 'work_field' });
  if (code == 200) {
    industryArr.value = data.map((item: any) => item.dictName);
  }
};
const onSubmit = async () => {
  loadingFlag.value = true;
  // pickOccupationToSubmit()//手动输入不需要在这个
  // formData.value.jobTitle = occupation.value.code//手动输入不需要在这个

  // console.log(occupation.value)
  // console.log('formData',formData.value);
  // console.log(formData);
  // return;
  if(isShenYangShiFan()){
    //educationInfoList.value[i].educationType
    for(let i in educationInfoList.value){
      if(educationInfoList.value[i].educationType == '1'){
        formData.value['collegeName'] = educationInfoList.value[i].collegeName
        formData.value['collegeId'] = educationInfoList.value[i].collegeId
        formData.value['majorName'] = educationInfoList.value[i].majorName
        formData.value['major'] = educationInfoList.value[i].major
        formData.value['schoolStartYear'] = educationInfoList.value[i].schoolStartYear
        formData.value['education'] = educationInfoList.value[i].education
      }else if(educationInfoList.value[i].educationType == '2'){
        formData.value['secondCollegeName'] = educationInfoList.value[i].collegeName
        formData.value['secondCollegeId'] = educationInfoList.value[i].collegeId
        formData.value['secondMajorName'] = educationInfoList.value[i].majorName
        formData.value['secondMajor'] = educationInfoList.value[i].major
        formData.value['secondSchoolStartYear'] = educationInfoList.value[i].schoolStartYear
        formData.value['secondEducation'] = educationInfoList.value[i].education
      }else if(educationInfoList.value[i].educationType == '3'){
        formData.value['thirdCollegeName'] = educationInfoList.value[i].collegeName
        formData.value['thirdCollegeId'] = educationInfoList.value[i].collegeId
        formData.value['thirdMajorName'] = educationInfoList.value[i].majorName
        formData.value['thirdMajor'] = educationInfoList.value[i].major
        formData.value['thirdSchoolStartYear'] = educationInfoList.value[i].schoolStartYear
        formData.value['thirdEducation'] = educationInfoList.value[i].education
      }
    }
  }
  if(isChengDeYiXueYuan()){
    formData.value.schoolmateType = $route.query?.schoolmateType || ''
  }
  formData.value['educationCorrection'] = educationCorrection.value
  // console.log('educationInfoList.value',educationInfoList.value)
  // return
  const { code, data, msg } = await Api.completeSchoolmateInformation({
    ...formData.value,
    ...fileHandle.compare(formData.value),
    ...diplomaImageFile.compare(formData.value),
    ...userProfilePictureFile.compare(formData.value),
    ...identificationDocumentImageFile.compare(formData.value),
  });
  if (code == 200) {
    loadingFlag.value = false;
    if (!!data) {
      await initAppMenu(); //请求菜单
      $router.replace({
        //审核通过
        path: '/index',
      });
      setUserStatus(data.userStatus);
    } else {
      //待审核
      Toast.success({ message: msg });
      // router.push({ path: '/login' });
      // router.back();
      $router.replace({
        path: '/submited',
      });
      // Toast({ message: '请等待审核' });
    }
  } else {
    loadingFlag.value = false;
    Toast.fail({ message: msg });
  }
};

onBeforeMount(async () => {
  
  if(isShenYangShiFan() || isLiaoShiDa() || isChengDuYiXueYuan()){
    inPJobTitleFlag.value = true
  }

  await initData();
  await initArea();
  await initIndustry();
  getYearData()
  // 是否是从职务选择页返回的
  if (!userStore.isNeedInitOccupation) {
       Object.assign(formData.value, getDataFromCache());
  }else{
    initOccupation()
  }  
});
</script>
<style lang="less" scoped>
.wrap {
  background: #cccccc6e;
  min-height: 100vh;
  padding: 33px 20px;

  .title {
    padding-left: 20px;
    margin: 0 0 33px;
    font-family: PingFangSC-Medium;
    font-size: 32px;
    color: #333333;
    letter-spacing: 0;
    line-height: 32px;
    font-weight: 500;
    border-left: 5px solid var(--theme-color);
  }

  .revise-btn {
    line-height: 88px;
    width: 100%;
    border-radius: 44px;
    border: 2px solid var(--theme-color);
    color: var(--theme-color);
    background: #b42d3b17;
    font-size: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 40px 0 60px;
  }

  :deep(.van-cell-group) {
    border-radius: 16px;
    overflow: hidden;
  }

  .submit-btn {
    margin: 50px 0;
  }

  :deep(.van-field__label) {
    width: auto;
    max-width: 7.2em;
  }
}
</style>