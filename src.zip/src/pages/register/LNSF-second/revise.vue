<template>
  <!-- <van-sticky>
    <van-nav-bar title="" left-arrow @click-left="onClickLeft" />
  </van-sticky> -->
  <main class="wrap">
    <div class="title"> 问题描述 </div>
    <van-field v-model="description" rows="8" autosize label="" type="textarea" maxlength="300"
      placeholder="请输入学历信息错误之处（字数不超过300字）" show-word-limit class="poosa" />
    <div class="title"> 上传证明材料 </div>
    <van-field v-model="proofFile" readonly name="diplomaImage" input-align="left" error-message-align="left">
      <template #input>
        <div class="upload-tit">证明材料
          <span class="red">（请上传本人毕业证书或学位证书等可以证明本人 学历信息的材料）</span>
        </div>
        <compress-uploader v-model="healthFileList" max-count="1" :after-read="afterRead" accept=".png,.jpg,.jpeg,.pdf" />
        <span class="tips">注意：上传证明材料仅支持jpg、pdf格式，大小不超过2M。</span>
      </template>
    </van-field>
    <div class="submit-btn" @click="onSubmit">
      <van-button color="var(--theme-color)" block round>提 交</van-button>
    </div>
  </main>
</template>
<script lang="ts" setup>
import ApiUpload from '@/api/uploadfile';
import { Dialog, Toast } from 'vant';
import Api from '@/api/user/index';

const $router = useRouter();
const onClickLeft = () => $router.back();
const healthFileList = ref([]);
const description = ref('');
const proofFile = ref('');
let cacheForm = JSON.parse(sessionStorage.getItem('regQueryData') as string);
const lnsdSchoolmateId = ref(cacheForm.lnsdSchoolmateId);
const afterRead = async (file: any) => {
  let formData1 = new FormData();
  formData1.append('file', file.file);
  // formData.append('flag', 'Y');//加密上传
  file.status = 'uploading';
  file.message = '上传中...';
  await ApiUpload.uploadFile(formData1)
    .then((res) => {
      if (res.code == 200) {
        file.status = '';
        file.message = '';
        proofFile.value = res.data.uploadUrl;
        Toast.success('上传成功');
      } else {
        file.status = 'failed';
        file.message = '上传失败';
        Toast.fail(res.msg);
      }
    })
    .catch((err) => {
      file.status = 'failed';
      file.message = '上传失败';
      Toast.fail(`上传失败：${err}`);
    });
};
const onSubmit = async () => {
  if (description.value == undefined || description.value == '' || description.value == null) {
    Toast('请输入问题描述！');
    return;
  }
  if (proofFile.value == undefined || proofFile.value == '' || proofFile.value == null) {
    Toast('请上传证明材料！');
    return;
  }
  const { msg, data, code } = await Api.applyEduCorrection({
    description: description.value,
    proofFile: proofFile.value,
    lnsdSchoolmateId: lnsdSchoolmateId.value,
  });
  if (code == 200) {
    Toast.success('您的申请已提交！');
    $router.back();
  } else {
    Toast.fail(msg);
  }
};
</script>
<style lang="less" scoped>
.wrap {
  background: #f5f5f5;
  padding: 34px 30px;
  min-height: 100vh;

  .title {
    padding-left: 20px;
    margin: 0 0 33px;
    font-family: PingFangSC-Medium;
    font-size: 32px;
    color: #333333;
    letter-spacing: 0;
    line-height: 32px;
    font-weight: 500;
    border-left: 5px solid var(--theme-color);
  }

  .poosa {
    border-radius: 16px;
    margin-bottom: 40px;
  }

  .submit-btn {
    margin: 50px 0;
  }
}

:deep(.van-cell) {
  border-radius: 16px;
}

:deep(.van-field__control--custom) {
  display: flex;
  flex-direction: column;
  align-items: normal;
  min-height: var(--van-cell-line-height);

  .upload-tit {
    font-size: 24px;
    line-height: 40px;

    .red {
      color: #ff0000;
    }
  }

  .tips {
    font-size: 24px;
    color: #999999;
    line-height: 40px;
  }

  .van-uploader {
    margin: 24px 0;
  }
}
</style>