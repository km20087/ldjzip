<template>
  <div class="third-cont">
    <h5>请上传毕业证/学位证</h5>
    <p>务必上传相关信息证明，我们会保护信息安全</p>
    <div class="uploader-cont">
      <van-uploader :after-read="afterRead" />
    </div>

    <van-button round block type="primary"> 提交审核 </van-button>
  </div>
</template>
<script lang="ts" setup>
const afterRead = (file: any) => {
  // 此时可以自行将文件上传至服务器
  console.log(file);
};
</script>
<style lang="less" scoped>
.third-cont {
  padding: 30px;
  h5 {
    font-size: 36px;
    margin-top: 30px;
    margin-bottom: 0;
    line-height: 50px;
  }
  p {
    margin: 0;
    line-height: 70px;
  }
  .uploader-cont {
    margin: 20px 0 40px;
  }
}
</style>