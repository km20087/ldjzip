<template>
  <van-sticky>
    <van-nav-bar title="初步填写信息" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <div class="con">
    <div class="form">
      <van-form
        input-align="right"
        @submit="onSubmit"
        error-message-align="right"
      >
        <van-field
            label="姓名"
            v-model="formData.name"
            name="validator"
            required
            :rules="[{ required: true, message: '请输入姓名' }]"
            placeholder="请输入姓名"
          />
          <van-field
            v-model="cardName"
            is-link
            readonly
            required
            name="area"
            label="证件类型"
            placeholder="点击选择证件类型"
            @click="showArea = true"
          />
          <van-popup v-model:show="showArea" position="bottom">
            <van-picker :columns="CardList" @confirm="onConfirm" @cancel="showArea = false" />
          </van-popup>
         <van-field
            label="证件号"
            v-model="formData.cardNumber"
            name="validator"
            required
            :rules="[{ required: true, message: '请输入证件号' }]"
            placeholder="请输入证件号"
          />          
          <van-field
            label="手机号"
            v-model="formData.mobile"
            name="validator"
            placeholder="请输入手机号"
            :rules="[{ required: true, message: '请输入手机号' }]"
          />
          <van-field
            v-model="areaName"
            is-link
            readonly
            required
            name="area"
            label="省市"
            placeholder="点击选择省市"
            @click="showFlag = true"
            :rules="cardRules"
          />
          <van-popup v-model:show="showFlag" position="bottom">
            <van-cascader
              v-model="cascaderValue"
              title="请选择所在地区"
              :options="options"
              :field-names="fieldName"
              @close="showFlag = false"
              @change="onChange"
              @finish="onFinish"
            />
          </van-popup>                             
          <van-field
            label="工作单位"
            required
            v-model="formData.employer"
            name="validator"
            :rules="[{ required: true, message: '请输入工作单位' }]"
            placeholder="请输入工作单位"
          />
          <van-field
            label="职务"
            v-model="occupation.occupationName"
            name="validator"
            placeholder="请选择职务"
            readonly
            @click="goOccupationPage"
          />
        <van-field
            label="邮箱"
            v-model="formData.emailAddress"
            name="validator"
            required
            :rules="[{ required: true, message: '请输入邮箱' }]"
            placeholder="请输入邮箱"
          />
        <div class="butt1">
          <van-button :disabled="loadingFlag" round block type="primary" native-type="submit"> 提交 </van-button>
        </div>
        <van-loading type="spinner" class='loadingioi' v-if='loadingFlag' color="#0094ff" size='28px'></van-loading>          
      </van-form>                                
    </div>
    </div>
</template>
<script lang="ts" setup>
import { ref, reactive } from "vue";
import { Toast } from "vant";
import { useRouter, useRoute } from "vue-router";
import { CardList } from "@/constants";
import ApiDept from "@/api/common";
import { useOccupation } from "@/hooks/useOccupation";
import { useUserStore } from "@/store";
// import datalist from "../second/datalist";
import datalist from "@/utils/dataList/datalist";
import ApiMy from "@/api/my";
import Api from "@/api/user";
const areaP = reactive({
  parentNo: "",
  addrLevel: "1",
  addrName: "",
  pageSize: 100,
  pageNum: 1
});
const router = useRouter();
const loadingFlag = ref(false);
const userStore = useUserStore();
const showArea = ref(false);
const showFlag = ref(false);
const cardName = ref("");
// const areaName = ref('')
const listParam = <any>ref({});
const cascaderValue = ref("");
const options = <any>reactive([]);
const formData = <any>reactive({});
const provinceName = ref("");
const cityName = ref("");
const areaName1 = ref("");
const fieldName = reactive({
  text: "addrName",
  value: "addrNo",
  children: "children"
});
const onClickLeft = () => {
  router.push({
    //审核通过
    path: "/index"
  });
};
function getName(name: string | null) {
  return name || "";
}
const areaName = computed(() => {
  return (
    // getName(provinceName.value) + getName(cityName.value) + getName(areaName1.value) + ''
    getName(formData.provinceName) +
    getName(formData.cityName) +
    getName(formData.areaName) +
    ""
  );
});
const cardRules: any = [
  { required: true, message: "请选择省市" },
  {
    validator: (value?: any) => {
      console.log(value);
      if (!value) {
        return false;
      }
    },
    message: "请选择省市",
    trigger: ["onChange", "onBlur"]
  }
];
const {
  occupation,
  initOccupation,
  goOccupationPage,
  pickOccupationToSubmit,
  getDataFromCache,
  getDataListCache
} = useOccupation(formData, listParam.value);
const onConfirm = (value: any) => {
  console.log(listParam.value);
  cardName.value = value.text;
  listParam.value.cardType = cardName.value;
  formData.cardType = value.cardId;
  showArea.value = false;
};
const onChange = async ({ value, selectedOptions, tabIndex }: any) => {
  console.log(value);
  let le = selectedOptions.length - 1;
  let ao = selectedOptions[le];
  if (ao.hasChild == "1") {
    areaP.parentNo = String(value);
    areaP.addrLevel = String(Number(ao.addrLevel) + 1);
    const { data, code, msg } = await ApiDept.areaList(areaP);
    addTree(selectedOptions, data.list, value);
  } else {
    showFlag.value = false;
  }
};
const addTree = (selectedOptions: any, children: any, id: any) => {
  selectedOptions.forEach((item: any) => {
    if (item.addrNo === id) {
      item.children = children;
    }
  });
};
const initArea = async () => {
  const { data, code, msg } = await ApiDept.areaList(areaP);
  if (code == 200) {
    let list = data.list;
    if (areaP.addrLevel == "1") {
      options.push(...data.list);
      // console.log(arrayToTree(options));
    }
  }
};
const onFinish = ({ value, selectedOptions, tabIndex }: any) => {
  console.log(value);
  console.log(selectedOptions);
  let a = selectedOptions.length - 1;
  if (selectedOptions[a].addrLevel == "1") {
    // provinceName.value = selectedOptions[a].addrName;
    formData.provinceName = selectedOptions[a].addrName;
    formData.provinceId = selectedOptions[a].addrNo;
  } else if (selectedOptions[a].addrLevel == "2") {
    // cityName.value = selectedOptions[a].addrName;
    formData.cityName = selectedOptions[a].addrName;
    formData.cityId = selectedOptions[a].addrNo;
  } else if (selectedOptions[a].addrLevel == "3") {
    // areaName1.value = selectedOptions[a].addrName;
    formData.areaName = selectedOptions[a].addrName;
    formData.areaId = selectedOptions[a].addrNo;
  }
};
const onSubmit = async () => {
  loadingFlag.value = true;
  goOccupationPage("1");
  // return;
  pickOccupationToSubmit();
  console.log(formData);
  const { code, data, msg } = await Api.inputBasicInformation({
    ...formData
  });
  console.log(data);
  if (code == 200 || code == 202) {
    loadingFlag.value = false;
    router.replace({
      //审核通过
      path: "/register/second"
    });
  } else {
    loadingFlag.value = false;
    Toast({ message: msg });
  }

  // if (code == 202) {
  //   router.replace({
  //     //审核通过
  //     path: "/register/second"
  //   });
  // } else if (code == 200) {
  //   router.replace({
  //     //审核通过
  //     path: "/index"
  //   });
  // }
};
const initFormData = (name: string, value: string) => {
  // console.log(name);
  for (let i in datalist) {
    // console.log(datalist[i].type == name);
    if (datalist[i].type == name) {
      let param = datalist[i].list;
      for (let a in param) {
        if (param[a].value == value) {
          listParam.value[name] = param[a].text;
        }
      }
    }
  }
};
const initPer = async () => {
  const { data, code, msg } = await ApiMy.getDetailedInformation({});
  Object.assign(formData, data);
  for (let i in formData) {
    if (!!formData[i]) {
      initFormData(String(i), formData[i]);
      console.log(i);
      console.log(formData[i]);
    }
  }
  // 初始化职务信息
  initOccupation();
};
function handleDataAfterGetPerInfo() {
  for (let i in CardList) {
    if (CardList[i].cardId == formData.cardType) {
      cardName.value = CardList[i].text;
    }
  }
}
onMounted(() => {
  sessionStorage.removeItem("data1");
  initArea();
  formData.mobile = sessionStorage.getItem("mobile");
  if (userStore.isNeedInitOccupation) {
    handleDataAfterGetPerInfo();
  } else {
    Object.assign(formData, getDataFromCache());
    Object.assign(listParam.value, getDataListCache());
    handleDataAfterGetPerInfo();
  }
});
</script>
<style lang='less' scoped>
.loadingioi {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.con {
  width: 100%;
  height: 100%;
  position: relative;
  overflow-y: scroll;
  .form {
    width: 100%;
    height: 100%;
    // padding-bottom: 30px;
  }
}
.butt1 {
  // position: fixed;
  // bottom: 5px;
  // left: 50%;
  // transform: translate(-50%, -50%);
  margin: 0px 30px;
  height: 200px;
  text-align: center;

  /deep/ .van-butto {
    margin: 0 auto;
  }
  /deep/.van-button__content {
    // width: 300px;
  }
  // margin-top: 10px;
  // margin: 10px 20px;
}
.up {
  margin: 15px 15px;
  // display: flex;
  // align-items: center;
  &-label {
    // font-size: 24px;
    color: #646566;
    padding: 0 15px;
  }
  &-border {
    margin: 0 15px;
    border-bottom: 1px solid #e7e7e7;
  }
  up-label::before {
    margin-right: 0.05333rem;
    color: red;
    content: "*";
  }
}

.upload {
  margin: 15px 15px 0;
  padding-bottom: 15px;
  border-bottom: 1px solid #e7e7e7;
  text-align: center;
  &-btn {
    width: 100px;
    height: 100px;
    background-color: #e7e7e7;
    border-radius: 5px;
  }
  &-tips {
    width: 95%;
    margin-top: 10px;
    color: #fe2f2f;
    font-size: 12px;
  }
  &-up {
    text-align: center;
    margin-top: 5px;
    .van-button--normal {
      font-size: 12px;
      height: 20px;
    }
  }
}
</style>
