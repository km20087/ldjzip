import { SchoolCode } from '@/constants';  

/**
 * registerTypeMole---是走非自动认证的，需要用户填写信息
 * **/
export const registerTypeMole:string[] = [
    SchoolCode.ShanDa,
    SchoolCode.GuangWenYi,
    SchoolCode.HeBeiShiFan,
    SchoolCode.WuLuMuQiZhiYeDaXue,
    SchoolCode.ChengDuYiXueYuan,
    SchoolCode.BaoTouZhiYeJiShu,
    SchoolCode.BeiHuaHangTianGongYe,
    SchoolCode.LiaoShiFuShuZhongXue,
    SchoolCode.XiangXianZhongXue,
    SchoolCode.ShenYangYaoKeDaXue,
    // SchoolCode.ChengDeYiXueYuan,
    SchoolCode.ShiJiaZhuangYiZhong,
    SchoolCode.GuangDongShuiLiXueYuan,//广东水利学院

    // '4144010560',//汕大
    // '4144013707',//广东XX学校
    // '4113010094',//河北
    // '4165011565',//乌鲁木齐
    // '4151013705',//成都医学院
    // '4115012057',//包头职业
    // '4113011629',//北华航天技术,
    // '4121000165',//辽师师范附属中学
    // // '4401130303',//广州培英中学
    // '4401130302',//象贤中学
    // "4121010163",//沈阳药科
    // '4113010093',//承德医学院
    // '4113010601',//石家庄第一中
    // '4144010862',//广东水利学院
] 

export const registerLNMole = [
    SchoolCode.LiaoShiDa,
    SchoolCode.PeiYingZhongXue,
    SchoolCode.HeBeiZhongYiYao,
    SchoolCode.ShenYangShiFan,
    // '4121010165',//辽宁
    // '4401130303',//广州培英中学
    // '4113014432',//河北中医药
    // '4121010166',//沈阳
] 

// export const registerNormalMole = [
//     '4121010166'//沈阳
// ] 


// const registerLNMolePath = [
//     '/register/register_middle_first',
//     '/register/register_middle_second',
// ]

// const registerOldMolePath = [
//     '/register/type',
//     '/register/second',
// ]

// const registerNormalMolePath = [
//     '/register/register_middle_first',
//     '/register/register_middle_second',
// ]

// /**根据schoolcode来判断使用哪种登录模式**/
// export const useRegisterMOle = (SchoolCode:string) =>{
//     if(registerTypeMole.includes(SchoolCode)){
//         return '/register/type'
//     }else if(registerLNMole.includes(SchoolCode)){
//         return 'registerLNMole'
//     }else if(registerNormalMole.includes(SchoolCode)){
//         return 'registerNormalMole'
//     }

// }