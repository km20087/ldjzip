<template>
    <div class="uploadPop">
        <van-field v-model="formData['diplomaImage']" readonly name="diplomaImage" input-align="left"
            error-message-align="left">
            <template #input>
                <div class="upload-tit">证明材料
                    <span class="red">（请上传本人毕业证书或学位证书等可以证明本人 学历信息的材料）</span>
                </div>
                <compress-uploader v-model="healthFileList" max-count="1" :max-size="2 * 1024 * 1024"
                    :after-read="afterRead" accept=".png,.jpg,.jpeg,.pdf" />
                <span class="tips">注意：上传证明材料仅支持jpg、pdf格式，大小不超过2M。</span>
            </template>
        </van-field>
        <van-button color="var(--theme-color)" round block @click="twiceMit">提 交</van-button>
    </div>
</template>
<script setup lang="ts">
import { fommatDate } from '@/utils/fommatDate';
import ApiUpload from '@/api/uploadfile';
import { Dialog, Toast } from 'vant';
import Api from '@/api/user/index';
import FileHandle from '@/utils/file-handle';
import { useOccupation } from '@/hooks/useOccupation';
import { getUserInfo } from '@/utils';
import {  isLiaoShiDa } from '@/utils/customizedType';
let diplomaImageFile = new FileHandle(['diplomaImage']);
const formData = ref({
    name: '',
    gender: '',
    genderTxt: '',
    birthday: '',
    formerName: '',
    diplomaImage: '',
});
const $router = useRouter();
let { getDataFromCache } = useOccupation(formData.value);
const healthFileList = <any>ref([]);

const afterRead = async (file: any) => {
    let formData1 = new FormData();
    formData1.append('file', file.file);
    // formData.append('flag', 'Y');//加密上传
    file.status = 'uploading';
    file.message = '上传中...';
    await ApiUpload.uploadFile(formData1)
        .then((res) => {
            if (res.code == 200) {
                file.status = '';
                file.message = '';
                formData.value['diplomaImage'] = res.data.uploadUrl;
                Toast.success('上传成功');
            } else {
                file.status = 'failed';
                file.message = '上传失败';
                Toast.fail(res.msg);
            }
        })
        .catch((err) => {
            file.status = 'failed';
            file.message = '上传失败';
            Toast.fail(`上传失败：${err}`);
        });
};
const twiceMit = async () => {
    let reqData:any = { ...formData.value, ...diplomaImageFile.compare(formData) };
    if(isLiaoShiDa()){
        reqData['type'] = 'audit'
    }
    const { code, data, msg } = await Api.inputBasicInformation(reqData);
    if (code == 200) {
        Toast.success('已提交人工审核，请耐心等待结果...');
        $router.replace({ name: 'first' });
    } else if (code == 202) {
        let data2 = getDataFromCache();
        sessionStorage.setItem('regQueryData', JSON.stringify(data2));
        $router.push({ name: 'LNSF_second' });
    } else {
        Toast(msg);
    }
};
onBeforeMount(() => {
    let userInfo = JSON.parse(getUserInfo() as string)
    formData.value.name = userInfo.name
    formData.value.formerName = userInfo.formerName
    formData.value.gender = userInfo.gender
    formData.value.birthday = userInfo.birthday

})
</script>
<style scoped lang="less">
.uploadPop {
    padding: 30px;
}

:deep(.van-cell) {
    padding: var(--van-cell-vertical-padding) 0;
}

:deep(.van-field__control--custom) {
    display: flex;
    flex-direction: column;
    align-items: normal;
    min-height: var(--van-cell-line-height);

    .upload-tit {
        font-size: 24px;
        line-height: 40px;

        .red {
            color: #ff0000;
        }
    }

    .tips {
        font-size: 24px;
        color: #999999;
    }

    .van-uploader {
        margin: 24px 0;
    }
}
</style>