<template>
  <!-- <van-sticky>
    <van-nav-bar title="" left-arrow @click-left="onClickLeft" />
  </van-sticky> -->
  <main class="wrap">
    <div class="title"> 基础信息 </div>
    <van-form v-if="schoolCode !==SchoolCode.ChengDeYiXueYuan" @failed="onFailed" input-align="right" @submit="onSubmit" error-message-align="right">
      <van-field label="姓名" v-model="formData['name']" name="name" placeholder="请输入真实姓名" required
        :rules="[{ required: true, message: `请输入真实姓名` }]" />
      <!-- <van-field label="曾用名" v-model="formData['formerName']" name="formerName" placeholder="请输入曾用名" /> -->
      <van-field label="性别" v-model="formData['genderTxt']" name="gender" placeholder="请选择" required
        :rules="[{ required: true, message: `请选择性别` }]" is-link readonly @click="showGender" />
      <van-field label="出生日期" v-model="formData['birthday']" name="birthday" placeholder="请选择" required
        :rules="[{ required: true, message: `请选择出生日期` }]" is-link readonly @click="showDayPicker" />
      <van-popup v-model:show="uploadShow" position="bottom" round>
        <div class="uploadPop">
          <van-field v-model="formData['diplomaImage']" readonly name="diplomaImage" input-align="left"
            error-message-align="left">
            <template #input>
              <div class="upload-tit">证明材料
                <span class="red">（请上传本人学历（学位）证书<span v-if="isLiaoShiDa()">或辽师大档案馆开具的学历（学位）证明</span>，复印件无效）</span>
              </div>
              <compress-uploader v-model="healthFileList" max-count="1" :max-size="2 * 1024 * 1024"
                :after-read="afterRead" accept=".png,.jpg,.jpeg,.pdf"/>
              <span class="tips">注意：上传证明材料仅支持jpg、pdf格式，大小不超过2M。</span>
            </template>
          </van-field>
          <van-button color="var(--theme-color)" round block @click="twiceMit">提 交</van-button>
        </div>
      </van-popup>
      <van-popup v-model:show="showPicker" position="bottom">
        <van-picker :columns="columns" :columns-field-names="columnsNames" @confirm="onConfirmPicker"
          @cancel="showPicker = false" />
      </van-popup>
      <van-popup v-model:show="showBirthday" position="bottom">
        <van-datetime-picker v-model="britadayShow" type="date" title="选择出生日期" :min-date="minDate"
          @confirm="onConfirmBirthdayPicker" @cancel="showBirthday = false" />
      </van-popup>
      <van-button color="var(--theme-color)" round block native-type="submit">提 交1</van-button>
    </van-form>
    <van-form v-else @failed="onFailed" input-align="right" @submit="onSubmit" error-message-align="right">
      <van-field label="姓名" v-model="formData['name']" name="name" placeholder="请输入真实姓名" required
        :rules="[{ required: true, message: `请输入真实姓名` }]" />
      <!-- <van-field label="曾用名" v-model="formData['formerName']" name="formerName" placeholder="请输入曾用名" /> -->
      <van-field label="性别" v-model="formData['genderTxt']" name="gender" placeholder="请选择" required
        :rules="[{ required: true, message: `请选择性别` }]" is-link readonly @click="showGender" />

      <van-field label="出生日期" v-if="formData.schoolmateType !=='2'" v-model="formData['birthday']" name="birthday" placeholder="请选择" required
        :rules="[{ required: true, message: `请选择出生日期` }]" is-link readonly @click="showDayPicker" />
      <van-field label="入学年份" v-if="formData.schoolmateType !=='2'" v-model="formData['schoolStartYear']" name="schoolStartYear" placeholder="请选择" required
        :rules="[{ required: true, message: `请选择入学年份` }]" is-link readonly @click="showTime('schoolStartYear')" />

      <van-field label="入职时间" v-else v-model="formData['jobDuration']" name="jobDuration" placeholder="请选择" required
        :rules="[{ required: true, message: `请选择入职时间` }]" is-link readonly @click="showTime('jobDuration')" />        
      <van-popup v-model:show="showPicker" position="bottom">        
        <van-picker :columns="columns" :columns-field-names="columnsNames" @confirm="onConfirmPicker"
          @cancel="showPicker = false" />
      </van-popup>
          <van-popup v-model:show="startTimeFlag" position="bottom">
            <van-picker :columns="timeList" title="请选择年份" show-toolbar :default-index="select" @confirm="yearConfirmStart"
              @cancel="startTimeFlag = false" />
          </van-popup>      
      <van-popup v-model:show="showBirthday" position="bottom">
        <van-datetime-picker v-model="britadayShow" type="date" title="选择出生日期" :min-date="minDate"
          @confirm="onConfirmBirthdayPicker" @cancel="showBirthday = false" />
      </van-popup>
      <van-button color="var(--theme-color)" round block native-type="submit">提 交</van-button>
    </van-form>    
  </main>
</template>
<script lang="ts" setup>
import { fommatDate } from '@/utils/fommatDate';
import ApiUpload from '@/api/uploadfile';
import { Dialog, Toast } from 'vant';
import { formatDate, formatDateTime } from '@/utils/tool/time';
import Api from '@/api/user/index';
import FileHandle from '@/utils/file-handle';
import { useOccupation } from '@/hooks/useOccupation';
import { isChengDuYiXueYuan, isLiaoShiDa,isShenYangShiFan } from '@/utils/customizedType';
import { SchoolCode } from '@/constants';
import { getSchoolCode} from '@/utils'
let diplomaImageFile = new FileHandle(['diplomaImage']);
const $router = useRouter();
const $route = useRoute();
const schoolCode = getSchoolCode()
const onClickLeft = () => $router.replace({ name: 'first' });
const formData = ref({
  name: '',
  gender: '',
  genderTxt: '',
  birthday: '',
  schoolStartYear:"",
  jobDuration:"",
  formerName: '',
  diplomaImage: '',
  schoolmateType:'',
});
let { getDataFromCache } = useOccupation(formData.value);
const minDate = ref(new Date(1920, 0, 1));
const britadayShow = ref(new Date());
const uploadShow = ref(false);
const showPicker = ref(false);
const showBirthday = ref(false);
const startTimeFlag = ref(false)
const timeList = <any>reactive([]);
const select = ref('');
const dateValue = ref('');
const columns = ref([
  { label: '男', value: '1' },
  { label: '女', value: '0' },
]);
const timeType = ref('')
const columnsNames = ref({ text: 'label', value: 'value' });
const healthFileList = <any>ref([]);

const showGender = () => {
  showPicker.value = true;
};
const onConfirmPicker = (val: any, idx: any) => {
  formData.value.genderTxt = val.label;
  formData.value.gender = val.value;
  showPicker.value = false;
};
const showDayPicker = () => {
  showBirthday.value = true;
};
const onConfirmBirthdayPicker = (val: any) => {
  formData.value.birthday = fommatDate(val, 'yyyy-MM-dd');
  showBirthday.value = false;
};

//获取默认最新时间
const getCurrentYear = () => {
  var nowTime = new Date();
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  let dateValue1 = '';
  dateValue1 = formatDate(new Date(year, month, day));
  dateValue.value = String(dateValue1.slice(0, 4));
  // this.signs(this.dateValue)
};

const getYearData = () => {
  var nowTime = new Date(dateValue.value);
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  for (let i: number = 1900; i < 2035; i++) {
    timeList.push(i);
  }

  let years = formatDate(new Date(year, month, day));
  let Year = years.slice(0, 4);

  select.value = timeList.indexOf(Number(Year));
  console.log(select.value);
};

const showTime = (val:string)=>{
  timeType.value = val
  startTimeFlag.value = true
}

const yearConfirmStart = (val: string) =>{
  if(timeType.value == 'schoolStartYear'){
    formData.value.schoolStartYear = val
    startTimeFlag.value = false
  }else if(timeType.value == 'jobDuration'){
    formData.value.jobDuration = val
    startTimeFlag.value = false
  }else{

  }
}

const afterRead = async (file: any) => {
  let formData1 = new FormData();
  formData1.append('file', file.file);
  // formData.append('flag', 'Y');//加密上传
  file.status = 'uploading';
  file.message = '上传中...';
  await ApiUpload.uploadFile(formData1)
    .then((res) => {
      if (res.code == 200) {
        file.status = '';
        file.message = '';
        formData.value['diplomaImage'] = res.data.uploadUrl;
        Toast.success('上传成功');
      } else {
        file.status = 'failed';
        file.message = '上传失败';
        Toast.fail(res.msg);
      }
    })
    .catch((err) => {
      file.status = 'failed';
      file.message = '上传失败';
      Toast.fail(`上传失败：${err}`);
    });
};
const onFailed = (errorInfo: any) => {
  console.log('failed', errorInfo);
};
const onSubmit = async () => {

  let reqData = { ...formData.value, ...diplomaImageFile.compare(formData) };
  const { code, data, msg } = await Api.inputBasicInformation(reqData);
  console.log('code',code)
  if (code == 200) {// && !isShenYangShiFan()
    if(!isLiaoShiDa() && !isShenYangShiFan()){//非辽宁的学校和沈阳的学校，直接到注册信息填写页 
      // $router.push({ name: 'second' });
      Dialog.confirm({
        title: '提 示',
        message: '信息不匹配，请完善证明材料！',
      }).then(() => {
        // let data2 = getDataFromCache();
        // console.log('formData.value',formData.value)
        // return
         let schoolmateType = $route.query?.schoolmateType || ''
        sessionStorage.setItem('regQueryData', JSON.stringify(formData.value));         
        $router.push({ name: 'second',query:{schoolmateType:schoolmateType} });//
        // $router.push({ name: 'LNSF_second' });//
      });       
    }
    // else if(isShenYangShiFan()){
    //   let data2 = getDataFromCache();
    //   sessionStorage.setItem('regQueryData', JSON.stringify(data2));    
    //   $router.push({ name: 'LNSF_second' });//
    // }
    else{//辽宁注册，需要上传学历相关图片
      Dialog.confirm({
        title: '提 示',
        message: '信息不匹配，请上传证明材料！',
      }).then(() => {
        uploadShow.value = true;
      });      
    }    

  } else if (code == 202) {
    let schoolmateType = $route.query?.schoolmateType || ''
    if(schoolCode == SchoolCode.ChengDeYiXueYuan && schoolmateType !== '0'){
        sessionStorage.setItem('regQueryData', JSON.stringify(formData.value));         
        $router.push({ name: 'second',query:{schoolmateType:schoolmateType} });//
        return
    }
    let data2 = getDataFromCache();
    sessionStorage.setItem('regQueryData', JSON.stringify(data2));    
    if(schoolCode == SchoolCode.ChengDeYiXueYuan){
      $router.push({ name: 'LNSF_second',query:{schoolmateType:schoolmateType} })
    }else{
      $router.push({ name: 'LNSF_second' });//
    }
    
  } else {
    Toast(msg);
  }
};
const twiceMit = async () => {
  // return
  if(healthFileList.value.length == 0){
    Toast('请上传证明材料')
    return
  }
  let reqData:any = { ...formData.value, ...diplomaImageFile.compare(formData) };
    if(isLiaoShiDa()){
        reqData['type'] = 'audit'
    }  
  const { code, data, msg } = await Api.inputBasicInformation(reqData);
  if(isLiaoShiDa()){
    if (code == 200) {
      Toast.success('已提交人工审核，请耐心等待结果...');
      $router.replace({ name: 'first' });
    } else if (code == 202) {
      let data2 = getDataFromCache();
      sessionStorage.setItem('regQueryData', JSON.stringify(data2));
      $router.push({ name: 'LNSF_second' });
    } else {
      Toast(msg);
    }    
  }else{
    if(code == 200 || code == 202){
      let data2 = getDataFromCache();
      console.log('data',data2)
      // return
      sessionStorage.setItem('regQueryData', JSON.stringify(reqData));
      $router.push({ name: 'LNSF_second' });
    }
  }
};
onMounted(()=>{
  console.log('$route.query?.schoolmateType',$route.query?.schoolmateType)
  console.log('schoolCode == SchoolCode.ChengDeYiXueYuan',schoolCode == SchoolCode.ChengDeYiXueYuan)
  let schoolmateType = $route.query?.schoolmateType || ''
  formData.value.schoolmateType = schoolmateType as string
  if(schoolCode == SchoolCode.ChengDeYiXueYuan){
    getCurrentYear();
    getYearData();
  }
})
</script>
<style lang="less" scoped>
.wrap {
  padding: 0 32px;

  .title {
    padding-left: 20px;
    margin: 39px 0;
    font-family: PingFangSC-Medium;
    font-size: 32px;
    color: #333333;
    letter-spacing: 0;
    line-height: 32px;
    font-weight: 500;
    border-left: 5px solid var(--theme-color);
  }
}

:deep(.van-cell) {
  padding: var(--van-cell-vertical-padding) 0;
}

:deep(.van-field__control--custom) {
  display: flex;
  flex-direction: column;
  align-items: normal;
  min-height: var(--van-cell-line-height);

  .upload-tit {
    font-size: 24px;
    line-height: 40px;

    .red {
      color: #ff0000;
    }
  }

  .tips {
    font-size: 24px;
    color: #999999;
  }

  .van-uploader {
    margin: 24px 0;
  }
}

.uploadPop {
  padding: 30px;
}
</style>