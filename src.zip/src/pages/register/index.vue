<template>
  <van-sticky>
    <nav-bar title="注册/登录" left-arrow @click-left="onClickLeft"/>
  </van-sticky>

  <!-- <router-view v-slot="{ Component }">
    <transition name="router-fade" mode="out-in">
      <keep-alive>
        <component :is="Component" />
      </keep-alive>
    </transition>
  </router-view> -->
  <router-view></router-view>
</template>

<script lang="ts" setup>
import { isAllowVisitorToUseSchool } from '@/utils/customizedType';
import { useRouter } from 'vue-router';

const router = useRouter();

defineOptions({
  name: 'register',
  beforeRouteEnter(_, from) {
    let { path, query, params } = from
    sessionStorage.setItem('registerFromRouter', JSON.stringify({path, query, params}))
  }
})

const onClickLeft = () => {
  let registerFromRouter = JSON.parse(sessionStorage.getItem('registerFromRouter') || '{}')
  if (isAllowVisitorToUseSchool() && Object.keys(registerFromRouter).length > 0) {
    router.replace(registerFromRouter)
  } else {
    router.back();
  }
};
</script>
