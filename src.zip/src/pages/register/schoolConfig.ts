import { SchoolCode } from "@/constants";
import { getSchoolCode } from "@/utils";

export const schoolConfig = (type: string) => {
    let schoolCode = getSchoolCode();
    if (type == 'login_banner') {
        if (schoolCode == SchoolCode.ShanDa) {
            sessionStorage.setItem('logoFlag', '1')
            return '1'
        } else {
            let logoFlag = sessionStorage.getItem('logoFlag')
            if (logoFlag === '1') {
                return '1'
            } else {
                sessionStorage.setItem('logoFlag', '2')
                return '2'
            }
        }
    }
}