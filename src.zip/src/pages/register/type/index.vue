<template>
    <div class='content' :style="!!typeBack?{'background-image': `url(${typeBack})`}:{ 'background': backgroundDetail(settingStore.themeColor) }">
      <!-- background: linear-gradient(180deg, #ac7d52 0%, rgba(172, 125, 82, 0.2) 100%); -->
        <div class='tips'>
            请选择注册类型
        </div>
        <div class='item' v-for="(item,index) in schoolmateTypeList" :key="index" @click="jump(item.value)" >
            <div class='left'>
              <!-- <img :src='label2' class='ims'/> -->
              <Svglabel0 class='ims'  :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" v-if="item.value == '0'"/>
              <Svglabel1 class='ims'  :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" v-if="item.value == '1'"/>
              <Svglabel2 class='ims'  :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" v-if="item.value == '2'"/>
              <Svglabel3 class='ims'  :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }" v-if="item.value == '3'"/>
              <div class='title'>
                {{item.name}}
              </div>
            </div>
            <div class='right'>
              <SvgZuojiantou class='imsA' :style="{ '--sub-color': hex2Rgba(settingStore.themeColor, 0.5) }"/>
            </div>            
        </div>
    </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from "vue";
import { useRouter } from "vue-router";

import Svglabel0 from "@/assets/img/label0.svg";
import Svglabel1 from "@/assets/img/label1.svg";
import Svglabel2 from "@/assets/img/label2.svg";
import Svglabel3 from "@/assets/img/label3.svg";
import arrowLeft from "@/assets/img/arrowLeft.png";
import SvgBiye from "@/assets/icons/biye2.svg";
import SvgQiye from "@/assets/icons/qiye2.svg";
import SvgZaixiaosheng from "@/assets/icons/zaixiaosheng2.svg";
import SvgZhigong from "@/assets/icons/zhigong2.svg";
import SvgZuojiantou from "@/assets/icons/zuojiantou2.svg";
import { useSettingStore } from '@/store';
import { backgroundDetail,hex2Rgba } from '@/utils/hex2rgba';
import ApiConfig from '@/api/config';
import { getSchoolCode,getRealFilePath } from '@/utils';
import { registerTypeMole } from '@/pages/register/constant';
import { isGuangWenYi,isShenYangYaoKeDaXue,isChengDeYiXueYuan } from '@/utils/customizedType';
import useCache from '@/hooks/useCache'
import { homeSwipePic } from '@/api/home'
const settingStore = useSettingStore();
const router = useRouter();
const schoolmateTypeList = ref([] as any)
const nameList = ref([
  {
    name:"校友",
    value:"0"
  },
  {
    name:"教职工(曾)",
     value:"2"
  },
  {
    name:"在校生",
     value:"1"
  },
  {
    name:"合作企业人员",
     value:"3"
  },
]) 

const nameListGWY = ref([
  {
    name:"毕业生",
    value:"0"
  },
  {
    name:"教职工",
     value:"2"
  },
  {
    name:"在校生",
     value:"1"
  },
  {
    name:"合作企业人员",
     value:"3"
  },
]) 

const typeList = ref([] as any)
const typeBack = ref('')

/***
 * 辽宁师范是不走register/type这个页面，所以不用考虑，
 * 广东XX学校，汕大，河北,乌鲁木齐,成都医学院都是走同一套，(选择用户类型后直接跳转到register/second)
 * 沈阳还有以后的学校的流程是：用户选择校友类型，那就跳转register/register_middle_first
 * 先匹配三要素，做免登处理，用户选择非校友类型那就直接走register/second
 * 
 * */ 
const jump = (val: string) => {
  let schoolcode = getSchoolCode() as string
  // console.log(val);
  let setName = schoolcode + "type"
  sessionStorage.setItem(setName,val)
  if(registerTypeMole.includes(schoolcode)){
    router.push({ path: "second", query: { schoolmateType: val } });
  }else{
    if(isChengDeYiXueYuan()){
      router.push({ path: "register_middle_first",query: { schoolmateType: val }})
    }else{
      if(val == '0'){//校友类型
        router.push({ path: "register_middle_first"})
      }else{
        router.push({ path: "second", query: { schoolmateType: val } });
      }      
    }

  }
};

const initSchoolmateType =async () => {
  const { data, code, msg } = await ApiConfig.infoConfigSchoolGet({enable:"1"});
  let nameArr = []
  if(isGuangWenYi() || isChengDeYiXueYuan()){
    nameArr = nameListGWY.value
  }
  else if(isShenYangYaoKeDaXue()){
    nameList.value[1].name="教职工"
    nameArr = nameList.value
  }
  else{
    nameArr = nameList.value
  }
  if(code == 200){
    for(let i in data){
      for(let a in nameArr){
        if(nameArr[a].value == data[i].identityType){
          schoolmateTypeList.value.push(nameArr[a])
        }
      }
    }
  }
}

onMounted(()=>{
  initSchoolmateType()
      useCache({
      key: 'REGISTER_TYPE_BACKGROUND',
      service: homeSwipePic,
      params: {
        imageType: 'REGISTER_TYPE_BACKGROUND',
      },
      callback: ({ code, data, mag }: any) => {
        if (code == 200 && data.images.length) {
          typeBack.value = getRealFilePath(data.images[0].fileAddress)
        }
      },
    })
})
</script>
<style lang="less" scoped>
.content {
  width: 100%;
  height: 100%;
  // background: linear-gradient(180deg, #ac7d52 0%, rgba(172, 125, 82, 0.2) 100%);
  padding: 70px 32px 0px 32px;
      background-repeat: no-repeat;
    background-size: 100% 100%;
  .tips {
    font-size: 40px;
    font-family: PingFangSC PingFang SC;
    font-weight: 500;
    color: #ffffff;
  }
  .item {
    margin-top: 60px;
    padding-left: 40px;
    padding-right: 44px;
    width: 686px;
    height: 160px;
    background: #ffffff;
    box-shadow: 0px 2 14px 0px rgba(172, 125, 82, 0.16);
    border-radius: 32px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    .left {
      width: 70%;
      height: 100%;
      display: flex;
      align-items: center;
      .title {
        margin-left: 30px;
        font-size: 36px;
        font-family: PingFangSC PingFang SC;
        color: #363636;
        font-weight: 900;
      }
      .ims {
        width: 86px;
        height: 86px;
        :deep(path:last-child) {
        fill: var(--theme-color);
    }
      }
    }
    // .right {
    //   width: 44px;
    //   height: 44px;
    // }
    .imsA {
      // width: 50%;
      // height: 50%;
    }
  }
}
</style>