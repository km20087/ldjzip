<template>
  <div
    class="login-cont"
    :style="
      backUrl
        ? {
            'background-image': 'url(' + backUrl + ')',
            'background-repeat': 'no-repeat',
            'background-size': 'cover',
          }
        : ''
    "
  >
    <div class="login-banner">
      <img class="logo-img" :src="loginLogo" alt="" />
      <span v-if="schoolCode !== SchoolCode.PeiYingZhongXue" :class="UseResConfigByCSS().blackTitle?'title blaTitle':'title'">{{ settingStore.schoolName }}校友服务平台</span>
      <span v-else class="title pyTitle">培英荟</span>
    </div>
    <div class="login-action">
      <div class="phone-input">
        <input
          type="text"
          v-model="send.mobile"
          :maxlength="schoolCode == SchoolCode.LiaoShiDa ? undefined : '11'"
          :placeholder="schoolCode == SchoolCode.LiaoShiDa ? '请输入手机号码或学工号' : '请输入手机号码'"
          @blur="onBlur"
        />
      </div>
      <div class="phone-input">
        <input type="text" v-model="code" :maxlength="4" placeholder="请输入计算结果" />
        <!-- <img class="item2-code" :src="imageBase64" @click="getImgVerify" /> -->
      </div>
      <div class="phone-input">
        <input
          :type="!hideYanzheng ? 'text' : 'password'"
          v-model="loginP.verCode"
          autocomplete="off"
          :maxlength="!hideYanzheng ? 6 : 16"
          :placeholder="!hideYanzheng ? '请输入短信验证码' : '请输入密码'"
        />
        <template v-if="!hideYanzheng">
          <span
            class="item2-timer"
            @click="getCode"
            v-if="!state"
            :style="{ color: settingStore.themeColor }"
            >
              获取验证码
            </span>
          <span class="item2-timer" v-else
            ><van-count-down :time="cou" format="ss" class="time"
          /></span>
        </template>
      </div>
      <div class="phone-input agreePart" v-if="protocolList.length > 0">
        <van-checkbox v-model="checked" shape="square" @click="goPro" />
        <div class="sodo">
          <p class="agft">本人已阅读并同意以下内容</p>
          <p
            class="woos"
            @click="goProtocolPage(item)"
            v-for="item in protocolList"
            :key="item.niId"
            :style="{ color: settingStore.themeColor }"
          >
            {{ item.newsTitle }}</p
          >
        </div>
      </div>
      <van-dialog v-model:show="proFlag" :comfirm-button-color="themecolor" :show-confirm-button="false" class="wasadd">
        <slot name="title" >
          <div class="sdLogo" v-if="proFlag && schoolCode == SchoolCode.ShanDa">
            <img :src="aggrementLogo" class="logSize" alt="">
          </div> 
        </slot>
        <div class="sdbg">
        </div>  
        <div v-if="schoolCode == SchoolCode.ShanDa" class="logoCss">
          <p class="fon24">服务协议</p>
        </div>
        <div v-html="prodetail" class="xieyi-cont" />
        <div class="bottomButton">
         <van-button type="primary" class="wasd" @click="seurAgree()" round >确 认</van-button>
        </div>
      </van-dialog>
        <!-- <div class="sdLogo" v-if="proFlag && schoolCode == SchoolCode.ShanDa">
          <img :src="aggrementLogo" class="logSize" alt="">
        </div> -->
      <div class="btn-bar">
        <van-button type="primary" round block @click="toNext">登录</van-button>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import { ref, onBeforeMount, Ref, reactive, watchEffect } from 'vue';
  import { useRouter } from 'vue-router';
  import { Toast, Dialog } from 'vant';
  import 'vant/es/toast/style';
  import Api, { LoginParams, sendParams } from '@/api/user';
  import router, { initMenu } from '@/router';
  import { useProtocol } from '@/hooks/useProtocol';
  import { useSettingStore } from '@/store';
  import { schoolConfig } from '../schoolConfig';
  import { RSAencrypt } from '@/utils/encrypt';
  import useCache from '@/hooks/useCache';
  import { homeSwipePicSchool ,homeSwipePic} from '@/api/home';
  import { IdentifyMode, SchoolCode,UseResConfigByCSS } from '@/constants';
  import { getSchoolCode, getSchoolId, MenuKey, removeSessionStorageItem, setButtons, setMenus, setToken, setUserId, setUserInfo, setUserStatus } from '@/utils';
  import { storeToRefs } from 'pinia'
import { Base64 } from 'js-base64';
  import { getRealFilePath } from '@/utils';
  // import AggrementLogo from "@/assets/icons/aggrementLogo.svg"
  import aggrementLogo from "@/assets/mine/aggrementLogo.png"
  // import aggrementBg from "@/assets/mine/aggrementBg.png"

  const settingStore = useSettingStore();
  const { schoolId } = storeToRefs(settingStore)

  const { getListDataByWatchSchoolId, list: protocolList, goProtocolPage } = useProtocol();
  getListDataByWatchSchoolId();

  let schoolCode = new URLSearchParams(location.search).get('schoolCode');
  const picUrl = ref(process.env.VITE_APP_PIC_BASE_URL);
  // const bacFlag = ref('');
  const loginLogo = ref('');
  const backUrl = ref('');
  const checked = ref(false);
  const $router = useRouter();
  const proFlag = ref(false)
  const prodetail = ref('')
  const themecolor = ref('')
  const send = reactive<sendParams>({
    mobile: '',
    schoolId: schoolId.value,
    codeKey: '',
    code: '',
    // loginType: 'sms',
  });
  const code = ref('');
  const imageBase64 = ref('');
  const clientId = ref('')
  const redirectUrl = ref('')
  const newLoginFlag = ref(false)
  const loginP = reactive<LoginParams>({
    mobile: '',
    schoolId: schoolId.value,
    id: '',
    verCode: '',
    transid: '',
    wxCode: '',
    seOpenId: '',
    codeKey: '',
    code: '',
    loginType: 'sms',
  });
  const schoolList:string[] = [
    SchoolCode.LiaoShiDa,//辽师
    // SchoolCode.ShenYangShiFan,//沈阳
    // SchoolCode.ChengDuYiXueYuan//成都
  ]

  const cou = ref(60000);
  const state = ref(false);
 
  const hideYanzheng = ref(false);
  const onBlur = () => {
    let scCode = getSchoolCode();
    if (!scCode) return;
    let keyword = scCode.substring(scCode.length - 5, scCode.length);
    hideYanzheng.value =
      send.mobile.startsWith(keyword) ||
      (scCode == SchoolCode.LiaoShiDa && !/^1[3|4|5|6|7|8|9]\d{9}$/.test(send.mobile));
    loginP.loginType = hideYanzheng.value ? 'password' : '';
  };
  const toNext = async () => {
    loginP.schoolId = send.schoolId;
    loginP.codeKey = send.codeKey;
    sessionStorage.removeItem('data1');
    let verCode = loginP.verCode;
    // if (hideYanzheng.value) {
    //   // @ts-ignore
    //   verCode = RSAencrypt(verCode);
    // } else {
    //   if (!loginP.id) {
    //     Toast({ message: '请获取验证码' });
    //     return;
    //   }
    // }

    // if (protocolList.value.length > 0 && !checked.value) {
    //   Toast({ message: '请勾选协议' });
    //   return;
    // }
    let seOpenId = sessionStorage.getItem('seOpenId');
    if (seOpenId) {
      loginP.seOpenId = seOpenId
    }
    loginP.mobile = send.mobile;
    sessionStorage.setItem('mobile', loginP.mobile);
    if(newLoginFlag.value){ // 辽师单点登录
      let scCode = getSchoolCode() || "";
      const res = await Api.loginCas({
        ...loginP,
        code: code.value.toUpperCase(),
        verCode,
        clientId:clientId.value,
        redirectUrl:redirectUrl.value,
        schoolCode:scCode
        // redirectUri:redirectUrl.value,
      });
      Toast({
        message: res.msg,
      });
      if(res.code == 200){
        window.location = res.data.redirectUrl
      }
    }else{//常规登录
        const { data, msg } = await Api.login({
        ...loginP,
        code: code.value.toUpperCase(),
        verCode,
      });
      Toast({
        message: msg,
      });
      if (data) {
        setToken(data['token']);
        setUserInfo(JSON.stringify(data.user))
        setUserId(data.user.userId);
        setUserStatus(data.user.userStatus)
        sessionStorage.setItem('resson', data.rejectReason);
        //生日祝福
        let birFlag = sessionStorage.getItem('birthdayReminder');
        //校友类型
        sessionStorage.setItem('schoolmateType', data.user.schoolmateType);
        if (!birFlag || birFlag != 'pass') {
          sessionStorage.setItem('birthdayReminder', String(data.birthdayReminder));
        }
        // 获取用户信息
        settingStore.initIdentifyMode(data.user)
        if (settingStore.identifyMode == IdentifyMode.Manage) {
          $router.replace({ path: '/tab/index' });
          return
        }
        //辽宁师范游客只有登录注册权限
        if (
          schoolListFlag() &&
          (data.user.userStatus === '03' ||
            data.user.userStatus === '04' ||
            data.user.userStatus === '05') &&
          data.user?.needConfirm !== '2'
        ) {
          $router.replace({ path: '/register/register_middle_first' });
          return;
        } else if (schoolListFlag() && data.user.userStatus === '05' && data.user?.needConfirm == '2') {
          Dialog.confirm({
            title: '提 示',
            message: data.rejectReason ? data.rejectReason : '信息不完善，请上传证明材料',
          }).then(() => {
            $router.replace({ path: '/register/register_middle_second' });
          });
          return;
        }
        //00正常，01封禁，02删除，03待审核，04待完善资料，05审核失败，06-校友修改资料待审核，07-封禁的游客
        // 第一次登录后，直接跳首页，需要除了认证
        // initAppMenu().then(() => {
        initMenu().then(() => {
          // if (data.user.userStatus === '04' || data.user.userStatus === '05') {
          //   //00正常，01封禁，02删除，03待审核，04待完善资料，05审核失败，06-校友修改资料待审核，07-封禁的游客
          //   $router.replace({
          //     path: '/register/second',
          //     query: { mobile: send.mobile, graduationSchoolName: data.user.schoolName },
          //   });
          // } else if (data.user.userStatus === '00') {
          //   $router.replace({ path: '/index' });
          // } else if (data.user.userStatus === '03') {
          //   $router.replace({
          //     path: '/submited',
          //     query: {
          //       name: data.user.name,
          //       yuanxi: data.user.collegeName,
          //       studentIdNumber: data.user.studentIdNumber,
          //     },
          //   });
          // } else {
          //   Toast({ message: '请等待审核' });
          // }
          if (data.user.userStatus === '01' || data.user.userStatus === '07') {
            Toast({ message: msg });
            // $router.replace({ path: '/register/first' });
          } else {
            if(schoolCode == SchoolCode.ShenYangYaoKeDaXue){
              if(data.user.userStatus === '03' || data.user.userStatus === '04' || data.user.userStatus === '05'){
                $router.replace({ path: '/register/type' });
              }else if(data.user.userStatus === '00' || data.user.userStatus === '06'){
                $router.replace({ path: '/tab/index' });
              }else{
                Toast({ message: msg });
              }
             
            }else{
              $router.replace({ path: '/tab/index' });
            }
            
          }
        });
      }
    }

  };

  const goPro = ()=>{
    let scCode = getSchoolCode();
    if(scCode == SchoolCode.ShanDa){
      themecolor.value = settingStore.themeColor
      proFlag.value = true
      prodetail.value = decodeURIComponent(
        Base64.decode(Base64.decode(Base64.decode(Base64.decode(protocolList.value[0].content))))
      );            
    }
    // console.log('goPro--prodetail',prodetail.value)
  }

  const schoolListFlag = ()=>{
    let schoolCode = getSchoolCode()
    return schoolList.includes(schoolCode!)
  }
  const seurAgree = ()=>{
    proFlag.value = false
    checked.value = true
  }
  const getImgVerify = async () => {
    try {
      const result: any = await Api.fetchImgCode();
      console.log(result);
      var base64 = window.btoa(
        new Uint8Array(result.data).reduce(function (data, byte) {
          return data + String.fromCharCode(byte);
        }, '')
      );
      imageBase64.value = getRealFilePath('img/ver6.png');
      loginP.transid = result.headers.transid;
      send.codeKey = result.headers.transid;
    } catch (err) {
      console.log('getImgCode err', err);
    }
  };
  const initAppMenu = async () => {
    const { data, code, msg } = await Api.appAutMenu({});
    if (code == 200) {
      setMenus(JSON.stringify(data.menus));
      setButtons(JSON.stringify(data.buttons))
    }
    await initMenu();
  };
  const getMes = async () => {
    const { data, code, msg } = await Api.sendSms(send);
    Toast({
      message: msg,
    });
    if (code == 200) {
      state.value = true;
      setTimeout(() => {
        state.value = false;
      }, 60000);
    }
    let a: any = data;
    loginP.id = a;
  };
  const getCode = () => {
    if (!!send.mobile) {
      send.code = code.value.toUpperCase();
      getMes();
    } else {
      Toast({ message: '请输入手机号码' });
    }
  };
  const initBackUrl = async () => {
    useCache({
      key: 'Login_backPic',
      service: homeSwipePicSchool,
      params: {
        imageType: 'Login_backPic',
        schoolId: schoolId.value,
      },
      callback: ({ code, data, msg }: any) => {
        if (code == 200) {
          let { images } = data;
          if (images.length) {
            backUrl.value = picUrl.value + images[0].fileAddress;
          }
        }
      },
    });
  };

  const libLogin = ()=>{//辽师图书馆单点登录
    let schoolCode = getSchoolCode()
    if(schoolCode == SchoolCode.LiaoShiDa){//辽师图书馆单点登录
      let search = window.location.search
      console.log('libLogin',search.split('&'))
      let aStr = 'clientId='
      let bStr = 'redirectUrl='
      let strArr = search.split('&')
      if(strArr.length > 1){
        for(let i in strArr){
          if(strArr[i].includes(aStr)){
            console.log('clientId',strArr[i].split(aStr)[1])
            clientId.value = strArr[i].split(aStr)[1]
          }else if(strArr[i].includes(bStr)){
            console.log('redirectUrl',strArr[i].split(bStr)[1])
            redirectUrl.value = strArr[i].split(bStr)[1]
          }
        }
        if(!!clientId.value && !!redirectUrl.value){
          newLoginFlag.value = true
        }
      }else{
        return
      }
    }
    // http://localhost:5173/index.html?schoolCode=4121010165&clientId=m9A-HRj6KY4wl7RXgRs8q8iGIFm8zeNfZ8sJJN4ZkiA&redirectUrl=https://xy.keledge.com:8443/lnsf/php/cas/login#/register/first
  }

  onBeforeMount(async () => {
    libLogin()
    // bacFlag.value = schoolConfig('login_banner') as string;
    await initBackUrl();
    removeSessionStorageItem(MenuKey);
    getImgVerify();

    // useCache({
    //   key: 'LOGIN_ICON',
    //   service: homeSwipePicSchool,
    //   params: {
    //     imageType: 'LOGIN_ICON',
    //     schoolId: schoolId.value,
    //   },
    //   callback: ({ code, data, msg }: any) => {
    //     if (code == 200) {
    //       let { images } = data;
    //       if (images.length) {
    //         loginLogo.value = picUrl.value + images[0].fileAddress;
    //       }
    //     }
    //   },
    // });
  useCache({
    key: 'HOME_BOTTOM_ICON',
    service: homeSwipePic,
    params: {
      imageType: 'HOME_BOTTOM_ICON'
    },
    callback: ({code, data, msg}: any) => {
      if (code == 200) {
        loginLogo.value = data.images[0].fileAddress
        // if (data.images.length > 0 && !isDemo) {
        //   loginLogo.value = picUrl + data.images[0].fileAddress
        // }else{
        //    loginLogo.value = data.images[0].fileAddress
        // }

      }
    }
  })

  });
</script>
<style lang="less" scoped>
  // .loas {
  //   margin: 0px 10px;
  //   border-radius: 8px;
  //   border: 2px solid #dfdfdf;
  //   margin-top: 10px;
  //   margin-bottom: 10px;
  //   /deep/ .van-cell {
  //     padding: 0px;
  //     padding-left: 10px;
  //   }
  // }
  // .buasd {
  //   width: 85%;
  //   margin: 0 auto;
  // }
  // .first-cont {
  //   .phone-cont {
  //     display: flex;
  //     align-items: center;
  //     margin: 0px 10px;
  //     border-radius: 8px;
  //     border: 2px solid #dfdfdf;
  //     /deep/ .van-cell {
  //       border-left: 2px solid #dfdfdf;
  //     }
  //     .phone-area {
  //       width: 30%;
  //     }
  //     input {
  //       border: 0;
  //     }
  //     .input-area {
  //       width: 100%;
  //       height: 88px;
  //       padding: 0 30px;
  //       background: #fff;
  //     }
  //     .input-text {
  //       width: 70%;
  //       height: 88px;
  //       padding: 0 25px;
  //     }
  //   }
  //   .certifi-code {
  //     display: flex;
  //     align-items: center;
  //     justify-content: space-between;
  //     margin-top: 30px;
  //     margin-bottom: 60px;
  //     input {
  //       padding: 25px;
  //       width: 68%;
  //       height: 88px;
  //       border: 2px solid #dfdfdf;
  //       border-radius: 8px;
  //     }
  //     .time {
  //       width: 100%;
  //       height: 100%;

  //       border: inherit;
  //       border-color: var(--van-black);
  //       border-radius: inherit;
  //     }
  //   }
  // }

  .login-cont {
    background: url('../../../assets/img/BEIJINGTU.png') no-repeat;
    width: 100%;
    height: 100%;
    position: relative;
    // background-size: cover;
    .sdLogo{
      width: 230px;
      height: 146px;
      position: absolute;
      top:0;
      left:50%;
      z-index:2026;
      text-align: center;
      transform: translate(-52%,-47%);
    }
      .logSize{
        width: 230px;
        height: 146px;
        position: relative;
        // top:-50%
      }        
  }

  .login-contShan {
    background: url('../../../assets/img/shandabeijing.jpg') no-repeat;
    width: 100%;
    height: 100%;
    background-size: cover;
  }

  .login-banner {
    width: 100%;
    height: 313.5px;
    box-sizing: border-box;
    // padding-bottom: 80px;
    margin-bottom: 90px;

    background-position: center center;
    background-size: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    .logo-img {
      width: 89.5px;
      height: 90px;
    }

    .title {
      margin-top:24px;
      font-size: 36px;
      font-family: PingFangSC-Medium, PingFang SC;
      font-weight: 500;
      font-style: normal;
      color: #ffffff;
      //  color: #222222;
    }
    .pyTitle{
       font-weight: 600;
      color: #222222;
    }
    .blaTitle{
      color: #333333;
    }

    .title2 {
      font-size: 20px;
      color: #fff;
      line-height: 44px;
      font-weight: 600;
    }

    .title2 {
      font-size: 15px;
    }
  }

  .bacOpacity {
    // opacity: 0.8;
  }

  .login-action {
    background: #fff;
    padding: 35px 5% 75px 5%;
    margin: 0 32px;
    margin-top: -80px;
    border-radius: 20px;

    display: flex;
    flex-direction: column;
    align-items: center;

    .tips {
      font-size: 15px;
      font-weight: 800;
      width: 80%;
      line-height: 45px;
    }

    .phone-input {
      margin: 8px 0;
      width: 100%;
      position: relative;

      input {
        width: 586px;
        height: 90px;
        background: #f5f5f5;
        border: 0px;
        margin-top: 40px;
        line-height: 48px;
        padding: 0 25px;
        border-radius: 30px;
      }

      .item2-code {
        position: absolute;
        // transform: translate(-50%, -50%);
        transform: translate(-110%, 65%);
        width: 150px;
        height: 70px;
        // border-radius: 20px;
        // top: 11.5px;
        // right: 25px;
      }

      .item2-timer {
        width: 200px;
        height: 60px;
        line-height: 60px;
        padding: 0 15px;
        position: absolute;
        // top: 9px;
        // right: 25px;
        transform: translate(-100%, 100%);
        text-align: center;
        color: #1277ff;
        // border: 1px solid;
        // border-radius: 15px;
        // font-size: 14px;
      }
    }

    .btn-bar {
      width: 93%;
      margin: 20px 0;
    }

    .form-submit {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 80%;
      padding: 0 5px;

      &-btn {
        color: #1277ff;
        font-weight: 600;
      }
    }

    .agreePart {
      display: flex;
      margin-left: 10px;

      // justify-content: center;
      // align-items: center;
      .sodo {
        margin-left: 10px;
        font-size: 0px;
        width: 80%;
        //
        word-wrap: break-word;
      }

      .agft {
        // font-size: 14px;
        display: inline;
        font-size: 24px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #959595;
      }

      .woos {
        display: inline;
        font-size: 24px;
        font-family: PingFangSC-Regular, PingFang SC;
        font-weight: 400;
        color: #1e93ef;
      }
    }
  }

  .siias {
    font-size: 14px;
  }

  .wsaw {
    width: 100%;
    text-align: center;
  }
  // :deep(.van-dialog__content){
  //   position: relative;
  // }
  .xieyi-cont{
    width: 630px;
    height:800px;
    overflow-y:scroll ;
    padding:20px 50px;
    box-sizing: border-box;
    // padding-bottom: 95px;
  }


    .wasadd{
    // box-sizing: border-box;
    width: 100%;
    position: relative;
      .sdbg{
    position: absolute;
    width: 100%;
    height:240px;
    top:0;
    left:0;
    background: url("@/assets/mine/aggrementBg.png") no-repeat;
    background-size:100% 100%;
  }    
    .logoCss{
      width: 100%;
      height: 40px;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 93px;
      margin-bottom: 24px;
      .fon24{
        font-size: 34px;
        color:#222;
        font-weight: 700;
      }
    }
  }
.bottomButton{
  width: 100%;
  height:148px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.wasd{
  width: 375px;
  height: 88px;
  margin-bottom: 0px;
  // border-radius: 0;
  // color:transparent
}
// :deep(.van-popup){
//   overflow-y:inherit !important;
// }
:deep(.van-dialog){
  overflow:inherit;
}
:deep(.van-popup--center){
  top:55%;
}
</style>
