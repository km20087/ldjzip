<template>
    <div class='content'>
		<van-nav-bar :title="title" left-text="" left-arrow @click-left="onClickLeft" />  
        <div class='jonInfo'>
			<!-- <fix-image  :src="jobInfo.logo" class="logoIms"></fix-image> -->
			<div class='jobtitle'>
				{{jobInfo.positionName}}
			</div>
			<div class='jobdetail'>
                <div class='left'>
                    <div class='creatTime'>
                        {{changeTime(jobInfo.createTime)}}
                    </div>
                    <div class='views'>
                        浏览量:{{jobInfo.views || 0}}
                    </div>
                </div>
				<!-- <div class='salaryTypeClass'>
					面议
				</div> -->
				<div class='salaryTypeClass' v-if="jobInfo.salaryType == '0'">
					面议
				</div>
				<div class='salaryTypeClass' v-if="jobInfo.salaryType == '1'">
					{{jobInfo.salaryMin}} - {{jobInfo.salaryMax}}
				</div>	                
			</div>
        </div>
		<div class="gap"></div>		      
        <div class='enterprise_detail' @click="onClickLeft">
           <enterprisetitle :logo="enterpriseInfo.logo" :enterpriseName="enterpriseInfo.enterpriseName" :positionCount="enterpriseInfo.positionCount" :views="enterpriseInfo.views" />         
        </div>
        <div class="gap"></div>	
        <div class='address'>
            <div class='location'>
                <div class='locationCn'>工作地点</div>
            </div>
            <div class='address_detail'>
                <div class='address_detail_title'>地址:</div>
                <div class='address_detail_title mar20'>{{jobInfo.address}}</div>
            </div>
        </div>
        <div class="gap"></div>	
        <div class='job_description'>
            <div class='description'>
                <div class='descriptionCn'>职位描述</div>
            </div>
            <div class='description_detail' v-html="jobInfo.description">

            </div>
        </div>        
    </div>
</template>
<script lang='ts' setup>
import { reactive, ref } from 'vue';
import enterprisetitle from '../enterprise-detail/enterprisetitle.vue'
import Api from "@/api/enterprise"
import { Base64 } from 'js-base64';


const router = useRouter();
const route = useRoute();
const title = ref('校企招聘');

const jobInfo = <any>ref({})
const enterpriseInfo = <any>ref({})

const onClickLeft = () => {
    router.go(-1);
};

const changeTime = (val:any)=>{
	let time = new Date(val)
	let year = time.getFullYear()
	let month = addZeroShow(time.getMonth()+1)
	let day = addZeroShow(time.getDate())
	return `${year}-${month}-${day}`
}

const addZeroShow = (val:number) =>{
  if(val < 10){
    return '0'+String(val)
  }else{
    return String(val)
  }
}

const initData = ()=>{
    let info = sessionStorage.getItem('jobDetail') || ''
    let enterprise = sessionStorage.getItem('enterpriseInfo') || ''
    if(info){
        jobInfo.value = JSON.parse(info)
        addViews(jobInfo.value.id)
        let description = ''
        if(jobInfo.value.description){
            description = decodeURIComponent(
            Base64.decode(Base64.decode(Base64.decode(Base64.decode(jobInfo.value.description)))))
        }
        jobInfo.value.description = description.replace(/<img/gi, "<img style='width:100%;height:100%'")
    }
    if(enterprise){
        enterpriseInfo.value = JSON.parse(enterprise)
    }
    console.log('jobInfo:',jobInfo.value)    
    console.log('enterpriseInfo:',enterpriseInfo.value)    
}

const addViews = async (id:string) =>{
	// let id = route.query.id || ''
	await Api.addPositionViews({id})
}

onMounted(()=>{
    initData()
})
</script>

<style lang='less' scoped>

.content{
    width:100%;
	.gap {
		// margin-top: 30px;
		width: 100%;
		height: 20px;
		background-color: #f5f5f5;
    }    
	.jonInfo{
		background-color: #ffffff;
		margin-bottom:20px;
		width:100%;
		padding: 30px 20px;
		box-sizing: border-box;
		
		.jobtitle{
			font-size:36px;
			font-weight:600;
			display:flex;
			justify-content: flex-start;
			align-items: center;
		}
		.jobdetail{
			margin-top:30px;
			width:100%;
			display: flex;
			align-items: center;
            justify-content: space-between;
            .left{
                display:flex;
                align-items:center;
                justify-content:flex-start;
                font-size: 28px;
                .creatTime{
                    // font-size: 28px;
                }
                .views{
                    margin-left:30px;
                }                        
            }
			.salaryTypeClass{
				color:#40A9FF;
                font-size: 30px;
                font-weight:900;
			}            
        } 
    }
    .enterprise_detail{
        padding:30px 0px;
        box-sizing:border-box;
    }
    .address{
        width:100%;
        height: 150px;
        padding: 30px 20px;
                
        .location{
            width:100%;
            display:flex;
            justify-content:flex-start;
            .locationCn{
                font-weight:900;
                font-size:30px;
            }
        }
        .address_detail{
            width:100%;
            margin-top:20px;
            display:flex;
            justify-content:flex-start;   
            align-items:center;
            font-size:30px    
            .address_detail_title{
                // margin-left:20px;
            }
            .mar20{
                margin-left:20px;
            }
        }        
    }    
    .job_description{
        width:100%;
        padding: 30px 20px;
        .description{
            width:100%;
            display:flex;
            justify-content:flex-start;
        }
        .descriptionCn{
            font-weight:900;
            font-size:30px;            
        }
        .description_detail{
            margin-top:20px;
        }
    }
}
</style>