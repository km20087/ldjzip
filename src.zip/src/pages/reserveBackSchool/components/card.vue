<template>
    <div class="card">
        <div class="left">
            <div class="left-name">{{ name || returningPersonnelName }}</div>
            <div class="left-collega limitShow">学院：{{ collega }}</div>
            <div class="left-phone">联系方式：{{ phone }}<img v-if="isShowCP" :src="ICON_COPY" class="copybtn"
                    @click="copyText(phone)" /></div>
        </div>
        <div class="right" v-if="auditStatus == '1' && !!qrCode && isShanDa()">
            <img :src="qrCode" class="ims" @click="showImg"/>
        </div>
        <van-image-preview v-model:show="show" :images="imgList"  :showIndex="false">
            <template #image="{ src }">
                <img :src="success" alt="" class="showSuccess">
                <img :src="src" alt="" class="iso">
                <div class="textA">
                    <p>{{returningPersonnelName}}</p>
                    <p>联系方式:{{phone}}</p>
                    <p v-if="plateNumber">车牌号:{{plateNumber}}</p>
                    <p>{{timeNow}}</p>
                </div>
            </template>
        </van-image-preview>
    </div>
</template>
<script lang="ts" setup>
import ICON_COPY from '@/assets/returnSchoolMonth/icon-copy.png'
import copyText from '@/hooks/useCopyText'
import { isShanDa } from '@/utils/customizedType';
//  import successIcon from '@/assets/appointment/successIcon.png';
import success from '@/assets/img/success.png';
const timeNow = <any>ref(null)
const props = withDefaults(
    defineProps<{
        name?: string;
        collega?: string
        phone?: string
        member?: number
        total?: number
        isShowCP?: boolean
        qrCode?:string
        auditStatus?:string
        plateNumber?:string,
        returningPersonnelName?:string
    }>(),
    {
        name: '',
        collega: '',
        phone: '',
        member: 0,
        total: 0,
        isShowCP: false,
        qrCode:"",
        auditStatus:"",
        returningPersonnelName:"",
        plateNumber:"",

    }
);
const show = ref(false)
const imgList = <any>ref([])
const qrcodeTime = <any>ref(null)
const qrcodeSetTime = <any>ref(null)
const showImg =async ()=>{
    show.value = true
    // let date1 = new Date()
    // timeNow.value = date1.getFullYear() +"/"+ date1.getMonth() + "/" + date1.getDate()+" "+ date1.getHours() + ":" + date1.getMinutes() + ":" + date1.getSeconds()
    // sessionStorage.setItem('dialogShow','1')
}

const initQrcodeTime = ()=>{
     console.log('bofore--watch-true',qrcodeSetTime.value)
    qrcodeSetTime.value = setInterval(()=>{
        let date1 = new Date()
        timeNow.value = date1.getFullYear() +"年"+ Number(date1.getMonth()+1) + "月" + date1.getDate()+"日 "+ date1.getHours() + ":" + date1.getMinutes() + ":" + date1.getSeconds()
    },1000)
    console.log('watch-true',qrcodeSetTime.value)
}

watch(
    ()=>props.qrCode,
    (val)=>{
    imgList.value = []
    imgList.value.push(val)
    console.log('watch--imgList',val)
    
    },
    {
        immediate:true,
        deep:true
    }
)
watch(()=>show.value,
    (val)=>{
        console.log('watch-val',val)
        if(val){
            console.log('watch-true')
            initQrcodeTime()
        }else{
            clearInterval(qrcodeSetTime.value)
            console.log('watch-false',qrcodeSetTime.value)
        }
    },
    {
        immediate:true
    }
)
</script>
<style lang="less" scoped>
.card {
    width: 100%;
    padding: 20px 32px;
    background: var(--theme-color);
    border-radius: 16px;
    font-family: PingFangHK-Medium;
    color: #fff;
    display: flex;
    align-items: center;
    font-weight: 500;

    .left {
        flex: 73;

        .left-name {
            font-size: 36px;
            line-height: 72px;
        }

        .left-collega,
        .left-phone {
            font-size: 24px;
            line-height: 48px;
            display: flex;
            align-items: center;

            .copybtn {
                width: 36px;
                height: 36px;
                margin-left: 20px;
            }
        }
        .limitShow{
            overflow-x: hidden;
        }
    }

    .right {
        flex: 27;
        position: relative;
        padding-left: 35px;
        display: flex;
        align-items: center;
        justify-content: center;

        &::before {
            content: '';
            width: 1px;
            height: 100%;
            background: linear-gradient(to bottom, transparent 0%, #fff 40%, #fff 50%, transparent 100%);
            position: absolute;
            left: 0px;
        }
        .ims{
            width: 100px;
            height: 100px;
        }
        .right-label {
            font-size: 24px;
            line-height: 58px;
        }

        .right-num {
            font-size: 32px;

            span {
                font-size: 54px;
            }
        }
    }
}
.iso{
    width: 60%;
    height: 60%;
    height: auto;
    font-size: 36px;
    color:#fff;
}
.showSuccess{
    width: 100px;
    // width: auto;
    height: 100px;
    margin-bottom: 20px;
}
.textA{
    // text-align: center;
    margin-top:20px;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    p{
        margin: 0px;
    }
}
:deep(.van-image-preview__image-wrap){
    // text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
}
</style>