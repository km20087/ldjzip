<template>
    <div class="dateCon">
        <!-- <van-icon name="arrow-left" @click="chagePage('prev')" class="pageButton Aleft" color="#409EFF" size="15px"/>
        <van-icon name="arrow" @click="chagePage('next')" class="pageButton Aright" color="#409EFF" size="15px"/>         -->
        <div class="backTop" :style="{'background':`linear-gradient(180deg,${hex2Rgba(settingStore.themeColor,1)} 0%,${hex2Rgba(settingStore.themeColor,0.5)} 100% )`}">
            <backSchool1 class='backPo'/>
            <backSchool2  class='backPo2'/>
            <div class="title1" v-if="schoolCode !== SchoolCode.ShanDa && schoolCode !== SchoolCode.ShenYangYaoKeDaXue">
                请选择返校日期
            </div>
            <div class="title1" v-else>
                请选择返校开始时间和结束时间
            </div>            
        </div>
        <van-swipe :loop="false" :show-indicatiors="false" ref='indoSwipe' :show-indicators="false">
            <van-swipe-item>
                <div class="dateList">
                    <div v-for="(item,index) in dateSwipe1" :key="index" 
                    :class="item.clickFlag?'dateItem clicked':'dateItem'" 
                    :style="item.clickFlag?{'background':`linear-gradient(180deg,${hex2Rgba(settingStore.themeColor,0.5)} 0%,${hex2Rgba(settingStore.themeColor,1)} 100% )`}:''"
                    @click="jumpApply(item,index,'1')">
                        <div class="month">{{item.month}}</div>
                        <div class="dayNum">{{item.dayNum}}</div>
                        <div class="day">{{item.day}}</div>
                    </div>
                </div>
            </van-swipe-item>
            <van-swipe-item>
                <div class="dateList">
                    <div v-for="(item,index) in dateSwipe2" :key="index" 
                    :class="item.clickFlag?'dateItem clicked':'dateItem'" 
                    :style="item.clickFlag?{'background':`linear-gradient(180deg,${hex2Rgba(settingStore.themeColor,0.5)} 0%,${hex2Rgba(settingStore.themeColor,1)} 100% )`}:''"
                    @click="jumpApply(item,index,'2')">
                        <div class="month">{{item.month}}</div>
                        <div class="dayNum">{{item.dayNum}}</div>
                        <div class="day">{{item.day}}</div>
                    </div>
                </div>                
            </van-swipe-item>
            <van-swipe-item>
                <div class="dateList">
                    <div v-for="(item,index) in dateSwipe3" :key="index" 
                    :class="item.clickFlag?'dateItem clicked':'dateItem'" 
                    :style="item.clickFlag?{'background':`linear-gradient(180deg,${hex2Rgba(settingStore.themeColor,0.5)} 0%,${hex2Rgba(settingStore.themeColor,1)} 100% )`}:''"
                    @click="jumpApply(item,index,'3')">
                        <div class="month">{{item.month}}</div>
                        <div class="dayNum">{{item.dayNum}}</div>
                        <div class="day">{{item.day}}</div>
                    </div>
                </div>                
            </van-swipe-item>                        
        </van-swipe>
        <div class="timeTips" v-show="!!selectedDate">
            返校日期：{{selectedDate}}
        </div>
        <van-dialog v-model:show="showDialog" 
        title="注意" class="dia" 
        show-confirm-button 
        show-cancel-button
        @confirm="confirmDate"
        @cancel="cancelDate"
        >
            <div class="diacontent" v-if="schoolCode !== SchoolCode.ShanDa && schoolCode !== SchoolCode.ShenYangYaoKeDaXue">
                请确认是否选择该日期作为返校日期
            </div>
            <!-- <div class="diacontent minfontSize" v-else>
                  请确认是否选择{{cnDateRange}}作为返校日期
            </div> -->
        </van-dialog>
    </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import  backSchool1 from "@/assets/icons/backSchool_1.svg"
import  backSchool2 from "@/assets/icons/backSchool_2.svg"
import { useRouter } from 'vue-router';
import { hex2Rgba } from '@/utils/hex2rgba';
import { useSettingStore } from '@/store';
import { deepClone } from '@/utils/util';
import { getSchoolCode } from '@/utils';
import { SchoolCode } from "@/constants";
import { Toast } from 'vant';
const settingStore = useSettingStore();
const dateList = <any>ref([])
const router = useRouter();
const indoSwipe = ref()
const showDialog = ref(false)
const dateSwipe1 = <any>ref([])
const dateSwipe2 = <any>ref([])
const dateSwipe3 = <any>ref([])
const schoolCode = getSchoolCode();
const clickFlag = ref(false)
const oldArr = ref('')
const oldIndex = ref('')
const nowArr = ref('')
const nowIndex = ref('')
const dateSureList = <any>ref([])
const cnDateRange = ref('')
const returningStartTime = <any>ref({
    date:0,
    index:0,
    arr:"0"
})
const returningEndTime = <any>ref({
    date:0,
    index:0,
    arr:"0"
})
const selectedDate = ref('')

const confirmItme = ref({} as dateItem)
const emit = defineEmits(['getBackSchoolDate','addDataListSD'])
interface dateItem{
    month:string,
    day:string,
    dayNum:number,
    date:number,
    clickFlag:boolean
}

const initDateList = () =>{
    
    let today = new Date()
    let initStartDate = null
    if(schoolCode == SchoolCode.ShanDa || schoolCode == SchoolCode.ShenYangYaoKeDaXue){
        initStartDate = today.getDate()+1
    }else{
        initStartDate = today.getDate()+2
    }
    // let initStartDate = today.getDate()+2
    let startDate =  new Date(today.setDate(initStartDate))
    console.log('initStartDate',initStartDate)    
        dateList.value.push({
            month:startDate.getMonth()+1+'月',
            day:WeekDay(startDate.getDay()),
            dayNum:startDate.getDate(),
            date:startDate.getTime()
        })    
    for(let i = 0;i<30;i++){
        let dateItem = new Date(startDate.setDate(startDate.getDate()+1))
        dateList.value.push({
            month:dateItem.getMonth()+1+'月',
            day:WeekDay(dateItem.getDay()),
            dayNum:dateItem.getDate(),
            date:dateItem.getTime(),
            clickFlag:false
        })
    }
    dateSwipe1.value = dateList.value.slice(0,14)
    dateSwipe2.value = dateList.value.slice(14,28)
    dateSwipe3.value = dateList.value.slice(28,100)    
}

const WeekDay = (val:number)=>{
    const CNum = ['日', '一', '二', '三', '四', '五', '六', '七', '八', '九']
    let str = '周'
    str = str + CNum[val]
    return str
}

const chagePage = (val:string) =>{
    if(val=='prev'){
        indoSwipe.value.prev()
    }else{
        indoSwipe.value.next()
    }
}

const jumpApply = (item:dateItem,index:number,arr:string)=>{
    console.log('jumpApply',item)
    if(schoolCode == SchoolCode.ShanDa || schoolCode == SchoolCode.ShenYangYaoKeDaXue){

        // item.clickFlag = !item.clickFlag
        // ArrNowState(item,String(index),arr)
        dateRangeSure(item,index,arr)
    }else{
        showDialog.value = true
        item.clickFlag = true
        ArrNowState(item,String(index),arr)
        confirmItme.value = item
        selectedDate.value = confirmItme.value.month +  confirmItme.value.dayNum + "日" + " " + item.day         
    }    
        // router.push({name: 'reserveBackSchoolInfo',query:{date:item.date}})
}


const dateRangeSure = (item:dateItem,index:number,arr:string)=>{
        console.log('___dateRangeSure___',item)
            if(dateSureList.value.map((it:any)=>it.date).includes(item.date)){
                for(let i in dateSureList.value){
                    if(dateSureList.value[i].date == item.date){
                        item.clickFlag = false
                        dateSureList.value.splice(i,1)
                        console.log('dateSureList.value',dateSureList.value)
                        return
                    }
                }
            }
        if(dateSureList.value.length < 2){
            dateSureList.value.push(
                {
                    date:item.date,
                    index:index,
                    arr:arr,
                    cnDate:item.month + item.dayNum
                }
            )
            item.clickFlag = true
            if(dateSureList.value.length == 2){
                let startDateCn = ''
                let endDateCn = ''
                if(dateSureList.value[0].date > dateSureList.value[1].date){
                    startDateCn =  dateSureList.value[1].cnDate
                    endDateCn = dateSureList.value[0].cnDate
                }else{
                    startDateCn =  dateSureList.value[0].cnDate
                    endDateCn = dateSureList.value[1].cnDate
                }
                cnDateRange.value = startDateCn + "至" +endDateCn
                // showDialog.value = true
            }
        }
        emit('addDataListSD',dateSureList.value)
        // console.log('dateRangeSure',dateSureList.value)
}

const ArrNowState = (item:dateItem,index:string,arr:string)=>{
    if(oldIndex.value == ''){
        oldIndex.value = index
        oldArr.value = arr
        nowIndex.value = index
        nowArr.value = arr        
    }else{
        oldIndex.value = JSON.parse(JSON.stringify(nowIndex.value))
        oldArr.value = JSON.parse(JSON.stringify(nowArr.value))
        nowIndex.value = index
        nowArr.value = arr        
    }
    ArrShow()
}   

const ArrShow = ()=>{
    let oldIndexN = Number(oldIndex.value)
    let nowIndexN = Number(nowIndex.value)
    if(oldArr.value == '1'){
        dateSwipe1.value[oldIndexN].clickFlag = false
    }else if(oldArr.value == '2'){
        dateSwipe2.value[oldIndexN].clickFlag = false
    }else if(oldArr.value == '3'){
        dateSwipe3.value[oldIndexN].clickFlag = false
    }
    if(nowArr.value == '1'){
        dateSwipe1.value[nowIndexN].clickFlag = true
    }else if(nowArr.value == '2'){
        dateSwipe2.value[nowIndexN].clickFlag = true
    }else if(nowArr.value == '3'){
        dateSwipe3.value[nowIndexN].clickFlag = true
    }    
    
}

const confirmDate = ()=>{
    showDialog.value = false
    if(SchoolCode.ShanDa != schoolCode){
        emit('getBackSchoolDate',{val:confirmItme.value.date})
            // emit('getBackSchoolDate',{val:item.date})
        router.push({name: 'reserveBackSchoolInfo',query:{date:confirmItme.value.date}})
    }
    // else{
    //     let returningStartTime = 0
    //     let returningEndTime = 0
    //     if(dateSureList.value[0].date > dateSureList.value[1].date){
    //         returningStartTime =  dateSureList.value[1].date
    //         returningEndTime = dateSureList.value[0].date
    //     }else{
    //         returningStartTime =  dateSureList.value[0].date
    //         returningEndTime = dateSureList.value[1].date
    //     }        
    //     router.push({name: 'backSchool',query:{returningStartTime,returningEndTime}})
    // }

}

const cancelDate = ()=>{
    showDialog.value = false
}

onMounted(()=>{
    initDateList()
})
</script>
<style lang="less" scoped>
.dateCon{
    // width: 100%;
    position: relative;
    background-color: #ffffff;
    font-family: PingFang-SC-Medium, PingFang-SC;
    padding-bottom: 40px;
    box-sizing: border-box;
    .backTop{
        width: 100%;
        height: 200px;
        position: relative;
        .backPo1{
            position: absolute;
            left: 0px;
            top: 0px;
            width: 750px;
            height: 200px;        
        }
        .backPo2{
            position: absolute;
            left: 50px;
            top: 34px;
            width: 248px;
            height: 59px;         
        }
        .title1{
            position: absolute;
            left: 50px;
            top: 117px;
            font-size: 28px;
            color: #ffffff;

        }
    }
    :deep(.van-swipe){
        // width: 100%;
        border-radius: 24px 24px 0px 0px;
        position: relative;
        top:-24px;
        background: #ffffff;        
    }
    // .pageButton{
    //     position: absolute;
    //     top: 50%;
    //     transform: translate(-50%,-50%);
    //     z-index:1000;
    //     height: 150px;
    //     line-height: 150px;
    // }
    // .Aleft{
    //     left: 2%;
    // }
    // .Aright{
    //     left:98%;
    // }    
    .dateList{
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        padding: 30px 30px;
        box-sizing: border-box;        
        // padding: 0 40px;
        // box-sizing: border-box;
        // height: 300px;
        .dateItem{
            flex:1;
            padding: 24px 0px;
            box-sizing: border-box;
            margin-bottom: 10px;
            width: calc(84vw/7);
            min-width: calc(84vw/7);
            max-width: calc(84vw/7);
            background-color: #ffffff;
            color: #333333;
            box-shadow: 0px 5 16px 0px rgba(226,230,245,0.5);
            border-radius: 20px;
            border: 2px solid #ffe8e8;
            font-family: PingFang-SC-Medium, PingFang-SC;
            margin-right: 10px;
            &:nth-child(7n){
                margin-right: 0px;
            }
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            .month{
                color:#999999;
                font-size: 24px;
            }
            .dayNum{
                margin-top: 28px;
                color:#464646;
                font-size: 34px;
            }
            .day{
                margin-top: 28px;
                color:#999999;
                font-size: 24px;
            }            
        }
        .clicked{
            // color: #ffffff !important;
            .month{
                color:#ffffff;
                font-size: 24px;
            }
            .dayNum{
                margin-top: 28px;
                color:#ffffff;
                font-size: 34px;
            }
            .day{
                margin-top: 28px;
                color:#ffffff;
                font-size: 24px;
            }               
        }
    }
    .timeTips{
        width: 100%;
        padding: 0 30px;
        box-sizing: border-box;
        font-size: 32px;
        color:#D72415;
        font-weight: 600;
    }
    .dia{
        .diacontent{
            width: 100;
            display: flex;
            justify-content: center;
            height: 80px;
        }
        .minfontSize{
            font-size: 30px;
        }
    }
    :deep(.van-dialog__header){
        padding-top:30px
    }
}

</style>