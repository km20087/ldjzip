<template>
    <div class="con">
        <van-sticky>
            <nav-bar title="预约记录" left-arrow @click-left="goBack" />
        </van-sticky>         
        <div class="list">
			<van-list v-model:loading="loading" :finished="finished" :immediate-check="true" :finished-text="finsText" @load="onLoad" :offset='400'>
                <van-cell v-for="(item, index) in dataList" :key="index" @click='jumpDetail(item)'>
                    <!-- <div class='jobItem'>
                        <div class='jobtitle'>
                            {{item.positionName}}
                        </div>
                        <div class='jobdetail'>
                            <div class='creatTime'>
                                {{changeTime(item.createTime)}}
                            </div>
                            <div class='salaryTypeClass' v-if="item.salaryType == '0'">
                                面议
                            </div>
                            <div class='salaryTypeClass' v-if="item.salaryType == '1'">
                                {{item.salaryMin}} - {{item.salaryMax}}
                            </div>							
                        </div>
                    </div> -->
                    <div class="item">
                        <div class="top">
                            <div class="left">
                                <img :src="willcheck" alt=""  class="ims" v-if="item.auditStatus == '0' && !item.expired"/>
                                <!-- <img :src="checked" alt=""  class="ims" v-else-if="item.auditStatus == '1' && !item.expired"/> -->
                                <div class="status get" v-else-if="item.auditStatus == '1' && !item.expired">审核通过</div>
                                <img :src="nochecked" alt=""  class="ims" v-else-if="item.auditStatus == '2' && !item.expired"/>
                                <img :src="useless" alt=""  class="ims" v-else-if="item.expired"/>
                               
                            </div>
                            <div class="right">
                                <div class="watch">查看详情</div>
                                <!-- <img :src="arrowLeft" alt=""  class="imsA"/> -->
                                <van-icon name="down" class="leftA" size="13px" />
                            </div>
                        </div>
                        <div class="bottom">
                            <div class="wenzi">
                                返校日期：
                            </div>
                            <div class="date">
                                {{changeDate(item.returningDate)}}{{item.returningStartTime}}~{{item.returningEndTime}}
                            </div>
                        </div>
                    </div>
                </van-cell>
			</van-list>
        </div>
    </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useGoBack } from '@/hooks/useGoBack';
import { backSchoolList } from '@/api/servive';
import checked from '@/assets/guangwenyi/checked.png'
import nochecked from '@/assets/guangwenyi/nochecked.png'
import useless from '@/assets/guangwenyi/useless.png'
import willcheck from '@/assets/guangwenyi/willcheck.png'
import arrowLeft from "@/assets/img/arrowLeft.png";
const { goBack } = useGoBack()
const router = useRouter();
const query = <any>ref({
    pageNum:1,
    pageSize:10
})
const loading = ref(false)
const pages = ref(0)
const total = ref(0)
const isLastPageb = ref(false)
const finsText = ref('没有更多了');
const finished = ref(false);
const dataList = <any>ref([])

const jumpDetail = (val:any)=>{
    console.log(val)
    router.push({path:"/reserveBackSchoolDetailed",query:{id:val.returningSchoolId,auditStatus:val.auditStatus}})
}

const changeDate = (val:string)=>{
    if(!!val){
        let date = new Date(val)
        let year = date.getFullYear()
        let month = date.getMonth() + 1 
        let dateNum = date.getDate()
        return year+'年'+month+'月'+dateNum+"日"+" "
    }else{
        return ''
    }

}

const initData =async ()=>{
    // await 
    loading.value = true;
    try{
        let {code,msg,data} = await  backSchoolList({...query.value})
        if(code == 200){
            pages.value = data.pages
				total.value = data.total;
				isLastPageb.value = data.isLastPage;            
			if (pages.value == 1) {
				dataList.value.length = 0;
			}	
			dataList.value = dataList.value.concat(data.list)	
			loading.value = false;
        }else{
			finsText.value = msg;
			loading.value = false;
			finished.value = true;			
		}
    }catch(err){
        console.log(err)
    }	
	if (isLastPageb.value) {
		finished.value = true;
		loading.value = false;
	}		    
}

const onLoad = ()=>{
  if (!isLastPageb.value) {
	query.value.pageNum++;
	finished.value = false;
	initData();
  } else {
    loading.value = false;
    finished.value = true;
  }	
}


onMounted(()=>{
    initData()

})

</script>
<style lang="less" scoped>
.con{
    width: 100%;
	height: 99%;
	overflow: hidden;
    padding: 20px 24px 0px 24px;
    box-sizing: border-box;
    background-color: #f5f5f5;
    .list{
		width: 100%;
		height: 100%;
		overflow-y: auto;        
        .item{
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            height: 220px;
            background-color: #ffffff;
            box-shadow: 1px 2 8px 0px rgba(0,0,0,0.06);
            border-radius: 24px;
            .top{
                display: flex;
                width: 100%;
                justify-content: space-between;
                align-items: center;
                .ims{
                    width: 116px;
                    height: 48px;
                }
                .status {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 26px;
                    letter-spacing: 0;
                    height: 48px;
                    // text-align: center;
                    // line-height: 24px;
                    font-weight: 700;
                    padding: 0px 5px;
                    box-sizing: border-box;
                    border: 1px solid #10b155;
                    border-radius: 5px 5px;
                    background-color: #e7f7ee;
                    margin-bottom:15px;
                }
                .get {
                    color: #10b155;
                }
                .right{
                    display: flex;
                    align-items: center;
                     height: 48px;
                    .watch{
                        font-size: 26px;
                        color:#999999;
                        font-style:normal;
                        height: 48px;
                        line-height: 48px;
                    }
                    .imsA{
                        width: 52px;
                        height: 40px;
                    }
                    .leftA{
                        transform: rotate(270deg);
                        height: 48px;
                        margin-left: 5px;
                        line-height: 48px;
                        display: block;
                        color:#999999;
                    }
                }
            }
            .bottom{
                display: flex;
                align-items: center;
                justify-content: space-between;
                height: 92px;
                width: 100%;
                background-color: #f7f8f9;
                padding: 0px 20px;
                box-sizing: border-box;
                .wenzi{
                    font-size: 26px;
                    color:#666666;
                    font-style: normal;
                }
                .date{
                    font-size: 26px;
                    color:#222222;
                    font-style: normal;
                }
            }
        }
    }
}

</style>