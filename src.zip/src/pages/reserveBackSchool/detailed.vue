<template>
    <div class="gray-bg">
        <van-sticky>
            <nav-bar title="返校详情" left-arrow @click-left="goBack" />
        </van-sticky>
        <div class="banner">
            <card :name="detailData.groupName" :collega="detailData.collegeName" :phone="detailData.contactInformation"
                :member="detailData.registerCount" :total="detailData.groupSize"
                :auditStatus="detailData.auditStatus"
                :qrCode="detailData.qrCode"
                :plateNumber="detailData.plateNumber"
                :returningPersonnelName="detailData.returningPersonnelName"
                :isShowCP="detailData.isHideContact == '0' ? true : false" />
        </div>
        <div class="main">
            <div class="group-msg">
                <div class="list">
                    <!-- <fix-image :default-src="iconduring" /> -->
                    <div class="text">
                        <span>预约事项：</span>
                        <span class="b">{{ detailData.returningReason}}</span>
                    </div>
                </div>         
                <div class="list">
                    <!-- <fix-image :default-src="iconduring" /> -->
                    <div class="text" v-if="!!detailData.returningDate">
                        <span>返校时间：</span>
                        <span class="b">{{ detailData.returningDate}}</span>
                    </div>
                </div>                          
                <div class="list">
                    <!-- <fix-image :default-src="iconduring" /> -->
                    <div class="text">
                        <span>返校时间段：</span>
                        <span class="b">{{ detailData.returningStartTime }}至{{ detailData.returningEndTime }}</span>
                    </div>
                </div>
                <div class="list">
                    <!-- <fix-image :default-src="iconduring" /> -->
                    <div class="text">
                        <span>车辆信息：</span>
                        <span class="b">{{ detailData.plateNumber}}</span>
                    </div>
                </div>                  
                <!-- <div class="list">
                    <fix-image :default-src="icondeadline" />
                    <div class="text">
                        <span>报名截止时间：</span>
                        <span class="b">{{ detailData.registerDeadline }}</span>
                    </div>
                </div> -->
                <!-- <div class="list">
                    <fix-image :default-src="iconlibrary" />
                    <div class="text colums">
                        <span class="b">校史馆参观</span><span v-if="detailData.registered">：{{
                            detailData.visitorNumber }}人</span>
                    </div>
                </div>
                <div class="list">
                    <div class="text sub">
                        <span>校史馆参观安排：{{ detailData.visitDate }}</span>
                    </div>
                </div> -->
            </div>
            <div class="group-msg" v-if="!isShanDa()">
                <div class="btit">同行人信息：</div>
                <div class="qmjnb" v-for="(item,index) in detailData.numberOfAccompanyingPersonList" :key="index">
                    <van-row type="flex" justify="space-around" class="am top20">
                        <van-col :span="5">
                            <div class="acc1">
                                姓名：
                            </div>
                        </van-col>
                        <van-col :span="12">
                            <div class="acc1">
                                身份证号：
                            </div>
                        </van-col>
                        <van-col :span="7">
                            <div class="acc1">
                               手机号码：
                            </div>
                        </van-col>                                                
                    </van-row>                    
                    <van-row type="flex" justify="space-around" class="am">
                        <van-col :span="5">
                            <div class="acc">
                                {{item.name}}
                            </div>
                        </van-col>
                        <van-col :span="12">
                            <div class="acc">
                                {{item.idNumber}}
                            </div>
                        </van-col>
                        <van-col :span="7">
                            <div class="acc">
                                {{item.mobile}}
                            </div>
                        </van-col>                                                
                    </van-row>
                    <!-- {{ detailData.scheduled }} -->
                </div>
            </div>
            <div class="group-msg" v-if="isShanDa()">
                <div class="btit">备注：</div>
                <div class="qmjnb">
                    <div class="iwe">{{detailData.remark}}</div>
                </div>
            </div>            
            <div class="group-msg">
                <div class="btit">审核意见：</div>
                <div class="qmjnb">
                    <div class="iwe">{{translateAuditStatus(detailData.auditStatus)}}</div>
                </div>
            </div>
            <div class="opr-area" v-if="detailData.auditStatus == '2' && !isShanDa()">
                <van-button color="var(--theme-color)" round block size="large" icon="edit" @click="toEdit">编
                    辑</van-button>
            </div>
        </div>
    </div>
</template>
<script lang="ts" setup>
import card from './components/card.vue'
import iconlibrary from '@/assets/returnSchoolMonth/icon-library.png'
import icondeadline from '@/assets/returnSchoolMonth/icon-deadline.png'
import iconduring from '@/assets/returnSchoolMonth/icon-during.png'
import { getroupdetail } from '@/api/backSchoolMonth/index'
import {  backSchoolDetailGWY,detailHX,returnSchoolAddUpdate } from '@/api/servive';
import { Toast } from 'vant'
import { useGoBack } from '@/hooks/useGoBack';
import {onMounted} from 'vue';
import { isShanDa } from '@/utils/customizedType'
// import successIcon from '@/assets/appointment/successIcon.png';
const route = useRoute()
const router = useRouter()
const { goBack } = useGoBack()
const detailData = ref<Partial<ResultData>>({})
const groupActId = ref('')

const getDetailHX = async (id: any): Promise<void> => {
    const { code, msg, data } = await detailHX({ id })
    if (code == 200) {
        // sessionStorage.removeItem('groupDetail')
        detailData.value = data
        // sessionStorage.setItem('groupDetail', JSON.stringify(detailData.value))//保存起来，后面的报名或编辑的时候使用
    } else {
        Toast.fail(msg)
    }
}

const getDetail = async (): Promise<void> => {
    const { code, msg, data } = await backSchoolDetailGWY({ id:groupActId.value })
    if (code == 200) {
        // sessionStorage.removeItem('groupDetail')
        detailData.value = data
        // sessionStorage.setItem('groupDetail', JSON.stringify(detailData.value))//保存起来，后面的报名或编辑的时候使用
    } else {
        Toast.fail(msg)
    }
}

const onCancel = () => {
    goBack()
}

const translateAuditStatus =(val:any)=>{
    if(detailData.value.auditOpinion){
        return detailData.value.auditOpinion
    }
    if(val == '0'){
        return '待审核'
    }else if(val == '1'){
        return '审核通过'
    }else if(val == '2'){
        return '审核不通过'
    }
}
const toEdit = () => {
    sessionStorage.setItem('perReserInfo',JSON.stringify(detailData.value))
    router.push({ path: 'reserveBackSchoolInfo', query: { flag: 'edit' } })
    // ,id:detailData.value.id
}
onMounted(()=>{
    let auditStatus = route.query.auditStatus
    if(auditStatus == '1'){
        groupActId.value = route.query.id as string
        getDetail()
    }else{
        getDetailHX(route.query.id)
    }
    
})
</script>
<style lang="less" scoped>
.banner {
    padding: 30px;
    background-color: #fff;
}

.main {
    padding: 30px;

    .group-msg {
        background: #FFFFFF;
        border-radius: 16px;
        padding: 32px;
        margin-bottom: 24px;

        .list {
            display: flex;
            align-items: center;

            img {
                width: 32px;
                height: 32px;
            }

            .text {
                margin-left: 20px;
                line-height: 56px;
                color: #666;

                .b {
                    color: #333;
                }

                &.colums {
                    margin-top: 10px;
                }

                &.sub {
                    padding-left: 32px;
                }
            }
        }

        .btit {
            font-size: 32px;
            font-weight: 500;
        }

        .qmjnb {
            // padding: 24px 0;
            // height: 46px;
            width: 100%;
            line-height: 46px;
            .iwe{
                margin-top: 20px;
                font-size: 30px;
                color: #111;
            }
            .am{
                margin-top: 10px;
                // background-color: #999999;
                color:#666;
                .acc1{
                    font-weight: 700;
                    color: #333;
                }
            }
            .top20{
                margin-top: 20px;
            }
        }
    }

    .opr-area {
        display: flex;
        justify-content: space-around;
        padding: 20px;
        margin-top: 60px;

        .van-button {
            flex: 1;
            margin: 20px;
        }
    }
}
</style>