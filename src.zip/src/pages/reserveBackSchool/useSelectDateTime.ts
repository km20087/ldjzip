import { returnSchoolConfigStore } from '@/store';
import { storeToRefs } from 'pinia';

type Columns = {
  text: string;
  children?: Columns[];
};

export function useSelectDateTime() {
  const { appointmentTimePeriod, banAppointmentTimePeriod } = storeToRefs(
    returnSchoolConfigStore()
  );
  /**可选时间段数组 */
  let timeColumns: Columns[] = handleData(appointmentTimePeriod.value, genHourColumns).flat(1);
  /**可选时间段对象 */
  const timeColumnsObj = formatColumnsToObject(timeColumns);

  /**禁止日期时间段 */
  const banDateObj: Record<string, Record<string, Set<string>>> = {};
  handleData(banAppointmentTimePeriod.value, genFilterDateObj);
  /**禁止日期数组 */
  const banDateArr = Object.keys(banDateObj);

  /**
   * 对每项数据进行处理
   * @param data 原始可选时间段或禁止日期数据
   * @param fn 处理方法
   * @returns 
   */
  function handleData(data: string[], fn: Function) {
    return data.map((item) => fn(...item.split('--')));
  }

  /**
   * 生成过滤的日期、时间段
   */
  function genFilterDateObj(start: string, end: string) {
    let [startDateStr, startDateTime] = start.split(' ');
    let [endDateStr, endDateTime] = end.split(' ');
    startDateStr = startDateStr.replace(/-/g, '/');
    endDateStr = endDateStr.replace(/-/g, '/');

    let startDate = new Date(startDateStr);
    let endDate = new Date(endDateStr);

    // 处理边界值-若结束时间为某天零点， 及为前一天的23:59
    // if (endDateTime == '00:00') {
    //   endDate.setDate(endDate.getDate() - 1)
    //   endDateStr = formatDate(endDate)
    //   endDateTime = '23:59'
    // }

    // 判断开始日期与结束日期的间隔，生成不可用的时间段数据
    let day = (endDate.getTime() - startDate.getTime()) / 1000 / (60 * 60 * 24);
    let startDay = startDate.getDate();
    for (let i = 0; i <= day; i++) {
      let date = formatDate(new Date(new Date(startDate).setDate(startDay + i)));
      let hourColumns = genHourColumns(
        i == 0 ? startDateTime : '00:00',
        i == day ? endDateTime : '23:59'
      );
      let obj = formatColumnsToObject(hourColumns);
      banDateObj[date] = banDateObj[date] || {};
      for (let [hour, minutes] of Object.entries(obj)) {
        // banDateObj[date][hour] = Object.hasOwn(banDateObj[date], hour)
        banDateObj[date][hour] = Object.prototype.hasOwnProperty.call(banDateObj[date], hour)
          ? new Set([...banDateObj[date][hour], ...minutes])
          : new Set(minutes);
      }
    }
  }

  /**将时间选项转成以时为key, 分为value的对象 */
  function formatColumnsToObject(arr: Columns[]) {
    return arr.reduce(
      (obj: Record<string, Set<string>>, { text, children = [] }) => (
        (obj[text] = new Set(children.map(({ text }) => text))), obj
      ),
      {}
    );
  }

  /**格式转化 */
  function formatDate(date: Date) {
    return `${date.getFullYear()}/${fillZero(date.getMonth() + 1)}/${fillZero(date.getDate())}`;
  }

  /**
   * 当日期改变，更新可选时间段下拉数据
   * @param {*} chooseDate
   * @returns
   */
  function handleDateChange(chooseDate: string): Columns[] {
    chooseDate = chooseDate.replace(/-/g, '/');
    return banDateArr.includes(chooseDate) ? filterCommonTimeData(chooseDate) : timeColumns;
  }

  /**过滤不可选日期、时间段 */
  function filterCommonTimeData(date: string) {
    let result = [];
    for (let [hour, minutes] of Object.entries(timeColumnsObj)) {
      // if (Object.hasOwn(banDateObj[date], hour)) {
      if (Object.prototype.hasOwnProperty.call(banDateObj[date], hour)) {
        // if (hour in banDateObj[date]) {
        minutes = difference(minutes, banDateObj[date][hour]);
      }
      if (minutes.size == 0) continue;
      result.push({
        text: hour,
        children: [...minutes].map((item) => ({ text: item })),
      });
    }
    return result.sort((a, b) => Number(a.text) - Number(b.text));
  }

  function difference<T>(setA: Set<T>, setB: Set<T>) {
    const result = new Set(setA)
    for (const value of setB) {
      result.delete(value)
    }
    return result
  }

  // 08:30 - 12:00
  /**生成时的可选项 */
  function genHourColumns(start: string, end: string): Columns[] {
    let [startHour, startMinute] = start.split(':').map((item) => Number(item));
    let [endHour, endMinute] = end.split(':').map((item) => Number(item));
    let columns = [];
    for (let i = startHour; i <= endHour; i++) {
      columns.push({
        text: fillZero(i),
        children: genMinuteColumns(
          i == startHour ? startMinute : Number('00'),
          i == endHour ? endMinute : Number('59')
        ),
      });
    }
    return columns;
  }

  /**生成分的可选项目 */
  function genMinuteColumns(startMinute: number, endMinute: number): Columns[] {
    return Array.from({ length: endMinute - startMinute + 1 }, (_, i) => ({
      text: fillZero(startMinute + i),
    }));
  }

  /**补零 */
  function fillZero(val: number) {
    return val >= 10 ? val.toString() : `0${val}`;
  }

  return {
    handleDateChange
  };
}
