<template>
  <van-sticky>
    <van-nav-bar title="预约返校" left-arrow @click-left="onClickLeft" />
  </van-sticky>
  <van-form class="form-wrap" @failed="onFailed" @submit="onSubmit" input-align="right" error-message-align="right">
    <!-- <van-field label="返校事由" required v-model="actForm.returningReason" name="returningReason" placeholder="请选择返校事由"
      is-link @click="showReasons = true" :rules="[{ required: true, message: '请选择返校事由' }]" /> -->
    <!-- <van-popup v-model:show="showReasons" position="bottom" round>
      <van-picker :columns="reasonsList" @cancel="showReasons = false" @confirm="onConfirmRea" />
    </van-popup> -->
    <van-field v-if="isShenYangYaoKeDaXueFlag" v-model="actForm.returningDate" readonly required name="returningDate" label="返校日期" placeholder="点击选择日期"
     :rules="[{ required: true, message: '返校日期不能为空' }]"  />
    <!-- <van-popup v-model:show="showCalendarDate" position="bottom" round>
      <van-datetime-picker v-model="currentDate" type="date" title="选择日期" :min-date="minDate" :max-date="maxDate"
        @confirm="onConfirmDate" @cancel="showCalendarDate = false" />
    </van-popup> -->
    <van-field :label="isShenYangYaoKeDaXueFlag?'预约人':'姓名'" v-model="actForm.name" name="name" maxlength="80" placeholder="请输入姓名" disabled/>    
    <van-field :label="isShenYangYaoKeDaXueFlag?'联系电话':'手机号'" v-model="actForm.mobile" name="mobile" maxlength="80" placeholder="请输入手机号" disabled/>    
    <van-field label="返校期队/年级" 
      v-model="actForm.schoolEndYear" 
      name="schoolEndYear" 
      maxlength="80"  
      @click="startTimeFlag = isShenYangYaoKeDaXueFlag && true " 
      :disabled="!isShenYangYaoKeDaXueFlag"
    />
    <van-field label="院系" v-if="!isShenYangYaoKeDaXueFlag" v-model="actForm.collegeName" name="collegeName" maxlength="80" placeholder="" disabled/>    
    <van-field
      v-model="actForm.collegeName"
      is-link
      v-else
      readonly
      name="collegeName"
      label="院系"
      required
      :placeholder="'请选择院系'"
      :rules="[{ required: true, message: '请输入院系' }]"
      @click="columnShow('collegeName', '')"
    />    
    
    <van-field label="专业" v-if="!isShenYangYaoKeDaXueFlag" v-model="actForm.majorName" name="remark" maxlength="80" placeholder="" disabled/>
    <van-field
      v-model="actForm.majorName"
      is-link
      readonly
      v-else
      name="majorName"
      label="专业"
      required
      :placeholder="'请选择专业'"
      :rules="[{ required: true, message: '请输入专业' }]"
      @click="columnShow('majorName', actForm.college)"
    />

    <van-field v-model="actForm.returningStartTime" readonly label-width="150px" required name="returningStartTime"
      label="返校时段（始）" placeholder="点击选择时间" @click="show2cli()" :rules="stimeRules" />
    <van-popup v-model:show="showCalendar2" position="bottom" round>
      <van-picker v-model="currentTime" :columns="timeColumns" title="选择开始时间" @confirm="onConfirm2"
        @cancel="showCalendar2 = false"></van-picker>
    </van-popup>

    <van-field v-model="actForm.returningEndTime" readonly required label-width="150px" name="returningEndTime" 
      label="返校时段（终）" placeholder="点击选择时间" @click="show3cli" :rules="etimeRules" />
    <van-popup v-model:show="showCalendar3" position="bottom" round>
      <van-picker v-model="currentTime" :columns="timeColumns" title="选择结束时间" @confirm="onConfirm3"
        @cancel="showCalendar3 = false"></van-picker>
    </van-popup>
    <van-field label="进校方式" v-if="!isShenYangYaoKeDaXueFlag" v-model="entryMethod" disabled required name="entryMethod" maxlength="80" placeholder="" />
    <van-field v-if="!isShenYangYaoKeDaXueFlag" label="预约事项" v-model="actForm.returningReason" required :rules="[{ required: true, message: '请输入预约事项' }]" name="returningReason" maxlength="80" placeholder="请输入预约事项" />
    <!-- 通过 validator 返回错误提示 -->
    <!-- <van-field label="联系方式" required v-model="actForm.contactInformation" name="contactInformation" placeholder="请输入联系方式"
      :rules="ExamContact" /> -->
    <van-field :label="isShenYangYaoKeDaXueFlag?'返校人数':'同行人数'" required v-model="actForm.numberOfAccompanyingPersons"
      name="numberOfAccompanyingPersons">
      <template #input>
        <van-stepper v-model="actForm.numberOfAccompanyingPersons" default-value="0" min="0"
          :max="accompanyingPersonsLimit" @plus="changeNum(1)" @minus="changeNum(0)" />
      </template>
    </van-field>
    <van-cell :title="isShenYangYaoKeDaXueFlag?'返校人数信息':'同行人信息'" required v-if="partnerList.length > 0">
      <template #label>
        <div class="">
          <van-row gutter="1" class="partner-list" v-for="(item, index) in partnerList" :key="index">
            <img src="@/assets/img/del_icon@2x.png" width="10" height="10" class="del-icon" alt=""
              @click="popOne(index)" />
            <van-col span="5"
              ><van-field
                input-align="center"
                error-message-align="center"
                v-model="item.name"
                type="text"
                placeholder="姓名"
                :rules="[{ required: true, message: '请输入' }]"
              ></van-field
            ></van-col>
            <van-col span="12"
              ><van-field
                input-align="center"
                error-message-align="center"
                v-model="item.idNumber"
                type="text"
                placeholder="身份证号"
                :rules="checkID"
              ></van-field
            ></van-col>
            <van-col span="7"
              ><van-field
                input-align="center"
                error-message-align="center"
                v-model="item.mobile"
                type="text"
                placeholder="手机号码"
                :rules="checkOhone"
              ></van-field
            ></van-col>
          </van-row>
        </div>
      </template>
    </van-cell>
    <van-field label="车辆信息"  v-model="actForm.plateNumber" name="plateNumber" placeholder="请输入车牌号" />    
    <van-field v-if="!isShenYangYaoKeDaXueFlag" label="备注"  v-model="actForm.remark" name="remark" maxlength="80" placeholder="请输入备注" />
      <van-field
      v-else
        v-model="actForm.remark"
        rows="6"
        autosize
        label="返校活动安排"
        type="textarea"
        maxlength="100"
        placeholder="请输入返校活动安排"
        show-word-limit
      />    
    <div class="wenxin">
      温馨提示：<br />
      <br />
      <span v-if="schoolCode == SchoolCode.ShenYangYaoKeDaXue" class="mar20">具体事宜请联系校友办公室晁璇，电话:15841418772。</span>
      
      <span v-if="schoolCode !== SchoolCode.ShenYangYaoKeDaXue">请保持车辆随行人员与申请随行人员一致，车辆免费入校时间与申请入校时间一致，请勿过久停留</span>
      <!-- <span>1.入校：黄河路校区南北院正门、西山湖校区正门，其他出入口不能入校。<br />
        &emsp;&emsp;入校时请配合安保人员核验身份。<br /></span>
      <span>2.出校：可从任一校门出校。</span>
      <br /> -->
      <!-- <span>3.返校不可选时段：<span v-for="(item, index) in banTimeArr" :key="index">{{ item.start }}--{{ item.end
      }},<br /></span></span> -->
    </div>
    <div style="margin: 16px">
      <van-button :disabled="loading" round block type="primary" native-type="submit">
        提交
      </van-button>
    </div>
  </van-form>
  <van-popup v-model:show="showPicker" position="bottom">
    <van-picker :columns="columns" ref="showAllTitle" class="wop" :class="{'ani-style':styleAn}" @change="showAllText" @confirm="onConfirmPicker" @cancel="showPicker = false" >
    </van-picker>
  </van-popup>  
  <van-popup v-model:show="startTimeFlag" position="bottom">
    <van-picker :columns="timeList" title="请选择年份" show-toolbar :default-index="select" @confirm="yearConfirmStart"
      @cancel="startTimeFlag = false" />
  </van-popup>  
  <!-- <van-popup v-model:show="agreeShow" position="bottom" style="width: 100%">
    <agree @agree-fun="agreeFun" />
  </van-popup> -->
</template>
<script lang="ts" setup>
import { onBeforeMount, onMounted, ref,getCurrentInstance } from 'vue';
import { Toast } from 'vant';
import { useRouter } from 'vue-router';
import { backSchool, getappAuditList,returnSchoolAddUpdate } from '@/api/servive';
import { fommatDate } from '@/utils/fommatDate';
import ApiDept from '@/api/common';
// import agree from './agree.vue';
import { returnSchoolConfigStore } from "@/store"
import { storeToRefs } from 'pinia';
import {  getRegisterDetail, } from '@/api/backSchoolMonth'
import { useSelectDateTime } from './useSelectDateTime'
import { getSchoolCode, getSchoolId, getUserStatus } from '@/utils';
import { SchoolCode } from "@/constants";
import {isShenYangYaoKeDaXue} from '@/utils/customizedType';
import ApiMy from '@/api/my';
import { formatDate, formatDateTime } from '@/utils/tool/time';

type Columns = {
  text: string;
  children?: Columns[];
};
const { appointmentTimePeriod, banAppointmentTimePeriod, accompanyingPersonsLimit } = storeToRefs(returnSchoolConfigStore())
const timeColumns = ref<Columns[]>([])
const { handleDateChange } = useSelectDateTime()

const $router = useRouter();
const $route = useRoute();
const onClickLeft = () => history.back();
const agreeShow = ref(false);
const currentDate = ref(new Date());
const currentTime = ref(new Date().getHours() + ':' + new Date().getMinutes());
const minDate = ref(new Date(2020, 0, 1));
const maxDate = ref(new Date(2030, 10, 1));
const minHour = ref<string>('')
const maxMinute = ref<string>('')
const minMinute = ref<string>('')
const maxHour = ref<string>('')
const banDate = ref<string[]>([])
const visitorFlag = ref(false);
const loading = ref(false);
const steValue = ref(0);
const isWXEnv = ref(false);
const reserveDate = ref('')
const startTimeFlag = ref(false);
const isShenYangYaoKeDaXueFlag = isShenYangYaoKeDaXue()
let actForm = ref({
  collegeName: '',
  college: '',
  majorName:"",
  major:"",
  name:'',
  mobile:"",
  schoolEndYear:"",
  contactInformation: '',
  description: '',
  numberOfAccompanyingPersons: 0,
  remark: '',
  returningEndTime: '',
  visitingUnit: '',
  returningReason: '',
  returningStartTime: '',
  numberOfAccompanyingPersonList: [] as partner[],
  deptName: '',
  userName: '',
  showText: '',
  campusUserId: '',
  visitorName: '',
  visitorIdNumber: '',
  plateNumber: '',
  campusUserEmail: '',
  campusUserName: '',
  returningDate: '',
  entryMethod:"1",//进校方式,1--二维码进入学校
  returningPersonnelName:""
});

const select = ref('');
const timeList = <any>reactive([]);
const dateValue = ref('');
const columns = ref<any[]>([])
const showAllTitle = ref()
const instance = getCurrentInstance()
const showPicker = ref(false)
const columnShowFlag = ref('')
const entryMethod = ref('二维码进入学校')
enum sexType {
  man = '1',
  woman = '0'
}
interface partner {
  name: string;
  idNumber: string;
  mobile: string;
}
const shandaFlag = ref(false);
const partnerList = ref<partner[]>([]);
const showReasons = ref(false);
const showCalendarDate = ref(false);
const showCalendar2 = ref(false);
const showCalendar3 = ref(false);
const showRelation = ref(false);
const showRelationInput = ref<boolean>(false)
const showSex = ref<boolean>(false)
const showInterviewee = ref(false);
let reasonsList = ref(['办理档案业务', '拜访老师', '参观校园']);
let relationshipList = ref(['父母', '子女', '亲属', '其他']);
let sexList = ref<Array<any>>([{ value: '0', label: '女' }, { value: '1', label: '男' }])
let intervieweeList = ref<any[]>([]);
let partnerIdx = ref('');
let sexIndex = ref<string>('')
const modle = ref('add')
interface timeType {
  start: string
  end: string
}
const schoolCode = getSchoolCode();
const getBanTime = (): timeType[] => {
  let res = new Array<timeType>
  for (let i = 0; i < banAppointmentTimePeriod.value.length; i++) {
    let [start, end] = banAppointmentTimePeriod.value[i].split('--')
    res.push({ start, end })
  }
  return res
}
const banTimeArr = ref<timeType[]>(getBanTime())
const styleAn = ref(false)
//自定义校验
const stimeRules = <any>[
  { required: true, message: '开始时间不能为空' },
  {
    validator: (value: any) => {
      for (let i = 0; i < banTimeArr.value.length; i++) {
        if ((actForm.value.returningDate + ' ' + value) > banTimeArr.value[i].start && (actForm.value.returningDate + ' ' + value) < banTimeArr.value[i].end) {
          return false
        }
      }
    },
    message: `当前日期该时段不可选`,
    trigger: ['onChange', 'onBlur'],
  },
];
const etimeRules = <any>[
  { required: true, message: '结束时间不能为空' },
  {
    validator: (value: any) => {
      if (value < actForm.value.returningStartTime) {
        return false;
      }
    },
    message: '结束时间不能早于开始时间',
    trigger: ['onChange', 'onBlur'],
  },
  {
    validator: (value: any) => {
      for (let i = 0; i < banTimeArr.value.length; i++) {
        if ((actForm.value.returningDate + ' ' + value) > banTimeArr.value[i].start && (actForm.value.returningDate + ' ' + value) < banTimeArr.value[i].end) {
          return false
        }
      }
    },
    message: `当前日期该时段不可选`,
    trigger: ['onChange', 'onBlur'],
  },
];
const ExamContact = <any>[
  { required: true, message: '请输入联系方式' },
  {
    validator: (value: any) => {
      const mobileReg =
        /^(([1][3,4,5,7,8,9]\d{9})|([0]\d{10,11})|(\d{7,8})|(\d{4}|\d{3})-(\d{7,8}))$/;
      const phoneReg = /^\d{3}-\d{8}|\d{4}-\d{7}$/;
      if (value.length === 11) {
        if (!mobileReg.test(value)) return false;
      } else if (value.length === 12) {
        if (!phoneReg.test(value)) return false;
      }
    },
    message: '请输入正确的手机号码或者固话号码（固话格式：区号-号码）',
    trigger: ['onBlur'],
  },
];
const checkID = <any>[
  { required: true, message: '请输入' },
  {
    validator: (value: any) => {
      const idReg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
      if (!idReg.test(value)) return false;
    },
    message: '格式有误',
    trigger: ['onBlur'],
  },
];
const checkOhone = <any>[
  { required: true, message: '请输入' },
  {
    validator: (value: any) => {
      const idReg = /^(([1][3,4,5,7,8,9]\d{9})|([0]\d{10,11})|(\d{7,8})|(\d{4}|\d{3})-(\d{7,8}))$/;
      if (!idReg.test(value)) return false;
    },
    message: '格式有误',
    trigger: ['onBlur'],
  },
];
const getYearData = () => {
  var nowTime = new Date(dateValue.value);
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  for (let i: number = 1900; i < 2035; i++) {
    timeList.push(i);
  }

  let years = formatDate(new Date(year, month, day));
  let Year = years.slice(0, 4);

  select.value = timeList.indexOf(Number(Year));
};
const getCurrentYear = () => {
  var nowTime = new Date();
  let year = nowTime.getFullYear();
  let month = nowTime.getMonth();
  let day = nowTime.getDate();
  let dateValue1 = '';
  dateValue1 = formatDate(new Date(year, month, day));
  dateValue.value = String(dateValue1.slice(0, 4));
  // this.signs(this.dateValue)
};

const yearConfirmStart = (value: string) => {
  actForm.value.schoolEndYear = value.toString();
  startTimeFlag.value = false;
};

const getViewList = async () => {
  const { code, data, msg } = await getappAuditList({
    roleCode: 'SCHOOL_LEADER',
  });
  if (code == 200) {
    intervieweeList.value = data;
    intervieweeList.value.map((item) => {
      return (item.showText = item.deptName + '-' + item.userName);
    });
  } else {
    Toast.fail(msg);
  }
};
const showDiaByShowInterviewee = () => {
  if (!shandaFlag.value) {
    showInterviewee.value = true;
  }
};
const changeNum = (s: any) => {
  console.log(actForm.value.numberOfAccompanyingPersons);
  if (s == 1) {
     partnerList.value.push({ name: "", idNumber: "", mobile: "" });
  } else if (s == 0) {
    partnerList.value.pop();
  }
};
const popOne = (idx: number) => {
  partnerList.value.splice(idx, 1);
  // actForm.value.numberOfAccompanyingPersons = String(partnerList.value.length);
  actForm.value.numberOfAccompanyingPersons = partnerList.value.length;
};

const filterTime = (t: any, options: any) => {


  return options
}

const columnShow = (val: string, id: string) => {
  console.log('columnShow')
    columnShowFlag.value = val
    if (val === 'collegeName') {//!!formData.classes && val === 'collegeName'
      initDept().then(() => {
        showPicker.value = true;
        showAllText()
      });
    } else if (actForm.value.college && val == 'majorName') {
      initMajor(id);//id, false
      showPicker.value = true;
    }

}
const initDept = async () => {
    let schoolId = getSchoolId() as string;
    const { data, msg, code } = await ApiDept.deptList({
      schoolId: schoolId,
    });
    columns.value = [];
    for (let i in data) {
      columns.value.push({ text: data[i].deptName, deptId: data[i].deptId });
    }
}

const showAllText = () =>{
  let o = new ResizeObserver((e)=>{
    console.log('size',e)
  })
  o.observe(document.querySelector('.form-wrap') as Element )
  let index = showAllTitle.value.getColumnIndex(0) as number
  let selectedItems:any = document.querySelectorAll('.van-picker-column__item')
    selectedItems.forEach((item:any,ix:Number) => {
    if(index == ix){
      let child:any = item.querySelector('.van-ellipsis')
      if (child.scrollWidth > item?.offsetWidth) { // 判断child文字宽度
        styleAn.value = true
      } else {
        styleAn.value = false
      }
      instance?.proxy?.$forceUpdate()
    }
  })
}

const onConfirmPicker = (val:any)=>{
  if(columnShowFlag.value == 'collegeName'){
    actForm.value.college = val.deptId;
    actForm.value.collegeName = val.text;
  }else if(columnShowFlag.value == 'majorName'){
    actForm.value.major = val.deptId;
    actForm.value.majorName = val.text;
  }else{

  }
    showPicker.value = false;


}
  

const onConfirmRea = (value: any) => {
  actForm.value.returningReason = value;
  showReasons.value = false;
};

const onFailed = (errorInfo: any) => {
  console.log('failed', errorInfo);
};
const onConfirm2 = (date: any) => {
  if (date) {
    actForm.value.returningStartTime = date.map((item: any) => item.text).join(':');
  }

  showCalendar2.value = false;
};
const onConfirmDate = (date: any) => {
  const returningDate = fommatDate(date, 'yyyy-MM-dd');
  actForm.value.returningDate = returningDate
  timeColumns.value = handleDateChange(returningDate)
  console.log(returningDate, timeColumns.value, "ppp");

  if (!timeColumns.value || !timeColumns.value.length) {
    Toast({
      message: '当天不可预约，请选择其他日期！',
      icon: 'none'
    });
    return
  }
  showCalendarDate.value = false;
};

const initTimeColumns = (date: string)=>{
  timeColumns.value = handleDateChange(date)
  console.log('initTimeColumns',timeColumns.value)
}

const showRelationFun = (idx: any) => {
  showRelation.value = true;
  partnerIdx.value = idx;
};
const showSexFun = (idx: any) => {
  sexIndex.value = idx
  showSex.value = true
};

const onConfirmRelIn = () => {
  showRelationInput.value = false
}

const initCollage = ()=>{

}

const initMajor =async (id:string)=>{
      let schoolId = getSchoolId() as string;
      const { data, msg, code } = await ApiDept.deptList({
      schoolId: schoolId,
      parentId: id,
      allDept:1
    });
    if(code == 200){
      columns.value = [];
      for (let i in data) {
        columns.value.push({ text: data[i].deptName, deptId: data[i].deptId });
      }
    }
}

const showDate = () => {
  let dateNow = new Date();
  minDate.value = new Date(fommatDate(dateNow, 'yyyy-MM-dd'));
  showCalendarDate.value = true;
  // console.log(minDate.value);
  // return;
};
const show2cli = () => {
  showCalendar2.value = true;
};
const show3cli = () => {
  showCalendar3.value = true;
};
const onConfirm3 = (date: any) => {
  if (date) {
    actForm.value.returningEndTime = date.map((item: any) => item.text).join(':');
  }
  showCalendar3.value = false;
};
const onConfirmViewee = (value: any) => {
  actForm.value.deptName = value.deptName;
  actForm.value.userName = value.userName;
  actForm.value.showText = value.showText;
  actForm.value.campusUserId = value.campusUserId;
  if (shandaFlag.value) {
    actForm.value.campusUserName = value.userName;
  }
  showInterviewee.value = false;
};
const agreeFun = () => {
  agreeShow.value = false;
};
const onSubmit = async (val: FormData) => {
  if(isShenYangYaoKeDaXueFlag){
    actForm.value.returningReason = '预约返校'
  }
  if (!isWXEnv.value && shandaFlag.value) {
    Toast.fail('请在微信环境下提交预约返校申请');
    return;
  }
  actForm.value.numberOfAccompanyingPersonList = partnerList.value;
  // console.log(actForm.value)
  loading.value = true;
  let api:any 
  if( modle.value == 'add'){
    api = backSchool
  }else{
    api = returnSchoolAddUpdate
    actForm.value.mobile = actForm.value.contactInformation
    actForm.value.name =  actForm.value.returningPersonnelName
  }
  // console.log('onSubmit--actForm.value',actForm.value)
  // return
  const { code, data, msg } = await api({
    ...actForm.value,
  });
  if (code == 200) {
    // Toast.success("预约返校申请提交成功");

    $router.push({ name: 'returnSuccess' });

    loading.value = false;
  } else {
    // $router.push({ name: 'returnFailed' });
    Toast.fail(msg);
    loading.value = false;
  }
};

const WeekDay = (val:number)=>{
    const CNum = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九']
    let str = '周'
    str = str + CNum[val]
    return str
}

const initReserveDate = ()=>{
    // console.log('initReserveDate',$route)
    let date = new Date(Number($route?.query.date))
    reserveDate.value = date.getMonth()+1+'月'+date.getDate() + '('+WeekDay(date.getDay())+")"
    // console.log('initReserveDate', date.getFullYear()+'-'+date.getMonth()+1+'-'+date.getDate())
    let year =  date.getFullYear()
    let month = date.getMonth()*1>9?String(date.getMonth()*1+1):'0'+String(date.getMonth()*1+1)
    let dateNum = date.getDate()>10?String(date.getDate()):'0' + String(date.getDate())
    // actForm.value.returningDate = date.getFullYear()+'-'+ (date.getMonth()*1+1) +'-'+date.getDate()
    const returningDate = fommatDate(date, 'yyyy-MM-dd');
    actForm.value.returningDate = returningDate
    timeColumns.value = handleDateChange(returningDate)
}

const initInfo =async ()=>{
    const { data, msg, code } = await ApiMy.baseInfo({});
    actForm.value.name = data.name
    actForm.value.mobile = data.mobileDetail
    actForm.value.contactInformation = data.mobileDetail
    actForm.value.schoolEndYear = data.schoolEndYear
    actForm.value.collegeName = data.collegeName
    actForm.value.college = data.collegeId
    actForm.value.majorName = data.majorName
    actForm.value.major = data.major
}

onBeforeMount(async() => {
//   let isAgree = sessionStorage.getItem('backSchoolAgree');
//   if (isAgree !== '1') {
//     agreeShow.value = true;
//   } else {
//     agreeShow.value = false;
//   }
  if($route?.query.flag == 'edit'){
    actForm.value = JSON.parse(sessionStorage.getItem("perReserInfo") as string)
    // let {code,msg,data} =await getRegisterDetail({id:$route?.query.id})
    if(!!actForm.value.returningDate)initTimeColumns(actForm.value.returningDate)
    partnerList.value = actForm.value.numberOfAccompanyingPersonList
    actForm.value.name = actForm.value.returningPersonnelName
    actForm.value.mobile = actForm.value.contactInformation
    modle.value = 'edit'
  }else{
    initInfo()
    initReserveDate()
    modle.value = 'add'
  }
  
    
});

onMounted(async () => {
  if(isShenYangYaoKeDaXueFlag){
    getCurrentYear();
    getYearData();
  }
  // let str = 'mozilla/5.0 (iphone; cpu iphone os 17_3_1 like mac os x) applewebkit/605.1.15 (khtml, like gecko) mobile/15e148 micromessenger/8.0.43(0x18002b2f) nettype/4g language/zh_cn'
  isWXEnv.value = navigator.userAgent.toLowerCase().includes('micromessenger');
  if (schoolCode == SchoolCode.ShanDa) {
    shandaFlag.value = true;
    actForm.value.showText = '陈仕达';
    actForm.value.campusUserName = '陈仕达';
    actForm.value.campusUserId = SchoolCode.ShanDa;
    actForm.value.campusUserEmail = 'chensd@stu.edu.cn';
    if (!isWXEnv.value) {
      Toast.fail('请在微信环境下提交预约返校申请');
    }
  }
//   getViewList();

});
</script>
<style lang="less" scoped>
.upload-text {
  font-size: 28px;
  color: #004dff;
}

.partner-list {
  position: relative;
  margin-bottom: 20px;

  .del-icon {
    position: absolute;
    top: -8px;
    right: -8px;
    z-index: 99;
  }

  .van-cell {
    background: #fbfbfb;
    padding-left: 10px;
    padding-right: 10px;
  }
}

.van-field__control {
  font-size: 20px !important;
}

.form-wrap {
  --van-field-label-width: 6.9em;
}

.wenxin {
  padding: var(--van-cell-vertical-padding) var(--van-cell-horizontal-padding);
  font-weight: 500;

  span {
    font-size: 24px;
    color: #999;
  }
}

.relInPop {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
}
.mar20{
  margin-bottom: 10px;
  display: inline-block;
}
</style>
