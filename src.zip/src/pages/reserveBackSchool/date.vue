<template>
    <div class="con">
        <van-nav-bar v-if="schoolCode == SchoolCode.ShanDa || schoolCode == SchoolCode.ShenYangYaoKeDaXue" title="预约返校" left-text="" left-arrow @click-left="goBack" />
        <van-sticky v-else>
            <nav-bar title="预约返校" left-arrow @click-left="goBack" />
        </van-sticky>            
        <dateSure @getBackSchoolDate="getBackSchoolDate" @addDataListSD="addDataListSD">

        </dateSure>
        <div class="showTips">
            <div class="detailTips" v-if="schoolCode !== SchoolCode.ShenYangYaoKeDaXue">
                <div class="title">
                    {{schoolCode == SchoolCode.ShanDa?'汕头大学校友返校温馨提示':'预约说明'}}
                    <!-- 汕头大学校友返校温馨提示 -->
                </div>
                
                <div class="con" v-if="schoolCode == SchoolCode.ShanDa">
                    <div class="part1">
                       
                    </div>
                    <div class="part2">
                        <div>1.学校热诚欢迎校友们回到母校，重温曾经度过的青春岁月；</div>
                        <div>2.请提前2天提交返校申请信息，如提交后未及时收到反馈，
                            可电话联系校友办陈老师（联系电话：86502180/13192173317）。
                            注意，在当前申请未过期前，请勿重复提交新的申请，以免申请信息出现错乱。</div>
                        <div>3.食堂就餐可使用微信/支付宝支付等方式，就餐时请遵守餐厅就餐秩序；</div>
                        <div>4.校园里的一草一木、一砖一瓦，都承载着校友们共同的记忆与情感，请共同维护良好的校园秩序。</div>
                    </div>

                </div>     
                <div v-else-if="schoolCode == SchoolCode.ShenYangYaoKeDaXue">
                </div>          
                <div class="con" v-else>
                    <div class="part1">
                        预约返校请仔细阅读以下说明:
                    </div>                    
                    <div class="part2" >
                        <div>1.预约返校仅限校友本人申请</div>
                        <div>2.校友返校预约需要申请，经人工审核通过后方可进校</div>
                        <div>3.同一人同一天内只需提交一次申请，请勿重复申请;</div>
                        <div v-if="schoolCode == SchoolCode.GuangWenYi">4.如有疑问，欢迎来电咨询020-37247500</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="buttonBottom">
            <van-button round v-if="schoolCode == SchoolCode.ShanDa || schoolCode == SchoolCode.ShenYangYaoKeDaXue" class="sure" @click="onSubmitSD">
                提交
            </van-button>            
            <van-button round v-else class="cancel" @click="goBack">
                取消
            </van-button>
            <van-button round  class="submit" @click="submitApply">
                预约记录
            </van-button>            
        </div>
    </div>
</template>
<script lang="ts" setup>
import { reactive, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useGoBack } from '@/hooks/useGoBack';
import { getSchoolCode } from '@/utils';
import { SchoolCode } from "@/constants";
import {isShenYangYaoKeDaXue} from '@/utils/customizedType';
import dateSure from "./components/dateSure.vue"
import { Toast } from 'vant';
const { goBack } = useGoBack()
const router = useRouter();
const dateVal = ref(0)
const dateTime = ref('')
let schoolCode = getSchoolCode();
const isShenYangYaoKeDaXueFlag = isShenYangYaoKeDaXue()
const dateListSD = <any>ref([])
const getBackSchoolDate = (val:number) =>{
    dateVal.value = val
    console.log('getBackSchoolDate',dateVal.value)
}   
const jumpBackSD = (val:any)=>{
    router.push({name: 'backSchool',query:{returningStartTime:val.returningStartTime,returningEndTime:val.returningEndTime}})
}

const addDataListSD = (val:any[]) =>{
    dateListSD.value = val
    // console.log('addDataListSD',dateListSD.value)
}

const onSubmitSD = ()=>{
    // console.log('onSubmitSD',dateListSD.value)
    // return
    if(dateListSD.value.length == 1){
        router.push(
            {
            name: 'backSchool',
            query:{
                returningStartTime:dateListSD.value[0].date,
                returningEndTime:dateListSD.value[0].date
                }
            }
        )
    }else if(dateListSD.value.length == 2){
        router.push(
            {
            name: 'backSchool',
            query:{
                returningStartTime:dateListSD.value[0].date,
                returningEndTime:dateListSD.value[1].date
                }
            }
        )
    }else{
        Toast.fail('请选择返校日期')
    }
    
}

const WeekDay = (val:number)=>{
    const CNum = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九']
    let str = '周'
    str = str + CNum[val]
    return str
}

const submitApply = () =>{
    router.push({name:"reserveBackSchoolRecord"})
}

</script>
<style lang="less" scoped>
.con{
    // width: 100%;
    position: relative;
    // background-color: #ffffff;
    font-family: PingFang-SC-Medium, PingFang-SC;
    // height: 100vh;
    .showTips{
        padding-top: 15px;
        box-sizing: border-box;
        width: 100%;
        background-color: #fff;
        min-height: 690px;
        // margin-bottom: 60px;
        .detailTips{
            background-color: #ffffff;
            box-sizing: border-box;
            width: 100%;
            padding: 40px 30px;
            .title{
                font-size: 36px;
                color:#222222;
            }
            .con{
                width: 100%;
                .part1{
                    margin-top: 40px;
                    color:#666666
                }
                .part2{
                    color:#222222;
                    .breakSpaces{
                        // white-space: break-spaces;
                        // min-width: 600px;
                        word-break: break-all;
                    }
                }
            }
        }


    }
    .buttonBottom{
        position: fixed;
        bottom: 60px;
        width: 100%;
        padding: 0 30px;
        // bottom: 60px;
        box-sizing: border-box;
        display: flex;
        justify-content: space-between;
        .sure{
            width: 330px;
            height: 80px;
            background: #f2f2f2;
            color: #222222;
            font-size: 32px;
        }        
        .cancel{
            width: 330px;
            height: 80px;
            background: #f2f2f2;
            color: #D72415;
            font-size: 32px;
        }
        .submit{
            width: 330px;
            height: 80px;
            // background: #D72415;
            background: var(--theme-color); 
            color: #ffffff;
            font-size: 32px;            
        }
    }
    .nowrap{
        word-break: break-all;
        margin-top: 20px;
    }
}
</style>