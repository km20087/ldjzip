import JSEncrypt from 'jsencrypt';
import CryptoJS from 'crypto-js';

export function encode(word: any, time: string) {
  function getAES(word: any, time: string) {
    const config = {
      AES_KEY: time,
      AES_IV: '6DA0557C5119454A',
    };
    const key = CryptoJS.enc.Utf8.parse(config.AES_KEY);
    const iv = CryptoJS.enc.Utf8.parse(config.AES_IV);
    let encrypted = '';
    let srcs = '';
    if (typeof word == 'string' && word != '') {
      srcs = word;
    } else if (typeof word == 'object') {
      //对象格式的转成json字符串
      // srcs = CryptoJS.enc.Utf8.parse(word)
      srcs = JSON.stringify(word);
    }
    encrypted = CryptoJS.AES.encrypt(srcs, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7,
    });

    return {
      reqData: encodeURIComponent(encrypted.toString()),
      keyData: getRSA(config.AES_KEY),
    };
  }

  function getRSA(password: string) {
    // 这个是rsa的公钥，直接写到前端
    const publicKey =
      'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC79l5k65IkdcV2O+3KDVMoD4gCFUXyHtSMGT19jXW6IJrgLDQp32WnLvxpKt7fYJbs0z4AOldOvxbmwq3StwAyzIc3MSGbNjo4XXhoJ3nOtbAcvRGNwDtP64LTXtV1RjmWEkr5ZNRskQlKqB4r3Rq3hBldYIU04cWkOMAnSJKITQIDAQAB';
    const encryptor = new JSEncrypt();
    encryptor.setPublicKey(publicKey);
    // 加密
    const rsaPassWord = encodeURIComponent(encryptor.encrypt(password));
    return rsaPassWord;
  }

  return getAES(word, time);
}

export function encodeParam(data: any, time: string = Date.now() + '000') {
  const { reqData, keyData } = encode(data, time);
  return {
    reqData: decodeURIComponent(reqData),
    keyData: decodeURIComponent(keyData),
    time,
  };
}

export function RSAencrypt(password: string) {
  // 这个是rsa的公钥，直接写到前端
  const publicKey =
    'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCQsNEwpVTT9smp4WAGxUQdMtiqz8uWwAlQjXHrYOt4yNpel9JjsJn27k2CDCn/pjh3YJp2qW+MOHosyLrnLqDAQDgmmHZ3bj/csxeSMu4zzz+xVrTqs7F8oRiE9OuRLZijz/9dnbs8aI/hcqvE3OjTuCswnEFZfCzxeWcGq/rktwIDAQAB';
  const encryptor = new JSEncrypt();
  encryptor.setPublicKey(publicKey);

  return encryptor.encrypt(password);
}
