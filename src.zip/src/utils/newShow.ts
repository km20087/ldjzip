export const newsTypeList = (val:string) =>{
    //list数量多的话要优化
    let list = ['donat_newsBH']
    return list.includes(val)
}