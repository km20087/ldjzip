import { encodeParam } from './encrypt'
import { getToken } from './util'
// import router from '@/router';
interface TrackPageInfo {
  sceneId: string
  sceneName: string
  pageDepth: number,
  url?:string,
  queryValueHash?:boolean,
}

interface TrackSendToApiParams {
  sceneId: string
  sceneName: string                   
  pageUri: string
  parentPageUri: string
  pageStayTime: number
  pageDepth: number
  status?: '00' | '01'                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
  errMsg?: string
}

const TrackRoutePath: Record<string, any> = {

  //(3)组织子页面功能菜单，包括搜索框（场景编号-0000018）；---需要在接口操作

  "/groups/list":{
    "":{
        sceneId: '000018',
        sceneName: '组织-搜索',
        queryValueHash:false,//query的参数值是否类似id
        pageDepth: 0, 
        url:"/tab/organization",        
    }
  },
  "/appSchoolmate/getSchoolmate":{
    "全部":{
        sceneId: '000020',
        sceneName: '校友-全部',
        queryValueHash:false,//query的参数值是否类似id
        pageDepth: 0, 
        url:"/tab/alumni",
    },
    "推荐":{
        sceneId: '000021',
        sceneName: '校友-推荐',
        queryValueHash:false,//query的参数值是否类似id
        pageDepth: 0,
        url:"/tab/alumni", 
    },
    "同级":{
        sceneId: '000022',
        sceneName: '校友-同级',
        queryValueHash:false,//query的参数值是否类似id
        pageDepth: 0,
        url:"/tab/alumni", 
    },
    "同城":{
        sceneId: '000023',
        sceneName: '校友-同城',
        queryValueHash:false,//query的参数值是否类似id
        pageDepth: 0,
        url:"/tab/alumni", 
    },            
  },
}
const ReportUrl = import.meta.env.VITE_APP_API_BASE_URL + '/dataCollect/push'
const isEncrypt = import.meta.env.VITE_APP_GLOBAL_ENCRYPT == '1'

class TrackPoint {
  ua = ''
  systemInfo = ''
  chanlInfo = ''
  pageUri = ''
  parentPageUri = ''
  pageVisitHistory: any = [] // 页面访问历史记录
  now = Date.now()
  pageDepth = 0
  constructor() {
    this.ua = navigator.userAgent
    this.systemInfo = this.getSystemInfo()
    this.chanlInfo = this.getChanlInfo()
  }

  run(url: string,typeVal:string) {
    // router.beforeEach((to, from) => {

    // })
    let now = Date.now()
    let fromTrack = TrackRoutePath[url][typeVal]
    if (fromTrack) {
      let { sceneId, sceneName, pageDepth } = fromTrack
      this.sendToAPI({
        sceneId,
        sceneName,                                                                                                                                                                   
        pageUri: fromTrack.url,
        parentPageUri: fromTrack.url,
        pageStayTime:0,
        pageDepth,
      })
    }

    this.now = now 
  }

  async sendToAPI(params: TrackSendToApiParams) {
    let syncTime = this.fommatDate(new Date(), 'yyyyMMddhhmmss')
    let token = getToken()
    if (!token) return

    const trackData = {
      token,
      systemInfo: this.systemInfo,
      chanlInfo: this.chanlInfo,
      chanlNo: '',
      status: '00',
      errMsg: '',
      menuId: '',
      menuName: '',
      txcode: '',
      syncTime,
      thirdPageFlag: '0',
      ...params,
    }
    const submitData = isEncrypt ? { ...encodeParam(trackData), time: undefined } : trackData
    const data = new Blob([JSON.stringify(submitData)], { type: 'application/json' })

    navigator.sendBeacon(ReportUrl, data)
  }

  /**系统信息，IOS、Android、HarmonyOs */
  getSystemInfo() {
    if (/harmony|hmos|鸿蒙/i.test(this.ua)) {
      return 'HarmonyOs'
    }

    if (/iphone|ipad|pod/i.test(this.ua)) {
      return 'IOS'
    }

    if (/android/i.test(this.ua)) {
      return 'Android'
    }

    return 'unknow'
  }

  /**渠道信息，01-H5、02-微信小程序、03-支付宝小程序、04-APP */
  getChanlInfo() {
    if (/miniProgram/i.test(this.ua)) {
      return '02'
    }
    return '01'
  }

  fommatDate(date: Date | string | number, mat: string) {
    if (typeof date === 'string' || typeof date === 'number') {
      date = new Date(date)
    }
    let y = date.getFullYear()
    let M: any = date.getMonth() + 1
    M = M < 10 ? '0' + M : M
    let d: any = date.getDate()
    d = d < 10 ? '0' + d : d
    let h: any = date.getHours()
    h = h < 10 ? '0' + h : h
    let m: any = date.getMinutes()
    m = m < 10 ? '0' + m : m
    let s: any = date.getSeconds()
    s = s < 10 ? '0' + s : s
    switch (mat) {
      case 'yyyy-MM-dd':
        date = y + '-' + M + '-' + d
        break
      case 'hh:mm:ss':
        date = h + ':' + m + ':' + s
        break
      case 'yyyyMMddhhmmss':
        date = y + M + d + h + m + s
        break
      default:
        date = y + '-' + M + '-' + d + ' ' + h + ':' + m + ':' + s
    }
    return date
  }
}

let trackPoint = new TrackPoint()

export { TrackPoint }
export default trackPoint
