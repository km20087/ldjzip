// import SparkMD5 from 'spark-md5'

function getFileMD5(file: File): Promise<string> {
  // return new Promise((resolve, reject) => {
  //   const spark = new SparkMD5.ArrayBuffer()
  //   const fileReader = new FileReader()
  //   fileReader.onload = (e: any) => {
  //     spark.append(e.target.result)
  //     resolve(spark.end())
  //   }
  //   fileReader.onerror = () => reject('')
  //   fileReader.readAsArrayBuffer(file)
  // })
}

export async function fragmentFile(file: File, maxFragmentFileSize = 1024 * 1024 * 3){
  // let fileHash = await getFileMD5(file)
  // let suffixMatchResult = file.name.toLowerCase().match(/\w+$/)
  // let suffix = suffixMatchResult && suffixMatchResult[0]
  // let chunkList = [], total = 0
  // // 开始切片
  // for(let i = 0; i < file.size; i = i + maxFragmentFileSize){
  //   const chunk = file.slice(i, Math.min(i+maxFragmentFileSize, file.size), file.type)
  //   chunkList.push({
  //     chunk,
  //     chunkName: `${fileHash}_${total++}.${suffix}`
  //   })
  // }
  // return {
  //   fileHash,
  //   chunkList,
  //   total,
  //   suffix
  // }
}