import CryptoJS from 'crypto-js';

const IV = '6DA0557C5119454A'; //密钥偏移量
const decryptByCBC = function (word: any, keyStr: string) {
  if (!word) return word;
  let key = CryptoJS.enc.Utf8.parse(keyStr);
  let base64 = CryptoJS.enc.Base64.parse(word);
  let srcs = CryptoJS.enc.Base64.stringify(base64);
  let decrypt = CryptoJS.AES.decrypt(srcs, key, {
    iv: CryptoJS.enc.Utf8.parse(IV),
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });
  let decryptedStr = decrypt.toString(CryptoJS.enc.Utf8);
  return decryptedStr.toString();
};

export default decryptByCBC;
