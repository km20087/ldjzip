/**
* 数字转整数 如 100000 转为10万
* @param {需要转化的数} num
* @param {需要保留的小数位数} point
*/
export const tranNumber = (num: number, point: number) => {
    let numStr = num.toString()
    // 1万以内直接返回
    if (numStr.length < 5) {
        return numStr;
    }
    //大于8位数是忆
    else if (numStr.length > 8) {
        let decimal = numStr.substring(numStr.length - 8, numStr.length - 8 + point);
        return parseFloat(parseInt(num / 100000000 as unknown as string) + '.' + decimal) + '忆';
    }
    //大于等于5位数是1万 (以1W分割 1W以下全部显示)
    else if (numStr.length >= 5) {
        let decimal = numStr.substring(numStr.length - 4, numStr.length - 4 + point)
        return parseFloat(parseInt(num / 10000 as unknown as string) + '.' + decimal) + 'w';
    }
}