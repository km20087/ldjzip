//hex："#3ba272"； opacity：透明度
export function hex2Rgba(hex: string, opacity = 1) {
  return `rgba(${parseInt('0x' + hex.slice(1, 3))}, ${parseInt('0x' + hex.slice(3, 5))}, ${parseInt(
    '0x' + hex.slice(5, 7)
  )}, ${opacity})`;
}
export function hex2Rgb(hex: string) {
  return `${parseInt('0x' + hex.slice(1, 3))}, ${parseInt('0x' + hex.slice(3, 5))}, ${parseInt(
    '0x' + hex.slice(5, 7)
  )}`;
}


export function backgroundDetail(color:string){
  return `linear-gradient(180deg, ${color} 0%, rgba(172, 125, 82, 0.2) 100%)`
}