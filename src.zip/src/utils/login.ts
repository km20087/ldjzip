import router from '@/router'
import { ifMinProgram, getToken, setToken,setUserId, setUserInfo, setUserStatus } from '@/utils/index'
import Api, { LoginParams, sendParams } from '@/api/user';
import { useRouter } from 'vue-router';
import  { initMenu } from '@/router';
import wx from 'weixin-js-sdk'

/**
 * 判断环境是否跳到原生小程序页面
 * @param isLoginBack 是否返回登录前的页面。默认true
 */
export async function goLoginPage(isLoginBack = true, otherParams: Record<string, any> = {}) {
  let { name, path, query } = router.currentRoute.value
  let wxRoutePath = encodeURIComponent(location.hash)
  if (!isLoginBack) {
    wxRoutePath = ''
    query = {}
  }
  sessionStorage.setItem('routerBefore', name as string)
  console.log('goLoginPage', ifMinProgram())
  if (ifMinProgram()) {
    wx.miniProgram.redirectTo({
      url: `/pages/smsLogin/index?routePath=${wxRoutePath}`,
      fail(err) {
        console.log('err', err)
      },
    })
  } else {
    // otherParams.next ? otherParams.next() : router.replace({ path: '/register/first', query })
    if (!getToken()) {
    const $router = useRouter();
    const { data, msg } = await Api.login({
      mobile: '',
      schoolId: 'FB628F116A0BC718E05354EDC480EF56',
      id: '',
      verCode: '',
      transid: '',
      wxCode: '',
      seOpenId: '',
      codeKey: '',
      code: '',
      loginType: 'sms',
    });
    if (data) {
      setToken(data['token']);
      setUserInfo(JSON.stringify(data.user))
      setUserId(data.user.userId);
      setUserStatus(data.user.userStatus)
      sessionStorage.setItem('resson', data.rejectReason);
    }
    console.log('*****tab/index/init*****')
      //00正常，01封禁，02删除，03待审核，04待完善资料，05审核失败，06-校友修改资料待审核，07-封禁的游客
      // 第一次登录后，直接跳首页，需要除了认证
      // initAppMenu().then(() => {
      initMenu().then(() => {
        router.replace({ path: '/tab/index' })
      });
    }
    // router.replace({ path: '/tab/index' })
  }
}
