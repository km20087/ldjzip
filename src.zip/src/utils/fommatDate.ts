const fommatDate = (date: Date | string | number, mat: string): string => {
  if (typeof date === 'string' || typeof date === 'number') {
    date = new Date(date);
  }
  let y = date.getFullYear();
  let M: string | number = date.getMonth() + 1;
  M = M < 10 ? '0' + M : M;
  let d: any = date.getDate();
  d = d < 10 ? '0' + d : d;
  let h: any = date.getHours();
  h = h < 10 ? '0' + h : h;
  let m: any = date.getMinutes();
  m = m < 10 ? '0' + m : m;
  let s: any = date.getSeconds();
  s = s < 10 ? '0' + s : s;
  switch (mat) {
    case 'yyyy-MM-dd':
      date = y + '-' + M + '-' + d;
      break;
    case 'yyyy/MM/dd':
      date = y + '/' + M + '/' + d;
      break;
    case 'yyyy-MM-dd hh':
      date = y + '-' + M + '-' + d + ' ' + h;
      break;
    case 'yyyy/MM/dd hh':
      date = y + '/' + M + '/' + d + ' ' + h;
      break;
    case 'yyyy-MM-dd hh:mm':
      date = y + '-' + M + '-' + d + ' ' + h + ':' + m;
      break;
    case 'yyyy/MM/dd hh:mm':
      date = y + '/' + M + '/' + d + ' ' + h + ':' + m;
      break;
    case 'yyyy-MM-dd hh:mm:ss':
      date = y + '-' + M + '-' + d + ' ' + h + ':' + m + ':' + s;
      break;
    case 'yyyy/MM/dd hh:mm:ss':
      date = y + '/' + M + '/' + d + ' ' + h + ':' + m + ':' + s;
      break;
    case '年月日':
      date = y + '年' + M + '月' + d + '日';
      break;
    case '年月日时分秒':
      date = y + '年' + M + '月' + d + '日' + ' ' + h + ':' + m + ':' + s;
      break;
    default:
      date = y + '-' + M + '-' + d + ' ' + h + ':' + m + ':' + s;
  }
  return date;
};
export { fommatDate };
