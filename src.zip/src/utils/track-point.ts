import { type Router } from 'vue-router'
import { encodeParam } from './encrypt'
import { getToken } from './util'

interface TrackPageInfo {
  sceneId: string
  sceneName: string
  pageDepth: number,
  query?:any,
  queryValueHash?:boolean,
}

interface TrackSendToApiParams {
  sceneId: string
  sceneName: string
  pageUri: string
  parentPageUri: string
  pageStayTime: number
  pageDepth: number
  status?: '00' | '01'
  errMsg?: string
}

const TrackRoutePath: Record<string, TrackPageInfo> = {
  '/register/second': {
    sceneId: '000001',
    sceneName: '校友认证页面',
    queryValueHash:false,
    pageDepth: 2
  },
  '/register/LNSF_second': {
    sceneId: '000001',
    sceneName: '校友认证页面',
    
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 2
  },
  '/tab/index': {
    sceneId: '000002',
    sceneName: '首页',
    
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 0
  },
  '/backSchool': {
    sceneId: '000003',
    sceneName: '预约返校页',
    
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1
  },
  '/backSchool-ln': {
    sceneId: '000003',
    sceneName: '预约返校页',
    
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1
  },
  '/tab/organization': {
    sceneId: '000004',
    sceneName: '校友组织',
    
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 0
  },
  '/tab/alumni': {
    sceneId: '000005',
    sceneName: '校友通讯录',
    
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 0
  },
  '/notice': {
    sceneId: '000006',
    sceneName: '通知公告',
    
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1
  },
  '/activeList':{
    sceneId: '000007',
    sceneName: '校友活动',
    
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1    
  },
  "/serviceNews?type=schoolmate_journal":{
    sceneId: '000008',
    sceneName: '校友期刊',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
  "/archive/index":{
    sceneId: '000009',
    sceneName: '档案服务',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
  "/feedback":{
    sceneId: '000010',
    sceneName: '建议反馈',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
  "/contactus":{
    sceneId: '000011',
    sceneName: '联系我们',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  }, 
  "/myActlist":{
    sceneId: '000012',
    sceneName: '我的活动',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },         
  "/perInfoCard":{
    sceneId: '000013',
    sceneName: '我的组织',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
  "/message":{
    sceneId: '000014',
    sceneName: '我的消息',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
  "/user_card":{
    sceneId: '000015',
    sceneName: '名片夹',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
  "/myPerInfoCard":{
    sceneId: '000016',
    sceneName: '个人资料',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
  "/selInfoConfig":{
    sceneId: '000017',
    sceneName: '对外展示信息设置',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
  "/loginOut":{
    sceneId: '000017',
    sceneName: '账号设置',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
  //(3)组织子页面功能菜单，包括搜索框（场景编号-0000018）；---需要在接口操作
  "/schoolmate-search":{
    sceneId: '000019',
    sceneName: '校友-搜索',
    queryValueHash:false,//query的参数值是否类似id
    pageDepth: 1 
  },
}
const ReportUrl = import.meta.env.VITE_APP_API_BASE_URL + '/dataCollect/push'
const isEncrypt = import.meta.env.VITE_APP_GLOBAL_ENCRYPT == '1'

class TrackPoint {
  ua = ''
  systemInfo = ''
  chanlInfo = ''
  pageUri = ''
  parentPageUri = ''
  pageVisitHistory: any = [] // 页面访问历史记录
  now = Date.now()
  pageDepth = 0
  constructor() {
    this.ua = navigator.userAgent
    this.systemInfo = this.getSystemInfo()
    this.chanlInfo = this.getChanlInfo()
  }

  run(router: Router) {
    router.beforeEach((to, from) => {
      let now = Date.now()
      // console.log('****to--from****',to,from)
      // console.log('query',Object.keys(from.query))
      // let a = TrackRoutePath[from.path]
      // console.log(a)
      // let fromTrack = null
      // if(a && !a.queryValueHash){
      //   fromTrack = TrackRoutePath[from.fullPath]
      // }else{
      //   fromTrack = TrackRoutePath[from.path]
      // }
      let fromTrack = TrackRoutePath[from.path] || TrackRoutePath[from.fullPath]
      if (fromTrack) {
        let { sceneId, sceneName, pageDepth } = fromTrack
        this.sendToAPI({
          sceneId,
          sceneName,
          pageUri: from.path,
          parentPageUri: this.parentPageUri,
          pageStayTime: now - this.now,
          pageDepth,
        })
      }

      let toTrack = TrackRoutePath[to.path]
      if (toTrack) {
        this.parentPageUri = from.path
        this.now = now
      }
    })
  }

  async sendToAPI(params: TrackSendToApiParams) {
    let syncTime = this.fommatDate(new Date(), 'yyyyMMddhhmmss')
    let token = getToken()
    if (!token) return

    const trackData = {
      token,
      systemInfo: this.systemInfo,
      chanlInfo: this.chanlInfo,
      chanlNo: '',
      status: '00',
      errMsg: '',
      menuId: '',
      menuName: '',
      txcode: '',
      syncTime,
      thirdPageFlag: '0',
      ...params,
    }
    const submitData = isEncrypt ? { ...encodeParam(trackData), time: undefined } : trackData
    const data = new Blob([JSON.stringify(submitData)], { type: 'application/json' })

    navigator.sendBeacon(ReportUrl, data)
  }

  /**系统信息，IOS、Android、HarmonyOs */
  getSystemInfo() {
    if (/harmony|hmos|鸿蒙/i.test(this.ua)) {
      return 'HarmonyOs'
    }

    if (/iphone|ipad|pod/i.test(this.ua)) {
      return 'IOS'
    }

    if (/android/i.test(this.ua)) {
      return 'Android'
    }

    return 'unknow'
  }

  /**渠道信息，01-H5、02-微信小程序、03-支付宝小程序、04-APP */
  getChanlInfo() {
    if (/miniProgram/i.test(this.ua)) {
      return '02'
    }
    return '01'
  }

  fommatDate(date: Date | string | number, mat: string) {
    if (typeof date === 'string' || typeof date === 'number') {
      date = new Date(date)
    }
    let y = date.getFullYear()
    let M: any = date.getMonth() + 1
    M = M < 10 ? '0' + M : M
    let d: any = date.getDate()
    d = d < 10 ? '0' + d : d
    let h: any = date.getHours()
    h = h < 10 ? '0' + h : h
    let m: any = date.getMinutes()
    m = m < 10 ? '0' + m : m
    let s: any = date.getSeconds()
    s = s < 10 ? '0' + s : s
    switch (mat) {
      case 'yyyy-MM-dd':
        date = y + '-' + M + '-' + d
        break
      case 'hh:mm:ss':
        date = h + ':' + m + ':' + s
        break
      case 'yyyyMMddhhmmss':
        date = y + M + d + h + m + s
        break
      default:
        date = y + '-' + M + '-' + d + ' ' + h + ':' + m + ':' + s
    }
    return date
  }
}

let trackPoint = new TrackPoint()

export { TrackPoint }
export default trackPoint
