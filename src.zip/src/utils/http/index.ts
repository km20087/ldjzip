/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import service, { AxiosRequestConfig } from './axios';
import {showDemoData} from "@/json/index";

const isDemo = import.meta.env.VITE_IS_DEMO  == '1'

export * from './types';
export function request<T>(config: AxiosRequestConfig): Promise<T> {
  if(isDemo){
    // console.log('request--config',config,config.url,config.data)
    if(config.url == "/appSchoolmate/getSchoolmate"){
      console.log(showDemoData(config.url,config.data,config))
    }
    return Promise.resolve(showDemoData(config.url,config.data,config))
  }else{
    return new Promise((resolve, reject) => {
      service
        .request(config)
        .then((res: any) => {
          // 一些业务处理
          resolve(res.data);


        })
        .catch((err) => {
          console.log('request fail:', err);
          reject(err)
        });
    });
  }
};



const http = {
  get<T = any>(url: string, params = {}, config?: AxiosRequestConfig): Promise<T> {
    return request({ url, params, ...config, method: 'GET' });
  },
  post<T = any>(url: string, data = {}, config?: AxiosRequestConfig): Promise<T> {
    return request({ url, data, ...config, method: 'POST' });
  },

  postP<T = any>(url: string, data = {},params = {}, config?: AxiosRequestConfig): Promise<T> {
    return request({ url, data, params,...config, method: 'POST' });
  },  

  put<T = any>(url: string, data = {}, config?: AxiosRequestConfig): Promise<T> {
    return request({ url, data, ...config, method: 'PUT' });
  },
  delete<T = any>(url: string, data = {}, config?: AxiosRequestConfig): Promise<T> {
    return request({ url, data, ...config, method: 'DELETE' });
  },
  // 上传文件，指定 'Content-Type': 'multipart/form-data'
  upload<T = any>(url: string, data = {}, config?: AxiosRequestConfig): Promise<T> {
    return request({
      url,
      data,
      ...config,
      method: 'POST',
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

export default http;
