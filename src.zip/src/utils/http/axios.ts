import axios, { AxiosResponse, AxiosRequestConfig, AxiosError } from 'axios';
import type { Response, res } from './types';
// import { auth } from '@/utils';
import { clearUserStorage, getToken } from '@/utils/index';
import { Toast } from 'vant';
import { encodeParam } from '@/utils/encrypt'
import decryptByCBC from '@/utils/decrypt'
import { goLoginPage } from '@/utils/login';

const isEncrypt = import.meta.env.VITE_APP_GLOBAL_ENCRYPT == '1'

axios.defaults.timeout = 1000 * 60;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';

// 创建axios实例
const service = axios.create({
  // 根据不同env设置不同的baseURL
  baseURL: import.meta.env.VITE_APP_API_BASE_URL,
});
// axios实例拦截请求
service.interceptors.request.use(
  (config: AxiosRequestConfig) => {
    config.headers = {
      ...config.headers,
      Authorization: getToken() || '',
    };
    // isEncrypt && import.meta.env.VITE_APP_IS_DEV_FILE_SERVER == 'true' && console.log(`${config.url} request data: `, config.data)
    if (isEncrypt && config.responseType != 'blob' && !(config.data instanceof FormData)) {
      let {reqData, keyData, time} = encodeParam(config.data)
      config.data = {
        reqData,
        keyData
      }
      // @ts-ignore
      config.time = time
    }
    return config;
  },
  (error: AxiosError) => {
    return Promise.reject(error);
  }
);

// axios实例拦截响应
service.interceptors.response.use(
  // 2xx时触发
  (response: AxiosResponse<res>) => {
    // response.data就是后端返回的数据，结构根据你们的约定来定义

    const { code, msg } = response.data;

    let errMessage = '';
    switch (code) {
      case 500:
        break;
      case 301: // token过期
        errMessage = 'Token expired';
        clearUserStorage()
        goLoginPage()
        break;
      case 2: // 无权限
        errMessage = 'No permission';
        break;
      default:
        errMessage = msg;
        break;
    }
    // if (errMessage) Toast.fail(errMessage);
    if (!isEncrypt || response.config.responseType == "blob" || response.config.data instanceof FormData) {
      return response;
    }
    if (isEncrypt && response.data?.data) {
      // @ts-ignore
      let data = decryptByCBC(response.data.data, response.config.time)
      try{
        data = JSON.parse(data)
      } catch(err) {}
      // import.meta.env.VITE_APP_IS_DEV_FILE_SERVER == 'true' && console.log(`${response.config.url} response data`, data)
      return {...response, data: {...response.data, data}}
    }
    return response;
  },
  // 非2xx时触发
  (error: AxiosError) => {
    Toast.fail('Network Error...');
    return Promise.reject(error);
  }
);

export type { AxiosResponse, AxiosRequestConfig };

export default service;
