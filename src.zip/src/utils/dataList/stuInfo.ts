/**
 * type inp:输入，photo；图片上传，special：下拉框选择-本地数据，select；下拉框选择,specialX---不好分类
 * 
 * */

import { SchoolCode } from '@/constants';
import { getSchoolCode } from '../util';
import {schoolShowConfig} from "@/utils/schoolLevelShow"
let normalList = [
  { cnName: '入学年份', enLabel: "schoolStartYear", type: 'select' },
  { cnName: '毕业年份', enLabel: "schoolEndYear", type: 'select' },
  { cnName: '毕业时校名', enLabel: "graduationSchoolName", type: 'inp' },

  { cnName: '校友类型', enLabel: "schoolmateType", type: 'special', hasChild: '1' },

  { cnName: '学院名称', enLabel: "collegeName", type: 'inpSpecial', id: 'collegeId', parentName: "schoolmateType", hasChild: '0', parentId: '1', },
  { cnName: '专业名称', enLabel: "majorName", type: 'inpSpecial', id: 'major', parentName: "schoolmateType", hasChild: '0', parentId: '1', },
  { cnName: '班级', enLabel: "classesName", type: 'inpSpecial', id: "classes", parentName: "schoolmateType", hasChild: '0', parentId: '1', },

  { cnName: '毕业证件照片', enLabel: "diplomaImage", type: 'photo' },

  { cnName: '学号', enLabel: "studentIdNumber", type: 'inp', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '学历', enLabel: "education", type: 'special', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '学位', enLabel: "academicDegree", type: 'special', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '同学姓名', enLabel: "classmateName", type: 'inp', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '辅导员姓名', enLabel: "counselorName", type: 'inpSpecial', parentId: '1', parentName: "schoolmateType", hasChild: '0',maxlength:5 },
  { cnName: '入读高校', enLabel: "enrollUniversity", type: 'inp', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '证明人', enLabel: "witnessName", type: 'inp', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '证明人手机号', enLabel: "witnessPhone", type: 'inp', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  //counselorName


  // { cnName: '工作部门', enLabel: "jobDepartment", type: 'inp', parentId: '2', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '工号', enLabel: "jobNumber", type: 'inp', parentId: '2', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '职位类别', enLabel: "positionType", type: 'special', parentId: '2', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '同事姓名', enLabel: "colleagueName", type: 'inp', parentId: '2', parentName: "schoolmateType", hasChild: '0' },

  { cnName: '是否留校任职', enLabel: "stayOnCampus", type: 'special' },
] 

let liaoshidaList = [
  { cnName: '入学年份', enLabel: "schoolStartYear", type: 'select' },
  { cnName: '毕业年份', enLabel: "schoolEndYear", type: 'select' },
  { cnName: '毕业时校名', enLabel: "graduationSchoolName", type: 'inp' },

  { cnName: '校友类型', enLabel: "schoolmateType", type: 'special', hasChild: '1' },

  { cnName: '学院名称', enLabel: "collegeName", type: 'inpSpecial', id: 'collegeId', parentName: "schoolmateType", hasChild: '0', parentId: '1', },
  { cnName: '专业名称', enLabel: "majorName", type: 'inpSpecial', id: 'major', parentName: "schoolmateType", hasChild: '0', parentId: '1', },
  { cnName: '班级', enLabel: "classesName", type: 'inpSpecial', id: "classes", parentName: "schoolmateType", hasChild: '0', parentId: '1', },

  { cnName: '毕业证件照片', enLabel: "diplomaImage", type: 'photo' },
  { cnName: '班主任姓名', enLabel: "classAdviser", type: 'inp', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '学号', enLabel: "studentIdNumber", type: 'inp', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '学历', enLabel: "education", type: 'special', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '学位', enLabel: "academicDegree", type: 'special', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '同学姓名', enLabel: "classmateName", type: 'inp', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '辅导员姓名', enLabel: "counselorName", type: 'inpSpecial', parentId: '1', parentName: "schoolmateType", hasChild: '0' },


  { cnName: '工作部门', enLabel: "jobDepartment", type: 'inp', parentId: '2', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '工号', enLabel: "jobNumber", type: 'inp', parentId: '2', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '职位类别', enLabel: "positionType", type: 'special', parentId: '2', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '同事姓名', enLabel: "colleagueName", type: 'inp', parentId: '2', parentName: "schoolmateType", hasChild: '0' },

  { cnName: '是否留校任职', enLabel: "stayOnCampus", type: 'special' },
]

let shandaList = [
  { cnName: '入学年份', enLabel: "schoolStartYear", type: 'select' },
  { cnName: '毕业年份', enLabel: "schoolEndYear", type: 'select' },
  { cnName: '毕业时校名', enLabel: "graduationSchoolName", type: 'inp' },

  /****0331汕大修改注册字段***/
  // { cnName: '校友类型', enLabel: "schoolmateType", type: 'special', hasChild: '1' },
  /****0331汕大修改注册字段***/

  { cnName: '学院名称', enLabel: "collegeName", type: 'inpSpecial', id: 'collegeId' },
  { cnName: '专业名称', enLabel: "majorName", type: 'inpSpecial', id: 'major',  },
  // { cnName: '专业(选填)', enLabel: "majorName", type: 'inpX' },//
  { cnName: '班级', enLabel: "classesName", type: 'inpSpecial', id: "classes",},

  //  parentName: "schoolmateType", hasChild: '0', parentId: '1',

  { cnName: '班级同学/老师姓名', enLabel: "classmateName", type: 'inp' },//
  { cnName: '班主任姓名', enLabel: "classAdviser", type: 'inp' },
  { cnName: '毕业证件照片', enLabel: "diplomaImage", type: 'photo' },

  { cnName: '学号', enLabel: "studentIdNumber", type: 'inp', },
  { cnName: '学历', enLabel: "education", type: 'special',   },
  { cnName: '学位', enLabel: "academicDegree", type: 'special', },
  // { cnName: '同学姓名', enLabel: "classmateName", type: 'inp', parentId: '1', parentName: "schoolmateType", hasChild: '0' },
  { cnName: '辅导员姓名', enLabel: "counselorName", type: 'inpSpecial', },
// parentId: '1', parentName: "schoolmateType", hasChild: '0

  { cnName: '工作部门', enLabel: "jobDepartment", type: 'inp',  },


  /****0331汕大修改注册字段***/
  // { cnName: '工号', enLabel: "jobNumber", type: 'inp', parentId: '2', parentName: "schoolmateType", hasChild: '0' },
  // { cnName: '职位类别', enLabel: "positionType", type: 'special', parentId: '2', parentName: "schoolmateType", hasChild: '0' },
  /****0331汕大修改注册字段***/

  { cnName: '工作职务', enLabel: "positionType", type: 'inp', },
  { cnName: '同事姓名', enLabel: "colleagueName", type: 'inp', },

  // { cnName: '入职时间', enLabel: "jobDuration", type: 'select', },
  // { cnName: '离职时间', enLabel: "jobResignation", type: 'special' },
  // parentId: '2', parentName: "schoolmateType", hasChild: '0'

  { cnName: '是否留校任职', enLabel: "stayOnCampus", type: 'special' },
] 

export default ()=>{
  let schoolCode = getSchoolCode()
  let list:any = []
  if(schoolCode == SchoolCode.ShanDa){
    list = shandaList
  }else if(schoolCode == SchoolCode.LiaoShiDa){
    // liaoshidaList
    list = liaoshidaList
  } else{
    list = normalList
    if(schoolShowConfig() == '1'){
      for(let i in list){
        if(list[i].enLabel == 'education'){
          list[i].cnName = '学段'
        }
      }
    }else if(schoolCode == SchoolCode.BaoTouZhiYeJiShu){
      for(let i in list){
        if(list[i].enLabel == 'collegeName'){
          list[i].cnName = '系部名称'
        }
      }
    }else if(schoolCode == SchoolCode.XiangXianZhongXue){
      for(let i in list){
        if(list[i].enLabel == 'classesName'){
          list[i].cnName = '毕业班级'
        }     
      }
    }else if(schoolCode == SchoolCode.ChengDeYiXueYuan){
      for(let i in list){
        if(list[i].enLabel == 'schoolDuties'){
          list[i].cnName = '在校职务'
        }
      } 
    }
  }    
  return list
}