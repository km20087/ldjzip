import { SchoolCode } from "@/constants"
import { getSchoolCode } from "../util"
import {schoolShowConfig} from "@/utils/schoolLevelShow"
let schoolCode = getSchoolCode()
let schoolLevel =  schoolShowConfig() as string
let NormalSchoolMateTypeList = [
  { text: '毕业生', value: "0" },
  { text: '在校生', value: "1" },
  { text: '教职工', value: "2" },
  { text: '企业', value: "3" }
]

let ShanDaSchoolMateTypeList = [
  { text: '校友', value: "0" },
  { text: '教职工(曾)', value: "2" },
  { text: '在校生', value: "1" },
  { text: '合作企业人员', value: "3" }
]

let NormalStayOnCampusList = [
      { text: '否', value: "0" },
      { text: '是', value: "1" },
]

let ShanDaStayOnCampusList = [
  { text: '否', value: "0" },
  { text: '仍在校任职', value: "1" },
  { text: '曾在校任职', value: "2" },
]

let ShanDaJobResignationList = [
  {text:"否",value:"0"},
  {text:"是",value:"1"},
]

const SchoolMateTypeList = schoolCode == SchoolCode.ShanDa ? ShanDaSchoolMateTypeList : NormalSchoolMateTypeList

const stayOnCampusList = schoolCode == SchoolCode.ShanDa ? ShanDaStayOnCampusList : NormalStayOnCampusList

const jobResignationList = schoolCode == SchoolCode.ShanDa ?ShanDaJobResignationList:[]


export default [
  {
    type: "academicDegree",
    list: [
      { text: '学士', value: "0" },
      { text: '硕士', value: "1" },
      { text: '博士', value: "2" },
    ]
  },
  {
    type: "auditRecordStatus",
    list: [
      { text: '待审核', value: "00" },
      { text: '一级审核通过', value: "01" },
      { text: '一级审核不通过', value: "02" },
      { text: '二级审核通过', value: "03" },
      { text: '二级审核不通过', value: "04" },
    ]
  },
  {
    type: "cardExchangeSendType",
    list: [
      { text: '我发起的', value: "0" },
      { text: '我收到的', value: "1" },
    ]
  },
  {
    type: "cardExchangeStatus",
    list: [
      { text: '待对方确认', value: "0" },
      { text: '已交换', value: "1" },
      { text: '拒绝交换', value: "2" },
      { text: '待自己确认', value: "3" },
    ]
  },
  {
    type: "cardExchangeType",
    list: [
      { text: '收到的未读名片', value: "0" },
      { text: '收到的已交换名片', value: "1" },
      { text: '收到的未交换名片', value: "2" },
    ]
  },
  {
    type: "cardType",
    list: [
      { text: '居民身份证', value: "1010" },
      { text: '中国护照', value: "1051" },
      { text: '外国护照', value: "1052" },
      { text: '香港居民身份证', value: "1140" },
      { text: '澳门居民身份证', value: "1150" },
      { text: '台湾居民身份证', value: "1160" },
      { text: '其他', value: "8888" },
    ]
  },
  {
    type: "education",
    // schoolLevel
    list:schoolLevel=='2'? [
      // { text: '小学', value: "0" },
      // { text: '初中', value: "1" },
      // { text: '高中', value: "2" },
      { text: '继续教育', value: "7" },
      { text: '中专', value: "8" },
      { text: '专科', value: "3" },
      { text: '本科', value: "4" },
      { text: '硕士研究生', value: "5" },
      { text: '博士研究生', value: "6" },
    ]:[
      { text: '初中', value: "1" },
      { text: '高中', value: "2" },
    ]
  },
  {
    type: "exchangeCardFlag",
    list: [
      { text: '不允许', value: "0" },
      { text: '允许', value: "1" },
    ]
  },
  {
    type: "gender",
    list: [
      { text: '女', value: "0" },
      { text: '男', value: "1" },
    ]
  },
  {
    type: "isSynchronize",
    list: [
      { text: '未同步', value: "0" },
      { text: '已同步', value: "1" },
    ]
  },
  {
    type: "location",
    list: [
      { text: '国内', value: "0" },
      { text: '国外', value: "1" },
    ]
  },
  {
    type: "maritalStatus",
    list: [
      { text: '未婚', value: "0" },
      { text: '已婚', value: "1" },
      { text: '离异', value: "2" },
      { text: '丧偶', value: "3" },
      { text: '保密', value: "4" },
    ]
  },
  {
    type: "politicalStatus",
    list: [
      { text: '中共党员', value: "0" },
      { text: '中共预备党员', value: "1" },
      { text: '共青团员', value: "2" },
      { text: '民革党员', value: "3" },
      { text: '民盟盟员', value: "4" },
      { text: '民建会员', value: "5" },
      { text: '民进会员', value: "6" },
      { text: '农工党党员', value: "7" },
      { text: '致公党党员', value: "8" },
      { text: '九三学社社员', value: "9" },
      { text: '台盟盟员', value: "10" },
      { text: '无党派人士', value: "11" },
      { text: '群众', value: "12" },

    ]
  },
  {
    type: "positionType",
    list: [
      { text: '专任教师', value: "0" },
      { text: '特任系列', value: "1" },
      { text: '博士后', value: "2" },
      { text: '访问学者', value: "3" },
      { text: '管理', value: "4" },
      { text: '技术', value: "5" },
      { text: '工勤', value: "6" },
    ]
  },
  {
    type: "religion",
    list: [
      { text: '基督教', value: "0" },
      { text: '伊斯兰教', value: "1" },
      { text: '佛教', value: "2" },
      { text: '其他', value: "3" },
    ]
  },
  {
    type: "schoolmateType",
    list: SchoolMateTypeList
  },
  {
    type: "userStatus",
    list: [
      { text: '毕业生', value: "0" },
      { text: '在校生', value: "1" },
      { text: '教职工', value: "2" },
      { text: '企业', value: "3" }
    ]
  },
  {
    type: "enterpriseScientificFlag",
    list: [
      { text: '否', value: "0" },
      { text: '是', value: "1" },
    ]
  },
  {
    type: "stayOnCampus",
    list:stayOnCampusList
  },
  // {
  //   type:'jobResignation',
  //   list: [
  //     { text: '否', value: "0" },
  //     { text: '是', value: "1" },
  //   ]
  // },
  {
    type: "workingInSchool",
    list: [
      { text: '否', value: "0" },
      { text: '是', value: "1" },
    ]
  },
]



