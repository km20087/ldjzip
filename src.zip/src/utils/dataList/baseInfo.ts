/**
 * type inp:输入，photo；图片上传，special：下拉框选择-本地数据，select；下拉框选择,specialX---不好分类
 *
 * */

import { SchoolCode } from '@/constants';
import { getSchoolCode } from '../util';

let normalList =  [
  { cnName: '姓名', enLabel: 'name', type: 'inp' },
  { cnName: '国籍', enLabel: 'nationality', type: 'special' },
  { cnName: '性别', enLabel: 'gender', type: 'special' },
  { cnName: '民族', enLabel: 'ethnic', type: 'special' },
  { cnName: '出生日期', enLabel: 'birthday', type: 'selectTime' },
  { cnName: '籍贯', enLabel: 'nativePlace', type: 'inp' },
  { cnName: '家庭住址', enLabel: '', type: '' },
  { cnName: '所在地区', enLabel: 'location', type: 'special' },
  { cnName: '政治面貌', enLabel: 'politicalStatus', type: 'special' },
  { cnName: '详细地址', enLabel: 'detailedAddress', type: 'inp' },

  { cnName: '证件类型', enLabel: 'cardType', type: 'special' },
  { cnName: '证件号码', enLabel: 'cardNumber', type: 'inp' },
  { cnName: '工作生活地区', enLabel: 'workLifeLocation', type: 'specialX' },  
  { cnName: '省名称', enLabel: 'provinceName', type: 'specialX' },
  { cnName: '市名称', enLabel: 'cityName', type: 'specialX' },
  { cnName: '区名称', enLabel: 'areaName', type: 'specialX' },
  { cnName: '联系方式', enLabel: 'mobile', type: 'inp' },
  { cnName: '联系电话', enLabel: 'contactNumber', type: 'inp', lnNO: 10 },
  { cnName: '微信号', enLabel: 'wechat', type: 'inp' },
  { cnName: 'QQ号', enLabel: 'qq', type: 'inp' },
  { cnName: '邮箱', enLabel: 'emailAddress', type: 'inp' },
  { cnName: '车牌号', enLabel: 'carNumber', type: 'inp' },
  { cnName: '婚姻状况', enLabel: 'maritalStatus', type: 'special' },
  { cnName: '宗教信仰', enLabel: 'religion', type: 'special' },
  { cnName: '用户头像', enLabel: 'userProfilePicture', type: 'photo' },
  { cnName: '免冠照片', enLabel: 'bareheadedPhoto', type: 'photo' },
  { cnName: '证件照片', enLabel: 'identificationDocumentImage', type: 'photo' },
  // { cnName: '常住地区', enLabel: 'residentArea', type: 'specialX' },
  { cnName: '生源地', enLabel: 'studentSourceArea', type: 'specialX' },

]


let shandaList = [
  { cnName: '姓名', enLabel: 'name', type: 'inp' },
  { cnName: '国籍', enLabel: 'nationality', type: 'special' },
  { cnName: '性别', enLabel: 'gender', type: 'special' },
  { cnName: '民族', enLabel: 'ethnic', type: 'special' },
  { cnName: '出生日期', enLabel: 'birthday', type: 'selectTime' },
  { cnName: '籍贯', enLabel: 'nativePlace', type: 'inp' },
  { cnName: '家庭住址', enLabel: '', type: '' },
  // { cnName: '所在地区', enLabel: 'location', type: 'special' },
  { cnName: '政治面貌', enLabel: 'politicalStatus', type: 'special' },
  { cnName: '详细地址', enLabel: 'detailedAddress', type: 'inp' },

  { cnName: '证件类型', enLabel: 'cardType', type: 'special' },
  { cnName: '证件号码', enLabel: 'cardNumber', type: 'inp' },
  { cnName: '生源地', enLabel: 'studentSourceArea', type: 'specialX' },
  { cnName: '工作生活地区', enLabel: 'workLifeLocation', type: 'specialX' },
  // { cnName: '省名称', enLabel: 'provinceName', type: 'specialX' },
  // { cnName: '市名称', enLabel: 'cityName', type: 'specialX' },
  // { cnName: '区名称', enLabel: 'areaName', type: 'specialX' },
  { cnName: '联系方式', enLabel: 'mobile', type: 'inp' },
  { cnName: '联系电话', enLabel: 'contactNumber', type: 'inp', lnNO: 10 },
  { cnName: '微信号', enLabel: 'wechat', type: 'inp' },
  { cnName: 'QQ号', enLabel: 'qq', type: 'inp' },
  { cnName: '邮箱', enLabel: 'emailAddress', type: 'inp' },
  { cnName: '车牌号', enLabel: 'carNumber', type: 'inp' },
  { cnName: '婚姻状况', enLabel: 'maritalStatus', type: 'special' },
  { cnName: '宗教信仰', enLabel: 'religion', type: 'special' },
  { cnName: '用户头像', enLabel: 'userProfilePicture', type: 'photo' },
  { cnName: '免冠照片', enLabel: 'bareheadedPhoto', type: 'photo' },
  { cnName: '证件照片', enLabel: 'identificationDocumentImage', type: 'photo' },
  // { cnName: '常住地区', enLabel: 'residentArea', type: 'specialX' },
]

export default ()=>{
    let schoolCode = getSchoolCode()
    let list:any = []
    if(schoolCode == SchoolCode.ShanDa){
      list = shandaList
    } else {
      list = normalList
    }    
    return list
  }

