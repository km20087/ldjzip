/**
 * type inp:输入，photo；图片上传，special：下拉框选择-本地数据，select；下拉框选择,specialX---不好分类
 * 
 * inpX--汕大需求改的
 *
 * */

export default {
  list: [
    //lnNO:辽宁师范字段排序序号
    { cnName: '姓名', enLabel: 'name', type: 'inp', lnNO: 1 },
    { cnName: '国籍', enLabel: 'nationality', type: 'special' },
    { cnName: '性别', enLabel: 'gender', type: 'special', lnNO: 2 },
    { cnName: '民族', enLabel: 'ethnic', type: 'special', lnNO: 3 },
    { cnName: '出生日期', enLabel: 'birthday', type: 'selectTime', lnNO: 4 },
    { cnName: '籍贯', enLabel: 'nativePlace', type: 'inp' },
    { cnName: '办公地址', enLabel: 'officeAddress', type: 'inp' },
    { cnName: '政治面貌', enLabel: 'politicalStatus', type: 'special' },

    { cnName: '证件类型', enLabel: 'cardType', type: 'special' },
    { cnName: '证件号码', enLabel: 'cardNumber', type: 'inp' },
    { cnName: '生源地', enLabel: 'studentSourceArea', type: 'specialX' },

    { cnName: '联系方式', enLabel: 'mobile', type: 'inp' },

    { cnName: '入学年份', enLabel: 'schoolStartYear', type: 'select' },
    { cnName: '毕业年份', enLabel: 'schoolEndYear', type: 'select' },
    { cnName: '毕业时校名', enLabel: 'graduationSchoolName', type: 'inp' },

    { cnName: '学院名称', enLabel: 'collegeName', type: 'inpSpecial', id: 'collegeId' },
    { cnName: '专业名称', enLabel: 'majorName', type: 'inpSpecial', id: 'major' },
    { cnName: '班级', enLabel: 'classesName', type: 'inpSpecial', id: 'classes' },

    { cnName: '班级同学/老师姓名', enLabel: 'classmateName', type: 'inp' },//

    // { cnName: '省名称', enLabel: 'provinceName', type: 'specialX' },
    // { cnName: '市名称', enLabel: 'cityName', type: 'specialX' },
    // { cnName: '区名称', enLabel: 'areaName', type: 'specialX' },

    { cnName: '工作生活地区', enLabel: 'workLifeLocation', type: 'specialX' },

    { cnName: '详细地址', enLabel: 'detailedAddress', type: 'inp' },
    { cnName: '电子邮箱', enLabel: 'emailAddress', type: 'inp', lnNO: 11 },
    { cnName: '单位名称', enLabel: 'employer', type: 'inp', lnNO: 5 },

    // {cnName:'主键',enLabel:"id"},
    { cnName: '职业', enLabel: 'industry', type: 'inp' },
    { cnName: '职务', enLabel: 'jobTitle', type: 'inp', lnNO: 6 },
    // { cnName: '所在地区', enLabel: 'location', type: 'special' },

    { cnName: '婚姻状况', enLabel: 'maritalStatus', type: 'special' },
    { cnName: '车牌号', enLabel: 'carNumber', type: 'inp' },

    { cnName: 'QQ号', enLabel: 'qq', type: 'inp', lnNO: 12 },
    { cnName: '宗教信仰', enLabel: 'religion', type: 'special' },

    //
    // { cnName: '校友类型', enLabel: 'schoolmateType', type: 'special', hasChild: '1' },

    {
      cnName: '学号',
      enLabel: 'studentIdNumber',
      type: 'inp',
      // parentId: '1',
      // parentName: 'schoolmateType',
      // hasChild: '0',
    },
    {
      cnName: '学历',
      enLabel: 'education',
      type: 'special',
      // parentId: '1',
      // parentName: 'schoolmateType',
      // hasChild: '0',
    },
    {
      cnName: '(曾)在校职务',
      enLabel: 'schoolDuties',
      type: 'inp',
      // parentId: '1',
      // parentName: 'schoolmateType',
      // hasChild: '0',
    },
    {
      cnName: '辅导员姓名',
      enLabel: 'counselorName',
      type: 'inpSpecial',
      // parentId: '1',
      // parentName: 'schoolmateType',
      // hasChild: '0',
    },    
    {
      cnName: '学位',
      enLabel: 'academicDegree',
      type: 'special',
      // parentId: '1',
      // parentName: 'schoolmateType',
      // hasChild: '0',
    },
    // {
    //   cnName: '同学姓名',
    //   enLabel: 'classmateName',
    //   type: 'inp',
    //   // parentId: '1',
    //   // parentName: 'schoolmateType',
    //   hasChild: '0',
    // },

    {
      cnName: '工作部门',
      enLabel: 'jobDepartment',
      type: 'inp',
      // parentId: '2',
      // parentName: 'schoolmateType',
      // hasChild: '0',
    },
    {
      cnName: '入职时间',
      enLabel: 'jobDuration',
      type: 'select',
      // parentId: '2',
      // parentName: 'schoolmateType',
      // hasChild: '0',
    },

    /****0331汕大修改注册字段***/
    // {
    //   cnName: '工号',
    //   enLabel: 'jobNumber',
    //   type: 'inp',
    //   parentId: '2',
    //   parentName: 'schoolmateType',
    //   hasChild: '0',
    // },
    // {
    //   cnName: '职位类别',
    //   enLabel: 'positionType',
    //   type: 'special',
    //   parentId: '2',
    //   parentName: 'schoolmateType',
    //   hasChild: '0',
    // },
    /****0331汕大修改注册字段***/


    {
      cnName: '工作职务',
      enLabel: 'positionType',
      type: 'inp',
      // parentId: '2',
      // parentName: 'schoolmateType',
      // hasChild: '0',
    },

    {
      cnName: '同事姓名',
      enLabel: 'colleagueName',
      type: 'inp',
      // parentId: '2',
      // parentName: 'schoolmateType',
      // hasChild: '0',
    },
    //
    //

    // {cnName:'学历信息',enLabel:"studentStatusInfo",type:'inp'},
    // {cnName:'用户id',enLabel:"userId"},
    { cnName: '免冠照片', enLabel: 'bareheadedPhoto', type: 'photo' },
    { cnName: '毕业证件照片', enLabel: 'diplomaImage', type: 'photo' },
    { cnName: '用户头像', enLabel: 'userProfilePicture', type: 'photo', lnNO: 14 },
    { cnName: '微信号', enLabel: 'wechat', type: 'inp' },
    { cnName: '证件照片', enLabel: 'identificationDocumentImage', type: 'photo' },

    { cnName: '企业名称', enLabel: 'enterpriseName', type: 'inp' },
    { cnName: '是否为科研机构', enLabel: 'enterpriseScientificFlag', type: 'special' },
    { cnName: '是否留校任职', enLabel: 'stayOnCampus', type: 'special' },
    { cnName: '离职时间', enLabel: 'jobResignation', type: 'select' },
    { cnName: '是否仍在职', enLabel: 'workingInSchool', type: 'special' },
    { cnName: '职务职位', enLabel: 'enterpriseJobPosition', type: 'inp' },
    { cnName: '企业简介', enLabel: 'enterpriseIntroduction', type: 'inp' },
    { cnName: '企业位置信息', enLabel: 'enterpriseAddress', type: 'inp' },
    //enterpriseAddress

    { cnName: '出生日期', enLabel: 'dateOfBirth', type: 'inp' },
    { cnName: '联系电话', enLabel: 'contactNumber', type: 'inp', lnNO: 10 },
    { cnName: '常住地区', enLabel: 'residentArea', type: 'inp', lnNO: 13 },
    { cnName: '职称', enLabel: 'professionalTitle', type: 'inp', lnNO: 7 },
    { cnName: '行政级别', enLabel: 'administrativeLevel', type: 'inp', lnNO: 8 },
    { cnName: '曾用名', enLabel: 'formerName', type: 'inp' },
    { cnName: '学制', enLabel: 'schoolingPeriod', type: 'inp' },
    { cnName: '学历性质', enLabel: 'academicType', type: 'inp' },
    { cnName: '工作领域', enLabel: 'workField', type: 'inp', lnNO: 9 },
  ],
};
