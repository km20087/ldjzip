import { isLiaoShiDa } from "../customizedType";

/**
 * type inp:输入，photo；图片上传，special：下拉框选择-本地数据，select；下拉框选择,specialX---不好分类
 * 
 * inpX--汕大需求改的
 *
 * */

import { SchoolCode } from '@/constants';
import { getSchoolCode } from "../util";

let liaoshidaList = [
  { cnName: '办公地址', enLabel: 'officeAddress', type: 'inp' },
  { cnName: '单位名称', enLabel: 'employer', type: 'inp' },
  { cnName: '职务', enLabel: 'jobTitle', type: 'specialX' },
  { cnName: '职业', enLabel: 'industry', type: 'inp' },
  // { cnName: '工作部门', enLabel: "jobDepartment", type: 'inp'},
  { cnName: '职称', enLabel: 'professionalTitle', type: 'inp' },
  { cnName: '行政级别', enLabel: 'administrativeLevel', type: 'inp' },
  { cnName: '是否仍在职', enLabel: 'workingInSchool', type: 'special' },
  { cnName: '入职时间', enLabel: "jobDuration", type: 'select' },
  { cnName: '离职时间', enLabel: "jobResignation", type: 'select' },  
  { cnName: '(曾)在校职务', enLabel: "schoolDuties", type: 'inp', },
]

let normalList = [
  { cnName: '办公地址', enLabel: 'officeAddress', type: 'inp' },
  { cnName: '单位名称', enLabel: 'employer', type: 'inp' },
  { cnName: '职务', enLabel: 'jobTitle', type: 'specialX' },
  { cnName: '职业', enLabel: 'industry', type: 'inp' },
  { cnName: '工作部门', enLabel: "jobDepartment", type: 'inp' },
  { cnName: '是否仍在职', enLabel: 'workingInSchool', type: 'special' },  
  { cnName: '入职时间', enLabel: "jobDuration", type: 'select' },
  { cnName: '离职时间', enLabel: "jobResignation", type: 'select' },    
  { cnName: '(曾)在校职务', enLabel: "schoolDuties", type: 'inp', },  
]

let shandaList = [
  { cnName: '办公地址', enLabel: 'officeAddress', type: 'inp' },
  { cnName: '单位名称', enLabel: 'employer', type: 'inp' },
  { cnName: '职务', enLabel: 'jobTitle', type: 'inpX' },
  { cnName: '职业', enLabel: 'industry', type: 'inp' },
  { cnName: '是否仍在职', enLabel: 'workingInSchool', type: 'special' },
  { cnName: '入职时间', enLabel: "jobDuration", type: 'select', },
  { cnName: '离职时间', enLabel: "jobResignation", type: 'special' },  
  { cnName: '(曾)在校职务', enLabel: "schoolDuties", type: 'inp', },
]

// export default isLiaoShiDa() ? [
//   { cnName: '办公地址', enLabel: 'officeAddress', type: 'inp' },
//   { cnName: '单位名称', enLabel: 'employer', type: 'inp' },
//   { cnName: '职务', enLabel: 'jobTitle', type: 'specialX' },
//   { cnName: '职业', enLabel: 'industry', type: 'inp' },
//   { cnName: '职称', enLabel: 'professionalTitle', type: 'inp' },
//   { cnName: '行政级别', enLabel: 'administrativeLevel', type: 'inp' },
// ] : [
//   { cnName: '办公地址', enLabel: 'officeAddress', type: 'inp' },
//   { cnName: '单位名称', enLabel: 'employer', type: 'inp' },
//   { cnName: '职务', enLabel: 'jobTitle', type: 'specialX' },
//   { cnName: '职业', enLabel: 'industry', type: 'inp' },
// ];

export default ()=>{
  let sc = getSchoolCode()
  console.log('sc',sc == SchoolCode.LiaoShiDa)
  let list:any = []
  if(sc == SchoolCode.ShanDa){
    list = shandaList
  }
  else if(sc == SchoolCode.LiaoShiDa){
    // list = liaoshidaList
    let arr = liaoshidaList
    for(let i in arr){
      if(arr[i].enLabel == 'employer'){
        arr[i].cnName = '工作单位及部门'
      }    
      //辽宁师范--0321：删除行政级别。         
      if(arr[i].enLabel == 'administrativeLevel'){
        console.log(arr[i].enLabel)
        arr.splice(Number(i),1)
      }
    }
    list = arr    
  }
  else if(sc == SchoolCode.GuangWenYi){//广东XX学校要求：把职务和职业对调
    let arr = normalList
    for(let i in arr){
      if(arr[i].enLabel == 'industry'){
        arr[i].cnName = '所在单位及职务'
      }
      if(arr[i].enLabel == 'jobTitle'){
        arr[i].cnName = '行业'
      }
    }
    // console.log('广东XX学校333:',arr)
    list = arr
  }else if(sc == SchoolCode.ChengDeYiXueYuan){
    let arr = normalList
    for(let i in arr){
      if(arr[i].enLabel == 'schoolDuties'){
        arr[i].cnName = '在校职务'
      }  
    }  
    list = arr
  }
  else{
    list = normalList
  }    
  return list
}
