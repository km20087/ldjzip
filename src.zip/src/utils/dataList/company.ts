/**
 * type inp:输入，photo；图片上传，special：下拉框选择-本地数据，select；下拉框选择,specialX---不好分类
 * 
 * */

 
import { SchoolCode } from '@/constants'
import { getSchoolCode } from '../util'

let normalList =  [
    // { cnName: '离职时间', enLabel: "jobResignation", type: 'select' },
    { cnName: '企业名称', enLabel: "enterpriseName", type: 'inp' },
    { cnName: '是否为科研机构', enLabel: "enterpriseScientificFlag", type: 'special' },
    { cnName: '职务职位', enLabel: "enterpriseJobPosition", type: 'inp' },
    { cnName: '企业简介', enLabel: "enterpriseIntroduction", type: 'inp' },
    { cnName: '企业位置信息', enLabel: "enterpriseAddress", type: 'inp' },
    // { cnName: '是否仍在职', enLabel: 'workingInSchool', type: 'special' },    
]

let shandaList = [
    // { cnName: '离职时间', enLabel: "jobResignation", type: 'special' },
    { cnName: '企业名称', enLabel: "enterpriseName", type: 'inp' },
    { cnName: '是否为科研机构', enLabel: "enterpriseScientificFlag", type: 'special' },
    // { cnName: '是否仍在职', enLabel: 'workingInSchool', type: 'special' },
    { cnName: '职务职位', enLabel: "enterpriseJobPosition", type: 'inp' },
    { cnName: '企业简介', enLabel: "enterpriseIntroduction", type: 'inp' },
    { cnName: '企业位置信息', enLabel: "enterpriseAddress", type: 'inp' },
]

export default ()=>{
    let schoolCode = getSchoolCode()
    let list:any = []
    if(schoolCode == SchoolCode.ShanDa){
      list = shandaList
    } else{
      list = normalList
    }    
    return list
  }