/**
 * type inp:输入，photo；图片上传，special：下拉框选择-本地数据，select；下拉框选择,specialX---不好分类
 *
 * */
import { SchoolCode } from '@/constants';

import list1 from './infoConfigList'//其他学校的配置
import list2 from './shandaInfoConfigList'//汕大的配置
import { getSchoolCode } from '../util';
import {schoolShowConfig} from "@/utils/schoolLevelShow"

export default {
  listForm() {
    let sc = getSchoolCode()
    let list:any = []
    if(sc == SchoolCode.ShanDa){
      list = list2.list
    }else if(sc == SchoolCode.GuangWenYi){//广东XX学校要求：把职务和职业对调
      let arr = list1.list
      for(let i in arr){
        if(arr[i].enLabel == 'industry'){
          arr[i].cnName = '所在单位'
        }
        if(arr[i].enLabel == 'jobTitle'){
          arr[i].cnName = '行业'
        }
        if(arr[i].enLabel == 'jobDepartment'){
          arr[i].cnName = '部门及职务'
        }        
      }
      list = arr
    }else if(sc == SchoolCode.LiaoShiDa){//辽宁师范：修改工作单位字段名称。
      let arr = list1.list
      for(let i in arr){
        if(arr[i].enLabel == 'employer'){
          arr[i].cnName = '工作单位及部门'
        }
        //辽宁师范--0321：删除行政级别。   
        if(arr[i].enLabel == 'administrativeLevel'){
          
          arr.splice(Number(i),1)
        }
      }
      list = arr
    }
    else if(sc == SchoolCode.BaoTouZhiYeJiShu){
      let arr = list1.list
      for(let i in arr){
        if(arr[i].enLabel == 'collegeName'){
          arr[i].cnName = '系部名称'
        }
      }
      list = arr
    }
    else if(sc == SchoolCode.ShenYangShiFan){//沈阳师范：保留工作单位字段名称。
      let arr = list1.list
      for(let i in arr){
        if(arr[i].enLabel == 'employer'){
          arr[i].cnName = '工作单位'
        }    
      }
      list = arr
    }
    else if(schoolShowConfig() == '1'){//sc == SchoolCode.LiaoShiFuShuZhongXue  || sc == SchoolCode.PeiYingZhongXue
      let arr = list1.list
      for(let i in arr){
        if(arr[i].enLabel == 'education'){
          arr[i].cnName = '学段'
        }    
        if(sc == SchoolCode.XiangXianZhongXue && arr[i].enLabel == 'classesName'){
          arr[i].cnName = '毕业班级'
        }
      }
      list = arr
    }    
    else if(sc == SchoolCode.ChengDeYiXueYuan){
      let arr = list1.list
      for(let i in arr){
        if(arr[i].enLabel == 'schoolDuties'){
          arr[i].cnName = '在校职务'
        }    
      }
      list = arr

    }
    else{
      list = list1.list
    }
    return {
      list
    };
  },
};
