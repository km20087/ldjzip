import { last } from 'lodash-es';

const enum FILE_TYPE {
  _IS_PDF = 'pdf',
  _IS_PNG = 'png',
  _IS_JPG = 'jpg',
}
export const downLoadFile = (url: string) => {
  const link = document.createElement('a');
  link.href = url;
  link.target = '_blank';
  let flag = url.match(/[\\/]/g);
  let last = flag && url.split(flag[flag?.length - 1]);
  let fileName = last ? last[last?.length - 1] : '附件.pdf';
  link.download = fileName;
  link.click();
};
