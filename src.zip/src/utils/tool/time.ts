// ## yyyy-MM-dd 
export const formatDate = (value:any)=> { // 时间戳转换日期格式方法
  if (value == null) {
    return ''
  } else {
    const date = new Date(value)
    const y = date.getFullYear()// 年
    let MM:string | number = date.getMonth() + 1 // 月
    MM = MM < 10 ? ('0' + MM) : MM
    let d:string | number = date.getDate() // 日
    d = d < 10 ? ('0' + d) : d
    return y + '-' + MM + '-' + d
  }
}

// ## yyyy-MM-dd HH：mm：ss
export const formatDateTime = (value:any)=> { // 时间戳转换日期格式方法
  if (value == null) {
    return ''
  } else {
    const date = new Date(value)
    const y = date.getFullYear() // 年
    let MM:string | number = date.getMonth() + 1 // 月
    MM = MM < 10 ? ('0' + MM) : MM
    let d:string | number = date.getDate() // 日
    d = d < 10 ? ('0' + d) : d
    let h:string | number = date.getHours() // 时
    h = h < 10 ? ('0' + h) : h
    let m:string | number = date.getMinutes()// 分
    m = m < 10 ? ('0' + m) : m
    let s:string | number = date.getSeconds()// 秒
    s = s < 10 ? ('0' + s) : s
    return y + '-' + MM + '-' + d + ' ' + h + ':' + m + ':' + s
    }
  }