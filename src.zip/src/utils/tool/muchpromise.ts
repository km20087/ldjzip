import { reactive, ref } from 'vue';

const activeCount = ref(0)
const maxCount = ref(0)
const promiseArr = ref<any>([])
const task = ref<any>()

function nextStep(){
    if(promiseArr.value.length === 0 || activeCount.value >= maxCount.value){
        return
    }
    const taskFlag = promiseArr.value.shift()
    if(taskFlag){
        activeCount.value++
    }
    taskFlag().finally(()=>{
        activeCount.value--
        nextStep()
    })
}


/***
 * max:同一时间运行的异步最大数
 * fn:异步
 * 示例：for(let i = 0;i < 10;i++){
 *   muchpromise(10,promiseFn)
 * }
 *promiseFn为实际的异步
*/
export const muchpromise = (max:number,fn:Function)=>{
    maxCount.value = max
    new Promise(async (resolve,reject)=>{
        task.value = async ()=>{
            try{
                resolve(await fn())
            }catch(err){
                reject(err)
                console.log(err)
            }
            
        }
        promiseArr.value.push(task.value)
        nextStep()
    })
}

