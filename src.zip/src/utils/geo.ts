export const geo = {
  getLocation(): Promise<Partial<GeolocationCoordinates>> {
    return new Promise((resolve, reject) => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            resolve({ latitude, longitude });
          },
          (err) => {
            console.log(`getPosError:${err.code},${navigator.geolocation},${err.message}`);
          }
        );
      } else {
        console.log('This browser does not support getting geolocation');
      }
    });
  },
  openMap({ latitude, longitude }: Record<string, string | number>) {
    if (latitude && longitude) {
      const href = `https://www.google.com/maps/place/${Number.parseFloat(
        <string>latitude
      )},${Number.parseFloat(<string>longitude)}`;
      window.open(href, '_blank');
    }
  },
};


export const eduName = (val:any)=>{
  let list = [
    // { text: '小学', value: "0" },
    // { text: '初中', value: "1" },
    // { text: '高中', value: "2" },
    { text: '继续教育', value: "7" },
    { text: '中专', value: "8" },
    { text: '专科', value: "3" },
    { text: '本科', value: "4" },
    { text: '硕士研究生', value: "5" },
    { text: '博士研究生', value: "6" },
  ]
  if(Number(val)){
    for(let i in list){
      if(val == list[i].value){
        return list[i].text
      }
    }
  }else{
    return val
  }

}