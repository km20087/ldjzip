export const numTohan = (val: any) => {// num='25' 转成 二十五
    const dicHan = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九']
    const unit = ['', '十', '百']
    let num = parseInt(val)
    const getWan = (temp: any) => {
        const strArr = temp.toString().split('').reverse()
        let newNum = ''
        for (var i = 0; i < strArr.length; i++) {
            newNum = (i == 0 && strArr[i] == 0 ? '' : (i > 0 && strArr[i] == 0 && strArr[i - 1] == 0 ? '' : dicHan[strArr[i]] + (strArr[i] == 0 ? unit[0] : unit[i]))) + newNum
        }
        return newNum
    }
    const overWan = Math.floor(num / 100)
    let noWan: any = num % 100
    if (noWan.toString().length < 2) noWan = '0' + noWan
    return overWan ? getWan(overWan) + '百' + getWan(noWan) : getWan(num)
}