import { SchoolCode, AllowVisitorToUseSchoolList } from "@/constants";
import { useSettingStore } from '@/store';
import { getSchoolCode, getUserStatus } from "../util";
// 汕头大学
export const isShanDa = (): boolean => {
    return getSchoolCode() == SchoolCode.ShanDa
}

// 常熟理工
export const isChangshu = (): boolean => {
    return getSchoolCode() == SchoolCode.ChangShu
}

// 辽宁广东XX学校
export const isLiaoShiDa = (): boolean => {
    return getSchoolCode() == SchoolCode.LiaoShiDa
}

// 广东XX学校
export const isGuangWenYi = (): boolean => {
    return getSchoolCode() == SchoolCode.GuangWenYi
}

// 成都医学院
export const isChengDuYiXueYuan = (): boolean => {
    return getSchoolCode() == SchoolCode.ChengDuYiXueYuan
}

// 河北广东XX学校
export const HeBeiShiFan = (): boolean => {
    return getSchoolCode() == SchoolCode.HeBeiShiFan
}

// 沈阳广东XX学校
export const isShenYangShiFan = (): boolean => {
    return getSchoolCode() == SchoolCode.ShenYangShiFan
}

export const isWuLuMuQiZhiYeDaXue = (): boolean => {
    return getSchoolCode() == SchoolCode.WuLuMuQiZhiYeDaXue
}

export const XiangXianZhongXue = (): boolean => {
    return getSchoolCode() == SchoolCode.XiangXianZhongXue
}

export const isBaoTouZhiYeJiShu = (): boolean => {
    return getSchoolCode() == SchoolCode.BaoTouZhiYeJiShu
}
export const isBeiHuaHangTianGongYe = (): boolean => {
    return getSchoolCode() == SchoolCode.BeiHuaHangTianGongYe
}
export const isChengDeYiXueYuan = (): boolean => {
    return getSchoolCode() == SchoolCode.ChengDeYiXueYuan
}

export const isShenYangYaoKeDaXue = (): boolean => {
    return getSchoolCode() == SchoolCode.ShenYangYaoKeDaXue
}

export const speShowMajor = ():boolean =>{
    return (getSchoolCode() == SchoolCode.BeiHuaHangTianGongYe) || (getSchoolCode() == SchoolCode.HeBeiShiFan)
}

/**是否是允许不登录游客可以粗略使用校友平台的学校 */
export const isAllowVisitorToUseSchool = () => {
    //00正常，01封禁，02删除，03待审核，04待完善资料，05审核失败，06-校友修改资料待审核，07-封禁的游客;
    let schoolCode = getSchoolCode()
    const settingStore = useSettingStore();
    let userStatus = getUserStatus();
    let isAuthorized = userStatus == '00' || userStatus == '06' || settingStore.isManagerMode
    return !isAuthorized && !!schoolCode && AllowVisitorToUseSchoolList.includes(schoolCode)
}