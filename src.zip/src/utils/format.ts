/**
 * 将一个数组转换成对象
 * @param arr 需要转换的数组
 * @param labelKey 将来要以数组中哪个key, 作为对象的key
 * @param valueKey 将来要以数组中哪个key，作为对象的value
 */
export function formatArray2Object(arr: any[], labelKey = 'value', valueKey = 'label') {
    return arr.reduce((obj: any, item) => ((obj[item[labelKey]] = item[valueKey]), obj), {})
  }
  