import { getSecret } from '@/api/servive';
import Api from '@/api/home';
import { useSettingStore } from '@/store';
export const toPhoneCall = (mobile: number | string) => {
  const url = `tel:${mobile}`;
  window.location.href = url;
};

/**
 * 动态设置css全局变量实现旋转
 * transform: rotate(var(--image-rotate))
 * @param deg 旋转角度
 * @param prop css变量, 默认'--image-rotate'
 */
export const setRotate = (deg: string, prop = '--image-rotate') => {
  let rotate = document.documentElement.style.getPropertyValue(prop) || '0deg';
  if (typeof deg === 'string') {
    rotate = deg;
  } else {
    rotate = parseInt(rotate) + 90 + 'deg';
  }
  document.documentElement.style.setProperty(prop, rotate);
};
export const TokenKey = 'AppToken';
export const UserStatusKey = 'userStatus';
export const UserIdKey = 'userId'
export const SchoolIdKey = 'schoolId'
export const UserInfoKey = 'userInfo'
export const MenuKey = 'menus'
export const ButtonKey = 'buttons'
const isDemo = import.meta.env.VITE_IS_DEMO  == '1'
/**从location.search上获取以key为键的参数值 */
export function getSearchInfoFromLink (key: string) {
  if (!key) return ''
	let searchParams = new URLSearchParams(location.search)
	return searchParams.get(key) || ''
}
export const getPrefix = () => getSearchInfoFromLink('schoolCode') + '_'

export const setLocalStorageItem = (key: string, value: string) => {
	localStorage.setItem(getPrefix() + key, value)
}

export const getLocalStorageItem = (key: string) => {
	return localStorage.getItem(getPrefix() + key)
}

export const removeLocalStorageItem = (key: string) => {
	localStorage.removeItem(getPrefix() + key)
}

export const setSessionStorageItem = (key: string, value: string) => {
	sessionStorage.setItem(getPrefix() + key, value)
}

export const getSessionStorageItem = (key: string) => {
	return sessionStorage.getItem(getPrefix() + key)
}

export const removeSessionStorageItem = (key: string) => {
	sessionStorage.removeItem(getPrefix() + key)
}

export const getSchoolCode = () => {
  // return getSessionStorageItem('schoolCode')
  return '4144013707'
}
export const setSchoolCode = (schoolCode: string) => {
  setSessionStorageItem('schoolCode', '4144013707')
}
export const getToken = () => {
  return getLocalStorageItem(TokenKey);
};

export const setToken = (token: any) => {
  return setLocalStorageItem(TokenKey, token);
};
export const getUserStatus = () => {
  // return getSessionStorageItem(UserStatusKey);
  return '00'
};
export const setUserStatus = (userStatus: string) => {
  return setSessionStorageItem(UserStatusKey, userStatus);
};
export const getUserId = () => {
  return getSessionStorageItem(UserIdKey);
};

export const setUserId = (userId: string) => {
  return setSessionStorageItem(UserIdKey, userId);
};

export const getSchoolId = () => {
  return getSessionStorageItem(SchoolIdKey);
};

export const setSchoolId = (id: string) => {
  return setSessionStorageItem(SchoolIdKey, id);
};

export const getUserInfo = () => {
  return getSessionStorageItem(UserInfoKey);
}

export const setUserInfo = (userInfo: any) => {
  return setSessionStorageItem(UserInfoKey, userInfo);
}
export const getMenus = () => {
  return getSessionStorageItem(MenuKey);
}

export const setMenus = (menus: any) => {
  return setSessionStorageItem(MenuKey, menus);
}
export const getButtons = () => {
  return getSessionStorageItem(ButtonKey);
}

export const getPermission=(perms:string) =>{
  let arr = JSON.parse(getSessionStorageItem(ButtonKey) as string) as any;
  return arr.map((item:any)=>item.perms).includes(perms)
}

export const setButtons = (buttons: any) => {
  let buttonObj:any = {}
  let buArr = JSON.parse(buttons)
  for(let i in buArr){
    buttonObj[buArr[i].perms] = '1'
  }  
  setSessionStorageItem(ButtonKey+"Obj",JSON.stringify(buttonObj))
  return setSessionStorageItem(ButtonKey, buttons);
}

/**清理个人缓存信息 */
export function clearUserStorage () {
  removeLocalStorageItem(TokenKey)
  removeLocalStorageItem('Cache__appAutMenu')
  removeLocalStorageItem('Cache__BaseInfo')
  removeLocalStorageItem('Cache__identifyMode_config')
  removeLocalStorageItem('Cache__getPendingAuditStatus')

  sessionStorage.removeItem('cacheFormData')
  sessionStorage.removeItem('regQueryData')
  removeSessionStorageItem(UserStatusKey)
  // removeSessionStorageItem(SchoolIdKey)
  removeSessionStorageItem(UserIdKey)
  removeSessionStorageItem(UserInfoKey)
  removeSessionStorageItem(MenuKey)
  removeSessionStorageItem(ButtonKey)
}

export const getSecretFun = () => {
  return new Promise(async (resolve, reject) => {
    let res = await getSecret({});
    if (res.code == 200) resolve(res.data);
  });
};
export const getPictures = (imageType: string): Promise<ImageList> => {
  const settingStore = useSettingStore();
  return new Promise(async (resolve, reject) => {
    let cacheResult = settingStore.imageInfo[imageType];
    if (cacheResult && cacheResult.images.length) {
      resolve(cacheResult);
    }
    const result = await Api.homeSwipePic({ imageType });
    if (result.code == 200) {
      resolve(result.data);
      settingStore.imageInfo[imageType] = result.data;
    }
  });
};

//  /app/images/list/school
export const getPicturesSchool = (type?: String, schoolId?: String) => {
  return new Promise(async (resolve, reject) => {
    const result = await Api.homeSwipePicSchool({ imageType: type, schoolId });
    if (result.code == 200) {
      resolve(result.data);
    }
  });
};

export const getType = (obj: any) => {
  //tostring会返回对应不同的标签的构造函数
  var toString = Object.prototype.toString;
  var map = <any>{
    '[object Boolean]': 'boolean',
    '[object Number]': 'number',
    '[object String]': 'string',
    '[object Function]': 'function',
    '[object Array]': 'array',
    '[object Date]': 'date',
    '[object RegExp]': 'regExp',
    '[object Undefined]': 'undefined',
    '[object Null]': 'null',
    '[object Object]': 'object',
  };

  if (obj instanceof Element) {
    return 'element';
  }
  return map[toString.call(obj)];
};

/**
 * 对象深拷贝
 * @param {*} data 被拷贝对象
 */
export const deepClone = (data: any) => {
  var type = getType(data);
  var obj;
  if (type === 'array') {
    obj = [] as any;
  } else if (type === 'object') {
    obj = <any>{};
  } else {
    //不再具有下一层次
    return data;
  }
  if (type === 'array') {
    for (var i = 0, len = data.length; i < len; i++) {
      obj.push(deepClone(data[i]));
    }
  } else if (type === 'object') {
    for (var key in data) {
      obj[key] = deepClone(data[key]);
    }
  }
  return obj;
};

export function getImg(route: string) {
  return new URL(`/src/assets/${route}`, import.meta.url).href;
}



/**获取图片的绝对路径 */
export function getRealFilePath(url: any) {
  if (isDemo) {
    return location.origin + location.pathname.replace(/index\.html/, '') + url
  } else { 
    if (!url || url.startsWith('http')) return url
    let prefix = /\?token/.test(url) ? import.meta.env.VITE_APP_API_DFS_URL : import.meta.env.VITE_APP_PIC_BASE_URL
    if (!prefix.startsWith('http')) {
      prefix = location.origin + prefix
    }
    return prefix + url
  }

}

//判断是否为微信小程序
export const ifMinProgram = () => {
  return window.navigator.userAgent.includes('miniProgram')
}

export const isHasMenu = (val:string)=>{
  let menu = JSON.parse(getMenus() as string);
  let arrMenu:string[] = []
  for(let i in menu){
    arrMenu.push(menu[i].url)
  }
  return arrMenu.includes(val)
}

export const isHasButton = (val:string)=>{
  let buttons = JSON.parse(getSessionStorageItem(ButtonKey+"Obj") as string);

  console.log("isHasButton"+"-"+val,!!buttons[val])
  return !!buttons[val]
}