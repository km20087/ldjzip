import { useSettingStore } from '@/store';
import { getSchoolCode } from '@/utils'
const settingStore = useSettingStore();
const schoolCode = getSchoolCode() as string
let schoolLevel = settingStore.schoolInfoObj[schoolCode]?.schoolLevel
export function schoolShowConfig(){
    console.log('````schoolShowConfig`````', schoolLevel)
    return '2'
    if(!Number(schoolLevel) && Number(schoolLevel) !== 0){
        let zhongxue = ['初中','高中']
        let daxue = ['专科','大学','本科']
        if(zhongxue.includes(schoolLevel)){
            return '1'
        }else if(daxue.includes(schoolLevel)){
            return '2'
        }
    }else{
        let zhongxue = ['3','4','5','6','7','8','9']//高中，初中，完全中学，中职中专，成人初高中，小学，幼儿园
        let daxue = ['1','2','0']//高职高专，成人学校，本科
        if(zhongxue.includes(schoolLevel)){
            return '1'
        }else if(daxue.includes(schoolLevel)){
            return '2'
        }        
    }

}

export function zhongxueConfig(){
    let schoolConfig:any = {
        // "4121000165":{
        //     education:"学段",
        //     schoolEndYear:"届别",
        //     class:"班级"
        // },
        // "4401130303":{
        //     education:"学段",
        //     schoolEndYear:"届别",
        //     class:"班级"
        // },
        // "4401130302":{
        //     education:"学段",
        //     schoolEndYear:"届别",
        //     class:"班级"            
        // }
        education:"学段",
        schoolEndYear:"届别",
        class:"班级" 
    }
    let defaultConfig:any = {
        education:"学历",
    }
    // console.log(schoolConfig[schoolCode] || defaultConfig)
    if(schoolShowConfig()== '1'){
        return schoolConfig
    }else{
        defaultConfig
    }
    // return schoolConfig[schoolCode] || defaultConfig
}
